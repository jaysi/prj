﻿#include "double.h"

#define FLAG_NEGATIVE_NEXT	(0x0001<<0)

struct iivcombi_s{
	enum tok_t pre;
	enum tok_t cur;
	enum tok_t com;
} iivcombi[] = {
	{TOK_PLUS, TOK_ASSIGN, TOK_PLUS_EQ},
	{TOK_MINUS, TOK_ASSIGN, TOK_MINUS_EQ},
	{TOK_AND, TOK_AND, TOK_AND_AND},
	{TOK_OR, TOK_OR, TOK_OR_OR},
	{TOK_ASSIGN, TOK_ASSIGN, TOK_EQ},
	{TOK_LT, TOK_ASSIGN, TOK_LE},
	{TOK_GT, TOK_ASSIGN, TOK_GE},
	{TOK_NOT, TOK_ASSIGN, TOK_NE},
	{TOK_INVAL, TOK_INVAL, TOK_INVAL}
};

enum tok_t find_iicombi(struct session* sess){	

	struct iivcombi_s* s;
	for(s = iivcombi; s->pre != TOK_INVAL; s++){
		
		printd_comb1("prev: %i, curr: %i, cprev: %i, ccurr: %i\n", sess->cursess->pre->exp->prevtok->id, sess->cursess->pre->exp->curtok->id, s->pre, s->cur);
		
		if( s->pre == sess->cursess->pre->exp->prevtok->id &&
			s->cur == sess->cursess->pre->exp->curtok->id)
				return s->com;
	}
	
	return TOK_INVAL;
}

int combine(struct session* sess){
	
	enum tok_t comb;
	struct tok_s* tk;
	unsigned short flags = 0;		
	
	assert(sess->cursess->pre->exp->infixfirst);
	
	sess->cursess->pre->exp->prevtok = sess->cursess->pre->exp->infixfirst;
	for(sess->cursess->pre->exp->curtok = sess->cursess->pre->exp->infixfirst->next;
		sess->cursess->pre->exp->curtok;
		sess->cursess->pre->exp->curtok = sess->cursess->pre->exp->curtok->infixnext){
			
		printd_comb1("current tok: %s\n", sess->cursess->pre->exp->curtok->str);
		printd_comb1("prev tok: %s\n", sess->cursess->pre->exp->prevtok->str);
		
		if(flags & FLAG_NEGATIVE_NEXT){
			sess->cursess->pre->exp->curtok->flags |= TOKF_NEG;
			flags &= ~FLAG_NEGATIVE_NEXT;
		}
		
		comb = find_iicombi(sess);
		
		if(comb != TOK_INVAL){
			
			printd_comb1("found combination.\n");
			
			tk = tokidptr(sess, comb);
			assert(tk);
			
			sess->cursess->pre->exp->prevtok->id = tk->id;
			sess->cursess->pre->exp->prevtok->type = tk->type;
			sess->cursess->pre->exp->prevtok->pred = tk->pred;
			
			sess->cursess->pre->exp->prevtok->next = sess->cursess->pre->exp->curtok->next;
			sess->cursess->pre->exp->prevtok->infixnext = sess->cursess->pre->exp->curtok->infixnext;
			
			tk = sess->cursess->pre->exp->curtok;
			
			sess->cursess->pre->exp->curtok = sess->cursess->pre->exp->curtok->next;
			
		    //check infix syntax
			if(!syntax(sess)){
		        printe(MSG_SYNTAX2, sess->cursess->pre->exp->prevtok?sess->cursess->pre->exp->prevtok->str:"", sess->cursess->pre->exp->delim);
		        return false_;
		    }
		    
		    sess->cursess->pre->exp->curtok = tk;
			
		} else {
			
		    //check infix syntax
			if(!syntax(sess)){
		        printe(MSG_SYNTAX2, sess->cursess->pre->exp->prevtok?sess->cursess->pre->exp->prevtok->str:"", sess->cursess->pre->exp->delim);
		        return false_;
		    }			
			
			sess->cursess->pre->exp->prevtok = sess->cursess->pre->exp->curtok;			
		}

		switch( sess->cursess->pre->exp->prevtok->type ){
			
			case TOKT_MATH_BASIC:
				
				if(flags & FLAG_NEGATIVE_NEXT){
					printe(MSG_FORMAT, sess->cursess->pre->exp->prevtok->str, sess->cursess->pre->exp->curtok->str);						
					return false_;
				} else {
					flags |= FLAG_NEGATIVE_NEXT;
				}									
				
				break;
				
			default:
				break;					
			
		}												
				
	}
	
	return true_;
	
}
