#ifndef TEST_BITSTRING_H
#define TEST_BITSTRING_H

int test_bitstring();

#endif
