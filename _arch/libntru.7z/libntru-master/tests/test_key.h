#ifndef TEST_KEY_H
#define TEST_KEY_H

int test_key();

#endif
