#ifndef TEST_NTRU_H
#define TEST_NTRU_H

int test_ntru();

#endif
