#ifndef TEST_HASH_H
#define TEST_HASH_H

int test_hash();

#endif
