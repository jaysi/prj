﻿#include "mainwindow.h"
#include "createwindow.h"
#include "uninstallwindow.h"
#include <QApplication>

#include <QStyleFactory>

int main(int argc, char *argv[])
{
    QApplication::setStyle(QStyleFactory::create("fusion"));

    QApplication a(argc, argv);
    MainWindow w;
    CreateWindow c;
    UninstallWindow u;

    if((argv[1] && !strcmp(argv[1], "build")) || !strcmp(argv[0], "makins13.exe")){
        c.show();
    } else if((argv[1] && !strcmp(argv[1], "megahit")) || !strcmp(argv[0], "unins13.exe")){
        u.show();
    } else {
        w.show();
    }

    return a.exec();
}
