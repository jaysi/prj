#include "uninstallwindow.h"
#include "ui_uninstallwindow.h"

UninstallWindow::UninstallWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::UninstallWindow)
{
    ui->setupUi(this);
}

UninstallWindow::~UninstallWindow()
{
    delete ui;
}
