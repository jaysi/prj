﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_toolBrowse_clicked()
{
    QFileDialog fileDlg;
    QStringList list;
    fileDlg.setFilter(QDir::Dirs);

    if(fileDlg.exec() == QDialog::Rejected) return;

    list = fileDlg.selectedFiles();

    ui->linePath->setText(list.at(0));

}

