﻿#ifndef CREATEWINDOW_H
#define CREATEWINDOW_H

#include <QMainWindow>

namespace Ui {
class CreateWindow;
}

class CreateWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit CreateWindow(QWidget *parent = 0);
    ~CreateWindow();

private slots:
    void on_pushPreview_clicked();

    void on_toolAddFile_clicked();

    void on_toolBrowseLogo_clicked();

    void on_toolRemoveFile_clicked();

    void on_toolPostInstallExec_clicked();

    void on_toolPreUninstallExec_clicked();

private:
    Ui::CreateWindow *ui;
};

#endif // CREATEWINDOW_H
