﻿#include "createwindow.h"
#include "ui_createwindow.h"

#include <QFileDialog>
#include <QLabel>
#include <QComboBox>

CreateWindow::CreateWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CreateWindow)
{
    QStringList list;

    ui->setupUi(this);

    list << "source";
    list << "target";
    ui->tableFiles->setColumnCount(2);
    //ui->tableFiles->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableFiles->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableFiles->setHorizontalHeaderLabels(list);

}

CreateWindow::~CreateWindow()
{
    delete ui;
}

void CreateWindow::on_pushPreview_clicked()
{
    ui->textInfoText->setHtml(ui->plainInfoText->toPlainText());
}

void CreateWindow::on_toolAddFile_clicked()
{
    QStringList list;
    QFileDialog fileDlg;
    QLabel* label;
    QComboBox* combo;
    int i;
//    fileDlg.setDefaultSuffix(tr("db"));

    //fileDlg.setNameFilter(tr("BNF DataBase (*."DB_SUFFIX")"));

    fileDlg.setFilter(QDir::Files);

    if(fileDlg.exec() == QDialog::Rejected) return;

    list = fileDlg.selectedFiles();

    for(i = 0; i < list.count(); i++){
        label = new QLabel;
        label->setText(list.at(i));
        ui->tableFiles->insertRow(ui->tableFiles->rowCount());
        ui->tableFiles->setCellWidget(ui->tableFiles->rowCount()-1, 0, label);
        combo = new QComboBox;
        combo->setEditable(true);
        combo->addItem(tr("$insdir"));
        combo->addItem(tr("$home"));
#ifdef __WIN32
        combo->addItem(tr("$windir"));
        combo->addItem(tr("$prog"));
#endif
        ui->tableFiles->setCellWidget(ui->tableFiles->rowCount()-1, 1, combo);

    }
    ui->tableFiles->resizeColumnsToContents();

}

void CreateWindow::on_toolBrowseLogo_clicked()
{
    QStringList list;
    QFileDialog fileDlg;

    fileDlg.setNameFilter(tr("Image Files (*.png *.jpg *.bmp)"));

    fileDlg.setFilter(QDir::Files);

    if(fileDlg.exec() == QDialog::Rejected) return;

    list = fileDlg.selectedFiles();

    ui->lineLogoPath->setText(list.at(0));

}

void CreateWindow::on_toolRemoveFile_clicked()
{
    ui->tableFiles->removeRow(ui->tableFiles->currentRow());
}

void CreateWindow::on_toolPostInstallExec_clicked()
{
    QLabel* label = (QLabel*)ui->tableFiles->cellWidget(ui->tableFiles->currentRow(), 0);
    ui->linePostInstallExec->setText(label?label->text():tr(""));
}

void CreateWindow::on_toolPreUninstallExec_clicked()
{
    QLabel* label = (QLabel*)ui->tableFiles->cellWidget(ui->tableFiles->currentRow(), 0);
    ui->linePreUninstallExec->setText(label?label->text():tr(""));

}
