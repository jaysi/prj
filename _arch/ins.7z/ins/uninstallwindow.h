#ifndef UNINSTALLWINDOW_H
#define UNINSTALLWINDOW_H

#include <QMainWindow>

namespace Ui {
class UninstallWindow;
}

class UninstallWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit UninstallWindow(QWidget *parent = 0);
    ~UninstallWindow();

private:
    Ui::UninstallWindow *ui;
};

#endif // UNINSTALLWINDOW_H
