﻿#include <stdio.h>

#include "../libnm/include/netmetre.h"

int main(void)
{
    printf("Hello World!\n");
    return 0;
}

