#include <string.h>

#define HELPINFO_ICON   "- [ "

char* h311(char *dst, char *src, char key, int len){

	while(len){
		*dst = (*src)^key;
		
		dst++;
		src++;		
		key++;
		len--;
	}
	
	return dst;
	
}

int main(){
	
	char buf[1024];
	int len, i;
	char key[2];
	char ch;
	
	again:
	
	printf("string: ");
	gets(buf);
	printf("base: ");
	gets(key);
		
	len = strlen(buf);
	
	h311(buf, buf, key[0], len);
	
	printf("hidden as: %s\n", buf);
	printf("len: %i\nhex: ", len);
	
	for(i = 0; i < len; i++) printf("0x%x,", buf[i]);
	
	h311(buf, buf, key[0], len);
	buf[len] = '\0';
		
	printf("\nunhided as: %s\npress C to continue or any other key to end.\n", buf);
		
	ch = getch();
	if(ch == 'c') goto again;
	
	return 0;
}
