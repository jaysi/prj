#inculde "include/csblock.h"

error13_t _cs_fill_csblock_info(struct compass* cs){
	
}
