#ifndef CSMAP_H
#define CSMAP_H

#include "cstypes.h"
#include "csbitmap.h"
#include "../../lib13/include/hash13.h"

#define CSMAPBLOCK_ENTRY_PACKSTR

struct csmapblock_hdr{
    h13_crc32_t crc32;
    csbitmap_t bitmap;//shows full, empty entries
    csobjid_t start, end;
};

struct csmapblock_entry{

	csbtype_t btype;
    csobjflag_t objflags;
	csobjid_t objid;
	csbent_t emptybent;

}__attribute__((packed));

#else

#endif
