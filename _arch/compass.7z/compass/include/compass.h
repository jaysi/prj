#ifndef COMPASS_H
#define COMPASS_H

#include "csi.h"

struct compass{

};

#ifdef __cplusplus
	extern "C" {
#endif

error13_t cs_init(struct compass* cs);

#ifdef __cplusplus
	}
#endif

#endif // COMPASS_H


