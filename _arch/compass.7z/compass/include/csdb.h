#ifndef CSDB_H
#define CSDB_H

#include "../../lib13/include/lib13.h"

struct cs_db{

    struct io13 main;

};

struct cs_alias{

    char* name;
    struct cs_db* db;

};

#endif // CSDB_H
