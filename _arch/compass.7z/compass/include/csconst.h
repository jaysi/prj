#ifndef CSCONST_H
#define CSCONST_H

#include "cstypes.h"

#define CSOBJID_EMPTY	(0ULL)
#define CSOBJID_INVAL	((csobjid_t)-1)

#else

#endif
