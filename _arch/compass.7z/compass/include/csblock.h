#ifndef CSBLOCK_H
#define CSBLOCK_H

#include "include/cstypes.h"
#include "include/csbitmap.h"
#include "include/cstypes.h"
#include "../../lib13/include/lib13.h"

enum csblock_type{
	CSBTYPE_EMPTY,
	CSBTYPE_MAP,
	CSBTYPE_OBJDEFMAIN,
	CSBTYPE_OBJDEF,
	CSBTYPE_OBJBODY,
	CSBTYPE_INDEX,
	CSBTYPE_NULL
};

#define CSBLOCKTYPE(btype_enum) ((csbtype_t)btype_enum)

//this is fixed during the use of db, some of items are calculated at run-time
struct csblock_parameters{
	size_t hsize;//header size
	char* hpackstr;//packstr
	csbentsize_t entsize;
	char* endpackstr;
	size_t fullbitmapsize;//full entry bitmap
	csbent_t nent;
} csblock_param[] = {
	
};

struct csblock_memhdr{
	
};

struct csblock_diskhdr{
	csbtype_t btype;
	h13_crc32_t crc32;
	csbitmap_t bitmap;//shows full, empty entries		
}__attribute__((packed));

struct csblock{
	
	struct csblock_memhdr memhdr;
	struct csblock_diskhdr diskhdr;
	struct csblock_parameters* params;//pointer to block params entry
	
	void* entry;//entry array
	
};

#ifdef __cplusplus
	extern "C" {
#endif

error13_t _cs_fill_csblock_info(struct compass* cs);

#ifdef __cplusplus
	}
#endif

#endif // CSBLOCK_H
