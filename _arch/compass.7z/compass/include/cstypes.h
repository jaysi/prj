#ifndef CSTYPES_H
#define CSTYPES_H

#include "../../lib13/include/type13.h"
#include "../../lib13/include/obj13.h"

typedef uint32_t csbid_t;//block id
typedef uint8_t csbtype_t;//block type
typedef uint16_t csbsize_t;//block size
typedef uint16_t csbent_t;//block entry id
typedef uint16_t csbentsize_t;//block entry size
typedef uint32_t csbitmapsize_t;//bitmap length
typedef objid13_t csobjid_t;//object id
typedef uint8_t csopcode_t;//operation code
typedef int8_t csdata_t;
typedef uint32_t csobjver_t;//object version
typedef uint8_t csobjflag_t;//object flags

#endif //CSTYPES_H
