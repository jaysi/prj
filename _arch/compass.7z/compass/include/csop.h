#ifndef CSOP_H
#define CSOP_H

#include "cstypes.h"

//operations are stored directly inside the journal or WAL file.

//op codes
enum csopcode {
	CSOP_NOP,
	CSOP_NEW_OBJ,
	CSOP_RM_OBJ,
	CSOP_CHG_OBJ,
	CSOP_NEW_LINK,
	CSOP_RM_LINK,
	CSOP_CHG_LINK,
	CSOP_UNDO,
	CSOP_REDO,
	CSOP_INVAL
};

#define CSOPCODE(code) ((csopcode_t)code)

struct csop{
	enum csopcode code;
	size_t prev_size, cur_size;
	void* prev_buf;
	void* cur_buf;
};

#else

#endif
