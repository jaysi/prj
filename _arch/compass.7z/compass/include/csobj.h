#ifndef CSOBJ_H
#define CSOBJ_H

#include "../../lib13/include/obj13.h"
#include "cstypes.h"

//object flags
enum csobject_flag{
    CSOBJFLAG_VIRTUAL = 1 //virtual object, like 'mporg price list or invoice'
};

#define CSOBJFLAG(obj_flag_enum)    (0x01<<(obj_flag_enum))

//struct csobj_def_main{
//	csobjid_t objid;
//    csobjflag_t flags;
//	csbsize_t namelen;
//	csbent_t nlinks;
//	csbid_t next;
//	csbid_t body;//poiner to body block
//};

//struct csobj_def{
//	csobjid_t objid;//for recovery
//	csbent_t nlinks;
//	csbid_t next;
//};

//struct csobj_body{
//	csobjid_t objid;//for recovery
//	csbid_t seg;//segment, mostly for recovery
//	csbid_t next;//pointer to next block
//	csbsize_t segsize;
//	csdata_t* data;
//};

#else

#endif 
