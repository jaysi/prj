#ifndef CSBITMAP_H
#define CSBITMAP_H

#include "../../lib13/include/type13.h"
#define BITMAPELEMENTSIZE sizeof(uint8_t)
#include "../../lib13/include/bit13.h"

/*
	the right way to search for an empty bit
	for(i = 0; i < bitmap_size_in_bytes; i++){
		if(bitmap[i] != 255){
			for(j = 0; j < 8; j++){
				if(!ISBIT(bitmap[i], j)){
					return i*7 + j;
				}
			}
		}
	}
*/

typedef uint8_t csbitmap_t;

#else

#endif

