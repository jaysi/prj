#ifndef CSDATA_H
#define CSDATA_H

enum csdata_type{
	CSDATATYPE_EMPTY,
	CSDATATYPE_NULL,
	CSDATATYPE_INT,
	CSDATATYPE_DOUBLE,
	CSDATATYPE_RAW
};

enum csdata_sign{
	CSDATASIGN_UNSIGNED,
	CSDATASIGN_SIGNED
};

enum csdata_width{
	CSDATAWIDTH_8 = 3,//3
	CSDATAWIDTH_16,//4
	CSDATAWIDTH_32,//5
	CSDATAWIDTH_64,//6
	CSDATAWIDTH_128//7
};

//pack
//bit4~7-type:4, bit1~3-width:3 (1~7), bit0-sign:1 (0 or 1)
#define CSDATATYPEPACK(sign, bytewidth, type)	((sign)|((bytewidth)<<1)|((type)<<4))

//extract
#define CSDATASIGN(datatypepack)	((datatypepack)&CSDATA_SIGN)
#define CSDATAWIDTH(datatypepack)	((datatypepack)&(CSDATAWIDTH_128<<1))
#define CSDATATYPE(datatypepack)	((datatypepack)&(15<<4))

//pre
#define CSDATA_CHAR		CSPACKDATATYPE(1, CSDATAWIDTH_8, CSDATATYPE_INT)
#define CSDATA_UCHAR	CSPACKDATATYPE(0, CSDATAWIDTH_8, CSDATATYPE_INT)

#else

#endif
