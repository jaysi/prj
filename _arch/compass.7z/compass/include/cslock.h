#ifndef CSLOCK_H
#define CSLOCK_H

#include "compass.h"
#include "../../lib13/include/lib13.h"



#ifdef __cplusplus
    extern "C" {
#endif

#ifdef __cplusplus
    }
#endif

#endif // CSLOCK_H
