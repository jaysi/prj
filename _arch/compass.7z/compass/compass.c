#include "compass.h"

error13_t cs_connect(struct compass* cs, );
