﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"
#include "mvaldialog.h"
#include "namedialog.h"

#include "db.h"

#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>

#include <QList>
#include <QMap>

void MainWindow::ClearCurCell(QTableWidget* table){

    int tab = -1;

    QList <QTableWidgetItem* > itemList = table->selectedItems();

    while(!itemList.isEmpty()){
        delete itemList.takeFirst();
    }

    if(table == ui->tableEdit) tab = TABLE_EDIT;
    else if(table == ui->tableItems) tab = TABLE_ITEMS;
    else if(table == ui->tablePays) tab = TABLE_PAYS;

    if(tab > -1) setChange(tab, 1);

}

void MainWindow::setCells(QTableWidget* table, QString str){
    int tab = -1;
    int i, row, col;
    QTableWidgetItem* item;
    int tR, bR, rC, lC, swap;

    QList<QTableWidgetSelectionRange> selList = table->selectedRanges();

    for(i = 0; i < selList.count(); i++){

        tR = selList.at(i).topRow();
        bR = selList.at(i).bottomRow();

        if(tR > bR){
            swap = bR;
            bR = tR;
            tR = swap;
        }

        rC = selList.at(i).rightColumn();
        lC = selList.at(i).leftColumn();

        if(rC > lC){
            swap = lC;
            lC = rC;
            rC = swap;
        }

        for(row = tR; row <= bR; row++){

            for(col = rC; col <= lC; col++){

                item = table->item(row, col);
                if(!item){
                    item = new QTableWidgetItem;
                    table->setItem(row, col, item);
                }
                item->setText(str);

            }

        }

    }

    if(table == ui->tableEdit) tab = TABLE_EDIT;
    else if(table == ui->tableItems) tab = TABLE_ITEMS;
    else if(table == ui->tablePays) tab = TABLE_PAYS;

    if(tab > -1) setChange(tab, 1);

}

void MainWindow::SolidCell(QTableWidget* table, int row, int col){

    Qt::ItemFlags flags;

    QTableWidgetItem* item = table->item(row, col);
    if(!item){
        item = new QTableWidgetItem;
        table->setItem(row, col, item);
    }
    item->setBackgroundColor(QColor(230, 230, 230));
    flags = item->flags();
    //flags &= ~(Qt::ItemIsEditable|Qt::ItemIsEnabled);
    flags &= !Qt::ItemIsEditable;

    item->setFlags(flags);

    item->setTextColor(QColor(0, 0, 0));

}

void MainWindow::unSolidCell(QTableWidget* table, int row, int col){

    Qt::ItemFlags flags;
    QColor c;
    QTableWidgetItem* item;

    item = new QTableWidgetItem;
    c = item->backgroundColor();
    delete item;

    item = table->item(row, col);
    if(!item) return;

    item->setBackgroundColor(c);
    flags = item->flags();
    //flags &= ~(Qt::ItemIsEditable|Qt::ItemIsEnabled);
    flags |= Qt::ItemIsEditable;

    item->setFlags(flags);

}

void MainWindow::SaveListText(QTableWidget* table, int row, int column){

    QString str;
    QComboBox* c;
    QTableWidgetItem* item;
    int tab = -1;

    if(!table->cellWidget(row, column)) return;
    if(!combolist) return;

    combolist = 0;

    c = (QComboBox*)(table->cellWidget(row, column));
    Q_ASSERT(c);
    str = c->currentText();

    if(!loading){
        if(str != c->itemText(0)){
            if(table == ui->tableEdit) tab = TABLE_EDIT;
            else if(table == ui->tableItems) tab = TABLE_ITEMS;
            else if(table == ui->tablePays) tab = TABLE_PAYS;

            if(tab > -1) setChange(tab, 1);
        }
    }

    qDebug()<<"combo value: "<<str;

    item = table->item(row, column);

    if(!item){

        item = new QTableWidgetItem;
        item->setText(str);
        loading = 1;
        table->removeCellWidget(row, column);
        table->setItem(row, column, item);
        loading = 0;

    } else {

        loading = 1;
        table->removeCellWidget(row, column);
        item->setText(str);
        loading = 0;

    }

    delete c;

}

void MainWindow::SaveEditText(QTableWidget* table, int row, int column){

    QString str;
    QLineEdit* c;
    QTableWidgetItem* item;

    if(!table->cellWidget(row, column)) return;

    c = (QLineEdit*)(table->cellWidget(row, column));
    Q_ASSERT(c);
    str = c->text();
//    if(str.isEmpty()) return;
    if(str == tr("//")) str = tr("");//deny empty date

    qDebug()<<"combo value: "<<str;

    item = table->item(row, column);

    if(!item){

        item = new QTableWidgetItem;
        item->setText(str);
        loading = 1;
        table->removeCellWidget(row, column);
        table->setItem(row, column, item);
        loading = 0;

    } else {

        loading = 1;
        table->removeCellWidget(row, column);
        item->setText(str);
        loading = 0;

    }

    delete c;

}

void MainWindow::monitorCellChange(QTableWidget* table, enum table_id tid,
                                   int row, int col,
                                   int prow, int pcol){

    if(loading) return;

    if(pcol < 0 || prow < 0) return;

    if(id_coltype(tid, pcol) == TY_DATE){
        SaveEditText(table, prow, pcol);
    }

//    if(tid == T_CUSTOMERS && !strcmp(col_name(tid, pcol), "name")){
//        SaveEditText(table, prow, pcol);
//    }

    if(col_flag(tid, pcol) & COLF_LIST){
        SaveListText(table, prow, pcol);
    }

}

void MainWindow::monitorItemCellChange(int row, int column, int prow, int pcolumn){

    monitorCellChange(ui->tableItems, T_FACTORS, row, column, prow, pcolumn);

}

void MainWindow::monitorEditCellChange(int row, int column, int prow, int pcolumn){    

    monitorCellChange(ui->tableEdit, id_table_alias(ui->comboTables->currentText().toUtf8().data()), row, column, prow, pcolumn);

}

void MainWindow::monitorPayCellChange(int row, int column, int prow, int pcolumn){

    monitorCellChange(ui->tablePays, T_PAYMENTS, row, column, prow, pcolumn);

}

void MainWindow::CreateNameList(enum table_id tid, char* colname, QStringList& list, QCompleter** com){

    struct stmt_s stmt;
    int col;

    while(!list.isEmpty()){
        list.removeFirst();
    }

    col = id_col(tid, colname);

    if(col < 0) return;

    if(!select_all(db, tid, &stmt)){
        return;
    }

    list << tr("");

    while(next(&stmt) == continue_){

        list << trUtf8(getcol_text(&stmt, col));

    }

    finalize(&stmt);

    if(*com) delete *com;
    *com = new QCompleter(list, this);

//    list.sort();
}

//void MainWindow::moveBack(){
//    qDebug()<<"THIS CALLED!";
//    QTableWidget* t = (QTableWidget*)this->focusWidget();
//    t->setCurrentCell(t->currentRow()+1, t->currentColumn()+1);
//    t->setFocus();
//}

void MainWindow::cellClicked(QTableWidget* table, enum table_id tid, int row, int column){

    QString str, strName, strVal;
    QTableWidgetItem* item;
    mvalDialog* dlg;
    nameDialog* ndlg;

    if(column < 0 || row < 0) return;

    if(id_coltype(tid, column) == TY_DATE){

        if(table->cellWidget(row, column)) return;

        QLineEdit* e = new QLineEdit;
        e->setInputMask(tr("9999/99/99"));
//        connect(e, SIGNAL(returnPressed()), this, SLOT(moveBack()));

        item = table->item(row, column);
        if(item){
            e->setText(item->text());
            delete item;
        }

        table->setCellWidget(row, column, e);

    }

    if(col_flag(tid, column) & COLF_LIST){
        combolist = 1;

        QComboBox* c = new QComboBox;
        c->setEditable(true);

        //save the old string
        item = table->item(row, column);

        if(item){

            if(!(item->flags() & Qt::ItemIsEnabled)) return;

            str = item->text();
            c->addItem(str);
        }

        if(!strcmp(col_name(tid, column), "item_id")){
            c->addItems(listItems);
            c->setCompleter(comItems);
        }

        if(!strcmp(col_name(tid, column), "customer_id")){
            c->addItems(listCustomers);
            c->setCompleter(comCustomers);
        }

        if(!strcmp(col_name(tid, column), "transtype_id")){
            c->addItems(listTransTypes);
            c->setCompleter(comTransTypes);
        }

        if(!strcmp(col_name(tid, column), "store_id")){
            c->addItems(listStores);
            c->setCompleter(comStores);
        }

        if(!strcmp(col_name(tid, column), "bank_id")){
            c->addItems(listBanks);
            c->setCompleter(comBanks);
        }

        if(!strcmp(col_name(tid, column), "paytype_id")){
            c->addItems(listPayTypes);
            c->setCompleter(comPayTypes);
        }

        if(!strcmp(col_name(tid, column), "transtat_id")){
            c->addItems(listTranStats);
            c->setCompleter(comTransStats);
        }

        if(!strcmp(col_name(tid, column), "sex_id")){
            c->addItems(listSex);
            c->setCompleter(comSex);
        }

        if(!strcmp(col_name(tid, column), "speciality_id")){
            c->addItems(listSpecs);
            c->setCompleter(comSpecs);
        }

        if(!strcmp(col_name(tid, column), "rank_id")){
            c->addItems(listRanks);
            c->setCompleter(comRanks);
        }

        if(!strcmp(col_name(tid, column), "socialstyle_id")){
            c->addItems(listSocialStyles);
            c->setCompleter(comSocialStyles);
        }

        if(!strcmp(col_name(tid, column), "customertype_id")){
            c->addItems(listCustomerTypes);
            c->setCompleter(comCustomerTypes);
        }

        if(!strcmp(col_name(tid, column), "offer_id")){
            c->addItems(listOffers);
            c->setCompleter(comOffers);
        }

        if(id_coltype(tid, column) == TY_BOOL){
            c->addItems(listBool);
            c->setEditable(false);
            if(!strcmp(col_name(tid, column), "course")){
                c->removeItem(c->findText(MSG_NEUT));
                c->addItem(MSG_NEUT2);
            }
        }

        c->setCurrentIndex(0);

        table->setCellWidget(row, column, c);
        table->cellWidget(row, column)->adjustSize();

    }

    if(!strcmp(col_name(tid, column), "addr") || !strcmp(col_name(tid, column), "contact") || !strcmp(col_name(tid, column), "rival")){

        item = table->item(row, column);

        if(!strcmp(col_name(tid, column), "addr")){

            strName = MSG_ADDRTYPE;
            strVal = MSG_ADDRVAL;

        } else if(!strcmp(col_name(tid, column), "contact")){

            strName = MSG_TELTYPE;
            strVal = MSG_TELVAL;

        } else {

            strName = MSG_NAME;
            strVal = MSG_VAL;

        }

        if( item ) {
            dlg = new mvalDialog(0, item->text(), cfg.max_contact, strName, strVal);
        } else {
            dlg = new mvalDialog(0, tr(""), cfg.max_contact, strName, strVal);
        }

        dlg->exec();

        str = dlg->getMvalStr();

        delete dlg;

        if(!item){
            if(!str.isEmpty()){
                item = new QTableWidgetItem;
                table->setItem(row, column, item);
                item->setText(str);
            }
        } else {
            item->setText(str);
        }

    }

//    if(tid == T_CUSTOMERS && !strcmp(col_name(tid, column), "name")){

//        if(table->cellWidget(row, column)) return;

//        QLineEdit* e = new QLineEdit;
//        e->setPlaceholderText(trUtf8("نام خانوادگی،نام/شرکت"));

//        item = table->item(row, column);
//        if(item){
//            e->setText(item->text());
//            delete item;
//        }

//        table->setCellWidget(row, column, e);

//    }

        if(tid == T_CUSTOMERS && (!strcmp(col_name(tid, column), "name") || !strcmp(col_name(tid, column), "salesmanager"))){

            item = table->item(row, column);

            if(item){
                ndlg = new nameDialog(0, item->text());
            } else {
                ndlg = new nameDialog(0, tr(""));
            }

            ndlg->exec();

            str = ndlg->getStr();

            delete ndlg;

            if(!item){
                if(!str.isEmpty()){
                    item = new QTableWidgetItem;
                    table->setItem(row, column, item);
                    item->setText(str);
                }
            } else {
                item->setText(str);
            }

        }

}

void MainWindow::on_tableEdit_cellClicked(int row, int column)
{
    cellClicked(ui->tableEdit, id_table_alias(ui->comboTables->currentText().toUtf8().data()), row, column);
}

void MainWindow::on_tableItems_cellClicked(int row, int column)
{
    cellClicked(ui->tableItems, T_FACTORS, row, column);
}

void MainWindow::on_tablePays_cellClicked(int row, int column)
{   
    cellClicked(ui->tablePays, T_PAYMENTS, row, column);
}

void MainWindow::setCellAutoDate(QTableWidget *table, enum table_id tid,
                                 int row, int column){

    QTableWidgetItem* item;
    int d[D13_ITEMS];

    if(!strcmp(col_name(tid, column), "date")){
        item  = table->item(row, column);
        if(!item){
            item = new QTableWidgetItem;
        }

        if(item->text().isEmpty()){
            d13_today(d);
            item->setText(trUtf8("%1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]));
            table->setItem(row, column, item);
        }

    }
}

void MainWindow::cellDClicked(QTableWidget* table, enum table_id tid,
                              int row, int column){

    if(row < 0 || column < 0) return;

    if(id_coltype(tid, column) == TY_DATE){
        setCellAutoDate(table, tid, row, column);
    }
}

void MainWindow::on_tableItems_cellDoubleClicked(int row, int column)
{
    cellDClicked(ui->tableItems, T_FACTORS, row, column);
}

void MainWindow::on_tableEdit_cellDoubleClicked(int row, int column)
{
    cellDClicked(ui->tableEdit,
                 id_table_alias(ui->comboTables->currentText().toUtf8().data()),
                 row, column);
}

void MainWindow::on_tablePays_cellDoubleClicked(int row, int column)
{
    cellDClicked(ui->tablePays, T_PAYMENTS, row, column);
}



void MainWindow::on_tableItems_cellChanged(int row, int column)
{

    QTableWidgetItem* item, *item2;
    struct stmt_s st;
    int id;
    int storemult, pricemult;
    int col;

    if(row < 0 || column < 0 || saving) return;

    item = ui->tableItems->item(row, column);
    if(!item || item->text().isEmpty()) return;

    if(!loading)
        if(!CheckCell(item, T_FACTORS, column))
            return;

    if(!strcmp(col_name(T_FACTORS, column), "item_id")){

        SolidCell(ui->tableItems, row, id_col(T_FACTORS, "item_price"));
        SolidCell(ui->tableItems, row, id_col(T_FACTORS, "totalprice"));

        if(ui->tableItems->item(row, id_col(T_FACTORS, "item_price"))->text().isEmpty()){
            if(translate_to_id(db, T_FACTORS, id_col(T_FACTORS, "item_id"), item->text().toUtf8().data(), this_id, &id)){

                ui->tableItems->item(row, id_col(T_FACTORS, "item_price"))->setText(trUtf8("%1").arg(translate_to_col_int(db, T_FACTORS, id_col(T_FACTORS, "item_price"), id, this_id, &st)));
                finalize(&st);

            }
        }
    }

    if(!strcmp(col_name(T_FACTORS, column), "transtype_id")){

        if(!translate_to_id(db, T_FACTORS, id_col(T_FACTORS, "transtype_id"), item->text().toUtf8().data(), this_id, &id)){
            QMessageBox::critical(this, MSG_VALIDITY, MSG_NOTDEF.arg(item->text()));
            item->setText("");
            return;

        }

        storemult = translate_to_col_int(db, T_FACTORS, id_col(T_FACTORS, "transtype_storemult"), id, this_id, &st);

        item = new QTableWidgetItem;        
        item->setText(tr("%1").arg(storemult));
        ui->tableItems->setItem(row, id_col(T_FACTORS, "transtype_storemult"), item);                

        finalize(&st);

        pricemult = translate_to_col_int(db, T_FACTORS, id_col(T_FACTORS, "transtype_pricemult"), id, this_id, &st);

        item = new QTableWidgetItem;
        item->setText(tr("%1").arg(pricemult));
        ui->tableItems->setItem(row, id_col(T_FACTORS, "transtype_pricemult"), item);                

        finalize(&st);

    }

    if(!strcmp(col_name(T_FACTORS, column), "item_qty")){

        qDebug()<<"item_qty changed";

        if(!loading){

            qDebug()<<"not loading";

            if(!checkItemOut(ui->tableItems, T_FACTORS, row, column)) return;

        }

    }

    if(!loading){

        setChange(TABLE_ITEMS, 1);
        RecalcFactor();

    }

    //need new row?

    if(row == ui->tableItems->rowCount() - 1){

        //if all non-ACCEPTNULL columns are full, add another row
        for(col = 0; col < table_cols(T_FACTORS); col++){
            item = ui->tableItems->item(row, col);
            if(!item || item->text().isEmpty()){
                if(!(col_flag(T_FACTORS, col) & COLF_ACCEPTNULL) && !(col_flag(T_FACTORS, col) & COLF_AUTO)){
                    goto end;
                }
            }
        }

        ui->tableItems->insertRow(ui->tableItems->rowCount());

        //insert default values
        item = new QTableWidgetItem;

        item2 = ui->tableItems->item(ui->tableItems->rowCount()-2, id_col(T_FACTORS, "date"));
        if(item2 && !item2->text().isEmpty()){

            item->setText(item2->text());
            ui->tableItems->setItem(ui->tableItems->rowCount()-1, id_col(T_FACTORS, "date"), item);

        }

        item = new QTableWidgetItem;
        item->setText(ui->tableItems->item(ui->tableItems->rowCount()-2, id_col(T_FACTORS, "customer_id"))->text());
        ui->tableItems->setItem(ui->tableItems->rowCount()-1, id_col(T_FACTORS, "customer_id"), item);

        if(!loading) RecalcFactor();

    }

    end:

    return;

}

void MainWindow::on_tableItems_cellActivated(int row, int col)
{

    if(combolist){

        SaveListText(ui->tableItems, row, col);

        if(col < ui->tableItems->columnCount() - 1) ui->tableItems->setCurrentCell(row, col+1);
        else if(row < ui->tableItems->columnCount() - 1) ui->tableItems->setCurrentCell(row+1, 0);
        else ui->tableItems->setCurrentCell(row, 0);

        ui->tableItems->setFocus();

        return;
    } else on_tableItems_cellClicked(row, col);

}


bool MainWindow::checkItemOut(QTableWidget* table, enum table_id tid, int row, int column){

    QTableWidgetItem* item, *item2;
    int id, min_qty, qty, remain_qty;
    struct stmt_s st;

    item = table->item(row, column);
    if(!item) return false;

    if(!strcmp(col_name(tid, column), "item_qty")){

        item2 = table->item(row, id_col(tid, "item_id"));
        if(!item2 || item2->text().isEmpty()){
            QMessageBox::warning(this, MSG_ORDER, MSG_ITEMFIRST);
            item->setText("");
            return false;
        }

        if(!translate_to_id(db, tid, id_col(tid, "item_id"), item2->text().toUtf8().data(), this_id, &id)){
            QMessageBox::critical(this, MSG_VALIDITY, MSG_NOTDEF.arg(item2->text()));
            item->setText("");
            return false;
        }

        remain_qty = translate_to_col_int(db, tid, id_col(tid, "item_qty"), id, this_id, &st);

        finalize(&st);

        min_qty = translate_to_col_int(db, tid, id_col(tid, "item_minqty"), id, this_id, &st);

        finalize(&st);

        qty = item->text().toInt();

        if(qty > remain_qty){
            QMessageBox::warning(this, MSG_STORE, MSG_NOTENOUGH.arg(remain_qty));
            item->setText("");
            return false;
        }

        if(remain_qty - qty <= min_qty){
            QMessageBox::information(this, MSG_STORE, MSG_LOW.arg(remain_qty-qty));
        }

        //

    } else {
        qDebug()<<"not item qty name!!!";
    }

    return true;

}

void MainWindow::on_tableEdit_cellChanged(int row, int column)
{
    QTableWidgetItem* item, *item2;
    int col;
    int id;
    int storemult;
    int r;
    struct stmt_s st;
    enum table_id tid = id_table_alias(ui->comboTables->currentText().toUtf8().data());

    if(row < 0 || column < 0 || saving){
        qDebug()<<"on_tableEdit_cellChanged(): saving";
        return;
    }

    item = ui->tableEdit->item(row, column);
    if(!item || item->text().isEmpty()){
        qDebug()<<"on_tableEdit_cellChanged(): !item";
        return;
    }

    if(!loading)
        if(!CheckCell(item, tid, column))
            return;

    switch(tid){

    case T_SENDS:

        qDebug()<<"on_tableEdit_cellChanged(): T_SENDS";

        if(!strcmp(col_name(T_SENDS, column), "transtype_id")){

            qDebug()<<"on_tableEdit_cellChanged(): transtype_id";

            if(!translate_to_id(db, T_SENDS, id_col(T_SENDS, "transtype_id"), item->text().toUtf8().data(), this_id, &id)){
                QMessageBox::critical(this, MSG_VALIDITY, MSG_NOTDEF.arg(item->text()));
                item->setText("");
                return;
            }

            storemult = translate_to_col_int(db, T_SENDS, id_col(T_SENDS, "transtype_storemult"), id, this_id, &st);

            qDebug()<<"on_tableEdit_cellChanged(): storemult: "<<storemult;

            item = new QTableWidgetItem;
            item->setText(tr("%1").arg(storemult));
            ui->tableEdit->setItem(row, id_col(T_SENDS, "transtype_storemult"), item);

            finalize(&st);
        }

        if(!strcmp(col_name(T_SENDS, column), "item_qty")){

            qDebug()<<"item_qty changed";

            if(!loading){

                qDebug()<<"not loading";

                if(!checkItemOut(ui->tableEdit, T_SENDS, row, column)) return;

            }

        }

        if(!strcmp(col_name(T_SENDS, column), "item_id")){

            SolidCell(ui->tableEdit, row, id_col(T_SENDS, "item_price"));

            if(ui->tableEdit->item(row, id_col(T_SENDS, "item_price"))->text().isEmpty()){
                if(translate_to_id(db, T_SENDS, id_col(T_SENDS, "item_id"), item->text().toUtf8().data(), this_id, &id)){

                    ui->tableEdit->item(row, id_col(T_SENDS, "item_price"))->setText(trUtf8("%1").arg(translate_to_col_int(db, T_SENDS, id_col(T_SENDS, "item_price"), id, this_id, &st)));
                    finalize(&st);

                }
            }
        }

        break;

    default:

        if((!strcmp(col_name(tid, column), "id") || !strcmp(col_name(tid, column), "name")) && row && !loading){
            for(r = row - 1; r > -1; r--){
                item2 = ui->tableEdit->item(r, column);
                if(item2){
                    if(item2->text() == item->text()){
                        QMessageBox::warning(this, MSG_VALIDITY, MSG_DUPLICATE);
                    }
                }
            }
        }

        break;

    }

    if(!loading){
        setChange(TABLE_EDIT, 1);
    }

    //need new row?

    if(row == ui->tableEdit->rowCount() - 1){

        //if all non-ACCEPTNULL columns are full, add another row
        for(col = 0; col < table_cols(tid); col++){
            item = ui->tableEdit->item(row, col);
            if(!item || item->text().isEmpty()){
                if(!(col_flag(tid, col) & COLF_ACCEPTNULL) && !(col_flag(tid, col) & COLF_AUTO)){
                    goto end;
                }
            }
        }

        ui->tableEdit->insertRow(ui->tableEdit->rowCount());

//        if(tid == T_CUSTOMERS){
//            //item = new QTableWidgetItem;
//            QLineEdit* e = new QLineEdit;
//            e->setPlaceholderText(trUtf8("نام خانوادگی، نام"));
//            ui->tableEdit->setCellWidget(ui->tableEdit->rowCount() - 1 , id_col(T_CUSTOMERS, "name"), e);
//        }

    }

    end:

    return;

}

void MainWindow::on_tableEdit_cellActivated(int row, int col)
{

    if(combolist){

        SaveListText(ui->tableEdit, row, col);

        if(col < ui->tableEdit->columnCount() - 1) ui->tableEdit->setCurrentCell(row, col + 1);
        else if(row < ui->tableEdit->columnCount() - 1) ui->tableEdit->setCurrentCell(row + 1, 0);
        else ui->tableEdit->setCurrentCell(row, 0);

        ui->tableEdit->setFocus();
        return;

    } else on_tableEdit_cellClicked(row, col);

}

void MainWindow::on_tablePays_cellChanged(int row, int column)
{
    QTableWidgetItem* item;
    int col;
    int id;
    int pricemult;
    struct stmt_s st;

    if(row < 0 || column < 0 || saving){
        qDebug()<<"failed row "<<row<<" col "<<column;
        return;
    }

    item = ui->tablePays->item(row, column);
    if(!item || item->text().isEmpty()){
        qDebug()<<"no item at row "<<row<<" col "<<column;
        return;
    }

    if(!loading)
        if(!CheckCell(item, T_PAYMENTS, column)){
        qDebug()<<"pay cell assert failed";
        return;
    }

    if(!strcmp(col_name(T_PAYMENTS, column), "transtat_id")){

        if(!translate_to_id(db, T_PAYMENTS, id_col(T_PAYMENTS, "transtat_id"), item->text().toUtf8().data(), this_id, &id)){
            QMessageBox::critical(this, MSG_VALIDITY, MSG_NOTDEF.arg(item->text()));
                item->setText("");
                return;
        }

        item = new QTableWidgetItem;
        ui->tablePays->setItem(row, id_col(T_PAYMENTS, "transtat_pricemult"), item);

        pricemult = translate_to_col_int(db, T_PAYMENTS, id_col(T_PAYMENTS, "transtat_pricemult"), id, this_id, &st);

        item->setText(tr("%1").arg(pricemult));

        finalize(&st);

    }

    if(!strcmp(col_name(T_PAYMENTS, column), "paytype_id")){

        if(!translate_to_id(db, T_PAYMENTS, id_col(T_PAYMENTS, "paytype_id"), item->text().toUtf8().data(), this_id, &id)){
            QMessageBox::critical(this, MSG_VALIDITY, MSG_NOTDEF.arg(item->text()));
            item->setText("");
            return;

        }

        item = new QTableWidgetItem;
        item->setText(tr("%1").arg(translate_to_col_int(db, T_PAYMENTS, id_col(T_PAYMENTS, "paytype_nobank"), id, this_id, &st)));
        ui->tablePays->setItem(row, id_col(T_PAYMENTS, "paytype_nobank"), item);

        finalize(&st);

        item = new QTableWidgetItem;
        item->setText(tr("%1").arg(translate_to_col_int(db, T_PAYMENTS, id_col(T_PAYMENTS, "paytype_noextid"), id, this_id, &st)));
        ui->tablePays->setItem(row, id_col(T_PAYMENTS, "paytype_noextid"), item);

        finalize(&st);

        if(ui->tablePays->item(row, id_col(T_PAYMENTS, "paytype_nobank"))->text().toInt()){
            SolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "bank_id"));
            SolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "branch"));
        } else {
            unSolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "bank_id"));
            SolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "branch"));
        }

        if(ui->tablePays->item(row, id_col(T_PAYMENTS, "paytype_noextid"))->text().toInt()){
            SolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "extid"));
        } else {
            unSolidCell(ui->tablePays, row, id_col(T_PAYMENTS, "extid"));
        }

    }

    if(!loading){
        setChange(TABLE_PAYS, 1);
        RecalcFactor();
    }

    //need new row?

    if(row == ui->tablePays->rowCount() - 1){

        //if all non-ACCEPTNULL columns are full, add another row
        for(col = 0; col < table_cols(T_PAYMENTS); col++){
            item = ui->tablePays->item(row, col);
            if(!item || item->text().isEmpty()){
                if(!(col_flag(T_PAYMENTS, col) & COLF_ACCEPTNULL) && !(col_flag(T_PAYMENTS, col) & COLF_AUTO)){
                    goto end;
                }
            }
        }

        ui->tablePays->insertRow(ui->tablePays->rowCount());

        if(!loading) RecalcFactor();
    }

    end:

    return;

}

void MainWindow::on_tablePays_cellActivated(int row, int col)
{

    if(combolist){

        SaveListText(ui->tablePays, row, col);

        if(col < ui->tablePays->columnCount() - 1) ui->tablePays->setCurrentCell(row, col+1);
        else if(row < ui->tablePays->columnCount() - 1) ui->tablePays->setCurrentCell(row+1, 0);
        else ui->tablePays->setCurrentCell(row, 0);

        ui->tablePays->setFocus();

        return;
    } else on_tablePays_cellClicked(row, col);
}

bool MainWindow::CheckCell(QTableWidgetItem* item, enum table_id tid, int col){

    bool ok = true;
    char date[MAXTIME];

    switch(id_coltype(tid, col)){
    case TY_INT:
        if(!(col_flag(tid, col) & COLF_TRANSL)){
            if(item->text().toInt(&ok, 10) < 0){
                //ok = false;
            }
        }
        break;
    case TY_DATE:
        if(d13_fix_jdate(item->text().toUtf8().data(), date) != E13_OK){
            ok = false;
        } else {
            item->setText(date);
        }
        break;
    default:
        break;
    }

    if(!ok){
        item->setToolTip(MSG_INVALIDFORMAT);
        item->setIcon(QIcon(":/res/error-26.png"));
        item->setTextColor(QColor(255, 0, 0));
        return false;
    }

    item->setToolTip("");
    item->setTextColor(QColor(0, 0, 0));
    //item->icon().detach();

    return true;

}

void MainWindow::setColumn(QTableWidget *table, enum table_id tid, char *colname, QString str){

    QTableWidgetItem* item;

    int col = id_col(tid, colname);
    if(col < 0) return;

    for(int row = 0; row < table->rowCount(); row++){
        item = table->item(row, col);
        if(!item){
            item = new QTableWidgetItem;
            table->setItem(row, col, item);
        }
        item->setText(str);
    }

}


