﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

//#define QT_NO_DEBUG_OUTPUT

#include <QMainWindow>
#include <QCloseEvent>
#include <QTableWidget>
#include <QShowEvent>
#include <QCompleter>
#include <QTextDocument>

#include "db.h"

#include "configdialog.h"
#include "initdialog.h"
#include "mvaldialog.h"

#include "../lib13/include/lib13.h"

#define TABLE_EDIT  0
#define TABLE_ITEMS 1
#define TABLE_PAYS  2
#define TABLE_N     3

#define TAB_FACTOR  0
#define TAB_REPORT  1
#define TAB_EDIT    2

#define REG_NO      0
#define REG_PENDING 1
#define REG_YES     2

#define PRINT_PRINTER   0
#define PRINT_HTML      1
#define PRINT_PREVIEW   2
#define PRINT_NULL      3

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void set_godmode();
    void set_managermode();

private slots:

    void printPreview();
    void printHtml();

    void aboutQt();

    void doCopy();
    void doPaste();
    void doDelete();

    void on_comboTables_currentIndexChanged(const QString &arg1);

    void on_toolExit_clicked();

    void monitorEditCellChange(int row, int column, int prow, int pcolumn);

    void monitorItemCellChange(int row, int column, int prow, int pcolumn);

    void monitorPayCellChange(int row, int column, int prow, int pcolumn);

    void on_toolSave_clicked();

    void on_tableItems_cellClicked(int row, int column);

    void on_tabW_currentChanged(int index);

    void on_tableItems_cellDoubleClicked(int row, int column);

    void on_tableItems_cellChanged(int row, int column);

    void on_tableItems_cellActivated(int row, int col);

    void on_tableEdit_cellChanged(int row, int column);

    void on_tablePays_cellChanged(int row, int column);

    void on_toolConfig_clicked();

    void on_tablePays_cellClicked(int row, int column);

    void on_tablePays_cellActivated(int row, int col);

    void on_toolPrint_clicked();

    void on_tableEdit_cellClicked(int row, int column);

    void on_slideFactorNo_valueChanged(int value);

    void on_spinFactorNo_valueChanged(int arg1);

    void on_btnNew_clicked();

    void on_toolDelete_clicked();

    void on_toolLoadDB_clicked();

    void on_comboDBs_currentIndexChanged(const QString &arg1);

    void on_tableEdit_cellActivated(int row, int col);

    void about();

    void on_tableEdit_cellDoubleClicked(int row, int column);

    void on_tablePays_cellDoubleClicked(int row, int column);

    void on_toolTrunc_clicked();

    void on_toolRefresh_clicked();

    void on_RradioStore_clicked();

    void on_RcheckMinQty_clicked();

    void on_RcomboDate_currentIndexChanged(const QString &arg1);

    void on_RradioSale_clicked();

    void on_RradioTrans_clicked();

    void on_RradioFinance_clicked();

    void on_toolCloseDB_clicked();

    void on_toolShowDbOps_clicked();

    void on_toolLoadDstDB_clicked();

    void on_toolCloseDstDB_clicked();

    void on_toolDstDBMerge_clicked();

    void on_toolDstDBBackup_clicked();

    void on_toolNewDB_clicked();

    void on_comboDstTables_currentIndexChanged(const QString &arg1);

    void on_comboDstDB_currentIndexChanged(const QString &arg1);

    void cellClicked(QTableWidget* table, enum table_id tid, int row, int column);
    void cellDClicked(QTableWidget* table, enum table_id tid, int row, int column);
    void monitorCellChange(QTableWidget* table, enum table_id tid, int row, int col, int prow, int pcol);

//    void moveBack();

    void on_comboCurrentStore_currentIndexChanged(const QString &arg1);

    void on_toolCopy_clicked();

    void on_toolPaste_clicked();

    void on_toolDeleteCell_clicked();

    void on_RradioSend_clicked();

    void on_radioInitTables_clicked();

    void on_radioSyncTables_clicked();

    void on_toolDeleteFactor_clicked();

    void on_comboFactorCustomer_currentTextChanged(const QString &arg1);

    void on_checkDiscountPercent_clicked();

    void on_checkTaxPercent_clicked();

    void on_RradioCustomers_clicked();

    void on_lineRemainPay_textChanged(const QString &arg1);

    void on_RcheckStartDateToday_clicked();

    void on_RcheckEndDateToday_clicked();

    void on_lineDiscount_textChanged(const QString &arg1);

    void on_lineTax_textChanged(const QString &arg1);

    void on_btnShowDbOps_clicked();

private:

    enum R_type{
        R_ITEM,
        R_SALE,
        R_TRANS,
        R_FIN,
        R_SEND,
        R_CUSTOMER
    };

    enum send_dir{
        DIR_SEND = 1,
        DIR_RECV = -1
    };

    void loadDBs(QStringList list);
    void loadDstDBs(QStringList list);

    void setChange(int tab, int n);
    bool hasChange(int tab);

    void loadLists();
    void LoadTable(QTableWidget* table, enum table_id tid, int load = 0, int nlogic = 0, struct logic_s* logic = NULL, char* sortcol = NULL, enum sort_t stype = SO_INC);
    bool WriteTable(QTableWidget* table, enum table_id tid, int new_store_id = -1, int dont_check = 0, int no_item_qty = 0);
    void LayoutTable(QTableWidget* table, enum table_id tid);
    void SaveListText(QTableWidget* table, int row, int column);
    void SaveEditText(QTableWidget* table, int row, int column);
    void ClearCurCell(QTableWidget* table);
    void LoadFactor(int id);
    void CreateNameList(enum table_id tid, char* colname, QStringList &list, QCompleter** com);
    void setDstTableList();
    void setColumn(QTableWidget* table, enum table_id tid, char* colname, QString str);

    void RecalcFactor();
    bool recalcItemQty(QTableWidget* table, enum table_id tid, enum send_dir dir);
    void RecalcPays(QTableWidget* table, QLineEdit *out);
    void RecalcSales(QTableWidget* table, QLineEdit *out);
    void RecalcStore(QTableWidget* table, QLineEdit* out);
    long double mult(char* fmt, ...);

    void outPrint(QString strStream, int mode);
    void printTable(QTableWidget* table, enum table_id tid, QString strTitle, int mode);
    void printInvoice(int mode);
    QString printRSales(int mode);
    QString printRTransactions(int mode);
    void printRStorage(int mode);
    void printRTransfer(int mode);
    void printRSalesTransaction(int mode);

    void printTo(int output);

    long groupVal(QString P, QString T);


    bool CheckCell(QTableWidgetItem* item, enum table_id tid, int col);

    void SolidCell(QTableWidget* table, int row, int col);
    void unSolidCell(QTableWidget* table, int row, int col);
    void makeLogic(enum table_id tid, long flags, struct logic_s* logic, int* nlogic);

    void exportReport(int bom);
    QString *exportTable(QTableWidget* table);

//    void CreateCellList(enum table_id tid, int col, QStringList &list, QCompleter **com);

    void setCellAutoDate(QTableWidget* table, enum table_id tid, int row, int col);

    bool checkItemOut(QTableWidget* table, table_id tid, int row, int column);

    void initConf();

    enum logic_t strToLogic(QString str);
    int strToBool(QString str);

    void createMenu();

    void setupView();
    void setCells(QTableWidget* table, QString str);

    QStringList listItems, listBanks, listCustomers, listTransTypes, listPayTypes, listTranStats, listStores, listLogic, listSex, listSpecs, listBool, listRanks, listSocialStyles, listCustomerTypes, listOffers;
    QCompleter *comItems, *comBanks, *comCustomers, *comTransTypes, *comPayTypes, *comTransStats, *comStores,            *comSex, *comSpecs,           *comRanks, *comSocialStyles, *comCustomerTypes, *comOffers;

    struct db_s* db_first, *db_last, *db;

    bool InitDB();
    bool FinishDB();

    int tday[D13_ITEMS];

    int factor_id;

    int this_id;
    char* this_name;
    char* this_addr;
    char* this_contact;

    Ui::MainWindow *ui;

    bool godmode;
    bool managermode;    

    int t_change[TABLE_N];
    int loading;
    int saving;
    int combolist;
    //int editmode;

    enum R_type report;

    QString RcurFilter;

    struct config cfg;

//    QString clip;

    ConfigDialog cfgDlg;
    initDialog* iniDlg;

protected:
    void closeEvent(QCloseEvent *event);
    bool eventFilter(QObject *obj, QEvent *event);    
    void showEvent(QShowEvent *event);
};

#endif // MAINWINDOW_H
