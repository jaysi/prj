﻿#include <unistd.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "db.h"
#include "../lib13/include/lib13.h"

#include "msg.h"

//the _ is a special char, it defines depency to another table or THIS table
//this helps much when TRANSL flag is on; %table name%_%column name%

#define MAXSQL  2048
#define MAXTABLENAME 50

//#define MAX_COLS    15

#define NA  ""
#define ERR ""

static char errmsg[200];
//#define perr(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr(MSG)
//#define perr2(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr2(MSG)
//#define perr3(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr3(MSG)
//#define perr4(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr4(MSG)
//#define perr5(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr5(MSG)
//#define perr6(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr6(MSG)
#define perrdb(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)

#define snprinte(fmt, args...) snprintf(errmsg, 200, fmt, ## args)
#define printe() perror(errmsg)

#define snprinte1 snprinte
#define printe1 printe

#define snprinte2 snprinte
#define printe2 printe

#define p _NullMsg

struct logic_sign_s{
    char* sign;
} logic_sign[] = {
    {"LIKE"},
    {"NOT LIKE"},
    {"="},
    {"<>"},
    {"<"},
    {"<="},
    {">"},
    {">="},
    {"BETWEEN"},
    {NULL}
};

struct logic_comb_sign_s{
    char* sign;
} logic_comb_sign[] = {
    {" "},
    {"AND"},
    {"OR"},
    {NULL}
};

struct table_info_s{
    char* name;
    char* alias;
    char tview;
    int ncols;
    int nfakes;
    char* col_name[25];
    char* col_type[25];
    char* col_alias[25];
    col_flag_t flags[25];
} table_info[] = {

    {
    "stores",
    "نمایندگی ها",
    TVIEW_GOD|TVIEW_MGR,
    4,
    1,
    {"name", "addr", "contact", "id", "new", NULL},
    {"TEXT", "TEXT", "TEXT", "INT", "INT", NULL},
    {"نام", "نشانی", "تماس", "شناسه", "جدید", NULL},
    {0, 0, 0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_FAKE|COLF_HIDE, COLF_END},
    },

    {
    "offers",
    "علاقه مندی ها",
    TVIEW_GOD|TVIEW_MGR,
    2,
    1,
    {"name", "id", "new", NULL},
    {"TEXT", "INT", "INT", NULL},
    {"علاقه", "شناسه", "جدید", NULL},
    {0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_FAKE|COLF_HIDE, COLF_END},
    },

    {
    "paytypes",
    "روش پرداخت",
    TVIEW_GOD,
    5,
    1,
    {"name", "id", "nobank", "noextid", "grp", "new", NULL},
    {"TEXT", "INT", "INT", "INT", "INT", "INT", NULL},
    {"نوع", "شناسه" ,"بدون بانک(0,1)","بدون شماره چک/حواله(0,1)","گروه/تیپ" ,"جدید",NULL},
    {0, COLF_HIDE|COLF_AUTO, 0, 0, 0, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "transtypes",
    "انواع تراکنش",
    TVIEW_GOD,
    4,
    1,
    {"name", "pricemult", "storemult", "id", "new", NULL},
    {"TEXT", "INT", "INT", "INT", "INT", NULL},
    {"نوع تراکنش", "ضریب بها(0,1,-1)" , "ضریب انبار(0,1,-1)" , "شناسه", "جدید", NULL},
    {0, 0, 0, COLF_HIDE|COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "transtats",
    "وضعیت تراکنش",
    TVIEW_GOD,
    4,
    1,
    {"name", "pricemult", "grp", "id", "new", NULL},
    {"TEXT", "INT", "INT", "INT", "INT", NULL},
    {"وضعیت تراکنش", "ضریب بها(0,1,-1)","گروه/تیپ" , "شناسه" ,"جدید",NULL},
    {0, 0, 0, COLF_HIDE|COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "sexs",//i know sexes!
    "جنسیت",
    TVIEW_GOD,
    3,
    1,
    {"name", "person", "id", "new", NULL},
    {"TEXT", "INT", "INT", "INT", NULL},
    {"جنسیت", "حقیقی" , "شناسه" ,"جدید",NULL},
    {0, 0, COLF_HIDE|COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "specialitys",//i know specialities
    "رشته / تخصص",
    TVIEW_GOD|TVIEW_MGR,
    2,
    1,
    {"name", "id", "new", NULL},
    {"TEXT", "INT", "INT", NULL},
    {"رشته / تخصص", "شناسه" ,"جدید",NULL},
    {0, COLF_HIDE|COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "banks",
    "بانکها",
    TVIEW_GOD|TVIEW_MGR,
    2,
    1,
    {"name", "id", "new", NULL},
    {"TEXT", "INT", "INT", NULL},
    {"نام", "شناسه", "جدید",NULL},
    {0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "ranks",
    "رتبه",
    TVIEW_GOD|TVIEW_MGR,
    2,
    1,
    {"name", "id", "new", NULL},
    {"TEXT", "INT", "INT", NULL},
    {"نام", "شناسه", "جدید",NULL},
    {0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "socialstyles",
    "تیپ شخصیتی",
    TVIEW_GOD|TVIEW_MGR,
    2,
    1,
    {"name", "id", "new", NULL},
    {"TEXT", "INT", "INT", NULL},
    {"نام", "شناسه", "جدید",NULL},
    {0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "customertypes",
    "نوع مشتری",
    TVIEW_GOD|TVIEW_MGR,
    3,
    1,
    {"name", "person", "id", "new", NULL},
    {"TEXT", "INT", "INT", "INT", NULL},
    {"نوع مشتری", "حقیقی" , "شناسه" ,"جدید",NULL},
    {0, 0, COLF_HIDE|COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "items",
    "کالاها",
    TVIEW_GOD|TVIEW_MGR,
    8,
    1,
    {"name", "specs", "id", "qty", "price", "minqty", "store_id" , "date", "new", NULL},
    {"TEXT", "TEXT", "INT", "INT", "INT", "INT", "INT", "DATE", "INT", NULL},
    {"نام", "مشخصات", "شناسه", "تعداد", "بهای واحد", "حداقل تعداد", "شناسه نمایندگی", "تاریخ", "جدید",NULL},
    {0, COLF_ACCEPTNULL, COLF_SINGULAR, 0, 0, 0, COLF_HIDE|COLF_AUTO|COLF_TRANSL, COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "customers",
    "مشتریان",
    TVIEW_ALL,
    20,
    1,

    {"id",
    "name",
    "sex_id",
    "extid",
    "eccode",
    "speciality_id",
    "heyatelmi",
    "addr",
    "contact",
    "customer_id",
    "date",
    "rank_id",
    "offer_id",
    "course",
    "club",
    "rival",
    "salesmanager",
    "socialstyle_id",
    "customertype_id",
    "store_id",
    "new",
    NULL},

    {"INT",
    "TEXT",
    "INT",
    "TEXT",
    "TEXT",
    "INT",
    "BOOLEAN",
    "TEXT",
    "TEXT",
    "INT",
    "DATE",
    "INT",
    "INT",
    "BOOLEAN",
    "BOOLEAN",
    "TEXT",
    "TEXT",
    "INT",
    "INT",
    "INT",
    "INT",
    NULL},

    {"شناسه داخلی", "نام", "جنسیت", "شماره اشتراک/نظام پزشکی/ثبت", "شماره اقتصادی", "رشته/تخصص", "هیات علمی", "نشانی", "تماس", "معرف", "تاریخ تولد/ثبت", "رتبه", "offer مورد علاقه", "علاقمندی به آموزش", "عضو کلوپ", "برندهای مورد استفاده", "مسئول خرید", "تیپ شخصیتی", "نوع", "شناسه نمایندگی", "جدید", NULL},
    {COLF_HIDE|COLF_AUTO|COLF_SINGULAR,
     0,
     COLF_TRANSL|COLF_LIST,
     0,
     0,
     COLF_TRANSL|COLF_LIST,
     COLF_TRANSL|COLF_LIST,
     0,
     0,
     COLF_TRANSL|COLF_LIST|COLF_ACCEPTNULL,
     COLF_AUTO,
     COLF_TRANSL|COLF_LIST,
     COLF_TRANSL|COLF_LIST,
     COLF_TRANSL|COLF_LIST,
     COLF_TRANSL|COLF_LIST,
     COLF_ACCEPTNULL,
     COLF_ACCEPTNULL,
     COLF_TRANSL|COLF_LIST,
     COLF_TRANSL|COLF_LIST,
     COLF_HIDE|COLF_AUTO|COLF_TRANSL,
     COLF_FAKE|COLF_HIDE,
     COLF_END}
    },

    {
    "factors",
    "فاکتورها",
    TVIEW_GOD,
    13,
    5,
    {"factor_id", "date", "customer_id", "item_id", "comments", "item_qty", "id", "transtype_id", "store_id", "discount", "tax", "item_price", "removed", "totalprice", "item_minqty", "transtype_storemult",  "transtype_pricemult", "new", NULL},
    {"INT","DATE", "INT", "INT", "TEXT", "INT",  "INT", "INT", "INT", "TEXT", "TEXT", "INT", "INT", "INT" , "INT", "INT", "INT", "INT", "INT", "INT", NULL},
    {"شماره فاکتور","تاریخ", "مشتری", "کالا" ,"توضیحات", "تعداد","شناسه",  "نوع تراکنش", "شناسه نمایندگی","تخفیف","مالیات/عوارض" ,"بهای واحد","حذف شده", "بهای کل", "حداقل", "ضریب انبار", "ضریب قیمت", "جدید", NULL},
    {COLF_HIDE|COLF_AUTO, COLF_AUTO, COLF_TRANSL|COLF_LIST, COLF_TRANSL|COLF_LIST, COLF_ACCEPTNULL, 0, COLF_HIDE|COLF_AUTO|COLF_SINGULAR, COLF_LIST|COLF_TRANSL, COLF_HIDE|COLF_AUTO|COLF_TRANSL, COLF_HIDE|COLF_ACCEPTNULL, COLF_HIDE|COLF_ACCEPTNULL, COLF_ONETIMEFIX, COLF_ACCEPTNULL|COLF_HIDE, COLF_FAKE|COLF_ONETIMEFIX, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "payments",
    "پرداختها",
    TVIEW_GOD,
    10,
    4,
    {"id", "factor_id", "transtat_id", "val", "date", "paytype_id", "extid", "bank_id", "branch", "store_id" , "transtat_pricemult", "paytype_nobank", "paytype_noextid", "new", NULL},
    {"INT", "INT", "INT", "INT", "DATE", "INT", "TEXT", "INT", "TEXT", "INT", "INT", "INT", "INT", "INT", NULL},
    {"شناسه", "شماره فاکتور", "وضعیت تراکنش", "مبلغ", "تاریخ", "نوع پرداخت","شماره چک/حواله", "بانک","نام/کد شعبه", "شناسه نمایندگی" ,"ضریب قیمت", "بدون بانک","بدون شناسه","جدید",NULL},
    {COLF_HIDE|COLF_AUTO, COLF_HIDE|COLF_AUTO, COLF_LIST|COLF_TRANSL, 0, COLF_AUTO, COLF_LIST|COLF_TRANSL, COLF_ACCEPTNULL, COLF_TRANSL|COLF_LIST|COLF_ACCEPTNULL, COLF_ACCEPTNULL, COLF_HIDE|COLF_AUTO|COLF_TRANSL, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {
    "sends",
    "ارسال / دریافت",
    TVIEW_GOD|TVIEW_MGR,
    8,
    2,
    {"item_id", "item_qty", "item_price", "id", "store_id", "transtype_id", "date", "reg", "transtype_storemult", "new", NULL},
    {"INT", "INT", "INT", "INT", "INT", "INT", "DATE", "INT", "INT", "INT", NULL},
    {"کالا", "تعداد" ,"بهای واحد", "شناسه" , "نمایندگی مقصد", "نوع تراکنش", "تاریخ", "ثبت شده","ضریب انبار", "جدید", NULL},
    {COLF_LIST|COLF_TRANSL, 0, COLF_HIDE|COLF_AUTO, COLF_AUTO|COLF_ONETIMEFIX, COLF_LIST|COLF_TRANSL, COLF_LIST|COLF_TRANSL, COLF_AUTO, COLF_AUTO, COLF_FAKE|COLF_HIDE, COLF_FAKE|COLF_HIDE, COLF_END}
    },

    {NULL, NULL, 0, 0, 0, {NULL}, {NULL}, {NULL}, {COLF_END}}
};

int create_table(struct db_s* db, enum table_id id){

    char sql[MAXSQL];
    size_t len = 0;
    char* emsg;
    int i;
#define RLEN (MAXSQL - len)

    snprintf(sql + len, RLEN, "CREATE TABLE IF NOT EXISTS %s(", table_info[id].name);
    len = strlen(sql);       

    for(i = 0; i < table_info[id].ncols; i++){
        snprintf(sql + len, RLEN, "%s %s%s",
                 table_info[id].col_name[i],
                 table_info[id].col_type[i],
                 i == table_info[id].ncols - 1?");":", ");
        len = strlen(sql);
    }

    perr(sql);

#undef RLEN

    if(sqlite3_exec((sqlite3*)db->h, sql, NULL, NULL, &emsg) != SQLITE_OK){        
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    return true_;

}

int init_this_store(struct db_s* db, int this_id, char* this_name, char* this_addr, char* this_contact){

    char sql[MAXSQL];
    sqlite3_stmt* stmt;

    snprintf(sql, MAXSQL, "INSERT INTO %s(name, addr, contact, id) VALUES(?1, ?2, ?3, ?4);", table_info[T_STORES].name);

    if(sqlite3_prepare(db->h, sql, -1, &stmt, NULL) != SQLITE_OK) return false_;

    if(sqlite3_bind_text(stmt, 1, this_name, -1, NULL) != SQLITE_OK) return false_;
    if(sqlite3_bind_text(stmt, 2, this_addr, -1, NULL) != SQLITE_OK) return false_;
    if(sqlite3_bind_text(stmt, 3, this_contact, -1, NULL) != SQLITE_OK) return false_;
    if(sqlite3_bind_int(stmt, 4, this_id) != SQLITE_OK) return false_;

    switch(sqlite3_step(stmt)){
    case SQLITE_OK:
    case SQLITE_DONE:
        break;

    default:
        return false_;
        break;
    }

    sqlite3_finalize(stmt);

    return true_;
}

int update_this_store(struct db_s* db, int this_id, char* this_name, char* this_addr, char* this_contact){

    char sql[MAXSQL];
    sqlite3_stmt* stmt;

    snprintf(sql, MAXSQL, "UPDATE %s SET %s = ?1, %s = ?2, %s = ?3 WHERE id = ?4;",
             table_info[T_STORES].name,
             table_info[T_STORES].col_name[0],
             table_info[T_STORES].col_name[1],
             table_info[T_STORES].col_name[2],
             this_id
             );

    if(sqlite3_prepare(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(sqlite3_bind_text(stmt, 1, this_name, -1, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }
    if(sqlite3_bind_text(stmt, 2, this_addr, -1, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }
    if(sqlite3_bind_text(stmt, 3, this_contact, -1, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }
    if(sqlite3_bind_int(stmt, 4, this_id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    switch(sqlite3_step(stmt)){
    case SQLITE_OK:
    case SQLITE_DONE:
        break;

    default:
        perrdb(sqlite3_errmsg(db->h));
        return false_;
        break;
    }

    sqlite3_finalize(stmt);

    return true_;
}

int this_store_info(struct db_s* db, int* this_id, char** this_name, char** this_addr, char** this_contact){

    char sql[MAXSQL];
    sqlite3_stmt* stmt;
    unsigned char* tmp;

    snprintf(sql, MAXSQL, "SELECT * FROM %s LIMIT 1;", table_info[T_STORES].name);

    if(sqlite3_prepare(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    switch(sqlite3_step(stmt)){
    case SQLITE_DONE:
    case SQLITE_OK:
        return continue_;
        break;
    case SQLITE_ROW:

        tmp = sqlite3_column_text(stmt, id_col(T_STORES, "name"));
        if(!tmp || !strlen((char*)tmp)){
            *this_name = NULL;
        } else {
            *this_name = (char*)malloc(strlen((char*)tmp)+1);
            strcpy(*this_name, (char*)tmp);
        }

        tmp = sqlite3_column_text(stmt, id_col(T_STORES, "addr"));
        if(!tmp || !strlen((char*)tmp)){
            *this_addr = NULL;
        } else {
            *this_addr = (char*)malloc(strlen((char*)tmp)+1);
            strcpy(*this_addr, (char*)tmp);
        }

        tmp = sqlite3_column_text(stmt, id_col(T_STORES, "contact"));
        if(!tmp || !strlen((char*)tmp)){
            *this_contact = NULL;
        } else {
            *this_contact = (char*)malloc(strlen((char*)tmp)+1);
            strcpy(*this_contact, (char*)tmp);
        }

        *this_id = sqlite3_column_int(stmt, id_col(T_STORES, "id"));

        return true_;

        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        break;
    }

    return false_;

}

int create_db(struct db_s* db){

    enum table_id id;

    for(id = T_STORES; id < T_INVAL; id++){
        if(!create_table(db, id)){
            return false_;
        }
    }

    return true_;

}

int init_db(struct db_s* db, char* name, char* alias){
    sqlite3* sdb;
    //sqlite3_stmt stmt;
    int do_create = false_;

    if(access(name, F_OK)) do_create = true_;

    if(sqlite3_open(name, &sdb) != SQLITE_OK){
        perrdb(sqlite3_errmsg(sdb));
        return false_;
    }

    db->h = sdb;
    db->next = NULL;

    if(do_create){
        if(!create_db(db)){
            return false_;
        }
    }

    db->alias = (char*)malloc(strlen(alias)+1);
    strcpy(db->alias, alias);

    db->path = (char*)malloc(strlen(name)+1);
    strcpy(db->path, name);

    return true_;
}

struct db_s* find_db_path(struct db_s* first, char* path){
    struct db_s* db;
    for(db = first; db; db = db->next){
        if(!strcmp(path, db->path)) return db;
    }
    return NULL;
}

struct db_s* find_db_alias(struct db_s* first, char* alias){
    struct db_s* db;
    for(db = first; db; db = db->next){
        if(!strcmp(alias, db->alias)) return db;
    }
    return NULL;
}

char* db_alias(struct db_s* db){
    return db->alias;
}

int close_db(struct db_s* db){
    sqlite3_close((sqlite3*)db->h);
    free(db->alias);
    free(db->path);
    return true_;
}

char* t_name(enum table_id id){
    return table_info[id].name;
}

char* t_alias(enum table_id id){
    return table_info[id].alias;
}

char* col_alias(enum table_id id, int col){
    if(col >= table_info[id].ncols + table_info[id].nfakes) return NA;
    return table_info[id].col_alias[col];
}

char* col_name(enum table_id id, int col){
    if(col >= table_info[id].ncols+ table_info[id].nfakes) return NA;
    return table_info[id].col_name[col];
}

enum table_id id_table(char* name){
    enum table_id ret;
    for(ret = T_STORES; ret < T_INVAL; ret++){
        if(!strcmp(name, table_info[ret].name)) break;
    }

    return ret;
}

enum table_id id_table_alias(char* alias){
    enum table_id ret;
    for(ret = T_STORES; ret < T_INVAL; ret++){
        if(!strcmp(alias, table_info[ret].alias)) break;
    }

    return ret;
}

int id_col(enum table_id id, char* name){
    int ret;

    for(ret = 0; ret < table_info[id].ncols+table_info[id].nfakes; ret++){
        if(!strcmp(name, table_info[id].col_name[ret])) break;
    }

    return ret==table_info[id].ncols+table_info[id].nfakes?-1:ret;
}

int id_col_alias(enum table_id id, char* alias){
    int ret;

    for(ret = 0; ret < table_info[id].ncols+table_info[id].nfakes; ret++){
        if(!strcmp(alias, table_info[id].col_alias[ret])) break;
    }

    return ret==table_info[id].ncols+table_info[id].nfakes?-1:ret;
}

int table_cols(enum table_id id){
    return table_info[id].ncols;
}

int table_fakes(enum table_id id){
    return table_info[id].nfakes;
}

int table_rows(enum table_id id){
    return false_;
}

int select_all(struct db_s* db, enum table_id id, struct stmt_s *st){

    char sql[MAXSQL];

    sqlite3_stmt* stmt = NULL;

    snprintf(sql, MAXSQL, "SELECT * FROM %s;", t_name(id), db->this_id);

    assert(db);
    assert(db->h);

    perr(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    st->h = stmt;
    st->db = db;

    return true_;

}

int trunc_table(struct db_s* db, enum table_id tid){
    char sql[MAXSQL];
    snprintf(sql, MAXSQL, "DELETE FROM %s;", t_name(tid));
    if(sqlite3_exec(db->h, sql, NULL, NULL, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }
    return true_;
}

int next(struct stmt_s* stmt){

    switch(sqlite3_step((sqlite3_stmt*)stmt->h)){

    case SQLITE_ROW:
        return continue_;
        break;

    case SQLITE_DONE:
    case SQLITE_OK:
        return true_;
        break;

    default:
    perrdb(sqlite3_errmsg(stmt->db->h));
    return false_;
    break;

    }
}

int getcol_int(struct stmt_s* stmt, int col){
    return sqlite3_column_int((sqlite3_stmt*)stmt->h, col);
}

const char* getcol_text(struct stmt_s* stmt, int col){
    return (const char*)sqlite3_column_text((sqlite3_stmt*)stmt->h, col);
}

int finalize(struct stmt_s* stmt){

    if(stmt->magic != STMT_MAGIC) return true_;

    if(sqlite3_finalize((sqlite3_stmt*)stmt->h) == SQLITE_OK){
        stmt->magic = 0;
        return true_;
    }

    return false_;

}

enum type_id id_coltype(enum table_id tid, int col){

    if(tid == T_INVAL || col < 0) return TY_INVAL;

    if(!strcmp(table_info[tid].col_type[col], "INT")){
        return TY_INT;
    }

    if(!strcmp(table_info[tid].col_type[col], "TEXT")){
        return TY_TEXT;
    }

    if(!strcmp(table_info[tid].col_type[col], "DATE")){
        return TY_DATE;
    }

    if(!strcmp(table_info[tid].col_type[col], "BOOLEAN")){
        return TY_BOOL;
    }

    return TY_INVAL;
}

col_flag_t col_flag(enum table_id tid, int col){
    return table_info[tid].flags[col];
}

void set_col_flag(enum table_id tid, int col, col_flag_t flag){
    table_info[tid].flags[col] |= flag;
}

void unset_col_flag(enum table_id tid, int col, col_flag_t flag){
    table_info[tid].flags[col] &= ~flag;
}

int reset(struct stmt_s* st){
    if(st->magic != STMT_MAGIC) return false_;
    sqlite3_reset((sqlite3_stmt*)st->h);
    return true_;
}

int update_col_byid(struct db_s* db, enum table_id tid, int id, int store_id, int col, char* val, struct stmt_s* st){

    char sql[MAXSQL];
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[3];

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "UPDATE %s SET %s = ?1 WHERE id = ?2", table_info[tid].name, col_name(tid, col));

    perr2(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:

    switch(id_coltype(tid, col)){

    case TY_BOOL:
    case TY_INT:
        if(sqlite3_bind_int((sqlite3_stmt*)st->h, 1, atoi(val)) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
        break;

    case TY_DATE:
        d13_resolve_date(val, date);
        if(sqlite3_bind_int((sqlite3_stmt*)st->h, 1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
        break;

    case TY_TEXT:    
        if(sqlite3_bind_text((sqlite3_stmt*)st->h, 1, val, -1, NULL) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
        break;

    default:
        if(sqlite3_bind_blob((sqlite3_stmt*)st->h, 1, val, strlen(val)+1, NULL) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
        break;
    }

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 2, id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){
    case SQLITE_DONE:
        if(!sqlite3_changes(db->h)) return continue_;
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        return false_;
        break;
    }

    perr("UPDATE TRUE");
    return true_;
}

/* THIS is the old update which ignored store_id
int updatebyid(struct db_s* db, enum table_id id, char** col, struct stmt_s* st){

    int i;
    char sql[MAXSQL];
    size_t len = 0;    
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[3];

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "UPDATE %s SET ", table_info[id].name);
    len = strlen(sql);

    for(i = 0; i < table_info[id].ncols; i++){

        //protect against id!!
        if(!strcmp(table_info[id].col_name[i], "id")) continue;

        if(i == table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "%s = ?%i",table_info[id].col_name[i], i+1);
        } else {
            snprintf(sql+len, RLEN, "%s = ?%i,",table_info[id].col_name[i], i+1);
        }
        //strcat(sql, ", ");
        len = strlen(sql);

    }    

    //assign id
    //assert(id_col(id, "id")0);

    if(sql[len-1]==',') {sql[len--] = 0;}

    snprintf(sql+len, RLEN, " WHERE id = ?%i;", i+1);

    perr(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:

    for(i = 0; i < table_info[id].ncols; i++){

        perr(col[i]);

        //protect against id!!
        if(!strcmp(table_info[id].col_name[i], "id")) continue;

        switch(id_coltype(id, i)){

        case TY_INT:
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, atoi(col[i])) != SQLITE_OK){
                return false_;
            }
            break;

        case TY_DATE:
            d13_resolve_date(col[i], date);
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                return false_;
            }
            break;

        case TY_TEXT:        
            if(sqlite3_bind_text((sqlite3_stmt*)st->h, i+1, col[i], -1, NULL) != SQLITE_OK){
                return false_;
            }
            break;

        default:
            if(sqlite3_bind_blob((sqlite3_stmt*)st->h, i+1, col[i], strlen(col[i])+1, NULL) != SQLITE_OK){
                return false_;
            }
            break;
        }

    }

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, atoi(col[id_col(id, "id")])) != SQLITE_OK){
        return false_;
    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){
    case SQLITE_DONE:
        if(!sqlite3_changes(db->h)) return continue_;
        break;
    default:
        return false_;
        break;
    }

    perr("UPDATE TRUE");
    return true_;
}
*/

int insert(struct db_s* db, enum table_id id, char** col, struct stmt_s* st){

    int i;
    char sql[MAXSQL];
    size_t len = 0;
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[3];

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "INSERT INTO %s(", table_info[id].name);
    len = strlen(sql);

    for(i = 0; i < table_info[id].ncols; i++){
        if(i == table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "%s",table_info[id].col_name[i]);
        } else {
            snprintf(sql+len, RLEN, "%s, ",table_info[id].col_name[i]);
        }
        len = strlen(sql);
    }

    snprintf(sql+len, RLEN, ") VALUES(");
    len = strlen(sql);

    for(i = 0; i < table_info[id].ncols; i++){
        if(i == table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "?%i",i+1);
        } else {
            snprintf(sql+len, RLEN, "?%i, ",i+1);
        }
        len = strlen(sql);
    }

    snprintf(sql+len, RLEN, ");");

    perr(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){        
        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

    if(!col) return continue_;

bind_data:

    printf("ncols = %i", table_info[id].ncols);

    for(i = 0; i < table_info[id].ncols; i++){

        perr(col[i]);

        switch(id_coltype(id, i)){

        case TY_BOOL:
        case TY_INT:            
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, atoi(col[i])) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        case TY_DATE:
            d13_resolve_date(col[i], date);
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        case TY_TEXT:
            if(sqlite3_bind_text((sqlite3_stmt*)st->h, i+1, col[i], -1, NULL) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        default:
            if(sqlite3_bind_blob((sqlite3_stmt*)st->h, i+1, col[i], strlen(col[i])+1, NULL) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;
        }

    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){
    case SQLITE_OK:
    case SQLITE_DONE:
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        return false_;
        break;
    }

    perr("INSERT TRUE");

    return true_;
}

int collect(struct db_s* db, enum table_id id,
           char** cols,
           int nlogic, struct logic_s* logic,
           char* sortcol, enum sort_t stype,
           struct stmt_s* st){

    char sql[MAXSQL];
    size_t len = 0;
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    int i;
    int date[3];

    snprintf(sql + len, RLEN, "SELECT ");
    len = strlen(sql);

    if(!cols){
        snprintf(sql + len, RLEN, "* ");
        len = strlen(sql);
    } else {
        while(*cols){
            snprintf(sql + len, RLEN, "%s%s", *cols, (cols+1)?",":" ");
            len = strlen(sql);
            cols++;
        }
    }

    snprintf(sql + len, RLEN, "FROM %s", table_info[id].name);
    len = strlen(sql);

    if(nlogic){

        snprintf(sql + len, RLEN, " WHERE ", table_info[id].name);
        len = strlen(sql);

        for(i = 1; i < nlogic + 1; i++){

            if(!(logic[i-1].flags & LOGICF_COL_CMP)){

                snprintf(sql + len, RLEN, "%s %s %s ?%i",
                         i == 1?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         i
                        );

            } else {

                snprintf(sql + len, RLEN, "%s %s %s %s",
                         i == 1?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         logic[i-1].sval
                        );

            }

            len = strlen(sql);

        }

    }

    if(sortcol){
        snprintf(sql + len, RLEN, " ORDER BY %s %s", sortcol, stype == SO_DEC?"DESC":"");
        len = strlen(sql);
    }
#undef RLEN
    strcat(sql, ";");

    assert(db);
    assert(db->h);

    perr2(sql);

    p(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(nlogic){

        for(i = 1; i < nlogic + 1; i++){

            if(!(logic[i-1].flags & LOGICF_COL_CMP)){

                switch(id_coltype(id, logic[i-1].col)){

                case TY_BOOL:
                case TY_INT:
                    p("bind %i at %i", logic[i-1].ival, i);
                    if(sqlite3_bind_int(stmt, i, logic[i-1].ival) != SQLITE_OK){
                        perrdb(sqlite3_errmsg(db->h));
                        return false_;
                    }
                break;

                case TY_DATE:
                    perr2(logic[i-1].sval);
                    if(d13_resolve_date(logic[i-1].sval, date) != E13_OK){
                        //perr2(logic[i-1].sval);
                        continue;
                    }

                    if(sqlite3_bind_int(stmt, i, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                        perrdb(sqlite3_errmsg(db->h));
                        return false_;
                    }
                    break;

                case TY_TEXT:
                    p("bind %s at %i", logic[i-1].sval, i);
                    if(sqlite3_bind_text(stmt, i, logic[i-1].sval, -1, NULL) != SQLITE_OK){
                        perrdb(sqlite3_errmsg(db->h));
                        return false_;
                    }
                break;

                default:
                    perrdb(sqlite3_errmsg(db->h));
                    return false_;

                }

            }

        }

    }

    st->h = stmt;
    st->db = db;
    st->magic = STMT_MAGIC;

    return true_;

}

int get_last_id(struct db_s* db, enum table_id tid){

    char sql[MAXSQL];
    int row;

    sqlite3_stmt* stmt;

    snprintf(sql, MAXSQL, "SELECT * FROM %s ORDER BY %s DESC;", table_info[tid].name, "id");

    if(sqlite3_prepare_v2(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return -1;
    }

    switch(sqlite3_step(stmt)){
    case SQLITE_ROW:
        row = sqlite3_column_int(stmt, id_col(tid, "id"));
        sqlite3_finalize(stmt);
        return row;
        break;

    case SQLITE_DONE:
    case SQLITE_OK:
        sqlite3_finalize(stmt);
        //no entries
        return 0;
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        sqlite3_finalize(stmt);
        break;

    }

    return -1;

}

int get_last_factorid(struct db_s* db){

    char sql[MAXSQL];
    int row;

    sqlite3_stmt* stmt;

    snprintf(sql, MAXSQL, "SELECT * FROM %s ORDER BY %s DESC;", table_info[T_FACTORS].name, "factor_id");

    if(sqlite3_prepare_v2(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return -1;
    }

    switch(sqlite3_step(stmt)){
    case SQLITE_ROW:
        row = sqlite3_column_int(stmt, id_col(T_FACTORS, "factor_id"));
        sqlite3_finalize(stmt);
        return row;
        break;

    case SQLITE_DONE:
    case SQLITE_OK:
        sqlite3_finalize(stmt);
        //no entries
        return 0;
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        sqlite3_finalize(stmt);
        break;

    }

    return -1;

}

//int get_this_store_id(struct db_s* db){

//    char sql[MAXSQL];
//    sqlite3_stmt* stmt;
//    int id;

//    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE name LIKE 'this';", table_info[T_STORES].name);

//    if(sqlite3_prepare_v2(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){

//        return -1;
//    }

//    switch(sqlite3_step(stmt)){
//    case SQLITE_ROW:
//        id = sqlite3_column_int(stmt, id_col(T_STORES, "id"));
//        sqlite3_finalize(stmt);
//        return id;
//        break;
//    case SQLITE_DONE:
//    case SQLITE_OK:
//        perr("not init!!!");
//        sqlite3_finalize(stmt);
//        return -1;
//        break;

//    default:
//        break;

//    }

//    sqlite3_finalize(stmt);

//    return -1;
//}

int translate_to_id(struct db_s* db, enum table_id tid, int col, char* text, int store_id, int* id){

    sqlite3_stmt* stmt;
    int has_store_id;

    char sql[MAXSQL];

    int refcoli;
    enum table_id reftid;

    if(col < 0) return false_;

    char* refname = col_name(tid, col);

    char* reftable, *refcol, *needle;

    needle = strchr(refname, '_');
    if(!needle) return false_;

    reftable = (char*)malloc(strlen(refname) + 2);

    memcpy(reftable, refname, needle - refname);
    reftable[needle-refname] = 0;
    strcat(reftable, "s");

    needle++;
    refcol = needle;

    reftid = id_table(reftable);
    refcoli = id_col(reftid, refcol);

    if(id_col(reftid, "store_id") > -1){
        has_store_id = 1;
    } else {
        has_store_id = 0;
    }

    free(reftable);

    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE %s LIKE ?1%s", table_info[reftid].name, "name", has_store_id?" AND store_id = ?2;":";");

    perr(sql);

    if(sqlite3_prepare(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    perr("TRANSL1");

    if(sqlite3_bind_text(stmt, 1, text, -1, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        sqlite3_finalize(stmt);
        return false_;
    }

    if(has_store_id){
        if(sqlite3_bind_int(stmt, 2, store_id) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            sqlite3_finalize(stmt);
            return false_;
        }
    }

    perr("TRANSL2");

    switch(sqlite3_step(stmt)){    
    case SQLITE_OK:
    case SQLITE_DONE:
        perr("TRANSL3");
        return false_;
        break;
    case SQLITE_ROW:
        perr("TRANSL4");
        *id = sqlite3_column_int(stmt, id_col(reftid, "id"));
        if(sqlite3_step(stmt) != SQLITE_DONE){
            perr("TRANSL5");
            sqlite3_finalize(stmt);
            return continue_;//break singularity
        } else {
            perr("TRANSL6");
            sqlite3_finalize(stmt);
            return true_;
        }
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        perr("TRANSL7");
        sqlite3_finalize(stmt);
        break;
    }

    perr("TRANSL8");

    return false_;
}

int translate_name_to_id(struct db_s* db, enum table_id tid, char* text, int* id){

    sqlite3_stmt* stmt;

    char sql[MAXSQL];

    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE %s LIKE ?1;", table_info[tid].name, "name");

    perr(sql);

    if(sqlite3_prepare(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    perr("TRANSL1");

    if(sqlite3_bind_text(stmt, 1, text, -1, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        sqlite3_finalize(stmt);
        return false_;
    }

    perr("TRANSL2");

    switch(sqlite3_step(stmt)){
    case SQLITE_OK:
    case SQLITE_DONE:
        perr("TRANSL3");
        return false_;
        break;
    case SQLITE_ROW:
        perr("TRANSL4");
        *id = sqlite3_column_int(stmt, id_col(tid, "id"));
        if(sqlite3_step(stmt) != SQLITE_DONE){
            perr("TRANSL5");
            sqlite3_finalize(stmt);
            return continue_;//break singularity
        } else {
            perr("TRANSL6");
            sqlite3_finalize(stmt);
            return true_;
        }
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        perr("TRANSL7");
        sqlite3_finalize(stmt);
        break;
    }

    perr("TRANSL8");

    return false_;
}

void free_rowset(void **rowset){
    char** colset;

    //TODO: tempo
    return;

    while(*rowset){

        colset = *rowset;

        while(*colset){

            free(*colset);
            colset++;
        }

        free(colset);

        rowset++;

    }

    free(rowset);
}

char* translate_to_name(struct db_s* db, enum table_id tid, int col, int id, int store_id, struct stmt_s* st){

    char sql[MAXSQL];
    char reftable[MAXTABLENAME];
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    static int has_store_id;


    char* refname = col_name(tid, col);
    char *refcol, *needle;

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    int refcoli;
    enum table_id reftid;

    if(col < 0) return NA;

    needle = strchr(refname, '_');
    if(!needle) return NA;

    memcpy(reftable, refname, needle - refname);
    reftable[needle-refname] = 0;
    strcat(reftable, "s");

    needle++;
    refcol = needle;

    reftid = id_table(reftable);
    refcoli = id_col(reftid, refcol);

    if(id_col(reftid, "store_id") > -1){
        has_store_id = 1;
    } else {
        has_store_id = 0;
    }

    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE id = ?1%s", reftable, has_store_id?" AND store_id = ?2;":";");

    snprinte1("%s - id: %i & store_id: %i", sql, id, store_id);
    printe1();

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return ERR;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 1, id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return ERR;
    }

    if(has_store_id){
        if(sqlite3_bind_int((sqlite3_stmt*)st->h, 2, store_id) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return ERR;
        }
    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){

    case SQLITE_OK:
    case SQLITE_DONE:
        return NA;
        break;

    case SQLITE_ROW:
        //translate id to name
        refcoli = id_col(reftid, "name");
        return sqlite3_column_text(st->h, refcoli);

        break;

    default:
        perrdb(sqlite3_errmsg(db->h));
        return ERR;
        break;

    }

}

int translate_to_col_int(struct db_s* db, enum table_id tid, int col, int id, int store_id, struct stmt_s* st){

    char sql[MAXSQL];
    char reftable[MAXTABLENAME];
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    static int has_store_id;

    perr5("entering translate_to_col_int()");

    char* refname = col_name(tid, col);
    assert(refname);
    perr5(refname);

    char *refcol, *needle;


    if(st->magic == STMT_MAGIC){

        reset(st);
        perr3("goto bind!");
        goto bind_data;
    }


    int refcoli;
    enum table_id reftid;


    if(col < 0){
        perr3("col < 0");
        return -1;
    }


    needle = strchr(refname, '_');
    assert(needle);

    if(!needle){

        perr3(refname);
        return -1;
    }
    perr5(needle);


    memcpy(reftable, refname, needle - refname);

    reftable[needle-refname] = 0;

    strcat(reftable, "s");

    perr5(reftable);

    needle++;

    refcol = needle;


    reftid = id_table(reftable);
    assert(reftid != T_INVAL);

    refcoli = id_col(reftid, refcol);
    assert(refcoli > -1);


    if(id_col(reftid, "store_id") > -1){
        perr5("has store_id");
        has_store_id = 1;
    } else {
        perr5("has no store_id");
        has_store_id = 0;
    }


    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE id = ?1%s", reftable, has_store_id?" AND store_id = ?2;":";");


    perr3(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){

        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return -1;
    }


    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:


    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 1, id) != SQLITE_OK){

        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return -1;
    }



    if(has_store_id){
        if(sqlite3_bind_int((sqlite3_stmt*)st->h, 2, store_id) != SQLITE_OK){

            perrdb(sqlite3_errmsg((sqlite3*)db->h));
            return -1;
        }
    }


    switch(sqlite3_step((sqlite3_stmt*)st->h)){

    case SQLITE_OK:
    case SQLITE_DONE:
        perr3("not found!");
        return -1;
        break;

    case SQLITE_ROW:
        //translate id to name
        refcoli = id_col(reftid, refcol);
        //perr6("translated!");
        return sqlite3_column_int(st->h, refcoli);

        break;

    default:
        perrdb(sqlite3_errmsg(db->h));
        perr3("donno! not found!");
        return -1;
        break;

    }

    perr3("shouldn't reach here!");

    return -1;

}

int delete_id(struct db_s* db, enum table_id tid, char* col, int id, int store_id, struct stmt_s* st){

    char sql[MAXSQL];
    sqlite3_stmt* stmt;
    static int has_store_id;

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    if(id_col(tid, "store_id") > -1) has_store_id = 1;
    else has_store_id = 0;

    snprintf(sql, MAXSQL, "DELETE FROM %s WHERE %s = ?1%s", table_info[tid].name, col, has_store_id?" AND store_id = ?2;":";");

    if(sqlite3_prepare_v2(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:

    if(sqlite3_bind_int(stmt, 1, id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(has_store_id){
        if(sqlite3_bind_int(stmt, 2, store_id) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
    }

    if(sqlite3_step(stmt) != SQLITE_DONE){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    return true_;

}

//int get_int_by_id(struct db_s* db, enum table_id tid, int id, int col, int* val){

//    char sql[MAXSQL];

//    sqlite3_stmt* stmt;
//    int ret = false_;

//    snprintf(sql, MAXSQL, "SELECT * FROM %s WHERE id = ?1;");

//    if(sqlite3_prepare_v2(db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
//        perrdb(sqlite3_errmsg(db->h));
//        return false_;
//    }

//    if(sqlite3_bind_int(stmt, 1, id) != SQLITE_OK){
//        perrdb(sqlite3_errmsg(db->h));
//        return false_;
//    }

//    switch(sqlite3_step(stmt)){
//    case SQLITE_DONE:
//        ret = continue_;
//        break;
//    case SQLITE_ROW:
//        *val = sqlite3_column_int(stmt, id);
//        ret = true_;
//        break;

//    default:
//        break;

//    }

//    sqlite3_finalize(stmt);
//    return ret;
//}

int update_item_qty(struct db_s* db, int id, int store_id, int qty, struct stmt_s* st){
    char sql[MAXSQL];
    sqlite3_stmt* stmt;

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "UPDATE %s SET qty = qty - ?1 WHERE id = ?2 AND store_id = ?3;", table_info[T_ITEMS].name);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

bind_data:
    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 1, qty) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 2, id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, 3, store_id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){
    case SQLITE_DONE:
        if(!sqlite3_changes(db->h)) return continue_;
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        return false_;
        break;
    }

    perr("UPDATE TRUE");
    return true_;


}

int updatebyid(struct db_s* db, enum table_id id, char** col, struct stmt_s* st){

    int i;
    char sql[MAXSQL];
    size_t len = 0;
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[3];
    int has_storeid;

    if(id_col(id, "store_id") >= 0){
        has_storeid = 1;
    } else {
        has_storeid = 0;
    }

    if(st->magic == STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "UPDATE %s SET ", table_info[id].name);
    len = strlen(sql);

    for(i = 0; i < table_info[id].ncols; i++){

        //protect against id!!
        if(!strcmp(table_info[id].col_name[i], "id") || !strcmp(table_info[id].col_name[i], "store_id")) continue;

        if(!strcmp(col[i], MSG_DONTUPDATE)) continue;

        if(i == table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "%s = ?%i",table_info[id].col_name[i], i+1);
        } else {
            snprintf(sql+len, RLEN, "%s = ?%i,",table_info[id].col_name[i], i+1);
        }
        //strcat(sql, ", ");
        len = strlen(sql);

    }

    //assign id
    //assert(id_col(id, "id")0);

    i++;

    if(sql[len-1]==',') {sql[len--] = 0;}

    if(has_storeid){
        snprintf(sql+len, RLEN, " WHERE id = ?%i AND store_id = ?%i;", i, i+1);
    } else {
        snprintf(sql+len, RLEN, " WHERE id = ?%i;", i);
    }

    perr(sql);

    if(sqlite3_prepare_v2((sqlite3*)db->h, sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg((sqlite3*)db->h));
        return false_;
    }

    st->h = stmt;
    st->magic = STMT_MAGIC;

    if(!col) return continue_;

bind_data:

    for(i = 0; i < table_info[id].ncols; i++){

        perr(col[i]);

        //protect against id!!
        if(!strcmp(table_info[id].col_name[i], "id") || !strcmp(table_info[id].col_name[i], "store_id")) continue;

        if(!strcmp(col[i], MSG_DONTUPDATE)) continue;

        switch(id_coltype(id, i)){

        case TY_BOOL:
        case TY_INT:
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, atoi(col[i])) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        case TY_DATE:
            if(d13_resolve_date(col[i], date) != E13_OK){
                perr("failed to resolve date");
            }
            if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        case TY_TEXT:
            if(sqlite3_bind_text((sqlite3_stmt*)st->h, i+1, col[i], -1, NULL) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;

        default:
            if(sqlite3_bind_blob((sqlite3_stmt*)st->h, i+1, col[i], strlen(col[i])+1, NULL) != SQLITE_OK){
                perrdb(sqlite3_errmsg(db->h));
                return false_;
            }
            break;
        }

    }

    i++;

    if(sqlite3_bind_int((sqlite3_stmt*)st->h, i, atoi(col[id_col(id, "id")])) != SQLITE_OK){
        perrdb(sqlite3_errmsg(db->h));
        return false_;
    }

    if(has_storeid){
        if(sqlite3_bind_int((sqlite3_stmt*)st->h, i+1, atoi(col[id_col(id, "store_id")])) != SQLITE_OK){
            perrdb(sqlite3_errmsg(db->h));
            return false_;
        }
    }

    switch(sqlite3_step((sqlite3_stmt*)st->h)){
    case SQLITE_DONE:
        if(!sqlite3_changes(db->h)) return continue_;
        break;
    default:
        perrdb(sqlite3_errmsg(db->h));
        return false_;
        break;
    }

    perr("UPDATE TRUE");
    return true_;
}

enum table_id t_next(enum table_id i){
    return i+1;
}

int rollback(struct db_s* db){
    //TODO
    if(sqlite3_exec(db->h, "ROLLBACK TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return false_;
    }
    return true_;
}

int start_trans(struct db_s* db){
    //TODO
    if(sqlite3_exec(db->h, "BEGIN TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return false_;
    }
    return true_;
}

int end_trans(struct db_s* db){
    //TODO
    if(sqlite3_exec(db->h, "COMMIT TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return false_;
    }
    return true_;
}

char t_view(enum table_id tid){
    return table_info[tid].tview;
}

char* create_multi_field(int n, struct mval* val){

    size_t bufsize = 0, pos = 0;
    int i;

    char* buf;

    if(!n){
        return NULL;
    }

    for(i = 0; i < n; i++){
        bufsize += strlen(val[i].name) + strlen(val[i].val) + 2;
    }

    snprinte2("bufsize = %u", bufsize);
    printe2();

    bufsize++;

    buf = (char*)malloc(bufsize);

    for(i = 0; i < n; i++){
        snprintf(buf + pos, bufsize - pos, "%s:%s%s", val[i].name, val[i].val, i < n - 1?";":"");
        pos += strlen(buf);
    }

    snprinte2("pos = %u", pos);
    printe2();

    return buf;
}

struct mval* parse_multi_field(char* mstr, int* n){
    char* pack[2];
    char** ary, **ary1;
    struct mval* val;
    int i;    
    pack[0] = "\"";
    pack[1] = NULL;
    *n = s13_exparts(mstr, ";", pack, '\\');
    if(!(*n)) return NULL;
    val = (struct mval*)malloc((*n)*sizeof(struct mval));
    ary = s13_exmem(*n);
    s13_explode(mstr, ";", pack, '\\', ary);
    i = s13_exparts(ary[0], ":", pack, '\\');
    if(!i) return NULL;
    ary1 = s13_exmem(i);
    for(i = 0; i < *n; i++){
        perr(ary[i]);
        s13_explode(ary[i], ":", pack, '\\', ary1);
        (val)[i].name = ary1[0];
        perr(ary1[0]);
        (val)[i].val = ary1[1];
        perr(ary1[1]);
    }

    s13_free_exmem(ary);
    s13_free_exmem(ary1);

    return val;
}

char* dyn_copy_str(char* str){
    unsigned len;
    if(str) len = strlen(str);
    else len = 0;

    char* buf = (char*)(malloc(len+1));
    if(len) strcpy(buf, str);
    else *buf = 0;
    return buf;
}
