﻿#ifndef MVALDIALOG_H
#define MVALDIALOG_H

#include <QDialog>
#include <QTableWidget>

#include "msg.h"

namespace Ui {
class mvalDialog;
}

class mvalDialog : public QDialog
{
    Q_OBJECT

public:
    explicit mvalDialog(QWidget *parent = 0);
    explicit mvalDialog(QWidget *parent = 0, QString mvalStr = tr(""), int max = 0, QString strName = MSG_NAME, QString strVal = MSG_VAL);
    ~mvalDialog();

    QString getMvalStr();

private slots:
    void on_btnOk_clicked();


private:
    Ui::mvalDialog *ui;
    QString retStr;
    void clearCurCell(QTableWidget* table);
    void setCells(QTableWidget* table, QString str);

protected:
    bool eventFilter(QObject *obj, QEvent *event);
};

#endif // MVALDIALOG_H
