﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"

#include "db.h"

#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>

#include <QList>
#include <QMap>

#include "db.h"

static char errmsg[200];
//#define perr(MSG) do{ snprintf(errmsg, 200, "%s_%i: %s", __FILE__, __LINE__, MSG); perror(errmsg); }while(0)
#define perr(MSG)

bool MainWindow::WriteTable(QTableWidget* table, enum table_id tid, int new_store_id, int dont_check, int no_item_qty){

    int col, row;
    int id, tl_id;
    if(tid == T_INVAL) return false;
    int nrows = table->rowCount();
    int ncols = table_cols(tid);
    struct stmt_s updatest, insertst;
    QTableWidgetItem* item, *item2;

    if(tid == T_INVAL) return false;

    char** coldata;

    id = get_last_id(db, tid);

    ui->labelJob->setText(MSG_SAVING);
    ui->progressJob->setMaximum(nrows*2-2);

    qDebug()<<"write "<<t_name(tid)<<" last id "<<id<<" nrows "<<nrows<< " ncols "<<ncols;


    //if(nrows == 1) nrows++;

    for(row = 0; row < nrows; row++){

        for(col = 0; col < ncols; col++){

            if(col_flag(tid, col) & COLF_FAKE){
                QMessageBox::critical(this, "Design Error", "Do not write FAKE columns!");
                return false;
            }

            item = table->item(row, col);

            if(!item || item->text().isEmpty()){ //no contents

                if(!item){

                    item = new QTableWidgetItem;
                    table->setItem(row, col, item);

                }

                if(col_flag(tid, col) & COLF_AUTO){//resolve cell

                    if(!strcmp(col_name(tid, col), "date")){

                        item->setText(trUtf8("%1/%2/%3").arg(tday[0]).arg(tday[1]).arg(tday[2]));

                    } else if(!strcmp(col_name(tid, col), "id")){

                        id++;

                        qDebug()<<"id is "<<id;

                        item->setText(tr("%1").arg(id));

                        item2 = new QTableWidgetItem;
                        item2->setText(tr("1"));
                        table->setItem(row, id_col(tid, "new"), item2);

                        qDebug()<<"*** set row "<<row<<" col(new) "<<id_col(tid, "new")<<" table "<<table->objectName()<<" to "<<table->item(row, id_col(tid, "new"))->text();

                    } else if(!strcmp(col_name(tid, col), "store_id")){

                        item->setText(tr("%1").arg(this_id));
                        qDebug()<<"set store_id col to "<<item->text();

                    } else if(!strcmp(col_name(tid, col), "factor_id")){

                        item->setText(tr("%1").arg(factor_id));

                    } else if(!strcmp(col_name(tid, col), "reg")){

                        item->setText(tr("%1").arg(REG_NO));

                    } else {

                        item->setText(trUtf8("# Design Error #"));
                        table->setCurrentCell(row, col);

                        qDebug()<<"return 1";
                        return false;
                    }

                } else if(col_flag(tid, col) & COLF_ACCEPTNULL){

                    if(!item){

                        item = new QTableWidgetItem;
                        table->setItem(row, col, item);

                    }

                    item->setText(tr(""));

                } else { //empty with no AUTO flag set? the row is invalid!

                    if(row == nrows - 1){//no problem if last row...
                        goto do_insert;
                    }

                    if(!item){

                        item = new QTableWidgetItem;
                        table->setItem(row, col, item);

                    }

                    item->setText(MSG_INVALID);
                    item->setIcon(QIcon(":/res/error-26.png"));

                    qDebug()<<"return 2";
                    table->setCurrentCell(row, col);
                    return false;

                }

            } else { // got contents!


                if(!dont_check && !CheckCell(item, tid, col)){
                    table->setCurrentCell(row, col);
                    return false;
                }

                if(col_flag(tid, col) & COLF_TRANSL){//translate cell from text to id

                    if(id_coltype(tid, col) == TY_BOOL){

                        if(!item->text().compare(MSG_YES)){

                            //item->setToolTip(tr("%1").arg(BOOL_YES));
                            tl_id = BOOL_YES;
                        } else if(!item->text().compare(MSG_NO)){

                            //item->setToolTip(tr("%1").arg(BOOL_NO));
                            tl_id = BOOL_NO;
                        } else {

                            //item->setToolTip(tr("%1").arg(BOOL_NEUT));
                            tl_id = BOOL_NEUT;
                        }

                    } else if(!strcmp(col_name(tid, col), "store_id")){

                        if(new_store_id > -1){

                            item->setText(tr("%1").arg(new_store_id));
                            tl_id = new_store_id;

                        } else {

                            if(!translate_to_id(db, tid, col, item->text().toUtf8().data(), this_id, &tl_id)){

                                item->setText(MSG_NOTDEF.arg(item->text()));
                                item->setIcon(QIcon(":/res/error-26.png"));
                                table->setCurrentCell(row, col);

                                qDebug()<<"return 3";

                                return false;

                            }

                        }

                    } else {

                        if(new_store_id < 0){

                            if(!translate_to_id(db, tid, col, item->text().toUtf8().data(), this_id, &tl_id)){

                                item->setText(MSG_NOTDEF.arg(item->text()));
                                item->setIcon(QIcon(":/res/error-26.png"));
                                table->setCurrentCell(row, col);

                                qDebug()<<"return 3";

                                return false;

                            }

                        } else {

                            if(!translate_to_id(db, tid, col, item->text().toUtf8().data(), new_store_id, &tl_id)){

                                item->setText(MSG_NOTDEF.arg(item->text()));
                                item->setIcon(QIcon(":/res/error-26.png"));
                                table->setCurrentCell(row, col);

                                qDebug()<<"return 3";

                                return false;

                            }

                        }

                    }

                    item->setToolTip(tr("%1").arg(tl_id));

                }

                if(no_item_qty){
                    if(tid == T_ITEMS && !strcmp(col_name(tid, col), "qty")){
                        item->setToolTip(tr("%1").arg(MSG_DONTUPDATE));
                    }
                }

            }
        }

        ui->progressJob->setValue(row);                

    }

    do_insert:    

    //now that analyse and allocations have finished you may insert rows    

    qDebug()<<"do_insert, nrows "<<nrows;
    int bufsize;
    int needle;
    char* buf;

    for(row = 0; row < nrows - 1; row++){

        bufsize = 0;
        for(col = 0; col < ncols; col++){
            if(col_flag(tid, col) & COLF_TRANSL){
                bufsize += strlen(table->item(row, col)->toolTip().toUtf8().data()) + 1;
            } else {
                bufsize += strlen(table->item(row, col)->text().toUtf8().data()) + 1;
            }

        }

        coldata = (char**)malloc(ncols*sizeof(char**));
        buf = (char*)malloc(bufsize);

        needle = 0;
        for(col = 0; col < ncols; col++){

            coldata[col] = buf + needle;
            if(col_flag(tid, col) & COLF_TRANSL){
                strcpy(coldata[col], table->item(row, col)->toolTip().toUtf8().data());
                needle += strlen(table->item(row, col)->toolTip().toUtf8().data()) + 1;
                item->toolTip().clear();
            } else {
                strcpy(coldata[col], table->item(row, col)->text().toUtf8().data());
                needle += strlen(table->item(row, col)->text().toUtf8().data()) + 1;
            }


            qDebug()<<col<<" "<<coldata[col];

        }

        switch(updatebyid(db, tid, coldata, &updatest)){//try to update first

        case true_:
            qDebug()<<"update ok "<<t_name(tid)<<" id "<<coldata[id_col(tid, "id")];
            break;

        case false_:

             qDebug()<<"update failed "<<t_name(tid)<<" id "<<coldata[id_col(tid, "id")];

            row = nrows;

            finalize(&updatest);
            finalize(&insertst);
            free(coldata);
            free(buf);

            table->setCurrentCell(row, col);

            return false;

            break;

        case continue_:

            qDebug()<<"inserting "<<t_name(tid)<<" id "<<coldata[id_col(tid, "id")];

            if(!insert(db, tid, coldata, &insertst)){//then insert new!

                row = nrows;

                finalize(&updatest);
                finalize(&insertst);
                free(coldata);
                free(buf);

                table->setCurrentCell(row, col);

                return false;

                break;

            }

            break;

        default:
            qDebug()<<"unknown case";
            break;

        }

        ui->progressJob->setValue(row*2);

        free(coldata);
        free(buf);

    }

    qDebug()<<"returns!";

    finalize(&updatest);
    finalize(&insertst);

    ui->labelJob->setText(MSG_IDLE);
    ui->progressJob->setValue(ui->progressJob->maximum());

    return true;

}

void MainWindow::LoadTable(QTableWidget* table, enum table_id tid, int load, int nlogic, struct logic_s *logic, char *sortcol, enum sort_t stype){

    int cols, fakes, i;
    QStringList list;
    struct stmt_s stmt;
    int rows = -1;
    struct QTableWidgetItem* item;
    int date[3];

    table->clearContents();
    for(i = 0; i < table->columnCount(); i++){
        item = table->horizontalHeaderItem(i);
        if(item) delete item;
    }

    table->setGridStyle(Qt::DashLine);

    if(tid == T_INVAL){
        ui->frameScrollWarning->setHidden(true);
        table->setColumnCount(0);
        return;
    }

    ui->labelJob->setText(MSG_LOADING);
    ui->progressJob->setMaximum(100);

    cols = table_cols(tid);
    fakes = table_fakes(tid);

    table->setColumnCount(cols+fakes);    

    for(i = 0; i < cols+fakes; i++){
        list << trUtf8(col_alias(tid, i));

        //TODO: TEMPORARY
        table->setColumnHidden(i, false);

        if((col_flag(tid, i) & COLF_HIDE)){
            if(!godmode){
                table->setColumnHidden(i, true);
            }
        }
    }

    table->setHorizontalHeaderLabels(list);

    for(i = 0; i < cols+fakes; i++){

        if((col_flag(tid, i) & COLF_AUTO) || (col_flag(tid, i) & COLF_FAKE)){
            table->horizontalHeaderItem(i)->setBackgroundColor(QColor(0, 0, 255, 5));
        }

        if((col_flag(tid, i) & COLF_ACCEPTNULL)){
            table->horizontalHeaderItem(i)->setBackgroundColor(QColor(0, 255, 0, 5));
        }

        if((col_flag(tid, i) & COLF_HIDE)){
            table->horizontalHeaderItem(i)->setBackgroundColor(QColor(255,0, 0, 5));
        }
    }


    if(table->horizontalScrollBar()->isVisible()){
        //ui->labelWidth->setText(table->horizontalScrollBar()->parent()->objectName());
        ui->frameScrollWarning->setHidden(true);
    } else {
        ui->frameScrollWarning->setHidden(true);
    }

    if(!load) goto end;

    //load table

    if(!nlogic && !sortcol){
        if(!select_all(db, tid, &stmt)) return;
    } else {
        if(!collect(db, tid, NULL, nlogic, logic, sortcol, stype, &stmt)) return;
    }

    struct stmt_s transl_stmt;

again:
    ui->progressJob->setValue(rows);
    switch(next(&stmt)){

    case true_:
        break;

    case continue_:

        rows++;
        table->insertRow(rows);

        for(i = 0; i < cols; i++){

            item = new QTableWidgetItem;

            switch(id_coltype(tid, i)){

            case TY_BOOL:

                switch(getcol_int(&stmt, i)){
                case BOOL_NO:
                    item->setText(MSG_NO);
                    break;
                case BOOL_YES:
                    item->setText(MSG_YES);
                    break;
                default:
                    if(!strcmp(col_name(tid, i), "course")){
                        item->setText(MSG_NEUT2);
                    } else {
                        item->setText(MSG_NEUT);
                    }
                    break;
                }

                break;

            case TY_INT:
                if(col_flag(tid, i) & COLF_TRANSL){
                    item->setText(trUtf8("%1").arg(translate_to_name(db, tid, i, getcol_int(&stmt, i), this_id, &transl_stmt)));
                } else {
                    item->setText(trUtf8("%1").arg(getcol_int(&stmt, i)));
                }
                break;

            case TY_DATE:
                if(d13_jdayno2jdate((unsigned int)getcol_int(&stmt, i), date) != E13_OK){
                    perr("error resolving date");
                }
                /*
                snprintf(errmsg, 200, "i:%i -> %u -> %i-%i-%i", i, (unsigned int)getcol_int(&stmt, i), date[0], date[1], date[2]);
                perror(errmsg);
                */
                item->setText(trUtf8("%1/%2/%3").arg(date[0]).arg(date[1]).arg(date[2]));
                break;

            case TY_TEXT:
                item->setText(trUtf8("%1").arg(getcol_text(&stmt, i)));
                break;

            default:
                break;

            }

            table->setItem(rows, i, item);
            if(col_flag(tid, i) & COLF_ONETIMEFIX) SolidCell(table, rows, i);

            finalize(&transl_stmt);
        }

        goto again;
        break;

    default:
        finalize(&stmt);
        return;
        break;

    }

    finalize(&stmt);

    ui->progressJob->setValue(100);
    ui->labelJob->setText(MSG_IDLE);

    end:

    table->setRowCount(rows+2);

    //if(ui->tabW->currentIndex() == TABLE_EDIT) table->resizeColumnsToContents();
}

void MainWindow::setChange(int tab, int n){

    if(n > 0){
        t_change[tab] += n;
    } else if(!n){
        t_change[tab] = 0;
    }//else do nothing! just refresh!

    if(hasChange(-1)){
        ui->toolSave->setIcon(QIcon(":/res/save-red-48.png"));
    } else {
        ui->toolSave->setIcon(QIcon(":/res/save-48.png"));
    }

}

bool MainWindow::hasChange(int tab){
    int i;
    if(tab >= 0){
        if(t_change[tab]) return true;
    } else {
        for(i = 0; i < TABLE_N; i++){
            if(t_change[i]) return true;
        }
    }
    return false;
}

QString* MainWindow::exportTable(QTableWidget* table){

    QString* strStream = new QString;
    QTextStream out(strStream);
    QTableWidgetItem* item;
    QString data;

    const int rowCount = table->model()->rowCount();
    const int columnCount = table->model()->columnCount();

//    out.setCodec("UTF-8");
//    out.setGenerateByteOrderMark(true);

    //headers
    for (int column = 0; column < columnCount; column++){
        if (!table->isColumnHidden(column)){
            data = table->horizontalHeaderItem(column)->text().toUtf8();
            out << QString("%1%2").arg(data).arg(column < columnCount - 1?trUtf8(";"):trUtf8(""));
        }
    }
    out << trUtf8("\n");

    // data table
    for (int row = 0; row < rowCount; row++) {
        for (int column = 0; column < columnCount; column++) {
            if (!table->isColumnHidden(column)) {
                item = table->item(row, column);
                data = item?item->text().toUtf8():trUtf8(" ");
                out << QString("%1%2").arg(data).arg(column < columnCount - 1?trUtf8(";"):trUtf8(""));
            }
        }
        out << trUtf8("\n");
    }

    return strStream;
}

void MainWindow::exportReport(int bom){

    QString* report1, *report2;
    QString filename;
    FILE* file;
    char bombuf[] = {0xef, 0xbb, 0xbf, 0x00};

    QStringList list;
    QFileDialog fileDlg;

    fileDlg.setOption(QFileDialog::ShowDirsOnly, true);
    fileDlg.setAcceptMode(QFileDialog::AcceptSave);
    fileDlg.setNameFilter(tr("CSV Text File (*.csv)"));
    fileDlg.setDefaultSuffix(tr("csv"));

    if(fileDlg.exec()){
        list = fileDlg.selectedFiles();
    }
    if(!list.count()) return;

    filename = list.at(0);

    report1 = exportTable(ui->tableReport);

    if(!ui->tableReport2->isHidden()){
        report2 = exportTable(ui->tableReport2);
    } else report2 = NULL;

    file = fopen(filename.toUtf8().data(), "a+");

    //QMessageBox::information(this, tr(""), *report1);    

    if(file){
        if(bom) fwrite(bombuf, strlen(bombuf), 1, file);
        fwrite(report1->toUtf8().data(), report1->toUtf8().size(), 1, file);
        if(report2) fwrite(report2->toUtf8().data(), report2->toUtf8().size(), 1, file);
        fflush(file);
        fclose(file);
    }

    delete report1;
    if(report2) delete report2;

}
