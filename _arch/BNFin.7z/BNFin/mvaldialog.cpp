﻿#include "mvaldialog.h"
#include "ui_mvaldialog.h"

#include "msg.h"
#include "db.h"

#include <QDebug>
#include <QKeyEvent>
#include <QClipboard>

#define MAX_ROWS    15

mvalDialog::mvalDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mvalDialog)
{
    ui->setupUi(this);
}

mvalDialog::mvalDialog(QWidget *parent, QString mvalStr, int max, QString strName, QString strVal) :
    QDialog(parent),
    ui(new Ui::mvalDialog)
{

    struct mval* val;
    char* buf;
    int n;
    QTableWidgetItem* item;

    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowFlags(Qt::WindowTitleHint);

    QStringList list;
    list << strName;
    list << strVal;

    ui->table->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->table->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->table->setColumnCount(2);
    ui->table->setRowCount(max?max:MAX_ROWS);
    ui->table->setHorizontalHeaderLabels(list);

    ui->table->installEventFilter(this);

    if(!mvalStr.isEmpty()){
        buf = dyn_copy_str(mvalStr.toUtf8().data());
        val = parse_multi_field(buf, &n);
        if(val){
            for(int i = 0; i < n; i++){

                qDebug()<<"i: "<<i<<val[i].name<<" && "<<val[i].val;

                item = new QTableWidgetItem;
                ui->table->setItem(i, 0, item);
                item->setText(trUtf8(val[i].name));

                item = new QTableWidgetItem;
                ui->table->setItem(i, 1, item);
                item->setText(trUtf8(val[i].val));
            }
            free(val);
        }
        free(buf);
    }

}

QString mvalDialog::getMvalStr(){
    return retStr;
}

mvalDialog::~mvalDialog()
{
    delete ui;
}

void mvalDialog::on_btnOk_clicked()
{

    int row;
    QTableWidgetItem* itemname, *itemval;

    retStr.clear();

    for(row = 0; row < MAX_ROWS; row++){

        itemname = ui->table->item(row, 0);
        if(!itemname || itemname->text().isEmpty()) continue;

        itemval = ui->table->item(row, 1);
        if(!itemval || itemval->text().isEmpty()) continue;

        retStr.append(itemname->text()).append(":").append(itemval->text()).append(";");

    }

    this->close();
}

void mvalDialog::clearCurCell(QTableWidget* table){

    QList <QTableWidgetItem* > itemList = table->selectedItems();

    while(!itemList.isEmpty()){
        delete itemList.takeFirst();
    }

}

void mvalDialog::setCells(QTableWidget* table, QString str){
    int i, row, col;
    QTableWidgetItem* item;
    int tR, bR, rC, lC, swap;

    QList<QTableWidgetSelectionRange> selList = table->selectedRanges();

    for(i = 0; i < selList.count(); i++){

        tR = selList.at(i).topRow();
        bR = selList.at(i).bottomRow();

        if(tR > bR){
            swap = bR;
            bR = tR;
            tR = swap;
        }

        rC = selList.at(i).rightColumn();
        lC = selList.at(i).leftColumn();

        if(rC > lC){
            swap = lC;
            lC = rC;
            rC = swap;
        }

        for(row = tR; row <= bR; row++){

            for(col = rC; col <= lC; col++){

                item = table->item(row, col);
                if(!item){
                    item = new QTableWidgetItem;
                    table->setItem(row, col, item);
                }
                item->setText(str);

            }

        }

    }

}

bool mvalDialog::eventFilter(QObject *obj, QEvent *event){

    QTableWidget* table;
    QKeyEvent* key;
    QTableWidgetItem* item;
    QString str;

    if( obj->objectName() == tr("table")){

        table = dynamic_cast<QTableWidget*>(obj);
        if(event->type() == QEvent::KeyPress){

            key = dynamic_cast<QKeyEvent*>(event);

            switch(key->key()){

            case Qt::Key_Delete:
                clearCurCell(table);
                break;

            case Qt::Key_C:
                if(key->modifiers() == Qt::ControlModifier){

                    item = table->currentItem();

                    if(item && !item->text().isEmpty()){

                        QApplication::clipboard()->setText(str);

                    }

                }

                break;

            case Qt::Key_V:

                if(key->modifiers() == Qt::ControlModifier){

                    str = QApplication::clipboard()->text();
                    setCells(table, str);

                }

                break;

            default:
                break;
            }

        }
    }
    return false;
}
