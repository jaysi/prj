﻿#include "namedialog.h"
#include "ui_namedialog.h"
#include "msg.h"
#include "db.h"

#include <QMessageBox>

nameDialog::nameDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::nameDialog)
{
    ui->setupUi(this);
}

nameDialog::nameDialog(QWidget *parent, QString nameStr) :
    QDialog(parent),
    ui(new Ui::nameDialog)
{
    char* needle;
    char* start;
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowFlags(Qt::WindowTitleHint);   

    if(!nameStr.isEmpty()){

        //ui->btnOk->setText(nameStr);

        start = dyn_copy_str(nameStr.toUtf8().data());

        //ui->btnOk->setText(trUtf8(start));

        needle = strpbrk(start, ";");
        if(!needle){
            ui->lineSurname->setText(nameStr);
        } else {
            ui->lineName->setText(trUtf8(needle + 1));
            *needle = 0;
            ui->lineSurname->setText(trUtf8(start));
        }

        free(start);
    }

}

nameDialog::~nameDialog()
{
    delete ui;
}

QString nameDialog::getStr(){
    return retStr;
}

void nameDialog::on_btnOk_clicked()
{
    retStr.clear();
    if(!ui->lineSurname->text().isEmpty()){
        retStr.append(ui->lineSurname->text());
        if(!ui->lineName->text().isEmpty()){
            retStr.append(trUtf8(";")).append(ui->lineName->text());
        }
        this->close();
    } else if(!ui->lineName->text().isEmpty()){
        QMessageBox::warning(this, MSG_CHANGE, MSG_SURNAMEFIRST);
    } else {
        this->close();
    }
}
