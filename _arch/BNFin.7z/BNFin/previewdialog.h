﻿#ifndef PREVIEWDIALOG_H
#define PREVIEWDIALOG_H

#include <QDialog>
#include <QString>

#define TEXT_T_PLAIN    0
#define TEXT_T_HTML     1

namespace Ui {
class previewDialog;
}

class previewDialog : public QDialog
{
    Q_OBJECT

public:
    explicit previewDialog(QWidget *parent = 0);
    explicit previewDialog(QWidget *parent = 0, QString strText = tr(""), int textType = 0, QString fontName = tr("B Nazanin"));
    ~previewDialog();

private slots:
    void on_toolNext_clicked();

    void on_toolPrev_clicked();

private:
    Ui::previewDialog *ui;
};

#endif // PREVIEWDIALOG_H
