void MainWindow::printInvoice(){
    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* item, *qty, *ppu, *desc;
    QString d = tr("-");

    const int itemRowCount = ui->tableItems->model()->rowCount();
    int row;

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Invoices</title>"
           "</head>"
           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"
               "<td width=\"20%\" height=\"20\">&nbsp;</td>"
               <<trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>فاكتور فروش</h1></td>")<<
               trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")<<
               "<td width=\"15%\" align=\"right\">" << ui->labelDate->text().toUtf8() <<"</td>"
            "</tr>"
            "<tr>"
              <<trUtf8("<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>خريدار:</h4></td>")<<
              trUtf8("<td align=\"left\"><h4>شماره: </h4></td>")<<
              "<td align=\"right\">" << ui->labelFactorNo->text().toUtf8() <<"</td>"
           "</tr>"
           "<tr>"
           "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p><strong>"<< ui->comboFactorCustomer->currentText().toUtf8() <<" "<< trUtf8("[لقب مشتری]") <<"</strong></p></td>"
            "</tr>"
          "</table>"
          "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
            "<tr >"
              <<trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")<<
              trUtf8("<td width=\"26%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام/كد كالا</h4></td>")<<
              trUtf8("<td width=\"6%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تعداد</h4></td>")<<
              trUtf8("<td width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>قيمت واحد )ريال(</h4></td>")<<
              trUtf8("<td width=\"18%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>قيمت كل )ريال(</h4></td>")<<
              trUtf8("<td width=\"32%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>توضيحات</h4></td>")<<
            "</tr>";
    for(row = 0; row < itemRowCount; row++){

        item = ui->tableItems->item(row, id_col(T_FACTORS, "item_id"));
        if(!item) continue;
        qty = ui->tableItems->item(row, id_col(T_FACTORS, "item_qty"));
        if(!qty) continue;
        ppu = ui->tableItems->item(row, id_col(T_FACTORS, "item_price"));
        if(!ppu) continue;
        desc = ui->tableItems->item(row, id_col(T_FACTORS, "comments"));
        if(desc) d = desc->text().toUtf8();

            out << "<tr>"
                   "<td align=\"center\">"<< row + 1 <<"</td>"
                   "<td><p>"<< item->text().toUtf8() <<" - " << trUtf8("[کد کالا]") << "<br />"
                   "</p></td>"
                   "<td align=\"center\">"<< qty->text().toUtf8() <<"</td>"
                   "<td>"<<ppu->text().toUtf8()<<"</td>"
                   "<td>"<<ppu->text().toUtf8().toInt()*qty->text().toUtf8().toInt()<<"</td>"
                   "<td>" << d <<"</td>"
                   "</tr>";
    }
    out << "</tr>";
    out << "<tr>"
           "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>جمع كل فاكتور )ريال:(</h4></td>")<<
           "<td>"<<ui->linePriceSum->text().toUtf8()<<"</td>"
           "</tr>"
           "<tr>"
             "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>درصد تخفيف:</h4></td>")<<
           "<td>"<<ui->lineDiscount->text().toUtf8()<<"</td>"
           "</tr>"
           "<tr>"
             "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>مبلغ تخفيف )ريال:(</h4></td>")<<
           "<td>"<<(ui->lineDiscount->text().toUtf8().toInt()/100)*ui->linePriceSum->text().toUtf8().toInt()<<"</td>"
           "</tr>"
           "<tr>"
             "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>جمع عوارض/ماليات )ريال:(</h4></td>")<<
           "<td>"<<ui->lineTax->text().toUtf8()<<"</td>"
           "</tr>"
           "<tr>"
             "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>مبلغ قابل پرداخت )ريال:(</h4></td>")<<
            "<td>"<<ui->lineTotalPrice->text().toUtf8()<<"</td>"
           "</tr>"
           "<tr>"
             "<td colspan=\"4\" align=\"center\"><p><br />"
             "</p></td>"
           "<td colspan=\"2\" align=\"right\"><p>"<<tr("[قیمت به حروف]")<<"</p></td>"
           "</tr>"
           "</table>"
           "<p>&nbsp;</p>"
           "<table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">"
             "<tr>"
               <<trUtf8("<td width=\"50%\" align=\"center\" valign=\"middle\"><p>امضاء فروشنده</p></td>")<<
               trUtf8("<td width=\"50%\" align=\"center\" valign=\"middle\">مهر و امضاء خريدار</td>")<<
             "</tr>"
           "</table>"
           "</body>"
           "</html>";

    QTextDocument *document = new QTextDocument();
    document->setDefaultFont(QFont(tr(DEF_FONT)));
    document->setHtml(strStream);

    QPrinter printer;

    QPrintDialog *dialog = new QPrintDialog(&printer, NULL);
    printer.setOrientation(QPrinter::Landscape);
    if (dialog->exec() == QDialog::Accepted) {
        document->print(&printer);
    }

    delete document;
}
