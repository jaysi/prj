﻿#ifndef DB_H
#define DB_H

#include "../sqlite/sqlite3.h"


#define false_ 0
#define true_ 1
#define continue_ 2

#define STMT_MAGIC  0xd1ef

#define MAIN_STORE_CODE 0

#define DB_SUFFIX "bnf"

#define DBFILE  "bnf.db"

#define MAXIDLEN    20

#define DEF_ROWS    100

typedef unsigned short col_flag_t;

#define COLF_AUTO       (0x0001<<0)
#define COLF_HIDE       (0x0001<<1)
#define COLF_TRANSL     (0x0001<<2)//translated
#define COLF_SINGULAR   (0x0001<<3)
#define COLF_ONETIMEFIX (0x0001<<4)//defined once!
#define COLF_LIST       (0x0001<<5)
#define COLF_FAKE       (0x0001<<6)
#define COLF_ACCEPTNULL (0x0001<<7)
#define COLF_END        0

#define TVIEW_GOD   (0x01<<0)
#define TVIEW_MGR   (0x01<<1)
#define TVIEW_USR   (0x01<<2)
#define TVIEW_ALL   (TVIEW_GOD|TVIEW_MGR|TVIEW_USR)

#define BOOL_NO     0
#define BOOL_YES    1
#define BOOL_NEUT   2

enum table_id{
    T_STORES,
    T_OFFERS,
    T_PAYTYPES,
    T_TRANSTYPES,
    T_TRANSTATS,
    T_SEX,
    T_SPECIALITY,
    T_BANKS,
    T_RANK,
    T_SOCIALSTYLE,
    T_CUSTOMERTYPE,
    T_ITEMS,
    T_CUSTOMERS,
    T_FACTORS,
    T_PAYMENTS,
    T_SENDS,
    T_INVAL
};

enum type_id{
    TY_INT,
    TY_TEXT,
    TY_DATE,
    TY_BOOL,
    TY_INVAL
};

struct cell_s{
    enum type_id type;
    char* data;
};

#define NSTMT 5

struct db_s{
    void* h;
    char* alias;
    char* path;

    int this_id;

    struct db_s* next;

};

struct stmt_s{
    unsigned short magic;
    void* h;
    struct db_s* db;
};

enum sort_t{

    SO_DEC,
    SO_INC //increase, from small to large!

};

enum logic_comb_t{
    LOGICOMB_NONE,
    LOGICOMB_AND,
    LOGICOMB_OR,
    LOGICOMB_INVAL
};

enum logic_t{

    LOGIC_LIKE,
    LOGIC_NOTLIKE,
    LOGIC_EQ,
    LOGIC_NE,
    LOGIC_LT,
    LOGIC_LE,
    LOGIC_GT,
    LOGIC_GE,
    LOGIC_BETWEEN,

    LOGIC_INVAL
};

#define LOGICF_COL_CMP  (0x01<<0) //compare columns

struct logic_s{
    char flags;
    enum logic_comb_t comb;
    int col;
    enum logic_t logic;
    char* sval;
    int ival;
};

struct rec_s{
    char* data;
    int idata;
};

struct col_s{
    struct rec_s* rec;
};

struct row_s{
    struct col_s* col;
};

struct mval{
    char* name;
    char* val;
};

#ifdef __cplusplus
extern "C"{
#endif

int translate_name_to_id(struct db_s* db, enum table_id tid, char* text, int* id);
char* fact_type_name(int paytype_id);
int init_db(struct db_s* db, char* name, char* alias);
int close_db(struct db_s* db);
char* t_name(enum table_id id);
char* col_alias(enum table_id id, int col);
char* col_name(enum table_id id, int col);
int id_col(enum table_id id, char* name);
int id_col_alias(enum table_id id, char* alias);
enum table_id id_table(char* name);
int table_cols(enum table_id id);
enum table_id id_table_alias(char* alias);
char* t_alias(enum table_id id);
int finalize(struct stmt_s* stmt);
const char *getcol_text(struct stmt_s* stmt, int col);
int getcol_int(struct stmt_s *stmt, int col);
int next(struct stmt_s *stmt);
int select_all(struct db_s* db, enum table_id id, struct stmt_s* stmt);
enum type_id id_coltype(enum table_id tid, int col);
col_flag_t col_flag(enum table_id tid, int col);
int collect(struct db_s* db, enum table_id id,
           char** cols,
           int nlogic, struct logic_s* logic,
           char* sortcol, enum sort_t stype,
           struct stmt_s* st);
int insert(struct db_s* db, enum table_id id, char** col, struct stmt_s* st);
int reset(struct stmt_s* st);
int get_this_store_id(struct db_s* db);
int get_last_id(struct db_s* db, enum table_id tid);
int get_last_factorid(struct db_s* db);
int translate_to_id(struct db_s *db, enum table_id tid, int col, char* text, int store_id, int *id);
int updatebyid(struct db_s* db, enum table_id id, char** col, struct stmt_s* st);
int init_this_store(struct db_s* db, int this_id, char* this_name, char* this_addr, char* this_contact);
int this_store_info(struct db_s* db, int* this_id, char** this_name, char** this_addr, char** this_contact);
int update_this_store(struct db_s* db, int this_id, char* this_name, char* this_addr, char* this_contact);
void free_rowset(void **rowset);
int rollback(struct db_s* db);
int table_fakes(enum table_id id);
char* translate_to_name(struct db_s* db, enum table_id tid, int col, int id, int store_id, struct stmt_s *st);
int delete_id(struct db_s* db, enum table_id tid, char* col, int id, int store_id, struct stmt_s *st);
int translate_to_col_int(struct db_s* db, enum table_id tid, int col, int id, int store_id, struct stmt_s* st);
char* db_alias(struct db_s* db);
//int get_int_by_id(struct db_s* db, enum table_id tid, int id, int store_id, int col, int* val);
int trunc_table(struct db_s* db, enum table_id tid);
int update_col_byid(struct db_s* db, enum table_id tid, int id, int store_id, int col, char* val, struct stmt_s* st);
enum table_id t_next(enum table_id i);
struct db_s* find_db_path(struct db_s* first, char* path);
struct db_s* find_db_alias(struct db_s* first, char* alias);
int start_trans(struct db_s* db);
int end_trans(struct db_s* db);
void set_col_flag(enum table_id tid, int col, col_flag_t flag);
void unset_col_flag(enum table_id tid, int col, col_flag_t flag);
int update_item_qty(struct db_s* db, int id, int store_id, int qty, struct stmt_s* st);
char t_view(enum table_id tid);
char* create_multi_field(int n, struct mval* val);
struct mval* parse_multi_field(char* mstr, int* n);
char* dyn_copy_str(char* str);

#ifdef __cplusplus
}
#endif

#endif // DB_H
