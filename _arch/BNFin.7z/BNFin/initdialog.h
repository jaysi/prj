﻿#ifndef INITDIALOG_H
#define INITDIALOG_H

#include <QDialog>

namespace Ui {
class initDialog;
}

class initDialog : public QDialog
{
    Q_OBJECT

public:
    explicit initDialog(QWidget *parent = 0);
    ~initDialog();

private:
    Ui::initDialog *ui;

protected:
//    void showEvent(QShowEvent *event);
};

#endif // INITDIALOG_H
