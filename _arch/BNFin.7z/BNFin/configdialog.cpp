﻿#include "configdialog.h"
#include "ui_configdialog.h"

#include "msg.h"

#include <QMessageBox>

ConfigDialog::ConfigDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConfigDialog)
{
    ui->setupUi(this);
    db = NULL;
    connect(this, SIGNAL(rejected()), this, SLOT(escape()));
}

ConfigDialog::~ConfigDialog()
{
    delete ui;
}

void ConfigDialog::setDB(struct db_s *dbptr){
    db = dbptr;
}

void ConfigDialog::setConfig(struct config *conf){

    cfg = conf;

}

void ConfigDialog::showEvent(QShowEvent *event){

    if(!db){
        ui->btnSave->setEnabled(false);
    } else {
        ui->btnSave->setEnabled(true);
    }

    event->accept();
}

void ConfigDialog::setMode(int mode){

}

void ConfigDialog::on_btnSave_clicked()
{
    this->close();
}

void ConfigDialog::escape(){
    this->close();
}

void ConfigDialog::closeEvent(QCloseEvent *event){

    event->accept();
}
