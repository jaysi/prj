﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"

#include "db.h"

#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>

#include <QList>
#include <QMap>

#define IFLAG_STORE (0x00000001<<0)
#define IFLAG_ITEM (0x00000001<<1)
#define IFLAG_QTY (0x00000001<<2)
#define IFLAG_DATE (0x00000001<<3)
#define IFLAG_BANK (0x00000001<<4)
#define IFLAG_PAYTYPE (0x00000001<<5)
#define IFLAG_TRANSTYPE (0x00000001<<6)
#define IFLAG_TRANSTAT (0x00000001<<7)
#define IFLAG_CUSTOMER (0x00000001<<8)
#define IFLAG_FACTORID (0x00000001<<9)
#define IFLAG_SEX   (0x00000001<<10)
#define IFLAG_SPEC   (0x00000001<<11)
#define IFLAG_RANK   (0x00000001<<12)
#define IFLAG_SOCIALSTYLE   (0x00000001<<13)
#define IFLAG_CUSTOMERTYPE   (0x00000001<<14)
#define IFLAG_HEYATELMI   (0x00000001<<15)
#define IFLAG_COURSE   (0x00000001<<16)
#define IFLAG_CLUB   (0x00000001<<17)

#define IGLOBALFLAG_CUSTOMER (IFLAG_DATE|IFLAG_CUSTOMER|IFLAG_SEX|IFLAG_SPEC|IFLAG_RANK|IFLAG_SOCIALSTYLE|IFLAG_CUSTOMERTYPE|IFLAG_HEYATELMI|IFLAG_COURSE|IFLAG_CLUB)

#define MAX_LOGIC 10000

enum logic_t MainWindow::strToLogic(QString str){
    if(str == MSG_LT) return LOGIC_LT;
    if(str == MSG_GT) return LOGIC_GT;
    if(str == MSG_LE) return LOGIC_LE;
    if(str == MSG_GE) return LOGIC_GE;
    if(str == MSG_EQ) return LOGIC_EQ;
    if(str == MSG_NE) return LOGIC_NE;
    return LOGIC_INVAL;
}

int MainWindow::strToBool(QString str){
    if(str == MSG_YES) return 1;
    if(str == MSG_NO) return 0;
    if(str == MSG_NEUT || str == MSG_NEUT2) return 2;
    return -1;
}

void MainWindow::makeLogic(enum table_id tid, long flags, struct logic_s* logic, int* nlogic){

    *nlogic = 0;
    int id;
    QList<int> fno;
//    char t[MAXTIME], t2[MAXTIME];

    RcurFilter.clear();

    if(!ui->RcomboStore->currentText().isEmpty() && (flags & IFLAG_STORE)){

        logic[*nlogic].col = id_col(tid, "store_id");
        if(!translate_name_to_id(db, T_STORES, ui->RcomboStore->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 1";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;        
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("نمایندگی"));

    }

    if(!ui->RcomboItem->currentText().isEmpty() && (flags & IFLAG_ITEM)){

        if(tid == T_ITEMS) logic[*nlogic].col = id_col(tid, "id");
        else logic[*nlogic].col = id_col(tid, "item_id");
        if(!translate_name_to_id(db, T_ITEMS, ui->RcomboItem->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 2";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("کالا"));

    }

    if(!ui->RcomboQtyLogic->currentText().isEmpty() && (flags & IFLAG_QTY)){

        if(tid == T_ITEMS) logic[*nlogic].col = id_col(tid, "qty");
        else logic[*nlogic].col = id_col(tid, "item_qty");

        if(!ui->RcheckMinQty->isChecked()){
            logic[*nlogic].ival = ui->RspinItemQty->value();
            logic[*nlogic].flags = 0;
        } else if(tid == T_ITEMS){
            logic[*nlogic].sval = "minqty";
            logic[*nlogic].flags = LOGICF_COL_CMP;
        }

        logic[*nlogic].logic = strToLogic(ui->RcomboQtyLogic->currentText());
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("تعداد"));

    }

    if(!ui->RcomboDate->currentText().isEmpty() && (flags & IFLAG_DATE)){

        logic[*nlogic].col = id_col(tid, "date");
        logic[*nlogic].logic = strToLogic(ui->RcomboDate->currentText());
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

//        logic[*nlogic].sval = ui->RlineStartDate->text().toUtf8().data();

        logic[*nlogic].sval = (char*)malloc(strlen(ui->RlineStartDate->text().toUtf8().data())+1);
        strcpy(logic[*nlogic].sval, ui->RlineStartDate->text().toUtf8().data());

        (*nlogic)++;

        if(ui->RcomboDate->currentText() == MSG_BETWEEN){
            logic[(*nlogic)-1].logic = LOGIC_GE;//correct prev

            logic[*nlogic].col = id_col(tid, "date");
            logic[*nlogic].logic = LOGIC_LE;
            logic[*nlogic].flags = 0;
            logic[*nlogic].comb = LOGICOMB_AND;

//            logic[*nlogic].sval = ui->RlineEndDate->text().toUtf8().data();

            logic[*nlogic].sval = (char*)malloc(strlen(ui->RlineEndDate->text().toUtf8().data())+1);
            strcpy(logic[*nlogic].sval, ui->RlineEndDate->text().toUtf8().data());

            (*nlogic)++;

        }

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("تاریخ"));

    }

    if(!ui->RcomboBank->currentText().isEmpty() && (flags & IFLAG_BANK)){

        logic[*nlogic].col = id_col(tid, "bank_id");
        if(!translate_name_to_id(db, T_BANKS, ui->RcomboBank->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 3";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("بانک"));

    }

    if(!ui->RcomboPayType->currentText().isEmpty() && (flags & IFLAG_PAYTYPE)){

        logic[*nlogic].col = id_col(tid, "paytype_id");
        if(!translate_name_to_id(db, T_PAYTYPES, ui->RcomboPayType->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 4";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("روش پرداخت"));

    }

    if(!ui->RcomboTransType->currentText().isEmpty() && (flags & IFLAG_TRANSTYPE)){

        logic[*nlogic].col = id_col(tid, "transtype_id");
        if(!translate_name_to_id(db, T_TRANSTYPES, ui->RcomboTransType->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 5";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("نوع تراکنش"));

    }

    if(!ui->RcomboTransStat->currentText().isEmpty() && (flags & IFLAG_TRANSTAT)){

        logic[*nlogic].col = id_col(tid, "transtat_id");
        if(!translate_name_to_id(db, T_TRANSTATS, ui->RcomboTransStat->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("وضعیت تراکنش"));

    }

    if(!ui->RcomboCustomer->currentText().isEmpty() && (flags & IFLAG_CUSTOMER)){

        logic[*nlogic].col = id_col(tid, "customer_id");
        if(!translate_name_to_id(db, T_CUSTOMERS, ui->RcomboCustomer->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("مشتری"));

    }

    if(!ui->RlineFactorNo->text().isEmpty() && (flags & IFLAG_FACTORID)){

        int fno1, fno2, max, min;
        char* start, *end, ch, *buf;

        fno1 = -1;
        fno2 = -2;

        buf = (char*)malloc(ui->RlineFactorNo->text().toUtf8().size()+1);

        strcpy(buf, ui->RlineFactorNo->text().toUtf8().data());

        start = buf;

        int i;
        while(start){

            end = strpbrk(start, ",-");

            if(end){
                qDebug()<<"end: "<<tr(end);
                ch = *end;
                *end = 0;
            } else {
                qDebug()<<"end: NULL";
                ch = 0;
            }

            qDebug()<<"start: "<<tr(start);

            if(fno1 < 0){

                if(ch == '-'){

                    i = atoi(start);
                    if(i < 0){
                        QMessageBox::warning(this, MSG_VALIDITY, MSG_INVALIDFORMAT);
                        free(buf);
                        return;
                    }

                    fno1 = i;

                }
                else{

                    i = atoi(start);
                    if(i < 0){
                        QMessageBox::warning(this, MSG_VALIDITY, MSG_INVALIDFORMAT);
                        free(buf);
                        return;
                    }

                    fno << i;
                }

            } else {

                if(ch == '-'){//false
                    QMessageBox::warning(this, MSG_VALIDITY, MSG_INVALIDFORMAT);
                    free(buf);
                    return;
                } else {

                    i = atoi(start);

                    if(i < 0){
                        QMessageBox::warning(this, MSG_VALIDITY, MSG_INVALIDFORMAT);
                        free(buf);
                        return;
                    }

                    fno2 = i;
                }

            }

            if(fno1 > -1 && fno2 > -1){

                if(fno1 > fno2) {max = fno1; min = fno2;}
                else {max = fno2; min = fno1;}

                for(i = min; i <= max; i++){
                    fno << i;
                }

                fno1 = -1;
                fno2 = -1;

            }

            if(end){
                *end = ch;
                start = end + 1;
            } else {
                start = NULL;
            }
        }

        qDebug()<<fno;

        free(buf);

        for(i = 0; i < fno.count(); i++){

            logic[*nlogic].ival = fno.at(i);

            logic[*nlogic].col = id_col(tid, "factor_id");

            //logic[*nlogic].ival = ui->RlineFactorNo->text().toInt();
            logic[*nlogic].flags = 0;
            logic[*nlogic].logic = LOGIC_EQ;
            logic[*nlogic].comb = (i==fno.count()-1?LOGICOMB_AND:LOGICOMB_OR);

            (*nlogic)++;

        }

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("شماره فاکتور"));

    }

    if(!ui->RcomboSex->currentText().isEmpty() && (flags & IFLAG_SEX)){

        logic[*nlogic].col = id_col(tid, "sex_id");
        if(!translate_name_to_id(db, T_SEX, ui->RcomboSex->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("جنسیت"));

    }

    if(!ui->RcomboSpec->currentText().isEmpty() && (flags & IFLAG_SPEC)){

        logic[*nlogic].col = id_col(tid, "speciality_id");
        if(!translate_name_to_id(db, T_SPECIALITY, ui->RcomboSpec->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("تخصص"));

    }

    if(!ui->RcomboRank->currentText().isEmpty() && (flags & IFLAG_RANK)){

        logic[*nlogic].col = id_col(tid, "rank_id");
        if(!translate_name_to_id(db, T_RANK, ui->RcomboRank->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("رتبه"));

    }


    if(!ui->RcomboSocialStyle->currentText().isEmpty() && (flags & IFLAG_SOCIALSTYLE)){

        logic[*nlogic].col = id_col(tid, "socialstyle_id");
        if(!translate_name_to_id(db, T_SOCIALSTYLE, ui->RcomboSocialStyle->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("موقعیت اجتماعی"));

    }

    if(!ui->RcomboCustomerType->currentText().isEmpty() && (flags & IFLAG_CUSTOMERTYPE)){

        logic[*nlogic].col = id_col(tid, "customertype_id");
        if(!translate_name_to_id(db, T_CUSTOMERTYPE, ui->RcomboCustomerType->currentText().toUtf8().data(), &id)){
            qDebug()<<"return 6";
            return;
        }
        logic[*nlogic].ival = id;
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("نوع مشتری"));

    }

    if(!ui->RcomboHeyatElmi->currentText().isEmpty() && (flags & IFLAG_HEYATELMI)){

        logic[*nlogic].col = id_col(tid, "heyatelmi");
        logic[*nlogic].ival = strToBool(ui->RcomboHeyatElmi->currentText());
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("عضویت در هیات علمی"));

    }

    if(!ui->RcomboCourse->currentText().isEmpty() && (flags & IFLAG_COURSE)){

        logic[*nlogic].col = id_col(tid, "course");
        logic[*nlogic].ival = strToBool(ui->RcomboCourse->currentText());
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("گذراندن دوره آموزشی"));

    }

    if(!ui->RcomboClubMember->currentText().isEmpty() && (flags & IFLAG_CLUB)){

        logic[*nlogic].col = id_col(tid, "club");
        logic[*nlogic].ival = strToBool(ui->RcomboClubMember->currentText());
        logic[*nlogic].logic = LOGIC_EQ;
        logic[*nlogic].flags = 0;
        logic[*nlogic].comb = LOGICOMB_AND;

        (*nlogic)++;

        if(!RcurFilter.isEmpty()) RcurFilter.append(MSG_RSEP);
        RcurFilter.append(trUtf8("عضویت در کلوپ"));

    }

}

void MainWindow::on_RcheckMinQty_clicked()
{
    if(!ui->RcheckMinQty->isChecked()){

        ui->RspinItemQty->setEnabled(true);
        ui->RspinItemQty->setValue(0);

    } else {

        ui->RspinItemQty->setEnabled(false);

    }
}

void MainWindow::on_RcomboDate_currentIndexChanged(const QString &arg1)
{
    if(arg1 == MSG_BETWEEN){
        ui->RlineEndDate->setEnabled(true);
        ui->RcheckEndDateToday->setEnabled(true);
    } else {
        ui->RlineEndDate->clear();
        ui->RlineEndDate->setEnabled(false);
        ui->RcheckEndDateToday->setEnabled(false);
        ui->RcheckEndDateToday->setChecked(false);
    }
}

void MainWindow::on_RradioStore_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;

    report = R_ITEM;

    ui->tableReport2->setHidden(true);

    makeLogic(T_ITEMS, IFLAG_STORE|IFLAG_ITEM|IFLAG_QTY|IFLAG_DATE, logic, &nlogic);

    qDebug()<<"Load";    

    LoadTable(ui->tableReport, T_ITEMS, 1, nlogic, logic);

    RecalcStore(ui->tableReport, ui->RlineTotalPrice);

}

void MainWindow::on_RradioSale_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;

    report = R_SALE;

    ui->tableReport2->setHidden(true);

    makeLogic(T_FACTORS, IFLAG_STORE|IFLAG_ITEM|IFLAG_QTY|IFLAG_DATE|IFLAG_TRANSTYPE|IGLOBALFLAG_CUSTOMER|IFLAG_FACTORID, logic, &nlogic);

    qDebug()<<"Load";

    unset_col_flag(T_FACTORS, id_col(T_FACTORS, "factor_id"), COLF_HIDE);

    LoadTable(ui->tableReport, T_FACTORS, 1, nlogic, logic);

    set_col_flag(T_FACTORS, id_col(T_FACTORS, "factor_id"), COLF_HIDE);

    RecalcSales(ui->tableReport, ui->RlineTotalPrice);
}


void MainWindow::on_RradioTrans_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;

    report = R_TRANS;

    ui->tableReport2->setHidden(true);

    makeLogic(T_PAYMENTS, IFLAG_STORE|IFLAG_DATE|IFLAG_TRANSTAT|IFLAG_BANK|IFLAG_PAYTYPE|IFLAG_FACTORID, logic, &nlogic);

    qDebug()<<"Load";

    unset_col_flag(T_PAYMENTS, id_col(T_PAYMENTS, "factor_id"), COLF_HIDE);

    LoadTable(ui->tableReport, T_PAYMENTS, 1, nlogic, logic);

    set_col_flag(T_PAYMENTS, id_col(T_PAYMENTS, "factor_id"), COLF_HIDE);

    RecalcPays(ui->tableReport, ui->RlineTotalPrice);
}

void MainWindow::on_RradioFinance_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;
    long sale;

    report = R_FIN;

    ui->tableReport2->setHidden(false);

    makeLogic(T_FACTORS, IFLAG_STORE|IFLAG_ITEM|IFLAG_QTY|IFLAG_DATE|IFLAG_TRANSTYPE|IGLOBALFLAG_CUSTOMER|IFLAG_FACTORID, logic, &nlogic);

    qDebug()<<"Load";

    unset_col_flag(T_FACTORS, id_col(T_FACTORS, "factor_id"), COLF_HIDE);

    LoadTable(ui->tableReport, T_FACTORS, 1, nlogic, logic);

    set_col_flag(T_FACTORS, id_col(T_FACTORS, "factor_id"), COLF_HIDE);

    RecalcSales(ui->tableReport, ui->RlineTotalPrice);

    sale = ui->RlineTotalPrice->text().toLong();

    makeLogic(T_PAYMENTS, IFLAG_STORE|IFLAG_DATE|IFLAG_TRANSTAT|IFLAG_BANK|IFLAG_PAYTYPE|IFLAG_FACTORID, logic, &nlogic);

    qDebug()<<"Load";

    unset_col_flag(T_PAYMENTS, id_col(T_PAYMENTS, "factor_id"), COLF_HIDE);

    LoadTable(ui->tableReport2, T_PAYMENTS, 1, nlogic, logic);

    set_col_flag(T_PAYMENTS, id_col(T_PAYMENTS, "factor_id"), COLF_HIDE);

    RecalcPays(ui->tableReport2, ui->RlineTotalPrice);

    sale += ui->RlineTotalPrice->text().toLong();

    ui->RlineTotalPrice->setText(tr("%1").arg(sale));
}

void MainWindow::on_RradioSend_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;

    report = R_SEND;

    ui->tableReport2->setHidden(true);

    makeLogic(T_SENDS, IFLAG_STORE|IFLAG_ITEM|IFLAG_QTY|IFLAG_DATE|IFLAG_TRANSTYPE, logic, &nlogic);

    qDebug()<<"Load";

    LoadTable(ui->tableReport, T_SENDS, 1, nlogic, logic);

}

void MainWindow::on_RradioCustomers_clicked()
{
    struct logic_s logic[MAX_LOGIC];
    int nlogic;

    report = R_CUSTOMER;

    ui->tableReport2->setHidden(true);

    makeLogic(T_CUSTOMERS, IGLOBALFLAG_CUSTOMER, logic, &nlogic);

    qDebug()<<"Load";

    LoadTable(ui->tableReport, T_CUSTOMERS, 1, nlogic, logic);
}
