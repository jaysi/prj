﻿#include <QApplication>
#include <QMessageBox>
#include <QStyleFactory>

#include "mainwindow.h"
#include "initdialog.h"

#include <unistd.h>
#include <QTimer>

int main(int argc, char *argv[])
{

/*
GTK Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-gtk.html
Windows Vista Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-windowsvista.html
Windows XP Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-windowsxp.html
Macintosh Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-macintosh.html
Fusion Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-fusion.html
Windows Style Widget Gallery | QtWidgets 5.1
qthelp://org.qt-project.qtwidgets.511/qtwidgets/gallery-windows.html

The QStyleFactory class creates QStyle objects.

The QStyle class is an abstract base class that encapsulates the look and feel of a GUI. QStyleFactory creates a QStyle object using the create() function and a key identifying the style. The styles are either built-in or dynamically loaded from a style plugin (see QStylePlugin).

The valid keys can be retrieved using the keys() function. Typically they include "windows" and "fusion". Depending on the platform, "windowsxp", "windowsvista", "gtk" and "macintosh" may be available. Note that keys are case insensitive.

*/

    QApplication::setStyle(QStyleFactory::create("fusion"));
    QApplication a(argc, argv);

    MainWindow w;
//    initDialog ini;

//    ini.show();

    while(*argv){
        if(!strcmp(*argv, "swchan") || strstr(*argv, "bnfgod")){
            w.set_godmode();
            break;
        } else if(!strcmp(*argv, "dnstuff") || strstr(*argv, "bnfmain")){
            w.set_managermode();
            break;
        }

        argv++;
    }

    w.show();    
    
    return a.exec();
}
