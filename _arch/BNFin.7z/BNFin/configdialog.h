﻿#ifndef CONFIGDIALOG_H
#define CONFIGDIALOG_H

#include <QDialog>
#include <QShowEvent>
#include <QString>

#include "db.h"

struct config{
    QString printFontName;
    int printOutput;
    int max_contact;    
};

namespace Ui {
class ConfigDialog;
}

class ConfigDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ConfigDialog(QWidget *parent = 0);
    ~ConfigDialog();

    void setDB(struct db_s* dbptr);
    void setMode(int mode);
    void setConfig(struct config* conf);

private slots:
    void on_btnSave_clicked();
    void escape();

//    void on_btnCancel_clicked();

private:    
    Ui::ConfigDialog *ui;
    struct db_s* db;
    int mode;

    struct config* cfg;

protected:
    void showEvent(QShowEvent *);
    void closeEvent(QCloseEvent *event);
};

#endif // CONFIGDIALOG_H
