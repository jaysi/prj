﻿#ifndef NAMEDIALOG_H
#define NAMEDIALOG_H

#include <QDialog>

namespace Ui {
class nameDialog;
}

class nameDialog : public QDialog
{
    Q_OBJECT

public:
    explicit nameDialog(QWidget *parent = 0);
    explicit nameDialog(QWidget *parent = 0, QString nameStr = tr(""));
    ~nameDialog();

    QString getStr();

private slots:
    void on_btnOk_clicked();

private:
    Ui::nameDialog *ui;

    QString retStr;
};

#endif // NAMEDIALOG_H
