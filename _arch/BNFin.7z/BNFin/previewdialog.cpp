﻿#include "previewdialog.h"
#include "ui_previewdialog.h"

previewDialog::previewDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::previewDialog)
{
    ui->setupUi(this);
}

previewDialog::previewDialog(QWidget *parent, QString strText, int textType, QString fontName) :
    QDialog(parent),
    ui(new Ui::previewDialog)
{
    ui->setupUi(this);

    QFont font(fontName);

    ui->textBrowser->setFont(font);

    switch(textType){
    case TEXT_T_PLAIN:
        ui->textBrowser->setPlainText(strText);
        break;
    case TEXT_T_HTML:
        ui->textBrowser->setHtml(strText);
        break;
    }

}

previewDialog::~previewDialog()
{
    delete ui;
}

void previewDialog::on_toolNext_clicked()
{
    ui->textBrowser->scroll(0, 10);
}

void previewDialog::on_toolPrev_clicked()
{
    ui->textBrowser->scroll(0, -10);
}
