﻿#include "initdialog.h"
#include "ui_initdialog.h"

#include <QShowEvent>
#include <unistd.h>

initDialog::initDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::initDialog)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);

    ui->progressBar->setRange(0, 0);
}

initDialog::~initDialog()
{
    delete ui;
}

//void initDialog::showEvent(QShowEvent *event){
//}
