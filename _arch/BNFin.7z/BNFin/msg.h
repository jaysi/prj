﻿#ifndef MSG_H
#define MSG_H

#define MSG_SUFFIX  "bnf"

#define MSG_DONTUPDATE "*.*"

#define MSG_CENTRAL "مرکزی"
#define MSG_MAINCONTACT "تلفن ثابت 1:-;"
#define MSG_MAINADDR "نشانی 1:-;"
#define MSG_IDLE  trUtf8("آماده")
#define MSG_MAIN    "اصلی"
#define MSG_STOREINFO   trUtf8("نمایندگی: %1 | نشانی: %2 | تماس: %3")
#define MSG_CHANGE  trUtf8("ثبت داده")
#define MSG_SAVECHANGE  trUtf8("شما تغییرات ذخیره نشده ای دارید! آیا میخواهید از نرم افزار خارج شوید؟")
#define MSG_SAVING  trUtf8("تحلیل و نوشتن داده ها")
#define MSG_INVALID trUtf8("غیر قابل قبول")
#define MSG_NOTDEF  trUtf8("در این نمایندگی (%1) معرفی نشده")
#define MSG_LOADING trUtf8("بارگذاری داده ها")
#define MSG_NOLOAD trUtf8("بارگذاری پایگاه داده (%1) ناموفق بود.")
#define MSG_NOCHANGE trUtf8("تغییری داده نشده.")
#define MSG_SAVEFAIL    trUtf8("عملیات بروز رسانی/درج در پایگاه داده ها ناموفق بود؛ لطفاً موارد مشخص شده را اصلاح نمایید.")
#define MSG_ORDER   trUtf8("ترتیب")
#define MSG_ITEMFIRST   trUtf8("ابتدا نوع کالا را مشخص نمایید.")
#define MSG_VALIDITY    trUtf8("صحت اطلاعات")
#define MSG_STORE   trUtf8("انبار")
#define MSG_NOTENOUGH   trUtf8("موجودی کافی نمیباشد (مقدار: %1).")
#define MSG_LOW trUtf8("موجودی حداقل میباشد (مقدار: %1).")
#define MSG_SAVEFIRST trUtf8("ابتدا تغییرات را ذخیره نمایید.")
#define MSG_INVALIDFORMAT trUtf8("قالب اشتباه است.")
#define MSG_PRINT   trUtf8("چاپ")
#define MSG_FULL    trUtf8("پر")
#define MSG_EMPTY    trUtf8("خالی")
#define MSG_LT  trUtf8("کمتر از")
#define MSG_GT  trUtf8("بیشتر از")
#define MSG_EQ  trUtf8("مساوی با")
#define MSG_NE  trUtf8("نامساوی با")
#define MSG_LE  trUtf8("کمتر یا مساوی با")
#define MSG_GE  trUtf8("بیشتر یا مساوی با")
#define MSG_MIN trUtf8("حداقل")
#define MSG_BETWEEN trUtf8("مابین")
#define MSG_MERGE trUtf8("پایگاه داده ' %1 ' در پایگاه داده ' %2 ' ترکیب خواهد شد، آیا ادامه میدهید؟")
#define MSG_DST trUtf8("نمایندگی مقصد انتخاب نشده، آیا ادامه میدهید؟")
#define MSG_EMPTYFIELD trUtf8("کلیه فیلدها باید دارای مقدار باشند.")
#define MSG_NEEDSTORE   trUtf8("نماینگی را مشخص نمایید")
#define MSG_DELETE  trUtf8("حذف")
#define MSG_DELETEFACTOR trUtf8("فاکتور شماره (%1) حذف خواهد شد؛ ادامه میدهید؟")
#define MSG_CSVFAIL trUtf8("ذخیره سازی در قالب متن ناموفق بود.")
#define MSG_DUPLICATE trUtf8("داده تکراری است!")
#define MSG_BADPERCENT  trUtf8("از مقادیر بین 0 تا 100 برای درصد استفاده نمایید.")
#define MSG_VALUEFIRST  trUtf8("ابتدا مقدار مربوطه را وارد نمایید.")
#define MSG_YES trUtf8("بلی")
#define MSG_NO trUtf8("خیر")
#define MSG_NEUT    trUtf8("-")
#define MSG_NEUT2   trUtf8("در حال آموزش")
#define MSG_RSEP    trUtf8(" ، ")
#define MSG_AND    trUtf8(" و ")
#define MSG_NAME    trUtf8("نوع تلفن/محل")
#define MSG_VAL     trUtf8("شماره تلفن/نشانی")
#define MSG_TELTYPE trUtf8("نوع تلفن")
#define MSG_TELVAL trUtf8("شماره تلفن")
#define MSG_ADDRTYPE    trUtf8("محل")
#define MSG_ADDRVAL     trUtf8("نشانی")

#define MSG_SURNAMEFIRST   trUtf8("ابتدا نام خانوادگی / شرکت را مشخص نمایید.")

#endif // MSG_H

