﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"
#include "previewdialog.h"

#include "db.h"
#include "../lib13/include/str13.h"

#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>
#include <QDialog>

#include <QList>
#include <QMap>

#include <QGridLayout>

#define MSG_RIAL ") ريال:("

void MainWindow::outPrint(QString strStream, int mode){

    QPrinter printer;
    QTextDocument *document;
    QPrintDialog *dialog;    
    previewDialog* preview;

    QString filename;
    FILE* file;

    QStringList list;
    QFileDialog fileDlg;

    switch(mode){

    case PRINT_PRINTER:

        document = new QTextDocument();
        document->setDefaultFont(QFont(cfg.printFontName));
        document->setHtml(strStream);        

        dialog = new QPrintDialog(&printer, NULL);
        printer.setOrientation(QPrinter::Landscape);
        if (dialog->exec() == QDialog::Accepted) {
            document->print(&printer);
        }

        delete document;

        break;

    case PRINT_HTML:

        strStream.replace(tr("rtl"), tr("ltr"));

        fileDlg.setOption(QFileDialog::ShowDirsOnly, true);
        fileDlg.setAcceptMode(QFileDialog::AcceptSave);
        fileDlg.setNameFilter(tr("HTML File (*.html)"));
        fileDlg.setDefaultSuffix(tr("html"));

        if(fileDlg.exec()){
            list = fileDlg.selectedFiles();
        }
        if(!list.count()) return;

        filename = list.at(0);

        file = fopen(filename.toUtf8().data(), "w+");

        if(file){
            fwrite(strStream.toUtf8().data(), strStream.toUtf8().size(), 1, file);
            fflush(file);
            fclose(file);
        }

        break;

    case PRINT_PREVIEW:

        preview = new previewDialog(0, strStream, TEXT_T_HTML, cfg.printFontName);
        preview->showMaximized();
        preview->exec();
        delete preview;

        break;


        break;

    case PRINT_NULL:
        break;

    default:
        QMessageBox::warning(this, tr(""), tr("Not Implemented %1").arg(mode));
        break;
    }
}

void MainWindow::printTable(QTableWidget* table, enum table_id tid, QString strTitle, int mode){
    QString strStream;
    QTextStream out(&strStream);

    const int rowCount = table->model()->rowCount();
    const int columnCount = table->model()->columnCount();

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Sales Report</title>"
           "</head>"

           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"

               <<"<td width=\"15%\" align=\"right\">"<<ui->labelDate->text()<<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")
               <<"<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>"<<strTitle<<"</h1></td>"
                "<td width=\"20%\" height=\"20\">&nbsp;</td>"

             "</tr>"
             "<tr>"
                "<td align=\"right\">&nbsp;</td>"
               "<td align=\"left\"><h4>&nbsp;</h4></td>"
               "<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>&nbsp;</h4></td>"
             "</tr>"
             "<tr>"
               "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p>"<<trUtf8("گزارش بر اساس: ")<<RcurFilter<<"</p></td>"
             "</tr>"
           "</table>"

        "<table border=1 cellspacing=0 cellpadding=2 dir=\"rtl\" align = \"right\">\n";

    // headers
    out << "<b><thead><tr bgcolor=#f0f0f0 align = \"right\">";
    for (int column = columnCount - 1; column > -1; column--)
        if (!table->isColumnHidden(column))
            out << QString("<th>%1</th>").arg(table->model()->headerData(column, Qt::Horizontal).toString());
    out << "</tr></thead></b>\n";

    // data table
    for (int row = 0; row < rowCount; row++) {
        out << "<tr>";
        for (int column = columnCount - 1; column > -1; column--) {
            if (!table->isColumnHidden(column)) {
                QString data = table->model()->data(table->model()->index(row, column)).toString().simplified();
                out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
            }
        }
        out << "</tr>\n";
    }
    out <<  "</table>\n"
        "</body>\n"
        "</html>\n";

    outPrint(strStream, mode);
}

void MainWindow::printInvoice(int mode){
    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* item, *qty, *ppu, *desc;
    QString d = tr("-"), disc = MSG_NEUT;
    long discprice;
    int itemid, id;
    QString socialstyle;
    struct stmt_s st;
    char nt_buf[2048];

    const int itemRowCount = ui->tableItems->model()->rowCount();
    int row;

    if(translate_to_id(db, T_CUSTOMERS, id_col(T_CUSTOMERS, "socialstyle_id"), ui->comboFactorCustomer->currentText().toUtf8().data(), this_id, &id)){
        socialstyle = trUtf8(translate_to_name(db, T_CUSTOMERS, id_col(T_CUSTOMERS, "socialstyle_id"), id, this_id, &st));
        //QMessageBox::critical(this, tr(""), trUtf8("could not translate %1").arg(ui->comboFactorCustomer->currentText()));
        //return;
    } else {
        socialstyle = tr(" - ");
    }

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Invoices</title>"
           "</head>"
           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"
           "<td width=\"15%\" align=\"right\">" << ui->labelDate->text().toUtf8() <<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"right\"><h4>تاريخ: </h4></td>")<<
               trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>فاكتور فروش</h1></td>")<<
                 "<td width=\"20%\" height=\"20\">&nbsp;</td>"
            "</tr>"
            "<tr>"
                "<td align=\"right\">" << ui->labelFactorNo->text().toUtf8() <<"</td>"
                <<trUtf8("<td align=\"right\"><h4>شماره: </h4></td>")<<
                  trUtf8("<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>خريدار:</h4></td>")<<
           "</tr>"
           "<tr>"
           "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p><strong>"<< ui->comboFactorCustomer->currentText().toUtf8() <<" "<< socialstyle <<"</strong></p></td>"
            "</tr>"
          "</table>"
          "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
            "<b><tr >"
                <<trUtf8("<td width=\"32%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>توضيحات</h4></td>")<<
                trUtf8("<td width=\"18%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>قيمت كل )ريال(</h4></td>")<<
                trUtf8("<td width=\"13%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>قيمت واحد )ريال(</h4></td>")<<
                trUtf8("<td width=\"6%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تعداد</h4></td>")<<
                trUtf8("<td width=\"26%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام/كد كالا</h4></td>")<<
                trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")<<
            "</tr></b>";
    for(row = 0; row < itemRowCount; row++){

        item = ui->tableItems->item(row, id_col(T_FACTORS, "item_id"));
        if(!item) continue;
        if(!translate_name_to_id(db, T_ITEMS, item->text().toUtf8().data(), &itemid)) continue;
        qty = ui->tableItems->item(row, id_col(T_FACTORS, "item_qty"));
        if(!qty) continue;
        ppu = ui->tableItems->item(row, id_col(T_FACTORS, "item_price"));
        if(!ppu) continue;
        desc = ui->tableItems->item(row, id_col(T_FACTORS, "comments"));
        if(desc) d = desc->text().toUtf8();                

            out << "<tr>"
                   "<td>" << d <<"</td>"
                   "<td>"<<ppu->text().toUtf8().toInt()*qty->text().toUtf8().toInt()<<"</td>"
                   "<td>"<<ppu->text().toUtf8()<<"</td>"
                   "<td align=\"center\">"<< qty->text().toUtf8() <<"</td>"
                   "<td><p>"<< item->text().toUtf8() <<MSG_RSEP<< itemid << "<br />"
                   "</p></td>"
                   "<td align=\"center\">"<< row + 1 <<"</td>"
                   "</tr>";
    }

    if(ui->checkDiscountPercent->isChecked()){
        disc = ui->lineDiscount->text();
        discprice = (disc.toInt()/100)*ui->linePriceSum->text().toUtf8().toLong();
    } else {
        discprice = ui->lineDiscount->text().toLong();
    }

    nt_convert_str(ui->lineTotalPrice->text().toUtf8().data(), nt_buf, 2048);

    out << "</tr>";
    out << "<tr>"
           "<td>"<<ui->linePriceSum->text().toUtf8()<<"</td>"
           <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>جمع كل فاكتور )ريال:(</h4></td>")<<
            "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           "</tr>"
           "<tr>"
             "<td>"<<disc<<"</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>درصد تخفيف:</h4></td>")<<
               "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           "</tr>"
           "<tr>"
               "<td>"<<discprice<<"</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>مبلغ تخفيف )ريال:(</h4></td>")<<
               "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           "</tr>"
           "<tr>"
             "<td>"<<ui->lineTax->text().toUtf8()<<"</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>جمع عوارض/ماليات )ريال:(</h4></td>")<<
               "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           "</tr>"
           "<tr>"
               "<td>"<<ui->lineTotalPrice->text().toUtf8()<<"</td>"
             <<trUtf8("<td align=\"left\" bgcolor=\"#CCCCCC\"><h4>مبلغ قابل پرداخت )ريال:(</h4></td>")<<
               "<td colspan=\"4\" align=\"center\">&nbsp;</td>"
           "</tr>"
           "<tr>"
           "<td colspan=\"2\" align=\"right\"><p>"<<trUtf8(nt_buf)<<"</p></td>"
               "<td colspan=\"4\" align=\"center\"><p><br />"
               "</p></td>"
           "</tr>"
           "</table>"
           "<p>&nbsp;</p>"
           "<table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">"
             "<tr>"
               <<trUtf8("<td width=\"50%\" align=\"center\" valign=\"middle\">مهر و امضاء خريدار</td>")<<
               trUtf8("<td width=\"50%\" align=\"center\" valign=\"middle\"><p>امضاء فروشنده</p></td>")<<
             "</tr>"
           "</table>"
           "</body>"
           "</html>";

    outPrint(strStream, mode);
}

QString MainWindow::printRSales(int mode){
    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* item, *trans, *ppu, *qty, *fid, *fdate, *customer;
    int itemid;

    const int itemRowCount = ui->tableReport->model()->rowCount();
    int row;

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Sales Report</title>"
           "</head>"

           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"
                "<td width=\"15%\" align=\"right\">"<<ui->labelDate->text()<<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")
               <<trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>")<<((mode==PRINT_NULL)?trUtf8("گزارش فروش/تراکنش"):trUtf8("گزارش فروش"))<<"</h1></td>"
                "<td width=\"20%\" height=\"20\">&nbsp;</td>"

             "</tr>"
             "<tr>"
                "<td align=\"right\">&nbsp;</td>"
               "<td align=\"left\"><h4>&nbsp;</h4></td>"
               "<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>&nbsp;</h4></td>"
             "</tr>"
             "<tr>"
               "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p>"<<trUtf8("گزارش بر اساس: ")<<RcurFilter<<"</p></td>"
             "</tr>"
           "</table>"
           "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
             "<b><tr >"
               <<trUtf8("<td width=\"28%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام خريدار</h4></td>")
                <<trUtf8("<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>مبلغ فروش )ريال(</h4></td>")
                 <<trUtf8("<td width=\"10%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تاريخ فاكتور</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>شماره فاكتور</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تعداد</h4></td>")
                 <<trUtf8("<td width=\"26%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام/كد كالا</h4></td>")
                 <<trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")
             <<"</tr></b>";
    for(row = 0; row < itemRowCount; row++){

        item = ui->tableReport->item(row, id_col(T_FACTORS, "item_id"));
        if(!item) continue;
        if(!translate_name_to_id(db, T_ITEMS, item->text().toUtf8().data(), &itemid)) continue;
        trans = ui->tableReport->item(row, id_col(T_FACTORS, "transtype_id"));
        if(!trans) continue;
        qty = ui->tableReport->item(row, id_col(T_FACTORS, "item_qty"));
        if(!qty) continue;
        fid = ui->tableReport->item(row, id_col(T_FACTORS, "factor_id"));
        if(!fid) continue;
        fdate = ui->tableReport->item(row, id_col(T_FACTORS, "date"));
        if(!fdate) continue;
        ppu = ui->tableReport->item(row, id_col(T_FACTORS, "item_price"));
        if(!ppu) continue;
        customer = ui->tableReport->item(row, id_col(T_FACTORS, "customer_id"));
        if(!customer) continue;

         out << "<tr>"
              "<td>"<<customer->text()<<"</td>"
              "<td align=\"right\">"<<ppu->text().toLong()*qty->text().toLong()<<"</td>"
              "<td align=\"center\">"<<fdate->text()<<"</td>"
              "<td align=\"center\">"<<fid->text()<<"</td>"
              "<td align=\"center\">"<<qty->text()<<"</td>"
              "<td><p>"<<trans->text()<<MSG_RSEP<<item->text()<<MSG_RSEP<<itemid<<"<br />"
              "</p></td>"
              "<td align=\"center\">"<<row+1<<"</td>"
              "</tr>";

    }

    out << "<tr>"
        <<"<td colspan=\"2\" align=\"right\">"<<ui->RlineTotalPrice->text()<<"</td>"
        <<trUtf8("<td colspan=\"5\" align=\"left\" bgcolor=\"#CCCCCC\"><h4>جمع مبالغ فروش )ريال:(</h4></td>")
        <<"</tr>"
        "</table>"
        "</body>"
        "</html>";

    outPrint(strStream, mode);

    return strStream;

}

void MainWindow::printRStorage(int mode){
    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* item, *ppu, *qty, *fdate, *itemid;

    const int itemRowCount = ui->tableReport->model()->rowCount();
    int row;

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Sales Report</title>"
           "</head>"

           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"

               <<"<td width=\"15%\" align=\"right\">"<<ui->labelDate->text()<<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")
               <<trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>گزارش انبار</h1></td>")
                <<"<td width=\"20%\" height=\"20\">&nbsp;</td>"

             "</tr>"
             "<tr>"
                "<td align=\"right\">&nbsp;</td>"
               "<td align=\"left\"><h4>&nbsp;</h4></td>"
               "<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>&nbsp;</h4></td>"
             "</tr>"
             "<tr>"
               "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p>"<<trUtf8("گزارش بر اساس: ")<<RcurFilter<<"</p></td>"
             "</tr>"
           "</table>"
           "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
             "<b><tr >"
                 <<trUtf8("<td width=\"10%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>آخرین بهای واحد )ريال(</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تاریخ آخرین دریافت</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تعداد</h4></td>")
                 <<trUtf8("<td width=\"26%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام/كد كالا</h4></td>")
                 <<trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")
             <<"</tr></b>";
    for(row = 0; row < itemRowCount; row++){

        item = ui->tableReport->item(row, id_col(T_ITEMS, "name"));
        if(!item) continue;
        itemid = ui->tableReport->item(row, id_col(T_ITEMS, "id"));
        if(!itemid) continue;
        qty = ui->tableReport->item(row, id_col(T_ITEMS, "qty"));
        if(!qty) continue;
        fdate = ui->tableReport->item(row, id_col(T_ITEMS, "date"));
        if(!fdate) continue;
        ppu = ui->tableReport->item(row, id_col(T_ITEMS, "price"));
        if(!ppu) continue;

         out << "<tr>"
              "<td align=\"right\">"<<ppu->text()<<"</td>"
              "<td align=\"center\">"<<fdate->text()<<"</td>"
              "<td align=\"center\">"<<qty->text()<<"</td>"
              "<td><p>"<<item->text()<<MSG_RSEP<<itemid->text()<<"<br />"
              "</p></td>"
              "<td align=\"center\">"<<row+1<<"</td>"
         "</tr>";

    }
           out << "</table>"
           "</body>"
           "</html>";

    outPrint(strStream, mode);

}

void MainWindow::printRTransfer(int mode){
    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* item, *ppu, *qty, *fdate, *store, *ttype, *reg;
    int itemid;

    const int itemRowCount = ui->tableReport->model()->rowCount();
    int row;

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Sales Report</title>"
           "</head>"

           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>"
           "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"

               <<"<td width=\"15%\" align=\"right\">"<<ui->labelDate->text()<<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")
               <<trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>گزارش ارسال / دریافت</h1></td>")
                <<"<td width=\"20%\" height=\"20\">&nbsp;</td>"

             "</tr>"
             "<tr>"
                "<td align=\"right\">&nbsp;</td>"
               "<td align=\"left\"><h4>&nbsp;</h4></td>"
               "<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>&nbsp;</h4></td>"
             "</tr>"
             "<tr>"
               "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p>"<<trUtf8("گزارش بر اساس: ")<<RcurFilter<<"</p></td>"
             "</tr>"
           "</table>"
           "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
             "<b><tr >"
                  <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>وضعیت</h4></td>")
                  <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نوع</h4></td>")
                 <<trUtf8("<td width=\"10%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>بهای واحد )ريال(</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تاریخ</h4></td>")
                  <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نمایندگی مقصد</h4></td>")
                 <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>تعداد</h4></td>")
                 <<trUtf8("<td width=\"26%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نام/كد كالا</h4></td>")
                 <<trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")
             <<"</tr></b>";
    for(row = 0; row < itemRowCount; row++){

        item = ui->tableReport->item(row, id_col(T_SENDS, "item_id"));
        if(!item) continue;
        if(!translate_name_to_id(db, T_SENDS, item->text().toUtf8().data(), &itemid)) continue;
        qty = ui->tableReport->item(row, id_col(T_SENDS, "qty"));
        if(!qty) continue;
        store = ui->tableReport->item(row, id_col(T_SENDS, "store_id"));
        if(!store) continue;
        fdate = ui->tableReport->item(row, id_col(T_SENDS, "date"));
        if(!fdate) continue;
        ppu = ui->tableReport->item(row, id_col(T_SENDS, "price"));
        if(!ppu) continue;
        ttype = ui->tableReport->item(row, id_col(T_SENDS, "transtype_id"));
        if(!ttype) continue;
        reg = ui->tableReport->item(row, id_col(T_SENDS, "reg"));
        if(!reg) continue;

         out << "<tr>"
                "<td align=\"center\">"<<reg->text()<<"</td>"
                "<td align=\"center\">"<<ttype->text()<<"</td>"
              "<td align=\"right\">"<<ppu->text()<<"</td>"
              "<td align=\"center\">"<<fdate->text()<<"</td>"
                "<td align=\"center\">"<<store->text()<<"</td>"
              "<td align=\"center\">"<<qty->text()<<"</td>"
              "<td><p>"<<item->text()<<MSG_RSEP<<itemid<<"<br />"
              "</p></td>"
              "<td align=\"center\">"<<row+1<<"</td>"
         "</tr>";

    }
           out << "</table>"
           "</body>"
           "</html>";

    outPrint(strStream, mode);

}

QString MainWindow::printRTransactions(int mode){

    QString strStream;
    QTextStream out(&strStream);
    QTableWidgetItem* fid, *tstat, *val, *ptype, *item;
    QString specs;    
    QStringList listPayTypes;
    QStringList listTransStats;
    int cortlansstats, colpaytypes;
    QTableWidget* table;

    if(mode == PRINT_NULL){
        table = ui->tableReport2;
    } else {
        table = ui->tableReport;
    }

    const int itemRowCount = table->model()->rowCount();
    int row;

    out << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">"
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
           "<head>"
           "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
           "<title>Sales Report</title>"
           "</head>"

           "<body dir=\"rtl\">"
           "<p align=\"left\">&nbsp;</p>";

    if(mode != PRINT_NULL){
           out<< "<table align=\"center\" width=\"90%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">"
             "<tr>"

               <<"<td width=\"15%\" align=\"right\">"<<ui->labelDate->text()<<"</td>"
               <<trUtf8("<td width=\"5%\" align=\"left\"><h4>تاريخ: </h4></td>")
               <<trUtf8("<td width=\"50%\" rowspan=\"2\" align=\"center\"><h1>گزارش تراکنش</h1></td>")<<
                "<td width=\"20%\" height=\"20\">&nbsp;</td>"

             "</tr>"
             "<tr>"
                "<td align=\"right\">&nbsp;</td>"
               "<td align=\"left\"><h4>&nbsp;</h4></td>"
               "<td height=\"20\" align=\"right\" valign=\"bottom\"><h4>&nbsp;</h4></td>"
             "</tr>"
             "<tr>"
               "<td colspan=\"4\" height=\"20\" align=\"right\" valign=\"top\"><p>"<<trUtf8("گزارش بر اساس: ")<<RcurFilter<<"</p></td>"
             "</tr>"
           "</table>";
    }

           out << "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
             "<b><tr>"
                  <<trUtf8("<td width=\"30%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>مشخصات</h4></td>")
//                  <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>وضعیت</h4></td>")
//                  <<trUtf8("<td width=\"8%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نوع</h4></td>")
                 <<trUtf8("<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>روش پرداخت</h4></td>")
                 <<trUtf8("<td width=\"10%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>وضعیت تراکنش</h4></td>")
                  <<trUtf8("<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>مبلغ تراکنش )ريال(</h4></td>")
                 //<<trUtf8("<td width=\"10%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>نوع تراکنش</h4></td>")
                 <<trUtf8("<td width=\"15%\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>شماره فاکتور</h4></td>")
                 <<trUtf8("<td width=\"5%\" height=\"30\" align=\"center\" bgcolor=\"#CCCCCC\"><h4>رديف</h4></td>")
             <<"</tr></b>";
    for(row = 0; row < itemRowCount; row++){

        specs.clear();

        fid = table->item(row, id_col(T_PAYMENTS, "factor_id"));
        if(!fid) continue;
//        ttype = table->item(row, id_col(T_PAYMENTS, "transtype_id"));
//        if(!ttype) continue;
        val = table->item(row, id_col(T_PAYMENTS, "val"));
        if(!val) continue;
        tstat = table->item(row, id_col(T_PAYMENTS, "transtat_id"));
        if(!tstat) continue;
        ptype = table->item(row, id_col(T_PAYMENTS, "paytype_id"));
        if(!ptype) continue;

        item = table->item(row, id_col(T_PAYMENTS, "date"));
        if(item && !item->text().isEmpty()){
            specs.append(item->text()).append(MSG_AND);
        }

        item = table->item(row, id_col(T_PAYMENTS, "extid"));
        if(item && !item->text().isEmpty()){
            specs.append(item->text()).append(MSG_AND);
        }

//        item = table->item(row, id_col(T_PAYMENTS, "date"));
//        if(item && !item->text().isEmpty()){
//            specs.append(item->text()).append(MSG_AND);
//        }

        item = table->item(row, id_col(T_PAYMENTS, "bank_id"));
        if(item && !item->text().isEmpty()){
            specs.append(item->text()).append(MSG_AND);
        }

        item = table->item(row, id_col(T_PAYMENTS, "branch"));
        if(item && !item->text().isEmpty()){
            specs.append(item->text()).append(MSG_AND);
        }

        specs.chop(MSG_AND.length());

//        <td align="center"><p>[شماره فاكتور]<br />
//        </p></td>

         out << "<tr>"
//                "<td align=\"center\">"<<reg->text()<<"</td>"
//                "<td align=\"center\">"<<fid->text()<<"</td>"
                "<td align=\"right\">"<<specs<<"</td>"
                "<td align=\"center\">"<<ptype->text()<<"</td>"
                "<td align=\"center\">"<<tstat->text()<<"</td>"
                "<td align=\"right\">"<<val->text()<<"</td>"
                "<td align=\"center\"><p>"<<fid->text()<<"<br /></p></td>"
                "<td align=\"center\">"<<row+1<<"</td>"
         "</tr>";
    }

//    out<<"</table>"

//    "<table align=\"center\" width=\"90%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">";

    //col scramble from here

    colpaytypes = id_col(T_PAYMENTS, "paytype_id");
    cortlansstats = id_col(T_PAYMENTS, "transtat_id");
    for(row = 0; row < table->rowCount(); row++){

        item = table->item(row, colpaytypes);

        if(item && !item->text().isEmpty()){
            listPayTypes << item->text();
        }

        item = table->item(row, cortlansstats);

        if(item && !item->text().isEmpty()){
            listTransStats << item->text();
        }

    }

    listPayTypes.removeDuplicates();
    listTransStats.removeDuplicates();

    long groupval;
    int i, j;

    for(j = 0; j < listTransStats.count(); j++){
        for(i = 0; i < listPayTypes.count(); i++){

            groupval = groupVal(listPayTypes.at(i), listTransStats.at(j));
            if(groupval){
                specs.clear();
                specs.append(listTransStats.at(j)).append(trUtf8(" - ")).append(listPayTypes.at(i));

                out<<"<tr>"
                  "<td colspan=\"2\" align=\"right\">"<<groupval<<"</td>"
                     "<td colspan=\"5\" align=\"left\" bgcolor=\"#CCCCCC\"><h4>"<<trUtf8(" جمع ")<< specs <<trUtf8(MSG_RIAL)<<"</h4></td>"
                "</tr>";


            }
        }
    }

    out << "</table>"
    "</body>"
    "</html>";

    outPrint(strStream, mode);

    return strStream;

}

long MainWindow::groupVal(QString P, QString T){
    int colpaytypes = id_col(T_PAYMENTS, "paytype_id");
    int cortlansstats = id_col(T_PAYMENTS, "transtat_id");
    int colval = id_col(T_PAYMENTS, "val");
    long groupval = 0;
    QTableWidgetItem* itemPayType, *itemTransStat, *itemVal;

    for(int row = 0; row < ui->tableReport->rowCount(); row++){

        itemPayType = ui->tableReport->item(row, colpaytypes);
        itemTransStat = ui->tableReport->item(row, cortlansstats);

        if(itemPayType && itemTransStat && itemPayType->text() == P && itemTransStat->text() == T){
            itemVal = itemPayType = ui->tableReport->item(row, colval);

            if(itemVal){
                groupval += itemVal->text().toLong();
            }
        }
    }

    return groupval;
}

void MainWindow::printRSalesTransaction(int mode){

    QString strStream = printRSales(PRINT_NULL);
    strStream.append(printRTransactions(PRINT_NULL));

    outPrint(strStream, mode);

}

void MainWindow::printTo(int output){
    int prev = cfg.printOutput;

    cfg.printOutput = output;
    on_toolPrint_clicked();

    cfg.printOutput = prev;
}

void MainWindow::printPreview(){
    printTo(PRINT_PREVIEW);
}

void MainWindow::printHtml(){
    printTo(PRINT_HTML);
}
