﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"

#include "db.h"

#include "../lib13/include/str13.h"

#include <QUrl>
#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>
#include <QClipboard>
#include <QApplication>

#include <QList>
#include <QMap>

#define MSG_MAN "\t + مدیریت مرکزی"
#define MSG_CHAN "\t\t ++ I AM THE SHADOW WARRIOR! ++ "

#define PATHMAX 1024

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    createMenu();

//    iniDlg.setWindowFlags(Qt::FramelessWindowHint);
//    iniDlg.show();

    godmode = false;
    managermode = false;

    cfgDlg.setWindowFlags(Qt::FramelessWindowHint);
    cfgDlg.setWindowFlags(Qt::WindowTitleHint);
    cfgDlg.setDB(db);

    if(!InitDB()){
        //iniDlg->close();
        QMessageBox::critical(this, trUtf8("خطا"), trUtf8("خطا در پایگاه داده"));
        exit(-1);
    }

    comItems=NULL;
    comBanks=NULL;
    comCustomers=NULL;
    comTransTypes=NULL;
    comPayTypes=NULL;
    comTransStats=NULL;
    comStores=NULL;
    comOffers = NULL;

    comSex=NULL; comSpecs=NULL; comRanks=NULL; comSocialStyles=NULL; comCustomerTypes=NULL;

    //event filters
    ui->tableItems->installEventFilter(this);
    ui->tableEdit->installEventFilter(this);
    ui->tablePays->installEventFilter(this);
    ui->comboDBs->installEventFilter(this);
    ui->comboDstDB->installEventFilter(this);

    ui->comboDBs->acceptDrops();
    ui->comboDstDB->acceptDrops();

    connect(ui->tableEdit, SIGNAL(currentCellChanged(int,int,int,int)),
            this, SLOT(monitorEditCellChange(int,int,int,int)));

    connect(ui->tableItems, SIGNAL(currentCellChanged(int,int,int,int)),
            this, SLOT(monitorItemCellChange(int,int,int,int)));

    connect(ui->tablePays, SIGNAL(currentCellChanged(int,int,int,int)),
            this, SLOT(monitorPayCellChange(int,int,int,int)));

    for(int i = 0; i < TABLE_N; i++){
        t_change[i] = 0;
    }

    loading = 0;
    saving = 0;
    combolist = 0;

    initConf();
    setupView();

    //iniDlg.close();

    //NUM2TEXT TEST
//    char buf[1024];
//    QString strnum = tr("1234567");
//    nt_convert_str(strnum.toLatin1().data(), buf, 1024);
//    ui->labelTest->setText(trUtf8(buf));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initConf(){
    cfg.printFontName = tr("B Nazanin");
    cfg.printOutput = PRINT_PRINTER;
    cfg.max_contact = 20;
}

void MainWindow::doCopy(){
    QKeyEvent *pressevent = new QKeyEvent ( QEvent::KeyPress, Qt::Key_C, Qt::ControlModifier);
    QCoreApplication::postEvent (QApplication::focusObject(), pressevent);
    //delete pressevent;
}

void MainWindow::doPaste(){
    QKeyEvent *pressevent = new QKeyEvent ( QEvent::KeyPress, Qt::Key_V, Qt::ControlModifier);
    QCoreApplication::postEvent (QApplication::focusObject(), pressevent);
    //delete pressevent;
}

void MainWindow::doDelete(){
    QKeyEvent *pressevent = new QKeyEvent ( QEvent::KeyPress, Qt::Key_Delete, Qt::NoModifier);
    QCoreApplication::postEvent (QApplication::focusObject(), pressevent);
    //delete pressevent;
}

void MainWindow::aboutQt(){
    QApplication::aboutQt();
}

void MainWindow::createMenu()
{        

    QAction *saveAct = new QAction(trUtf8("[ Ctrl + S ] ثبت"), this);
    QAction *printAct = new QAction(trUtf8("[ Ctrl + P ] چاپ"), this);
    QAction *printPreviewAct = new QAction(trUtf8("رویت پیش از چاپ"), this);
    QAction *printHtmlAct = new QAction(trUtf8("HTML خروجی"), this);
    QAction *exitAction = new QAction(trUtf8("[ Ctrl + X ] خروج"), this);

    QAction *copyAct = new QAction(trUtf8("[ Ctrl + C ] کپی"), this);
    QAction *pasteAct = new QAction(trUtf8("[ Ctrl + V ] بازنشانی"), this);
    QAction *rmrowAct = new QAction(trUtf8("[ Ctrl + D ] حذف سطر"), this);
    QAction *settingsAct = new QAction(trUtf8("...تنظیمات"), this);        

    QAction *aboutAct = new QAction(trUtf8("...درباره"), this);
    QAction *helpAct = new QAction(trUtf8("راهنمای استفاده"), this);

    connect(saveAct, SIGNAL(triggered()), this, SLOT(on_toolSave_clicked()));
    connect(printAct, SIGNAL(triggered()), this, SLOT(on_toolPrint_clicked()));
    connect(printPreviewAct, SIGNAL(triggered()), this, SLOT(printPreview()));
    connect(printHtmlAct, SIGNAL(triggered()), this, SLOT(printHtml()));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(on_toolExit_clicked()));

    connect(copyAct, SIGNAL(triggered()), this, SLOT(doCopy()));
    connect(pasteAct, SIGNAL(triggered()), this, SLOT(doPaste()));
    connect(rmrowAct, SIGNAL(triggered()), this, SLOT(on_toolDelete_clicked()));
    connect(settingsAct, SIGNAL(triggered()), this, SLOT(on_toolConfig_clicked()));

    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));
    connect(helpAct, SIGNAL(triggered()), this, SLOT(aboutQt()));

    QMenu* fileMenu = menuBar()->addMenu(trUtf8("فایل"));
    fileMenu->addAction(saveAct);
    fileMenu->addAction(printAct);
    fileMenu->addAction(printPreviewAct);
    fileMenu->addAction(printHtmlAct);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    QMenu* editMenu = menuBar()->addMenu(trUtf8("ویرایش"));
    editMenu->addAction(copyAct);
    editMenu->addAction(pasteAct);
    editMenu->addSeparator();
    editMenu->addAction(rmrowAct);
    editMenu->addSeparator();
    editMenu->addAction(settingsAct);

    QMenu* helpMenu = menuBar()->addMenu(trUtf8("راهنما"));
    helpMenu->addAction(helpAct);
    helpMenu->addSeparator();
    helpMenu->addAction(aboutAct);

    settingsAct->setDisabled(true);
    helpAct->setDisabled(true);
}

void MainWindow::setDstTableList(){

    QCheckBox* check;
    QListWidgetItem* item;

    ui->listTables->clear();
    ui->comboDstTables->clear();

//    if(!managermode) ui->listTables->setEnabled(false);

    for(enum table_id i = T_STORES; i < T_INVAL; i = t_next(i)){

        item = new QListWidgetItem;
        check = new QCheckBox;

        if(!managermode) check->setDisabled(true);

        if(managermode){

            if((i >= T_STORES && i < T_CUSTOMERS) || ( i > T_PAYMENTS && i < T_INVAL)){
                check->setChecked(true);
            }

            ui->comboDstTables->addItem(t_alias(i));

        } else if(i >= T_ITEMS && i <= T_PAYMENTS){

            check->setChecked(true);
            ui->comboDstTables->addItem(t_alias(i));

        }

        check->setText(t_alias(i));

        ui->listTables->insertItem(ui->listTables->count(), item);
        ui->listTables->setItemWidget(item, check);

    }
}

void MainWindow::setupView(){

    enum table_id tid;

    showMaximized();

    d13_today(tday);
    ui->labelDate->setText(trUtf8("%1/%2/%3").arg(tday[0]).arg(tday[1]).arg(tday[2]));

    ui->comboTables->addItem(tr(""));

    for(tid = T_STORES; tid < T_INVAL; tid = t_next(tid)){
        if(t_view(tid) & TVIEW_USR){
            ui->comboTables->addItem(trUtf8(t_alias(tid)));
        }
    }

    ui->comboTables->setCurrentIndex(1);        

    //ui->tableEdit->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableItems->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tablePays->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableShow->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->tableReport->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tableReport2->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    ui->tableEdit->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableItems->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tablePays->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableShow->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    ui->tableReport->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableReport2->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    ui->tableItems->setWordWrap(true);
    ui->tablePays->setWordWrap(true);
    ui->tableShow->setWordWrap(true);

    ui->tableReport->setWordWrap(true);
    ui->tableReport2->setWordWrap(true);

    ui->tableItems->setTextElideMode(Qt::ElideLeft);
    ui->tablePays->setTextElideMode(Qt::ElideLeft);
    ui->tableShow->setTextElideMode(Qt::ElideLeft);

    ui->tableReport->setTextElideMode(Qt::ElideLeft);
    ui->tableReport2->setTextElideMode(Qt::ElideLeft);

    ui->tableEdit->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->tableEdit->setWordWrap(true);

    ui->tabW->setCurrentIndex(TAB_EDIT);    
    ui->tabW->setCurrentIndex(TAB_FACTOR);

    ui->comboDBs->addItem(trUtf8(db_alias(db_first)));
    ui->comboDstDB->addItem(trUtf8(db_alias(db_first)));

    ui->toolLoadDB->setEnabled(false);
    ui->toolNewDB->setEnabled(false);
    ui->toolCloseDB->setEnabled(false);

    ui->toolConfig->setEnabled(false);

    ui->toolTrunc->setHidden(true);

    ui->labelJob->setText(MSG_IDLE);

    ui->labelClipStat->setText(MSG_EMPTY);

    listLogic << tr("");
    listLogic << MSG_LT;
    listLogic << MSG_GT;
    listLogic << MSG_EQ;
    listLogic << MSG_LE;
    listLogic << MSG_GE;
    listLogic << MSG_NE;
    listLogic << MSG_BETWEEN;

    listBool << tr("");
    listBool << MSG_YES;
    listBool << MSG_NO;
    listBool << MSG_NEUT;

    ui->RcomboClubMember->addItems(listBool);
    ui->RcomboCourse->addItems(listBool);
    ui->RcomboHeyatElmi->addItems(listBool);

    ui->RcomboQtyLogic->addItems(listLogic);

    ui->RcomboQtyLogic->removeItem(ui->RcomboQtyLogic->count()-1);

    ui->RcomboDate->addItems(listLogic);

    ui->RlineEndDate->setEnabled(false);

    ui->tableReport2->setHidden(true);

    ui->groupDbOps->setHidden(true);

    ui->comboDstStore->setEnabled(false);    

    loadLists();

    setDstTableList();

    ui->tableShow->setEnabled(false);
    ui->listTables->setEnabled(false);

    ui->RlineStartDate->setInputMask(tr("0000/00/00"));
    ui->RlineEndDate->setInputMask(tr("0000/00/00"));

    ui->RlineFactorNo->setPlaceholderText(tr("1,2,3-8"));

    ui->radioSyncTables->setChecked(true);
    ui->radioInitTables->setEnabled(false);
    ui->radioSyncTables->setEnabled(false);

    ui->groupDbOpButtons->setHidden(true);
    ui->groupDstDbOpButtons->setHidden(true);

    ui->comboCurrentStore->setEnabled(false);

    ui->comboFactorCustomer->addItems(listCustomers);

}

void MainWindow::showEvent(QShowEvent *event){

    ui->tabW->setCurrentIndex(TAB_FACTOR);

    event->accept();

//    iniDlg = new initDialog;
//    iniDlg->show();

//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), iniDlg, SLOT(close()));
//    timer->start(5000);

//    iniDlg->setFocus(Qt::ActiveWindowFocusReason);

}

bool MainWindow::InitDB(){

    QDir homedir;
    db = new struct db_s;
    db->next = NULL;    

    char path[PATHMAX];

    homedir = QDir::homePath();

    snprintf(path, PATHMAX, "%s/%s", homedir.path().toUtf8().data(), DBFILE);

    //move the dbfile from . to homedir if exists and @ homedir does not exists
    //for now, enforce!
    if(!access(DBFILE, F_OK) /*&& access(path, F_OK)*/){

        qDebug()<<"found dbfile "<<DBFILE;

        if(!access(path, F_OK)){
            qDebug()<<"found previous db "<<path;
            QFile::remove(trUtf8(path).append(tr(".bak")));
            QFile::copy(trUtf8(path), trUtf8(path).append(tr(".bak")));
            QFile::remove(path);
        }

        QFile::copy(DBFILE, trUtf8(path));

        remove(DBFILE);

    } else {
        qDebug()<<"not found dbfile "<<DBFILE;
    }


    if(!init_db(db, path, MSG_MAIN)){
        qDebug()<<"failed to init db";
    }

    switch(this_store_info(db, &this_id, &this_name, &this_addr, &this_contact)){

    case true_:
    break;

    case continue_:

        init_this_store(db, 0, MSG_CENTRAL, MSG_MAINADDR, MSG_MAINCONTACT);
        this_store_info(db, &this_id, &this_name, &this_addr, &this_contact);

    break;

    case false_:
        return false;
    break;

    }

    ui->labelID->setText(MSG_STOREINFO.arg(trUtf8(this_name)).arg(trUtf8(this_addr)).arg(trUtf8(this_contact)));

    db_first = db;
    db_last = db;

    return true;
}

void MainWindow::loadLists(){
    CreateNameList(T_ITEMS, "name", listItems, &comItems);
    CreateNameList(T_CUSTOMERS, "name", listCustomers, &comCustomers);
    CreateNameList(T_TRANSTYPES, "name", listTransTypes, &comTransTypes);
    CreateNameList(T_PAYTYPES, "name", listPayTypes, &comPayTypes);
    CreateNameList(T_BANKS, "name", listBanks, &comBanks);
    CreateNameList(T_TRANSTATS, "name", listTranStats, &comTransStats);
    CreateNameList(T_STORES, "name", listStores, &comStores);
    CreateNameList(T_SEX, "name", listSex, &comSex);
    CreateNameList(T_SPECIALITY, "name", listSpecs, &comSpecs);
    CreateNameList(T_RANK, "name", listRanks, &comRanks);
    CreateNameList(T_SOCIALSTYLE, "name", listSocialStyles, &comSocialStyles);
    CreateNameList(T_CUSTOMERTYPE, "name", listCustomerTypes, &comCustomerTypes);
    CreateNameList(T_OFFERS, "name", listOffers, &comOffers);
}

bool MainWindow::FinishDB(){

    for(db = db_first; db; db = db->next){
        close_db(db);
    }

    return true;
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event){

    QTableWidget* table;
    QKeyEvent* key;
    QDropEvent* drop;
    QTableWidgetItem* item;
    QStringList list;    
    QString str;
//    const QClipboard *clipboard = QApplication::clipboard();

    if( obj->objectName() == tr("tableItems")||
        obj->objectName() == tr("tablePays") ||
        obj->objectName() == tr("tableEdit")){

        table = dynamic_cast<QTableWidget*>(obj);
        if(event->type() == QEvent::KeyPress){

            key = dynamic_cast<QKeyEvent*>(event);

            switch(key->key()){

            case Qt::Key_Delete:
                ClearCurCell(table);
                break;

            case Qt::Key_C:
                if(key->modifiers() == Qt::ControlModifier){

                    item = table->currentItem();

                    if(item && !item->text().isEmpty()){

                        QApplication::clipboard()->setText(str);

                        ui->labelClipStat->setText(item->text());
                    }

                }

                break;

            case Qt::Key_V:

                if(key->modifiers() == Qt::ControlModifier){

                    str = QApplication::clipboard()->text();
                    setCells(table, str);

                }

                break;

            case Qt::Key_Up:
            case Qt::Key_Down:
            case Qt::Key_Left:
            case Qt::Key_Right:
            case Qt::Key_Enter:
            case Qt::Key_Return:
                break;

            default:

                if(obj->objectName() == tr("tableItems")){
                    on_tableItems_cellClicked(ui->tableItems->currentRow(), ui->tableItems->currentColumn());
                } else if(obj->objectName() == tr("tablePays")){
                    on_tablePays_cellClicked(ui->tablePays->currentRow(), ui->tablePays->currentColumn());
                } else if(obj->objectName() == tr("tableEdit")){
                    on_tableEdit_cellClicked(ui->tableEdit->currentRow(), ui->tableEdit->currentColumn());
                }

                break;
            }

        }
    } else if(obj->objectName() == tr("comboDBs")){
        //qDebug()<<event->type();
        if(event->type() == QEvent::DragEnter && managermode){
            qDebug()<<"drop";
            drop = dynamic_cast<QDropEvent*>(event);
            if (drop->mimeData()->hasUrls())
            {
                foreach (QUrl url, drop->mimeData()->urls())
                {
                    list << url.toLocalFile();
                }

                loadDBs(list);
            }
        }
    } else if(obj->objectName() == tr("comboDstDB")){
        //qDebug()<<event->type();
        if(event->type() == QEvent::DragEnter){
            qDebug()<<"drop";
            drop = dynamic_cast<QDropEvent*>(event);
            if (drop->mimeData()->hasUrls())
            {
                foreach (QUrl url, drop->mimeData()->urls())
                {
                    list << url.toLocalFile();
                }

                loadDstDBs(list);
            }
        }
    }

    return false;

}

void MainWindow::closeEvent(QCloseEvent *event){

    if(hasChange(-1)){
        switch(QMessageBox::question(this,
                                    MSG_CHANGE,
                                    MSG_SAVECHANGE,
                                    QMessageBox::Yes|QMessageBox::No)){

        case QMessageBox::No:
            event->ignore();
            return;
            break;

        default:
            break;

        }

    }

    FinishDB();

    event->accept();
}

void MainWindow::set_managermode(){
    QString str;
    enum table_id tid;
    managermode = true;

    ui->comboTables->clear();
    ui->comboTables->addItem(tr(""));
    for(tid = T_STORES; tid < T_INVAL; tid = t_next(tid)){
        if(t_view(tid) & TVIEW_MGR){
            ui->comboTables->addItem(trUtf8(t_alias(tid)));
        }
    }
    ui->comboTables->setCurrentIndex(1);

    ui->toolLoadDB->setEnabled(true);
    ui->toolNewDB->setEnabled(true);
    ui->toolCloseDB->setEnabled(true);

    str = ui->labelID->text();
    str.append(trUtf8(MSG_MAN));
    ui->labelID->setText(str);

    ui->comboDBs->acceptDrops();

    ui->tableShow->setEnabled(true);

    ui->comboDstStore->setEnabled(true);

    ui->listTables->setEnabled(true);

    ui->comboDstStore->insertItems(0, listStores);

    ui->radioInitTables->setEnabled(true);
    ui->radioSyncTables->setEnabled(true);

    ui->groupDbOpButtons->setHidden(false);
    ui->groupDstDbOpButtons->setHidden(false);

    ui->comboCurrentStore->setEnabled(true);

    setDstTableList();

}

void MainWindow::set_godmode(){
    godmode = true;
    QString str;
    enum table_id tid;

    set_managermode();

    ui->comboTables->clear();
    ui->comboTables->addItem(tr(""));
    for(tid = T_STORES; tid < T_INVAL; tid = t_next(tid)){
        if(t_view(tid) & TVIEW_GOD){
            ui->comboTables->addItem(trUtf8(t_alias(tid)));
        }
    }
    ui->comboTables->setCurrentIndex(1);


    ui->toolTrunc->setHidden(false);

    str = ui->labelID->text();
    str.append(trUtf8(MSG_CHAN));
    ui->labelID->setText(str);
}

void MainWindow::on_comboTables_currentIndexChanged(const QString &arg1)
{
    enum table_id tid;

    tid = id_table_alias(arg1.toUtf8().data());

    if(tid == T_INVAL){
        ui->tableEdit->setColumnCount(0);
        ui->tableEdit->setRowCount(0);
        return;
    }

    loading = 1;
    LoadTable(ui->tableEdit, tid, 1);

//    if(tid == T_CUSTOMERS){
//        //item = new QTableWidgetItem;
//        QLineEdit* e = new QLineEdit;
//        e->setPlaceholderText(trUtf8("نام خانوادگی، نام"));
//        ui->tableEdit->setCellWidget(ui->tableEdit->rowCount() - 1 , id_col(T_CUSTOMERS, "name"), e);
//    }

    loading = 0;        

}

void MainWindow::on_toolExit_clicked()
{
    close();
}

void MainWindow::on_toolSave_clicked()
{
    struct stmt_s st;
    enum table_id tid;

    if(ui->tabW->currentIndex() == TAB_EDIT){

        ui->tableEdit->setCurrentCell(0, 0);

        if(!hasChange(TABLE_EDIT)){
            QMessageBox::warning(this, MSG_CHANGE, MSG_NOCHANGE);
            return;
        }

        tid = id_table_alias(ui->comboTables->currentText().toUtf8().data());

        saving = 1;

        start_trans(db);

        if(WriteTable(ui->tableEdit, tid)){

            saving = 0;

            switch(tid){

            case T_ITEMS:
                CreateNameList(T_ITEMS, "name", listItems, &comItems);
                break;
            case T_CUSTOMERS:
                CreateNameList(T_CUSTOMERS, "name", listCustomers, &comCustomers);
                break;
            case T_TRANSTYPES:
                CreateNameList(T_TRANSTYPES, "name", listTransTypes, &comTransTypes);
                break;
            case T_PAYTYPES:
                CreateNameList(T_PAYTYPES, "name", listPayTypes, &comPayTypes);
                break;
            case T_BANKS:
                CreateNameList(T_BANKS, "name", listBanks, &comBanks);
                break;
            case T_TRANSTATS:
                CreateNameList(T_TRANSTATS, "name", listTranStats, &comTransStats);
                break;
            case T_STORES:
                CreateNameList(T_STORES, "name", listStores, &comStores);

                if(managermode){
                    ui->comboDstStore->clear();
                    ui->comboDstStore->insertItems(0, listStores);                    
                }

                break;

            case T_SEX:
                CreateNameList(T_SEX, "name", listSex, &comSex);
                break;
            case T_SPECIALITY:
                CreateNameList(T_SPECIALITY, "name", listSpecs, &comSpecs);
                break;
            case T_RANK:
                CreateNameList(T_RANK, "name", listRanks, &comRanks);
                break;
            case T_SOCIALSTYLE:
                CreateNameList(T_SOCIALSTYLE, "name", listSocialStyles, &comSocialStyles);
                break;
            case T_CUSTOMERTYPE:
                CreateNameList(T_CUSTOMERTYPE, "name", listCustomerTypes, &comCustomerTypes);
                break;

            case T_SENDS:
                qDebug()<<"on_toolSave_clicked(): tid = T_SENDS";
                if(!recalcItemQty(ui->tableEdit, T_SENDS, DIR_SEND)){
                    rollback(db);
                    QMessageBox::warning(this, MSG_SAVING, MSG_SAVEFAIL);
                    return;
                }
                break;
            default:
                //QMessageBox::warning(this, "Design", "Design Error 1");
                break;
            }

            end_trans(db);

/**/
            loading = 1;

            LoadTable(ui->tableEdit, tid, 1);

            loading = 0;

            emit on_comboDstTables_currentIndexChanged(ui->comboDstTables->currentText());

            setChange(TABLE_EDIT, 0);
/**/

        } else {

            rollback(db);

            saving = 0;
            QMessageBox::critical(this, MSG_CHANGE, MSG_SAVEFAIL);

//            loading = 1;
//            LoadTable(ui->tableEdit, tid);
//            loading = 0;
        }

    } else if(ui->tabW->currentIndex() == TAB_FACTOR){

        loading = 1;
        RecalcFactor();
        loading = 0;

        ui->tableItems->setCurrentCell(0, 0);
        ui->tablePays->setCurrentCell(0, 0);

        if(!hasChange(TABLE_ITEMS) && !hasChange(TABLE_PAYS)){
            QMessageBox::warning(this, MSG_CHANGE, MSG_NOCHANGE);
            return;
        }

        saving = 1;
        start_trans(db);
        if(WriteTable(ui->tableItems, T_FACTORS)){

            if(WriteTable(ui->tablePays, T_PAYMENTS)){
                if(recalcItemQty(ui->tableItems, T_FACTORS, DIR_SEND)){
                    end_trans(db);
                    saving = 0;
                    LoadFactor(factor_id);

                    setChange(TABLE_ITEMS, 0);
                    setChange(TABLE_PAYS, 0);
                    return;
                }

            } else {//delete items too!

                rollback(db);

                saving = 0;

                QMessageBox::critical(this, MSG_CHANGE, MSG_SAVEFAIL);

                delete_id(db, T_FACTORS, "id", factor_id, this_id, &st);
                finalize(&st);

                return;

            }

        } else {
            rollback(db);
            saving = 0;
            QMessageBox::critical(this, MSG_CHANGE, MSG_SAVEFAIL);
            return;
        }

        end_trans(db);

    } else if(ui->tabW->currentIndex() == TAB_REPORT){

        exportReport(1);

    }

}

void MainWindow::on_tabW_currentChanged(int index)
{

    struct stmt_s st;

    switch(index){
    case TAB_FACTOR:

        setChange(-1, -1);

        loading = 1;

        LoadTable(ui->tableItems, T_FACTORS, 0);
        LoadTable(ui->tablePays, T_PAYMENTS, 0);

        loading = 0;

        on_btnNew_clicked();

        ui->comboFactorCustomer->clear();
        ui->comboFactorCustomer->insertItems(0, listCustomers);

        break;

    case TAB_EDIT:

        ui->toolDelete->setEnabled(true);

        ui->comboCurrentStore->clear();
        ui->comboCurrentStore->insertItems(0, listStores);

        ui->comboCurrentStore->setCurrentIndex(ui->comboCurrentStore->findText(trUtf8(translate_to_name(db, T_ITEMS, id_col(T_ITEMS, "store_id"), this_id, this_id, &st))));
        finalize(&st);

        setChange(TABLE_ITEMS, 0);
        setChange(TABLE_PAYS, 0);

        break;

    case TAB_REPORT:

        setChange(TABLE_ITEMS, 0);
        setChange(TABLE_PAYS, 0);

        ui->RcomboBank->clear();
        ui->RcomboBank->insertItems(0, listBanks);

        ui->RcomboCustomer->clear();
        ui->RcomboCustomer->insertItems(0, listCustomers);

        ui->RcomboItem->clear();
        ui->RcomboItem->insertItems(0, listItems);

        ui->RcomboPayType->clear();
        ui->RcomboPayType->insertItems(0, listPayTypes);

        ui->RcomboStore->clear();
        ui->RcomboStore->insertItems(0, listStores);

        ui->RcomboTransStat->clear();
        ui->RcomboTransStat->insertItems(0, listTranStats);

        ui->RcomboTransType->clear();
        ui->RcomboTransType->insertItems(0, listTransTypes);

        ui->RcomboSex->clear();
        ui->RcomboSex->insertItems(0, listSex);

        ui->RcomboSpec->clear();
        ui->RcomboSpec->insertItems(0, listSpecs);

        ui->RcomboRank->clear();
        ui->RcomboRank->insertItems(0, listRanks);

        ui->RcomboSocialStyle->clear();
        ui->RcomboSocialStyle->insertItems(0, listSocialStyles);

        ui->RcomboCustomerType->clear();
        ui->RcomboCustomerType->insertItems(0, listCustomerTypes);

        ui->RcomboHeyatElmi->clear();
        ui->RcomboHeyatElmi->insertItems(0, listBool);

        ui->RcomboCourse->clear();
        ui->RcomboCourse->insertItems(0, listBool);

        ui->RcomboClubMember->clear();
        ui->RcomboClubMember->insertItems(0, listBool);

        ui->toolDelete->setEnabled(false);

        ui->toolSave->setIcon(QIcon(":/res/csv-48.png"));

        break;
    }
}


void MainWindow::on_toolConfig_clicked()
{
    cfgDlg.exec();
}

void MainWindow::on_toolPrint_clicked()
{
//    QPrinter printer;
//    QPrintDialog *dialog = new QPrintDialog(&printer, this);
//    dialog->setWindowTitle(MSG_PRINT);

    switch(ui->tabW->currentIndex()){
    case TAB_EDIT:
        if(hasChange(TABLE_EDIT)){
            QMessageBox::warning(this, MSG_CHANGE, MSG_SAVEFIRST);
            return;
        }
        printTable(ui->tableEdit, T_INVAL, ui->comboTables->currentText(), cfg.printOutput);
        break;

    case TAB_FACTOR:
        if(hasChange(TABLE_PAYS) || hasChange(TABLE_ITEMS)){
            QMessageBox::warning(this, MSG_CHANGE, MSG_SAVEFIRST);
            return;
        }

        printInvoice(cfg.printOutput);

//        printTable(ui->tableItems, T_INVAL, trUtf8("جدول"));
//        printTable(ui->tablePays, T_INVAL, trUtf8("جدول"));

        break;
    case TAB_REPORT:

        switch(report){
        case R_ITEM:
            printRStorage(cfg.printOutput);
            break;
        case R_SALE:
            printRSales(cfg.printOutput);
            break;
        case R_TRANS:
            printRTransactions(cfg.printOutput);
            break;
        case R_FIN:
            printRSalesTransaction(cfg.printOutput);
            break;
        case R_SEND:
            printRTransfer(cfg.printOutput);
            break;
        case R_CUSTOMER:
            printTable(ui->tableReport, T_INVAL, trUtf8("گزارش مشتریان"), cfg.printOutput);
            break;
        default:
            break;
        }

        break;
    default:
        break;
    }

//    dialog->exec();

//    ui->tableEdit->
}

void MainWindow::LoadFactor(int id){

    struct logic_s flogic[2], plogic;
    char* needle;
    QTableWidgetItem* item;

    flogic[0].col = id_col(T_FACTORS, "factor_id");
    flogic[0].ival = id;
    flogic[0].logic = LOGIC_EQ;
    flogic[0].flags = 0;
    flogic[0].comb = LOGICOMB_AND;

    flogic[1].col = id_col(T_FACTORS, "removed");
    flogic[1].ival = 1;
    flogic[1].logic = LOGIC_NE;
    flogic[1].flags = 0;
    flogic[1].comb = LOGICOMB_AND;

    plogic.col = id_col(T_PAYMENTS, "factor_id");
    plogic.ival = id;
    plogic.logic = LOGIC_EQ;
    plogic.flags = 0;        

    loading = 1;

    //INFO: managers should be able to see the deleted factors
    LoadTable(ui->tableItems, T_FACTORS, 1, managermode?1:2, flogic);
    LoadTable(ui->tablePays, T_PAYMENTS, 1, 1, &plogic);    

    factor_id = id;

    ui->labelFactorNo->setText(trUtf8("%1").arg(id));

    item = ui->tableItems->item(0, id_col(T_FACTORS, "discount"));
    if(item){
        if((needle=strchr(item->text().toUtf8().data(), '%'))){
            *needle = 0;
            ui->lineDiscount->setText(item->text());
            ui->checkDiscountPercent->setCheckState(Qt::Checked);
            *needle = '%';
        } else {
            ui->lineDiscount->setText(item->text());
        }
    }

    item = ui->tableItems->item(0, id_col(T_FACTORS, "tax"));
    if(item){
        if((needle = strchr(item->text().toUtf8().data(), '%'))){
            *needle = 0;
            ui->lineTax->setText(item->text());
            ui->checkTaxPercent->setCheckState(Qt::Checked);
            *needle = '%';
        } else {
            ui->lineTax->setText(item->text());
        }
    }

    RecalcFactor();

    item = ui->tableItems->item(0, id_col(T_FACTORS, "customer_id"));
    if(item) ui->comboFactorCustomer->setCurrentText(item->text());

    loading = 0;

}

void MainWindow::on_slideFactorNo_valueChanged(int value)
{
    ui->spinFactorNo->setValue(value);
    loading = 1;
    LoadFactor(value);    
    loading = 0;
    if(value == ui->spinFactorNo->maximum()){
        ui->toolDelete->setEnabled(true);
    } else {
        ui->toolDelete->setEnabled(false);
    }
}

void MainWindow::on_spinFactorNo_valueChanged(int arg1)
{
    ui->slideFactorNo->setValue(arg1);
}

void MainWindow::on_btnNew_clicked()
{
    factor_id = get_last_factorid(db) + 1;
    ui->labelFactorNo->setText(trUtf8("%1").arg(factor_id));
    ui->spinFactorNo->setRange(0, factor_id);
    ui->slideFactorNo->setRange(0, factor_id);

    ui->spinFactorNo->setValue(factor_id);

    loading = 1;

    LoadTable(ui->tableItems, T_FACTORS, 0);
    LoadTable(ui->tablePays, T_PAYMENTS, 0);

    loading = 0;

    ui->lineRemainPay->clear();
    ui->lineTotalPrice->clear();

    ui->toolDelete->setEnabled(true);

}

void MainWindow::on_toolDelete_clicked()
{
    QTableWidgetItem* item;
//    QList <QTableWidgetItem*> itemList;
    enum table_id tid;
    int id, col, row;
    struct stmt_s st;

    switch(ui->tabW->currentIndex()){

    case TAB_EDIT:

        if(ui->tableEdit->hasFocus()){

            row = ui->tableEdit->currentRow();
            if(row < 0) break;

            tid = id_table_alias(ui->comboTables->currentText().toUtf8().data());
            if(tid == T_INVAL) break;

            col = id_col(tid, "id");
            if(col < 0) break;

            item = ui->tableEdit->item(row, col);
            if(!item){
                ui->tableEdit->removeRow(row);
                break;
            }

            if(!item->text().isEmpty()){
                id = item->text().toInt();
                if(delete_id(db, tid, "id", id, this_id, &st)) ui->tableEdit->removeRow(row);
                finalize(&st);
            } else {
                ui->tableEdit->removeRow(row);
            }
        } else if(ui->tableShow->hasFocus() && managermode){

            row = ui->tableShow->currentRow();
            if(row < 0) break;
            ui->tableShow->removeRow(row);

        }

        break;

    case TAB_FACTOR:

        if(ui->tableItems->hasFocus()){
            row = ui->tableItems->currentRow();
            if(row >= 0){
                ui->tableItems->removeRow(row);
            }
        } else if(ui->tablePays->hasFocus()){
            row = ui->tablePays->currentRow();
            if(row >= 0){
                ui->tablePays->removeRow(row);
            }
        }

        RecalcFactor();

        break;

    default:
        break;

    }

}

void MainWindow::loadDBs(QStringList list){
    struct db_s* ent = NULL;
    int i;      

    for(i = 0; i < list.count(); i++){

        if(find_db_path(db_first, list.at(i).toUtf8().data())) continue;

        if(!ent) ent = new struct db_s;
        ent->next = NULL;

        if(init_db(ent, list.at(i).toUtf8().data(), list.at(i).toUtf8().data())){
            ui->comboDBs->addItem(list.at(i));
            db_last->next = ent;
            db_last = ent;
            ent = NULL;
        } else {
            QMessageBox::warning(this, MSG_LOADING, MSG_NOLOAD.arg(list.at(i)));
        }
    }

    ui->comboDBs->setCurrentIndex(ui->comboDBs->count()-1);
}

void MainWindow::loadDstDBs(QStringList list){
    struct db_s* ent = NULL;
    int i;
    for(i = 0; i < list.count(); i++){

        if(find_db_path(db_first, list.at(i).toUtf8().data())) continue;

        if(!ent) ent = new struct db_s;
        ent->next = NULL;

        if(init_db(ent, list.at(i).toUtf8().data(), list.at(i).toUtf8().data())){
            ui->comboDstDB->addItem(list.at(i));
            db_last->next = ent;
            db_last = ent;
            ent = NULL;
        }
    }

    ui->comboDstDB->setCurrentIndex(ui->comboDstDB->count()-1);
}

void MainWindow::on_toolLoadDB_clicked()
{
    QStringList list;
    QFileDialog fileDlg;
//    fileDlg.setDefaultSuffix(tr("db"));

    fileDlg.setNameFilter(tr("BNF DataBase (*."DB_SUFFIX")"));

    fileDlg.exec();

    list = fileDlg.selectedFiles();

    loadDBs(list);

}

void MainWindow::on_comboDBs_currentIndexChanged(const QString &arg1)
{
    struct db_s* ent;

    for(ent = db_first; ent; ent = ent->next){
        if(!strcmp(ent->alias, arg1.toUtf8().data())){
            db = ent;
            break;
        }
    }

    on_comboTables_currentIndexChanged(ui->comboTables->currentText());

    loadLists();

}

void MainWindow::about(){

    AboutDialog a;
    a.setWindowFlags(Qt::FramelessWindowHint);
    a.adjustSize();
    a.exec();

}

void MainWindow::on_toolTrunc_clicked()
{
    enum table_id tid = id_table_alias(ui->comboTables->currentText().toUtf8().data());
    if(tid == T_INVAL) return;

    trunc_table(db, tid);

    loading = 1;
    LoadTable(ui->tableEdit, tid, 1);
    loading = 0;
}

void MainWindow::on_toolRefresh_clicked()
{
    switch(ui->tabW->currentIndex()){

    case TAB_EDIT:
        emit ui->comboTables->currentIndexChanged(ui->comboTables->currentText());        
        emit ui->comboDstTables->currentIndexChanged(ui->comboDstTables->currentText());
        break;

    case TAB_FACTOR:
        RecalcFactor();
        break;

    case TAB_REPORT:

        switch(report){

        case R_ITEM:
            on_RradioStore_clicked();
            break;

        case R_SALE:
            on_RradioSale_clicked();
            break;

        case R_TRANS:
            on_RradioTrans_clicked();
            break;

        case R_FIN:
            on_RradioFinance_clicked();
            break;

        case R_SEND:
            on_RradioSend_clicked();
            break;

        case R_CUSTOMER:
            on_RradioCustomers_clicked();
            break;

        default:
            QMessageBox::critical(this, "", "DESIGN ERROR");
            break;
        }

        break;

    default:
        break;

    }

}



void MainWindow::on_toolNewDB_clicked()
{
    QStringList list;
    QFileDialog fileDlg;

    struct db_s* db = new struct db_s;

//    fileDlg.setFileMode(QFileDialog::DirectoryOnly);
    fileDlg.setOption(QFileDialog::ShowDirsOnly, true);
    fileDlg.setAcceptMode(QFileDialog::AcceptSave);
    fileDlg.setDefaultSuffix(tr(DB_SUFFIX));
    fileDlg.setNameFilter(tr("BNF DataBase (*."DB_SUFFIX")"));

    fileDlg.exec();

    list = fileDlg.selectedFiles();

    if(!init_db(db, list.at(0).toUtf8().data(), list.at(0).toUtf8().data())){
        QMessageBox::critical(this, MSG_SAVING, MSG_SAVEFAIL);
        return;
    }

    db_last->next = db;
    db_last = db;

    ui->comboDBs->addItem(list.at(0).toUtf8());
    ui->comboDBs->setCurrentIndex(ui->comboDBs->count()-1);
}

void MainWindow::on_toolCloseDB_clicked()
{

    struct db_s* ent, *prev;

    if(!ui->comboDBs->currentIndex()) return;

    ent = db;
    ui->comboDBs->removeItem(ui->comboDBs->currentIndex());    

    for(prev = db_first; prev; prev = prev->next){
        if(prev->next == ent){
            prev->next = ent->next;
            if(db_last == ent) db_last = prev;
            close_db(ent);
            delete ent;
        }
    }
}

void MainWindow::on_toolShowDbOps_clicked()
{
    //▲▼
    if(ui->groupDbOps->isHidden()){
//        ui->toolShowDbOps->setText(trUtf8("▼"));
        ui->toolShowDbOps->setArrowType(Qt::DownArrow);
        ui->groupDbOps->setHidden(false);
    } else {
//        ui->toolShowDbOps->setText(trUtf8("▲"));
        ui->toolShowDbOps->setArrowType(Qt::LeftArrow);
        ui->groupDbOps->setHidden(true);
    }
}

void MainWindow::on_toolLoadDstDB_clicked()
{
    QStringList list;
    QFileDialog fileDlg;
//    fileDlg.setDefaultSuffix(tr("db"));

    fileDlg.setNameFilter(tr("BNF DataBase (*."DB_SUFFIX")"));

    fileDlg.exec();

    list = fileDlg.selectedFiles();

    loadDstDBs(list);
}

void MainWindow::on_toolCloseDstDB_clicked()
{
    struct db_s* ent, *prev;

    if(!ui->comboDstDB->currentIndex()) return;

    ent = db;

    for(prev = db_first; prev; prev = prev->next){
        if(prev->next == ent){
            ui->comboDstDB->removeItem(ui->comboDstDB->currentIndex());
            prev->next = ent->next;
            if(db_last == ent) db_last = prev;
            close_db(ent);
            delete ent;
        }
    }

}

void MainWindow::on_toolDstDBMerge_clicked()
{

    QListWidgetItem* item;
    QTableWidgetItem* titem;
    QCheckBox *check;
    enum table_id tid;
    int col, row;
    struct db_s* prev, *dst_db;

    switch(QMessageBox::question(this,
                                MSG_CHANGE,
                                MSG_MERGE.arg(ui->comboDstDB->currentText()).arg(ui->comboDBs->currentText()),
                                QMessageBox::Yes|QMessageBox::No)){

    case QMessageBox::No:
        return;
        break;

    default:
        break;

    }    

    dst_db = find_db_alias(db_first, ui->comboDstDB->currentText().toUtf8().data());
    if(!dst_db) return;

    col = id_col(T_SENDS, "reg");

    start_trans(db);

    for(int i = 0; i < ui->listTables->count(); i++){

        item = ui->listTables->item(i);
        if(!item) continue;

        check = (QCheckBox*)ui->listTables->itemWidget(item);
        if(!check) continue;

        if(check->isChecked()){

            tid = id_table_alias(ui->comboDstTables->currentText().toUtf8().data());

            prev = db;
            db = dst_db;
            ui->comboDstTables->setCurrentIndex(ui->comboDstTables->findText(check->text()));
            db = prev;

            if(tid == T_SENDS){
                //change REG state from PENDING to YES
                for(row = 0; row < ui->tableShow->rowCount(); row++){
                    titem = ui->tableShow->item(row, col);
                    if(titem){
                        if(titem->text().toInt() == REG_PENDING){
                            titem->setText(tr("%1").arg(REG_YES));
                        }
                    }
                }

            }

            if(!WriteTable(ui->tableShow, tid, -1, 0, 1)){
                rollback(db);
                goto end;
            }

            if(tid == T_SENDS && !managermode){
                if(!recalcItemQty(ui->tableShow, T_SENDS, DIR_RECV)){
                    rollback(db);
                    goto end;
                }
            }

        }

    }

end:
    end_trans(db);

}

void MainWindow::on_toolDstDBBackup_clicked()
{
    QStringList list;
    QFileDialog fileDlg;
    struct db_s* prev;
    struct db_s* ent = new struct db_s;
    QListWidgetItem* item;
    QTableWidgetItem* titem;
    QCheckBox *check;
    enum table_id tid;
    int dst_store_id;
    struct logic_s logic;
    int col, row;

    if(ui->comboDstStore->currentText().isEmpty() && managermode){
        switch(QMessageBox::question(this,
                                    MSG_CHANGE,
                                    MSG_DST,
                                    QMessageBox::Yes|QMessageBox::No)){

        case QMessageBox::No:
            return;
            break;

        default:
            break;

        }
    }

//    fileDlg.setFileMode(QFileDialog::DirectoryOnly);
    fileDlg.setOption(QFileDialog::ShowDirsOnly, true);
    fileDlg.setAcceptMode(QFileDialog::AcceptSave);
    fileDlg.setDefaultSuffix(tr(DB_SUFFIX));
    fileDlg.setNameFilter(tr("BNF DataBase (*."DB_SUFFIX")"));

    if(fileDlg.exec()){
        list = fileDlg.selectedFiles();
    }
    if(!list.count()) return;

    if(!init_db(ent, list.at(0).toUtf8().data(), list.at(0).toUtf8().data())){
        QMessageBox::critical(this, MSG_SAVING, MSG_SAVEFAIL);
        return;
    }

    db_last->next = ent;
    db_last = ent;

    ui->comboDstDB->addItem(list.at(0).toUtf8());
    //ui->comboDstDB->setCurrentIndex(ui->comboDstDB->count()-1);

    prev = db;
    db = ent;

    start_trans(db);

    for(int i = 0; i < ui->listTables->count(); i++){

        item = ui->listTables->item(i);
        if(!item) continue;

        check = (QCheckBox*)ui->listTables->itemWidget(item);
        if(!check) continue;

        if(check->isChecked()){

            db = prev;
            ui->comboDstTables->setCurrentIndex(ui->comboDstTables->findText(check->text()));
            db = ent;

            tid = id_table_alias(ui->comboDstTables->currentText().toUtf8().data());

            /* THIS COULD HAPPEN ONLY AT MANAGER SIDE, AS FAR AS DstStore IS DISABLED AT BRANCHES */

            if(!ui->comboDstStore->currentText().isEmpty() && id_col(tid, "store_id") > -1){

                if(!translate_name_to_id(db, T_STORES, ui->comboDstStore->currentText().toUtf8().data(), &dst_store_id)){
                    rollback(db);
                    QMessageBox::critical(this, MSG_SAVING, MSG_NOTDEF.arg(ui->comboDstStore->currentText()));
                    goto end;

                }

            } else {

                dst_store_id = -1;

            }

            if(tid == T_ITEMS && !ui->comboDstStore->currentText().isEmpty() && managermode){
                col = id_col(T_ITEMS, "qty");
                for(row = 0; row < ui->tableShow->rowCount(); row++){
                    titem = ui->tableShow->item(row, col);
                    if(titem){
                        titem->setText(tr("0"));
                    }
                }
            }

            if(tid == T_SENDS && !ui->comboDstStore->currentText().isEmpty()){
                col = id_col(T_SENDS, "reg");
                //change REG state from NO to PENDING
                for(row = 0; row < ui->tableShow->rowCount(); row++){
                    titem = ui->tableShow->item(row, col);
                    if(titem){
                        if(titem->text().toInt() == REG_NO){
                            titem->setText(tr("%1").arg(REG_PENDING));
                        }
                    }
                }
            }

            if(!WriteTable(ui->tableShow, tid, dst_store_id, 1, 0)){
                rollback(db);
                goto end;
            }

        }

    }

end:
    end_trans(db);

    db = prev;

}

void MainWindow::on_comboDstTables_currentIndexChanged(const QString &arg1)
{
    enum table_id tid;
    struct db_s* prev;
    int nlogic;
    struct logic_s logic;

    tid = id_table_alias(arg1.toUtf8().data());

    if(tid == T_INVAL){
        ui->tableShow->setColumnCount(0);
        ui->tableShow->setRowCount(0);
        return;
    }

    loading = 1;
    prev = db;
    db = find_db_alias(db_first, ui->comboDstDB->currentText().toUtf8().data());
    if(db){

        nlogic = 0;

        if(!ui->comboDstStore->currentText().isEmpty()){//you are probably sending the backup for a store...

            if(tid == T_STORES){

                logic.col = id_col(T_STORES, "id");
                logic.logic = LOGIC_EQ;
                logic.flags = 0;
                if(!translate_name_to_id(prev, T_STORES, ui->comboDstStore->currentText().toUtf8().data(), &logic.ival)){
                    goto end;
                }

                nlogic = 1;

            } else if(tid == T_SENDS){

                logic.col = id_col(T_SENDS, "store_id");
                logic.logic = LOGIC_EQ;
                logic.flags = 0;
                if(!translate_to_id(prev, T_SENDS, logic.col, ui->comboDstStore->currentText().toUtf8().data(), this_id, &logic.ival)){
                    goto end;
                }

                nlogic = 1;

            }

        }

        LoadTable(ui->tableShow, tid, 1, nlogic, &logic);

    }

end:
    db = prev;
    loading = 0;
}

void MainWindow::on_comboDstDB_currentIndexChanged(const QString &arg1)
{
    on_comboDstTables_currentIndexChanged(ui->comboDstTables->currentText());
}

void MainWindow::on_comboCurrentStore_currentIndexChanged(const QString &arg1)
{
    int prev_id = this_id;
    if(!translate_name_to_id(db, T_STORES, arg1.toUtf8().data(), &this_id)){
        this_id = prev_id;
        ui->comboCurrentStore->setCurrentIndex(0);
    }
    qDebug()<<"set store id to "<<this_id;
}

void MainWindow::on_toolCopy_clicked()
{
    doCopy();
}

void MainWindow::on_toolPaste_clicked()
{
    doPaste();
}

void MainWindow::on_toolDeleteCell_clicked()
{
    doDelete();
}

void MainWindow::on_radioInitTables_clicked()
{

}

void MainWindow::on_radioSyncTables_clicked()
{

}

void MainWindow::on_toolDeleteFactor_clicked()
{
    struct stmt_s st;
    switch(QMessageBox::question(this,
                                MSG_DELETE,
                                 MSG_DELETEFACTOR.arg(factor_id),
                                QMessageBox::Yes|QMessageBox::No)){

    case QMessageBox::No:
        return;
        break;

    default:
        break;

    }

    setColumn(ui->tableItems, T_FACTORS, "removed", tr("1"));
    WriteTable(ui->tableItems, T_FACTORS);

    /*INFO: This is the old code which removed the factor completely

    start_trans(db);

    if(!delete_id(db, T_FACTORS, "id", factor_id, this_id, &st)){
        rollback(db);
        QMessageBox::warning(this, MSG_DELETE, MSG_SAVEFAIL);
        return;
    }

    finalize(&st);

    if(!delete_id(db, T_PAYMENTS, "factor_id", factor_id, this_id, &st)){
        rollback(db);
        QMessageBox::warning(this, MSG_DELETE, MSG_SAVEFAIL);
        return;
    }
    finalize(&st);

    end_trans(db);
    */

}

void MainWindow::on_comboFactorCustomer_currentTextChanged(const QString &arg1)
{

    setColumn(ui->tableItems, T_FACTORS, "customer_id", arg1);

}

void MainWindow::on_checkDiscountPercent_clicked()
{
    if(!ui->checkDiscountPercent->isChecked()){
        ui->lineDiscount->setEnabled(true);
    } else {
        if(ui->lineDiscount->text().isEmpty()){
            QMessageBox::warning(this, MSG_INVALID, MSG_VALUEFIRST);
            ui->checkDiscountPercent->setCheckState(Qt::Unchecked);
            return;
        }

        if(ui->lineDiscount->text().toInt() > 100 || ui->lineDiscount->text().toInt() < 0){
            QMessageBox::warning(this, MSG_INVALID, MSG_BADPERCENT);
            ui->checkDiscountPercent->setCheckState(Qt::Unchecked);
            ui->lineDiscount->clear();
            return;
        }

        ui->lineDiscount->setEnabled(false);

    }
}

void MainWindow::on_checkTaxPercent_clicked()
{
    if(!ui->checkTaxPercent->isChecked()){
        ui->lineTax->setEnabled(true);
    } else {
        if(ui->lineTax->text().isEmpty()){
            QMessageBox::warning(this, MSG_INVALID, MSG_VALUEFIRST);
            ui->checkTaxPercent->setCheckState(Qt::Unchecked);
            return;
        }

        if(ui->lineTax->text().toInt() > 100 || ui->lineTax->text().toInt() < 0){
            QMessageBox::warning(this, MSG_INVALID, MSG_BADPERCENT);
            ui->checkTaxPercent->setCheckState(Qt::Unchecked);
            ui->lineTax->clear();
            return;
        }

        ui->lineTax->setEnabled(false);

    }

}


void MainWindow::on_lineRemainPay_textChanged(const QString &arg1)
{
    char buf[1024];
    if(nt_convert_str(arg1.toUtf8().data(), buf, 1024) == E13_OK){
        ui->labelTextNum->setText(trUtf8(buf));
    }
}

void MainWindow::on_RcheckStartDateToday_clicked()
{
    if(ui->RcheckStartDateToday->isChecked()){
        ui->RlineStartDate->setText(ui->labelDate->text());
        ui->RlineStartDate->setEnabled(false);
    } else {
        ui->RlineStartDate->setEnabled(true);
        ui->RlineStartDate->clear();
    }
}

void MainWindow::on_RcheckEndDateToday_clicked()
{
    if(ui->RcheckEndDateToday->isChecked()){
        ui->RlineEndDate->setText(ui->labelDate->text());
        ui->RlineEndDate->setEnabled(false);
    } else {
        ui->RlineEndDate->setEnabled(true);
        ui->RlineEndDate->clear();
    }
}

void MainWindow::on_lineDiscount_textChanged(const QString &arg1)
{
    //setColumn(ui->tableItems, T_FACTORS, "discount", arg1);
    RecalcFactor();
}

void MainWindow::on_lineTax_textChanged(const QString &arg1)
{
    //setColumn(ui->tableItems, T_FACTORS, "tax", arg1);
    RecalcFactor();
}

void MainWindow::on_btnShowDbOps_clicked()
{
    on_toolShowDbOps_clicked();
}
