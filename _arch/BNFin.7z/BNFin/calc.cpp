﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "msg.h"
#include "aboutdialog.h"

#include "db.h"

#include "../lib13/include/str13.h"

#include <QUrl>
#include <qDebug>
#include <QMessageBox>
#include <QtPrintSupport>
#include <QFileDialog>
#include <QLineEdit>
#include <QClipboard>
#include <QApplication>

#include <QList>
#include <QMap>

#include <stdio.h>
#include <stdarg.h>

void MainWindow::RecalcSales(QTableWidget* table, QLineEdit* out){

    QTableWidgetItem* item;
    long total = 0, subtotal, pricemult;
    int ppu, qty;
    struct stmt_s st;
    int row, nrows = table->rowCount();
    int id;
    for(row = 0; row < nrows; row++){

        item = table->item(row, id_col(T_FACTORS, "item_id"));
        if(!item) continue;

        if(!translate_to_id(db, T_FACTORS, id_col(T_FACTORS, "item_id"), item->text().toUtf8().data(), this_id, &id)){
            return;
        }

        item = table->item(row, id_col(T_FACTORS, "item_qty"));
        if(!item) continue;
        else qty = item->text().toInt();

        ppu = translate_to_col_int(db, T_FACTORS, id_col(T_FACTORS, "item_price"), id, this_id, &st);

        item = new QTableWidgetItem;
        item->setText(tr("%1").arg(ppu));
        table->setItem(row, id_col(T_FACTORS, "item_price"), item);

        finalize(&st);

        item = table->item(row, id_col(T_FACTORS, "transtype_id"));
        if(!item) continue;

        if(!translate_to_id(db, T_FACTORS, id_col(T_FACTORS, "transtype_id"), item->text().toUtf8().data(), this_id, &id)){
            return;
        }

        pricemult = translate_to_col_int(db, T_FACTORS, id_col(T_FACTORS, "transtype_pricemult"), id, this_id, &st);

        finalize(&st);

        item = table->item(row, id_col(T_FACTORS, "totalprice"));
        if(!item){
            item = new QTableWidgetItem;
            table->setItem(row, id_col(T_FACTORS, "totalprice"), item);
        }

        subtotal = qty*ppu*pricemult;

        item->setText(trUtf8("%1").arg(subtotal));

        total += subtotal;

    }

    out->setText(tr("%1").arg(total));

}

void MainWindow::RecalcPays(QTableWidget* table, QLineEdit* out){

    QTableWidgetItem* item;
    long remain = 0, subtotal, pricemult;
    int id;
    struct stmt_s st;

    int row, nrows = table->rowCount();

    for(row = 0; row < nrows; row++){

        item = table->item(row, id_col(T_PAYMENTS, "transtat_id"));
        if(!item) continue;

        if(!translate_to_id(db, T_PAYMENTS, id_col(T_PAYMENTS, "transtat_id"), item->text().toUtf8().data(), this_id, &id)){
            return;
        }

        item = table->item(row, id_col(T_PAYMENTS, "val"));
        if(!item) continue;
        else subtotal = item->text().toLong();

        pricemult = translate_to_col_int(db, T_PAYMENTS, id_col(T_PAYMENTS, "transtat_pricemult"), id, this_id, &st);

        finalize(&st);

        remain += pricemult*subtotal;
    }

    out->setText(tr("%1").arg(remain));

}

void MainWindow::RecalcStore(QTableWidget* table, QLineEdit* out){

    QTableWidgetItem* item;
    long price, qty, remain = 0;

    int row, nrows = table->rowCount();

    for(row = 0; row < nrows; row++){

        item = table->item(row, id_col(T_ITEMS, "price"));
        if(!item) continue;
        price = item->text().toInt();

        item = table->item(row, id_col(T_ITEMS, "qty"));
        if(!item) continue;
        qty = item->text().toInt();

        remain += price*qty;
    }

    out->setText(tr("%1").arg(remain));

}


void MainWindow::RecalcFactor(){

    QTableWidgetItem* item;

    long double total = 0, rawtotal = 0, remain, subtotal, pricemult, discount, tax, ppu, qty;

    char* buf;
    char* needle;
    int row, nrows = ui->tableItems->rowCount();

    //set discount/tax values
    if(!loading){
        if(!ui->lineDiscount->text().toDouble()){
            setColumn(ui->tableItems, T_FACTORS, "discount", tr("0"));
        } else {

            if(ui->checkDiscountPercent->isChecked()){
                setColumn(ui->tableItems, T_FACTORS, "discount", ui->lineDiscount->text() + tr("%"));
            } else {
                setColumn(ui->tableItems, T_FACTORS, "discount", ui->lineDiscount->text());
            }

        }

        if(!ui->lineTax->text().toDouble()){
            setColumn(ui->tableItems, T_FACTORS, "tax", tr("0"));
        } else {

            if(ui->checkTaxPercent->isChecked()){
                setColumn(ui->tableItems, T_FACTORS, "tax", ui->lineTax->text() + tr("%"));
            } else {
                setColumn(ui->tableItems, T_FACTORS, "tax", ui->lineTax->text());
            }

        }
    }

    for(row = 0; row < nrows; row++){

        item = ui->tableItems->item(row, id_col(T_FACTORS, "item_price"));
        if(!item) continue;
        else ppu = item->text().toDouble();

        item = ui->tableItems->item(row, id_col(T_FACTORS, "item_qty"));
        if(!item) continue;
        else qty = item->text().toDouble();

        item = ui->tableItems->item(row, id_col(T_FACTORS, "transtype_pricemult"));
        if(!item) continue;
        else pricemult = item->text().toDouble();

        subtotal = qty*ppu*pricemult;

        item = ui->tableItems->item(row, id_col(T_FACTORS, "discount"));
        if(!item){
            discount = 0;
        } else {
            buf = dyn_copy_str(item->text().toUtf8().data());
            if((needle = strpbrk(buf, "%"))){
                *needle = 0;
                discount = atof(buf)*subtotal/100;
                if(loading){
                    ui->lineDiscount->setText(tr(buf));
                    ui->checkDiscountPercent->setChecked(true);
                }
            } else {
                discount = item->text().toDouble();
                if(loading){
                    ui->lineDiscount->setText(tr(buf));
                    ui->checkDiscountPercent->setChecked(false);
                }
            }
            free(buf);
        }

        item = ui->tableItems->item(row, id_col(T_FACTORS, "tax"));
        if(!item){
            tax = 0;
        } else {
            buf = dyn_copy_str(item->text().toUtf8().data());
            if((needle = strpbrk(buf, "%"))){
                *needle = 0;
                tax = atof(buf)*(subtotal-discount)/100;
                if(loading){
                    ui->lineTax->setText(tr(buf));
                    ui->checkTaxPercent->setChecked(true);
                }
            } else {
                tax = item->text().toDouble();
                if(loading){
                    ui->lineTax->setText(tr(buf));
                    ui->checkTaxPercent->setChecked(false);
                }

            }
            free(buf);
        }

        item = ui->tableItems->item(row, id_col(T_FACTORS, "totalprice"));
        if(!item){
            item = new QTableWidgetItem;
            ui->tableItems->setItem(row, id_col(T_FACTORS, "totalprice"), item);
        }

        item->setText(trUtf8("%1").arg((long)subtotal));

        rawtotal += subtotal;
        total += subtotal + tax - discount;

    }

    remain = total;

    nrows = ui->tablePays->rowCount();

    for(row = 0; row < nrows; row++){

        item = ui->tablePays->item(row, id_col(T_PAYMENTS, "val"));
        if(!item){
            //qDebug()<<"** Continue 1 @ "<<row;
            continue;
        } else {
            //qDebug()<<"** Item -> "<<item->text();
            subtotal = item->text().toDouble();
        }

        item = ui->tablePays->item(row, id_col(T_PAYMENTS, "transtat_pricemult"));
        if(!item){
            //qDebug()<<"** Continue 2 @ "<<row;
            continue;
        } else {
            //qDebug()<<"** Item -> "<<item->text();
            pricemult = item->text().toDouble();
        }

        //qDebug()<<"** Remain -> "<<remain<<" pricemult = "<<pricemult<<" subtotal = "<<subtotal;

        if(pricemult > 0.0){
            remain -= pricemult*subtotal;
        }
    }

    ui->linePriceSum->setText(trUtf8("%1").arg((long)rawtotal));

    ui->lineTotalPrice->setText(tr("%1").arg((long)total));

    ui->lineRemainPay->setText(tr("%1").arg((long)remain));
}

bool MainWindow::recalcItemQty(QTableWidget* table, enum table_id tid, enum send_dir dir){

    struct stmt_s st;
    QTableWidgetItem* item, *item_id, *item_sm;
    int row, qtycol, nrows, idcol, storemult, smcol, newcol;
    int id;

    qtycol = id_col(tid, "item_qty");
    idcol = id_col(tid, "item_id");
    smcol = id_col(tid, "transtype_storemult");
    newcol = id_col(tid, "new");

    if(qtycol < 0 || idcol < 0 || smcol < 0) return false;

    nrows = table->rowCount();
    if(nrows == 1) nrows++;

    for(row = 0; row < nrows; row++){

        qDebug()<<"recalcItemQty(): ROW "<<row<<" QTYCOL "<<qtycol<<" IDCOL "<<idcol;

        item = table->item(row, newcol);
        if(!item) continue;
        if(item->text().toInt() != 1) continue;

        item = table->item(row, qtycol);
        if(!item) continue;

        qDebug()<<"recalcItemQty(): QtyColVal "<<item->text();

        item_id = table->item(row, idcol);
        if(!item_id) continue;

        if(!translate_to_id(db, tid, idcol, item_id->text().toUtf8().data(), this_id, &id)){
            qDebug()<<" TRANSL "<<item_id->text()<<" ID "<<id;
            continue;
        }

        qDebug()<<"recalcItemQty(): UPDATE ITEM "<<item_id->text()<<" ID "<<id<<" QTY "<<item->text();

        item_sm = table->item(row, smcol);
        if(!item_sm) continue;

        storemult = item_sm->text().toInt()*dir;

        if(!update_item_qty(db,
                            id,
                            this_id,
                            (int)mult("iii",
                                      item_sm->text().toInt(),
                                      item->text().toInt(),
                                      dir),
                            &st)
                ){
            finalize(&st);
            return false;
        }

    }

    finalize(&st);

    return true;

}

long double MainWindow::mult(char* fmt, ...){

    va_list ap;
    double d;
    long l;
    long double mul = 1.0;
    int i;

    va_start(ap, fmt);
    while(*fmt){

        switch(*fmt){

        case 'l':
            l = va_arg(ap, long);
            mul = mul*l;
            break;

        case 'i':
            i = va_arg(ap, int);
            mul = mul*i;
            break;

        case 'd':
            d = va_arg(ap, double);
            mul = mul*d;
            break;

        default:
            break;

        }

        fmt++;
    }
    va_end(ap);

    return mul;
}
