﻿//TODO: remove the second stat() call in enum dir.

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <getopt.h>

#ifdef WIN32
#include <windows.h>
#endif

#define SIGN	0x8d00d1e8

#undef NDEBUG
#include "../lib13/include/lib13.h"

#define log(fmt, args...)       MACRO(\
                                        if(c->logfile) fprintf(c->logfile, fmt, ## args);\
                                )

#define printo(fmt, args...)    MACRO(\
                                    if(c->v) printf(fmt, ## args);\
                                    log(fmt, ## args);\
                                )

#define showline(fmt, args...)    MACRO(\
                                    printf(fmt, ## args);\
                                )

#define MINARGS (2)
#define MAXARGS (20)
#define LF "\n"
#define ENC 1
#define DEC 0
#define ESCAPE '\\'
#define LIST_DELIM ";,"
#define WILD_ANY    '*'
#define WILD_ONE    '?'

#define ALG         "aes"
#define PEEK_FILE   "peek.conf"
#define LOG_FILE    "peek.log"
#define BUFSIZE     (1*MB)

#define PATH_DIR    1
#define PATH_FILE   2
#define PATH_WILD   3
#define PATH_NONE   3

#define po      _DebugMsg
#define _deb1   _DebugMsg

const char* wild = "*?";

struct off {
    off_t start;//zero means from start
    off_t end;//zero means to end
};

struct path {
    int type;
    struct stat st;
    char* addr;
    int nsub;
    struct path* sub;//use if wildcarded
};

struct conf {
    //input
    int rec;
    char* alg;
    char* pass;
    char* file;
    char* pathlist;
    int dir;
    int show;
    char* offlist;
    char* output;
    char* ext;
    size_t bufsize;
    char* run;
    int log;
    int v;
    int crc;
    int shred;

    //internal
    crypt13_alg_t algt;
    int noff;
    struct off* off;
    int npath;
    struct path* path;    
    struct crypt13 crypt;
    char* buf;
    FILE* logfile;
#ifdef WIN32
	HANDLE h, hMap;
#endif
};

#define INFOBLOCK_PACK_FMT "LLL"
#define INFOBLOCK_SIZE  (sizeof(uint32_t)*3)
struct infoblock{
    uint32_t orig_size;
    uint32_t crc32;
    uint32_t sign;
};

char* map_file(struct conf* c, char* path, size_t bufsize);

void usage(struct conf* c, char* progname){
    int v = c->v;
    c->v = 1;
    printo("This is peace keeper, a program to protect."LF);
    printo("syntax:"LF);
    printo("%s options pathlist"LF, progname);
    printo("options:"LF);
    printo("-h --help                       shows help."LF);
    printo("-r --recursive                  recursive directory."LF);
    printo("-a --algorithm algorithm_name   crypto algorithm, [default = \'aes\']."LF);
    printo("-p --pass passphrase            sets passphrase."LF);
    printo("-f --file filename              sets peek file name."LF);
    printo("-d --decrypt                    decrypt."LF);
    printo("-e --encrypt                    encrypt [default]."LF);
    printo("-s --show                       decrypt in memmory and show,"LF);
    printo("                                no actual write to disk."LF);
    printo("-t --offset offsetlist          crypt the given offset (in bytes) list,"LF);
    printo("                                e.g. 0-100;200-300."LF);
    printo("-o --output filename            write results to the given file name."LF);
    printo("-x --extension ext              sets encrypted file extension,"LF);
    printo("                                so encryption goes to same path plus"LF);
    printo("                                the given ext and vice versa."LF);
    printo("-b --buffer size                sets buffer size (in bytes)."LF);
    printo("-u --run command                runs program and passed the output"LF);
    printo("                                file as an argument to it."LF);
    printo("-l --log                        enable logging to \'%s\'."LF, LOG_FILE);
    printo("-v --verbose                    enable verbose."LF);
    printo("-c --crc                        enable crc check."LF);
    printo("-m --shred n                    shred original file, overwrite n times."LF);
    printo("-n --thread n                   multi-threaded mode."LF);
    //printo("-z --size decryptsize           sets decryption size."LF);
    printo("*1  if none of -p nor -f is set, the program first tries to read"LF);
    printo("    passphrase from default file \'%s\'; if fails, tries interactive mode."LF, PEEK_FILE);
    printo("*2  available crypto algorithms are: des, des3, aes, ntru."LF);
    printo("*3  the \'pathlist\' is a \';\' separated list of files and directories."LF);
    printo("*4  while setting algorithm to an asymmetric (e.g. ntru) without any pathlist,"LF);
    printo("    the program generates a public/private key pair which could be"LF);
    printo("    written to a file."LF);
    printo("*5  the \'peek\' file is a simple script containing the options and needed args,"LF);
    printo("    please note that the first line is the number of arguments (argc); e.g.:"LF);
    printo("    4"LF);
    printo("    -o hell.txt"LF);
    printo("    --pass helloworld"LF);

    c->v = v;

}

int shred(struct conf* c, char* path){
    int i;
    char* buf;
    struct stat st;
    //TODO: TEMP
    if(c->shred > 0) {
        if(stat(path, &st) == -1) goto end;
        if(!(buf = map_file(c, path, st.st_size))) goto end;
        for(i = 0; i < c->shred; i++) {
            memset(buf, i, st.st_size);
#ifdef WIN32

        if(!FlushViewOfFile(buf, st.st_size)){
            goto endf;
        }

        FlushFileBuffers(c->h);

#else

#endif
        }
    }

endf:

#ifdef WIN32

        UnmapViewOfFile(buf);
        CloseHandle(c->hMap);
        CloseHandle(c->h);

#else

#endif


end:

	remove(path);

	return true_;
}

int show_buf(struct conf* c, char* buf, size_t bufsize){
	//TODO: TEMP
	showline("---	BEGIN	---\n");
	showline("%s\n", buf);
	showline("---	 END    ---\n");
    showline("Press any key to continue.\n");
	getch();getch();	
	return true_;
}

char* map_file(struct conf* c, char* path, size_t bufsize){
	char* buf;
#ifdef WIN32

    HANDLE h, hMap;
    h = CreateFileA(path, GENERIC_ALL, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if(h == INVALID_HANDLE_VALUE){
        printo("open failed."LF);
        return NULL;
    }

    hMap = CreateFileMappingA(h, NULL, PAGE_READWRITE, 0, bufsize, NULL);
    if(hMap == INVALID_HANDLE_VALUE){
    	CloseHandle(h);
        printo("create mapping failed."LF);
        return NULL;
    }

    buf = MapViewOfFile(hMap, FILE_MAP_ALL_ACCESS, 0, 0, bufsize);
    if(!buf){
    	CloseHandle(hMap);
    	CloseHandle(h);
        printo("mapping failed."LF);
        return NULL;
    }
	c->hMap = hMap;
	c->h = h;
#else

#endif

	return buf;
}

int crypt_file(struct conf* c, struct stat* st, char* path, void* param){    

    const size_t bsize = crypt13_enc_size(&c->crypt, INFOBLOCK_SIZE);
    char foot[bsize];
    size_t ebufsize;
    struct io13 io;
    error13_t ret;
    char* buf;
    struct infoblock ib;
    char* pathext;
    size_t outsize;
    char* tmpbuf, *ptr, *tmpptr;
    size_t offsize;

    /*
     * info block added at the end of the file.
     * uint32_t original_size;
     * uint32_t crc32;
     * uint32_t bufsize;
    */

    if(c->dir == DEC && c->ext){
        if(strcmp(p13_get_ext(path), c->ext)){
            printo("ignoring file < %s >..."LF, path);
            return true_;
        }
    }

    printo("%s file < %s (size = %u) >..."LF, c->dir == ENC?"encrypting":"decrypting", path, st->st_size);
    
    if(c->dir == ENC){
    
        if(c->ext && !strcmp(p13_get_ext(path), c->ext)){
            printo("ignoring file < %s >..."LF, path);
            return true_;
        }
    
        if(c->noff){
            offsize = c->off[0].end - c->off[0].start;
            if(offsize + c->off[0].start > c->off[0].end || offsize > st->st_size || !offsize) offsize = st->st_size;
        } else {
            offsize = st->st_size;
        }

        ebufsize = crypt13_enc_size(&c->crypt, offsize);

        po("ebufsize: %u, offsize: %u", ebufsize, offsize);
	    
        if(!c->ext){//may increase size
            if(io13_truncate(path, crypt13_enc_size(&c->crypt, st->st_size) + bsize) != E13_OK){
	    		printo("io error."LF);
	    		return false_;
	    	}
	    }
	}
	
	if(!(buf = map_file(c, path, ebufsize + bsize))){
		return false_;
	}

    if(c->dir == ENC){
    	
    	if(c->ext){
    		tmpbuf = (char*)m13_malloc(ebufsize + bsize);
    		if(!tmpbuf) goto fail;
    	}
    	
        if(c->crc){
            ib.crc32 = h13_crc32(buf, st->st_size);
        } else {
            ib.crc32 = 0;
        }

        ib.orig_size = st->st_size;
        ib.sign = SIGN;

        if(c->noff){
            ptr = buf + c->off[0].start;
            tmpptr = tmpbuf + c->off[0].start;
        } else {
            ptr = buf;
            tmpptr = tmpbuf;
        }

        if((ret = crypt13_encrypt(&c->crypt, ptr, ebufsize, c->ext?tmpptr:ptr, &outsize)) != E13_OK){
            printo("crypto failed (%s)."LF, e13_codemsg(ret));
            goto fail;
        }

        //assert(outsize == ebufsize);
        po("outsize: %u, ebufsize: %u", outsize, ebufsize);
        
//		foot = (char*)m13_malloc(crypt13_enc_size(&c->crypt, INFOBLOCK_SIZE));
//		if(!foot){
//				printo("out of memmory."LF);
//				goto fail;
//		}

        pack13(foot, INFOBLOCK_PACK_FMT, ib.orig_size, ib.crc32, ib.sign);

        if(c->noff){
            if(c->ext){
                ptr = tmpbuf + st->st_size;
            } else {
                ptr = buf + st->st_size;
            }
        } else {
            if(c->ext){
                ptr = tmpbuf + ebufsize;
            } else {
                ptr = buf + ebufsize;
            }
        }

        if((ret = crypt13_encrypt(&c->crypt, foot, INFOBLOCK_SIZE, ptr, &outsize)) != E13_OK){
            printo("crypto failed (%s)."LF, e13_codemsg(ret));
            goto fail;
        }
        
//        m13_free(foot);

//        assert(outsize == bsize);
        
        po("outsize: %u, bsize: %u", outsize, bsize);

    } else {
	
		if(c->show || c->ext){
			tmpbuf = (char*)m13_malloc(st->st_size);
			if(!tmpbuf){
				printo("out of memmory."LF);
				goto fail;
			}
			memcpy(tmpbuf, buf, st->st_size);
		}
		
//		foot = (char*)m13_malloc(crypt13_enc_size(&c->crypt, INFOBLOCK_SIZE));
//		if(!foot){
//				printo("out of memmory."LF);
//				goto fail;
//		}

        po("st->st_size - bsize -> %u - %u = %u, offsize = %u", st->st_size, bsize, st->st_size - bsize, offsize);

        if((ret = crypt13_decrypt(&c->crypt, buf + st->st_size - bsize, bsize, foot, &outsize)) != E13_OK){
            printo("crypto failed (%s)."LF, e13_codemsg(ret));
            goto fail;
        }

        unpack13(foot, INFOBLOCK_PACK_FMT, &ib.orig_size, &ib.crc32, &ib.sign);
        
//        m13_free(foot);
        
        if(ib.sign != SIGN){
        	printo("not encrypted using peek."LF);
        	goto fail;
        }

        if(c->noff){
            offsize = c->off[0].end - c->off[0].start;
            if(offsize + c->off[0].start > c->off[0].end || offsize > ib.orig_size || !offsize) offsize = ib.orig_size;
        } else {
            offsize = ib.orig_size;
        }

        ebufsize = crypt13_enc_size(&c->crypt, offsize);

        if(c->noff){
            ptr = buf + c->off[0].start;
            tmpptr = tmpbuf + c->off[0].start;
        } else {
            ptr = buf;
            tmpptr = tmpbuf;
        }

        if((ret = crypt13_decrypt(&c->crypt, ptr, offsize, (c->show||c->ext)?tmpptr:ptr, &outsize)) != E13_OK){
            printo("crypto failed (%s)."LF, e13_codemsg(ret));
            goto fail;
        }

        if(c->crc){
            if(ib.crc32 != h13_crc32((c->show||c->ext)?tmpbuf:buf, ib.orig_size)){
                printo("crc failed."LF);
                goto fail;
            }
        }

    }
    
    if(c->show && c->dir == DEC){
    	show_buf(c, tmpbuf, ib.orig_size);
    	m13_free(tmpbuf);
    	goto end;
    }

    if(!c->ext){

#ifdef WIN32

        if(!FlushViewOfFile(buf, c->dir==ENC?(ebufsize + bsize):ib.orig_size)){
            printo("sync failed."LF);
            return false_;
        }		

		FlushFileBuffers(c->h);
		
	    UnmapViewOfFile(buf);
	    CloseHandle(c->hMap);
	    CloseHandle(c->h);
		       
#else

#endif

		if(c->dir == DEC){
			if(io13_truncate(path, ib.orig_size) != E13_OK){
				printo("io error."LF);
				return false_;
			}
		}

    } else {//if(c->ext)
    
    	po("ext = %s", c->ext);

        if(c->dir == ENC){
        	po("ENC path: %s", path);
        	pathext = m13_malloc(strlen(path) + strlen(c->ext) + 5);
        	snprintf(pathext, strlen(path) + strlen(c->ext) + 5, "%s.%s", path, c->ext);
            po("pathext = %s", pathext);
        } else {
        	po("DEC");
        	pathext = m13_malloc(strlen(path) + 1);
        	strcpy(pathext, path);
            po("pathext = %s", pathext);
            ptr = p13_get_ext(pathext);
            po("ptr = %s", ptr);
			*(ptr-1) = '\0';
			po("pathext = %s", pathext);
        }
        
        po("pathext = %s", pathext);

        io13_init(&io, IO13_OFFLAG_CREATE|IO13_OFFLAG_WRONLY);
        if((ret = io13_open_file(&io, pathext)) != E13_OK){
            printo("failed to open (%s) output file < %s >."LF, e13_codemsg(ret), pathext);
            m13_free(tmpbuf);
            goto fail;
        }
        
        m13_free(pathext);
        
        po("file opened");

        io13_set_ioflags(&io, IO13_IOF_HARD, IO13_DIR_ALL);

        switch((ret = io13_write(&io, tmpbuf, c->dir==ENC?ebufsize+bsize:ib.orig_size, IO13_IOF_HARD))){

        case E13_OK:
            io13_close_file(&io);
            if(c->shred > -1){
            	shred(c, path);
            }
            po("OK");
            break;
        default:
            printo("io failed (%s) on output file < %s >."LF, e13_codemsg(ret), pathext);
            io13_close_file(&io);
            m13_free(tmpbuf);
            goto fail;
            break;

        }
        
        m13_free(tmpbuf);

end:
#ifdef WIN32
    UnmapViewOfFile(buf);
    CloseHandle(c->hMap);
    CloseHandle(c->h);
#else

#endif


    }

	if((c->dir == ENC && c->ext)){
		//TODO: This is a workaround to avoid size increase BUG!
		io13_truncate(path, st->st_size);
	}

    printo("done."LF);
    return true_;

fail:
#ifdef WIN32
    UnmapViewOfFile(buf);
    CloseHandle(c->hMap);
    CloseHandle(c->h);
#else

#endif
	if((c->dir == DEC && !c->ext && ib.sign != SIGN)){
		//TODO: This is a workaround to avoid size increase BUG!
		io13_truncate(path, st->st_size);		
	}

    return false_;

}

//use crypt_file as the call back
int enum_dir(struct conf* c, char* root, void* callback_fn, void* param, int recursive){

    struct dirent **namelist;
    int n;
    char path[MAXPATHNAME];
    struct stat sb;
    //int level = p13_get_path_depth(root);
    int (*callback)(struct conf* c, struct stat* st, char* path, void* param);
    callback = callback_fn;

    assert(callback);

    n = scandir(root, &namelist, 0, alphasort);
    printo("enumurating < %s >, n = %i", root, n);
    if (n < 0){
        printo("scandir() failed with err: %s, working directory is < %s >"LF, strerror(errno), root);
        return false_;
    } else {
        while (n--) {

            p13_merge_path(root, namelist[n]->d_name, path);

            if(stat(path, &sb) != -1){
                switch (sb.st_mode & S_IFMT) {
                    case S_IFDIR:

                        if( !strcmp(namelist[n]->d_name, PREV_DIR)||
                            !strcmp(namelist[n]->d_name, THIS_DIR))
                                break;

                        /* WHAT?
                        if(callback(h, &sb, path, param) < 0){
                            _deb1("callback failed");
                            return false_;
                        }
                        */

                        //level++;
                        if(recursive){
                            if(!enum_dir(c, path, callback_fn, param, recursive)){
                                _deb1("enum_dir failed");
                                return false_;
                            }
                        }

                        break;

                    case S_IFREG:

                        if(!callback(c, &sb, path, param)){
                            _deb1("callback failed");
                            return false_;
                        }

                        break;

                    default:
                        break;
                }
            }
            free(namelist[n]);
        }
        free(namelist);
    }

    //level--;
    return true_;
}

int parse_offlist(struct conf* c){

    int n, i;
    char* pack[3];
    char** ary;
    char* ary2[2];
    long lstart, lend;

    if(!c->offlist){
        c->off = NULL;
        c->noff = 0;
        po("no offset list");
        return true_;
    }

    po("has offset list!");

    pack[0] = "\"";
    pack[1] = "\'";
    pack[2] = NULL;

    n = s13_exparts(c->offlist, LIST_DELIM, pack, ESCAPE);
    if(n <= 0){
        printo("bad offset list (%i)."LF, n);
        return false_;
    }

    ary = s13_exmem(n);
    if(!ary){
        printo("out of memmory."LF);
        return false_;
    }

    s13_explode(c->offlist, LIST_DELIM, pack, ESCAPE, ary);

    c->off = (struct off*)malloc(n*sizeof(struct off));
    if(!c->off){
        printo("out of memmory."LF);
        s13_free_exmem(ary);
        return false_;
    }

    c->noff = n;

    for(i = 0; i < n; i++){

        if(s13_explode(ary[i], "-", pack, ESCAPE, ary2) != 2){

            printo("bad offset list format (%s)."LF, ary[i]);
            s13_free_exmem(ary);
            m13_free(c->off);
            return false_;

        }

        if((lstart = atol(ary2[0])) < 0){

            printo("bad offset list format (negative number in: %s)."LF, ary[i]);
            s13_free_exmem(ary);
            m13_free(c->off);
            return false_;

        }

        if((lend = atol(ary2[1])) < 0){

            printo("bad offset list format (negative number in: %s)."LF, ary[i]);
            s13_free_exmem(ary);
            m13_free(c->off);
            return false_;

        }

        if(lend <= lstart){

            printo("bad offset list format (end <= start: %s)."LF, ary[i]);
            s13_free_exmem(ary);
            m13_free(c->off);
            return false_;

        }

        c->off[i].start = lstart;
        c->off[i].end = lend;

        po("got offset %u to %u @ %i", c->off[i].start, c->off[i].end, i);

    }

    return true_;

}

int resolve_wild_path(struct conf* c, struct path path){

    char* filename, *cmpname;
    char ch;

    struct dirent **namelist;
    int n, i;
    char pathname[MAXPATHNAME];
    struct stat sb;

    filename = p13_get_filename(path.addr);

    ch = *filename;

    *filename = 0;

    if(strpbrk(path.addr, wild)){
        printo("wild cards in directory name is not supported for now."LF);
        path.sub = NULL;
        return false_;
    }

    n = scandir(path.addr, &namelist, 0, alphasort);
    if (n < 0){
        printo("scandir() failed with err: %s @ %s."LF, strerror(errno), path.addr);
        path.sub = NULL;
        return false_;
    } else {

        path.sub = (struct path*)m13_malloc(n*sizeof(struct path));
        if(!path.sub){
            printo("out of memmory."LF);
            return false_;
        }

        i = 0;

        while (n--) {

            p13_merge_path(path.addr, namelist[n]->d_name, pathname);

            if(stat(pathname, &sb) != -1){
                switch (sb.st_mode & S_IFMT) {
                    case S_IFDIR:
                        break;

                    case S_IFREG:

                        *filename = ch;

                        cmpname = p13_get_filename(pathname);

                        if(!s13_wildcmp(filename, cmpname, WILD_ANY, WILD_ONE, ESCAPE)){
                            path.sub[i].type = PATH_FILE;
                            if(!(path.sub[i].addr = s13_malloc_strcpy(pathname, MAXPATHNAME))){
                                printo("out of memmory."LF);
                                while(i--){
                                    m13_free(path.sub[i].addr);
                                }
                                m13_free(path.sub);
                                path.sub = NULL;
                                return false_;
                            }
                            i++;
                        }

                        break;

                    default:
                        break;
                }
            }
            free(namelist[n]);
        }
        free(namelist);
    }

    path.nsub = i;
    path.sub = (struct path*)m13_realloc(path.sub, i*sizeof(struct path));
    if(!path.sub){
        printo("out of memmory."LF);
        while(i--){
            m13_free(path.sub[i].addr);
        }
        m13_free(path.sub);
        path.sub = NULL;
        return false_;
    }

    return true_;

}

void free_path(struct conf* c){

    int i, j;

    for(i = 0; i < c->npath; i++){
        if(c->path[i].type == PATH_WILD){
            if(c->path[i].sub){
                for(j = 0; j < c->path[i].nsub; j++){
                    if(c->path[i].sub[j].addr) m13_free(c->path[i].sub[j].addr);
                }
            }
            m13_free(c->path[i].sub);
        }
    }
    m13_free(c->path);

}

int parse_pathlist(struct conf* c){

    int n,i;
    char* pack[3];
    char** ary;    

    if(!c->pathlist){
        c->path = NULL;
        c->npath = 0;
        return true_;
    }

    pack[0] = "\"";
    pack[1] = "\'";
    pack[2] = NULL;

    n = s13_exparts(c->pathlist, LIST_DELIM, pack, ESCAPE);
    if(n <= 0){
        printo("bad path list (%i)."LF, n);
        return false_;
    }

    ary = s13_exmem(n);
    if(!ary){
        printo("out of memmory."LF);
        return false_;
    }

    s13_explode(c->pathlist, LIST_DELIM, pack, ESCAPE, ary);

    c->path = (struct path*)malloc(n*sizeof(struct path));
    if(!c->path){
        printo("out of memmory."LF);
        s13_free_exmem(ary);
        return false_;
    }

    c->npath = n;

    for(i = 0; i < n; i++){

        c->path[i].addr = ary[i];

        //fnmatch()??

        if(strpbrk(c->path[i].addr, wild)){

            c->path[i].type = PATH_WILD;
            if(!resolve_wild_path(c, c->path[i])){
                s13_free_exmem(ary);
                free_path(c);
                return false_;
            }

        } else if(stat(c->path[i].addr, &c->path[i].st) != -1){
            switch (c->path[i].st.st_mode & S_IFMT) {
                case S_IFDIR:
                c->path[i].type = PATH_DIR;
                    break;

                case S_IFREG:
                c->path[i].type = PATH_FILE;
                    break;
                default:
                c->path[i].type = PATH_NONE;
                    break;
            }
        }

    }

    return true_;

}

int init_crypto(struct conf* c){

    error13_t e;

    c->algt = crypt13_alg_id(c->alg);
    if(c->algt == CRYPT13_ALG_NONE){
        printo("crypto algorithm \'%s\' unknown."LF, c->alg);
        return false_;
    }

    if((e = crypt13_init(&c->crypt, c->algt, (uint8_t*)c->pass, strlen(c->pass))) != E13_OK){
        printo("error: %s"LF, e13_codemsg(e));
        return false_;
    }


    return true_;
}

int assign_args(int argc, char* argv[], struct conf* c){

    int next_opt;
    
    po("assign args");

    const char* const short_opt = "hra:p:f:dest:o:x:b:u:lvcm:";
    const struct option long_opt[] = {
        {"help", 0, NULL, 'h'},
        {"recursive", 0, NULL, 'r'},
        {"algorithm", 1, NULL, 'a'},
        {"pass", 1, NULL, 'p'},
        {"file", 1, NULL, 'f'},
        {"decrypt", 0, NULL, 'd'},
        {"encrypt", 0, NULL, 'e'},
        {"show", 0, NULL, 's'},
        {"offset", 1, NULL, 't'},
        {"output", 1, NULL, 'o'},
        {"extension", 1, NULL, 'x'},
        {"buffer", 1, NULL, 'b'},
        {"run", 1, NULL, 'u'},
        {"log", 0, NULL, 'l'},
        {"verbose", 0, NULL, 'v'},
        {"crc", 0, NULL, 'c'},
        {"shred", 1, NULL, 'm'},
        {NULL, 0, NULL, 0},
    };

    do{

        next_opt = getopt_long(argc, argv, short_opt, long_opt, NULL);

        switch(next_opt){

        case 'h':
            usage(c, argv[0]);
            return false_;
            break;

        case 'r':
            c->rec = 1;
            break;

        case 'a':
            c->alg = optarg;
            break;

        case 'p':
            c->pass = optarg;
            break;

        case 'f':
            c->file = optarg;
            break;

        case 'd':
            c->dir = DEC;
            break;

        case 'e':
            c->dir = ENC;
            break;

        case 's':
            c->show = 1;
            break;

        case 't':
            c->offlist = optarg;
            break;

        case 'o':
            c->output = optarg;
            break;

        case 'x':
            c->ext = optarg;
            break;

        case 'b':
            c->bufsize = atol(optarg);
            break;

        case 'u':
            c->run = optarg;
            break;

        case 'l':
            c->log = 1;
            break;

        case 'v':
            c->v = 1;
            break;

        case 'c':
            c->crc = 1;
            break;
            
        case 'm':
        	c->shred = atoi(optarg);
        	break;

        case '?':
            usage(c, argv[0]);
            return false_;
            break;

        case -1:
//        	po("-1");
//            return false_;
            break;

        default:
        	po("default");
            return false_;
            break;

        }

    } while( next_opt != -1 );

    if( optind > -1 && optind < argc ) c->pathlist = argv[optind];

    return true_;

}

int do_crypt(struct conf* c, int npath, struct path* path){

    int i;

    for(i = 0; i < npath; i++){

        switch(path[i].type){

        case PATH_DIR:
            if(!enum_dir(c, path[i].addr, &crypt_file, NULL, c->rec)) return false_;
            break;

        case PATH_FILE:
            if(!crypt_file(c, &path[i].st, path[i].addr, NULL)) return false_;
            break;

        case PATH_WILD:
            if(!do_crypt(c, path[i].nsub, path[i].sub)) return false_;
            break;

        default:
            break;

        }

    }

    return true_;

}

int start(struct conf* c){

    FILE* peekfile = NULL;
    size_t red = 0UL;
    int argc;
    char** argv;
    int lines;
    char* argbuf = NULL;
    struct stat st;
    
    po("start...");

    if(!c->pass && !c->file){
    	c->file = PEEK_FILE;
    	po("no pass and file");
    }

    if(c->file){
    	
    	po("file set to:%s", c->file);

        if(stat(c->file, &st)){
            printo("could not stat file \'%s\':%s"LF, c->file, strerror(errno));
            return false_;
        }

        peekfile = fopen(c->file, "r");
        if(!peekfile){
            printo("could not open file \'%s\':%s"LF, c->file, strerror(errno));
            return false_;
        }                

        argv = (char**)m13_malloc(MAXARGS*sizeof(char*));
        if(!argv) {return false_;}

        argbuf = (char*)m13_malloc(st.st_size + 1);
        if(!argbuf) {m13_free(argv); return false_;}

        if(fgets(argbuf, st.st_size + 1, peekfile)){
            argc = atoi(argbuf);
            if(argc <= 0) goto end1;
        } else {
end1:
            printo("bad peek file format."LF);
            m13_free(argv);
            m13_free(argbuf);
            return false_;
        }

        lines = 0;
        while(fgets(argbuf + red, st.st_size - red, peekfile)){

            argv[lines] = argbuf + red;

            _deb1("argv[%i]: %s", lines, argv[lines]);

            red += strlen(argbuf + red) + 2;

            lines++;

        }

        if(!assign_args(argc, argv, c)){        	
            m13_free(argv);
            return false_;
        }

        m13_free(argv);
    }

    if(c->log){
        c->logfile = fopen(LOG_FILE, "a+");
    }

    if(!c->pass){
        printo("no passphrase is set."LF);
        m13_free(argbuf);
        return false_;
    }

    if(!init_crypto(c)){
        m13_free(argbuf);
        return false_;
    }        

    if(!c->pathlist){

        if(c->crypt.type != CRYPT13_TYPE_PUBKEY){
            printo("a path list is needed."LF);
            m13_free(argbuf);
            return false_;
        }

        //TODO

    } else {

        po("has pathlist!");

        if(!parse_offlist(c)){
            m13_free(argbuf);
            return false_;
        }

        if(!parse_pathlist(c)){
            m13_free(argbuf);
            m13_free(c->off);
            return false_;
        }

        do_crypt(c, c->npath, c->path);

    }

    return true_;

}

int main(int argc, char* argv[])
{
    struct conf c;

    //init conf struct
    c.alg = ALG;
    c.pass = NULL;
    c.file = NULL;
    c.pathlist = NULL;
    c.rec = 0;
    c.dir = ENC;
    c.show = 0;
    c.offlist = NULL;
    c.output = NULL;
    c.ext = NULL;
    c.bufsize = BUFSIZE;
    c.buf = NULL;
    c.run = NULL;
    c.log = 0;
    c.v = 0;
    c.crc = 0;
    c.shred = -1;
    c.noff = 0;

    c.logfile = NULL;

    if(argc < MINARGS){
        usage(&c, argv[0]);
        return 0;
    }
		
    if(!assign_args(argc, argv, &c)) return 1;
    
    if(!start(&c)) {if(c.buf) m13_free(c.buf); return 2;}

    if(c.buf) m13_free(c.buf);

//    printf("alg: %s, pass: %s, file: %s, rec: %i, pathlist: %s"LF, alg, pass, file, rec, pathlist);

    return 0;
}

