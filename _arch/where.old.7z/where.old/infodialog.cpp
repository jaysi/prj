﻿#include "infodialog.h"
#include "ui_infodialog.h"

infoDialog::infoDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::infoDialog)
{
    ui->setupUi(this);

#ifdef ANDROID
    showFullScreen();

    QSize size;
    QFont font;        

    size.setWidth(64);
    size.setHeight(64);

    ui->toolClose->setIconSize(size);
    ui->toolCopyAll->setIconSize(size);

    font.setPointSize(20);

    ui->text->setFont(font);

#endif

}

infoDialog::~infoDialog()
{
    delete ui;
}

void infoDialog::setInfo(QString strData){
    ui->text->setText(strData);
}

void infoDialog::on_toolClose_clicked()
{
    this->close();
}

void infoDialog::on_toolCopyAll_clicked()
{
    ui->text->selectAll();
    ui->text->copy();
}
