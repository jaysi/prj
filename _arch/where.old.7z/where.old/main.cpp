﻿#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

//#ifdef ANDROID
//    w.showFullScreen();
//#endif

//    QScreen *screen = a.primaryScreen ();
//    QFont F = a.font ();
//    int PixelSize = (f.pointSize () * screen->logicalDotsPerInch () * 1) / 72;
//    F.setPointSize (25);
//    A.setFont (F);
//    int NewPixelSize = (F.pointSize () * screen->logicalDotsPerInch () * 1) / 72;

#ifdef ANDROID
    a.setAttribute(Qt::AA_SynthesizeMouseForUnhandledTouchEvents);
#endif

    w.set_level(LEVEL_START);

    w.show();

    return a.exec();
}
