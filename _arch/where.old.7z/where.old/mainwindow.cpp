﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "infodialog.h"

#include <QtSql>
#include <QMessageBox>
#include <QLabel>
#include <QStringList>
#include <QListWidgetItem>
#include <QTextEdit>
#include <QMouseEvent>

#define _true 1
#define _false 0

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    st.mouse_press = false;

#ifdef ANDROID

    QSize size;
    QFont font;

    size.setWidth(64);
    size.setHeight(64);

    ui->toolButton->setIconSize(size);
    ui->toolMenu->setIconSize(size);
    ui->toolNext->setIconSize(size);
    ui->toolPrev->setIconSize(size);
    ui->toolSearch->setIconSize(size);

    font.setPointSize(20);

    ui->list->setFont(font);
    ui->line->setFont(font);

#endif

    installEventFilter(ui->centralWidget);
    installEventFilter(ui->horizontalLayout);
    installEventFilter(ui->horizontalLayout_2);
    installEventFilter(ui->label);
    installEventFilter(ui->label_2);
    installEventFilter(ui->line);
    installEventFilter(ui->list);
    installEventFilter(ui->toolButton);
    installEventFilter(ui->toolMenu);
    installEventFilter(ui->toolNext);
    installEventFilter(ui->toolPrev);
    installEventFilter(ui->toolSearch);
    installEventFilter(ui->verticalLayout);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::set_level(enum level l){

    //if(st.l == l) return;

    switch( l ) {
    case LEVEL_START:
        ui->list->hide();
        ui->toolMenu->hide();
        ui->toolSearch->hide();
        ui->label->show();
        ui->label_2->show();
        ui->toolNext->hide();
        ui->toolPrev->hide();
        ui->line->hide();
        break;

    case LEVEL_HOME:
        ui->list->show();
        ui->toolMenu->show();
        ui->toolSearch->show();
        ui->label->hide();
        ui->label_2->hide();
        break;

    case LEVEL_SEARCHING:
        ui->label->show();
        ui->label_2->show();
        ui->label_2->setText(tr(MSG_DONT_CARE));
        ui->toolNext->show();
        ui->list->setSelectionMode(QAbstractItemView::MultiSelection);
        break;

    default:
        ui->list->setSelectionMode(QAbstractItemView::SingleSelection);
        qDebug()<<tr("level %1 not implemented").arg(l);
        break;
    }

    st.l = l;
}

int MainWindow::init_db(){

    db = QSqlDatabase::addDatabase(DEF_DB_DRIVER);

    if(!db.isValid()) return _false;

    return _true;

}

int MainWindow::open_db(){

    db.setDatabaseName(
                get_db_target_path()
                );

    if(!db.open()){
        QMessageBox::critical(this, MSG_CRITICAL, MSG_DB_OPEN_FAIL);
        return _false;
    }

    return _true;

}

QString MainWindow::get_db_target_path(){

    QString databasePath;

    QString tmpString = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);//or HomeLocation?
    QFileInfo databaseFileInfo(QString("%1/%2").arg(tmpString).arg(DEF_DB_NAME));
    databasePath = databaseFileInfo.absoluteFilePath();

    return databasePath;

}

int MainWindow::check_db(){

    QString tmpString = QStandardPaths::writableLocation(QStandardPaths::HomeLocation);
    QFileInfo databaseFileInfo(QString("%1/%2").arg(tmpString).arg(DEF_DB_NAME));
//    QString databasePath = databaseFileInfo.absoluteFilePath();
    if ( !databaseFileInfo.exists() )
    {
        return _false;
    }

    return _true;

}

int MainWindow::copy_db(){

    QLabel* label = new QLabel;
    label->setText(tr(MSG_DB_INSTALLING));
    label->show();
    QFile file;
    bool copySuccess = file.copy( tr(DEF_DB_FILE_SOURCE) + tr(DEF_DB_NAME), get_db_target_path());
    if ( !copySuccess )
    {
        delete label;
        QMessageBox::critical(this, MSG_CRITICAL, QString(MSG_DB_NOCOPY).arg(tr(DEF_DB_FILE_SOURCE) + tr(DEF_DB_NAME)).arg(get_db_target_path()) + tr(" [[ system:")+file.errorString());
        return _false;
    }

    delete label;

    return _true;

}

int MainWindow::fill_list(QString table, QString fa_col_name, QString col_name, QString diff_col, QString cond){

    QSqlQuery q(db);
    QString sql;

//    snprintf(sql, MAXSQL, cond?SQL_GET_ALL_NO_TRUNC:SQL_GET_ALL, table);
    sql = tr(cond.isEmpty()?SQL_GET_ALL:SQL_GET_ALL_NO_TRUNC).arg(table);

    if(!cond.isEmpty()){
        sql += tr(" WHERE ") + cond + tr(";");
    }

    qDebug()<<tr("fill_list sql: %1").arg(sql);

    if(!q.exec(sql)){
        QMessageBox::critical(this, MSG_CRITICAL, MSG_DB_QUERY_FAIL);
        return _false;
    }

    ui->list->clear();
    while(q.next()){
        QListWidgetItem* item = new QListWidgetItem;
        if(!fa_col_name.isEmpty()) item->setText(q.value(fa_col_name).toString());
        if(!col_name.isEmpty()) item->setWhatsThis(q.value(col_name).toString());
        if(!diff_col.isEmpty()) item->setToolTip(q.value(diff_col).toString());
        ui->list->addItem(item);
    }

    q.finish();

    return _true;

}

int MainWindow::show_place_types_list(){

    if(fill_list(tr("base"), tr("table_sc_name"), tr("table_name"))){
        set_level(LEVEL_LIST_PLACE_TYPES);
        return _true;
    }

    return _false;

}

int MainWindow::show_place_list(QString place_type, QString cond){

    QString table;
    QListWidgetItem* item;
    QString strDiff, strData;
    QStringList q_desc_col_sc_names, q_desc_col_names;

    QSqlQuery q(db), q_desc(db);
    QString sql;

    table = place_type + tr("_data");

    sql = tr(cond.isEmpty()?SQL_GET_ALL:SQL_GET_ALL_NO_TRUNC).arg(table);

    if(!cond.isEmpty()){
        sql += tr(" WHERE ") + cond + tr(";");
    }

    if(!q.exec(sql)){
        qDebug() << sql + tr(" -- ") + q.lastError().text();
        QMessageBox::critical(this, MSG_CRITICAL, tr(MSG_DB_QUERY_FAIL));
        return _false;
    }

    table = place_type + tr("_desc");

    sql = tr(SQL_GET_ALL_SHOW).arg(table);

    if(!q_desc.exec(sql)){
        qDebug() << sql + tr(" -- ") + q.lastError().text();
        QMessageBox::critical(this, MSG_CRITICAL, MSG_DB_QUERY_FAIL);
        return _false;
    }

    ui->list->clear();

    while(q_desc.next()){
        q_desc_col_sc_names << q_desc.value("col_sc_name").toString();
        q_desc_col_names << q_desc.value("col_name").toString();
    }

    while(q.next()){
        item = new QListWidgetItem;
        strDiff = q.value("diff").toString();
        item->setText(q.value("name").toString() +
                      (strDiff.isEmpty()?"":tr(" [ ") + strDiff + tr(" ] "))
                      );

        for(int i = 0; i < q_desc_col_names.count(); i++){
            strData += q_desc_col_sc_names.at(i) +
                    tr(": ") +
                    q.value(q_desc_col_names.at(i)).toString() +
                    tr("\n");
        }

        item->setData(Qt::UserRole, strData);

        ui->list->addItem(item);
        strData.clear();
    }

    q_desc.finish();
    q.finish();

    //TODO!
    set_current_place_group(place_type, tr(""));

    return _true;

}

void MainWindow::set_current_place_group(QString group, QString group_fa){

    qDebug()<<tr("set place group to ")+group;
    st.place_group = group;
    st.place_group_fa = group_fa;

}

void MainWindow::set_current_place(QString name, QString name_fa){

    qDebug()<<tr("set place name to ")+name;
    st.place_name = name;
    st.place_name_fa = name_fa;

}

void MainWindow::on_list_itemClicked(QListWidgetItem *item)
{
    infoDialog* info_dlg;
    qDebug()<<tr("level %1").arg(get_level());
    switch(get_level()){
    case LEVEL_HOME:
    case LEVEL_LIST_PLACE_TYPES:
        qDebug()<<tr("clicked to show show_place_list");
        if(show_place_list(item->whatsThis(), NULL)){
            qDebug()<<tr("click ok, setting level");
            //set_current_place_group(item->whatsThis(), item->text()); already done in show_place_list
            set_level(LEVEL_LIST_PLACES);
        }
        break;
    case LEVEL_LIST_PLACES:
        qDebug()<<tr("clicked to show current_place_info");
        set_current_place(item->data(Qt::UserRole).toString(), item->text());
        info_dlg = new infoDialog;
        info_dlg->setInfo(item->data(Qt::UserRole).toString());
        info_dlg->show();
        break;
    default:
        break;
    }

}

void MainWindow::on_toolButton_clicked()
{

    switch(get_level()){
    case LEVEL_START:

        if(!check_db()){
            if(!copy_db()){
                return;
            }
        }

        if(init_db()){
            if(!open_db()){
                return;
            }
        } else return;        

        show_place_types_list();

        break;

    default:
        show_place_types_list();
        break;

    }

    set_level(LEVEL_HOME);

}

struct search_s* MainWindow::new_search(QString group){

    struct search_s* search = new struct search_s;
    if(!search) return NULL;
    search->q = new QSqlQuery(db);
    if(!search->q) return NULL;

    qDebug()<<tr("search in ") + group;

    if(!search->q->exec(tr(SQL_SELECT_SEARCH_FIELDS).arg(group))){
        qDebug() << tr(SQL_SELECT_SEARCH_FIELDS).arg(group) + tr(" -- ") + search->q->lastError().text();
        QMessageBox::critical(this, MSG_CRITICAL, MSG_DB_QUERY_FAIL);
        return NULL;
    }

    if(!search->q->size()){
        QMessageBox::warning(this, tr(MSG_WARNING), tr(MSG_NOTHING_TO_SEARCH));
        return NULL;
    }

    search->prev_ftype = FIELD_EMPTY;
    search->group = group;
    search->icond = 0;
    search->nsearchables = search->q->size();
    search->str = tr("SELECT * FROM %1_data").arg(group);

    for(int i = 0; i < MAXSEARCHCOND; i++){
        search->strlistCond[i].clear();
    }

    return search;

}

void MainWindow::on_toolSearch_clicked()
{   

    switch(get_level()){
    case LEVEL_LIST_PLACES:

        qDebug() << "searching";

        search = new_search(st.place_group);
        if(!search) break;

        qDebug()<<"ok";

        set_level(LEVEL_SEARCHING);

        on_toolNext_clicked();

        break;

    case LEVEL_SEARCHING:
        show_search_results();
        break;

    default:
        QMessageBox::warning(this, tr(MSG_WARNING), tr(MSG_SELECT_PLACE_TYPE_FIRST));
        break;

    }
}

QString MainWindow::assm_search_cond(){

    QString str;
    int i = -1, j;

    search->q->first();

    do {

        qDebug()<<tr("assm search i = %1").arg(i);

        if(search->strlistCond[++i].isEmpty()) continue;

        if(!str.isEmpty()) str += tr(") AND (");
        else str = tr("(") ;

        for(j = 0; j < search->strlistCond[i].count(); j++){
            if(!str.isEmpty() && j) str += tr(" OR ");
            //search->q->val("sel_size").toInt() == 0 ??? LINE INCLUDES
            str += search->q->value("col_name").toString() + tr(" LIKE '") + search->strlistCond[i].at(j) + tr("'");
        }

        qDebug() << tr("assm search i = %1 str = %2").arg(i-1).arg(str);

    } while(search->q->next());

    str += tr(")");

    qDebug()<<tr("search condition: %1").arg(str);
    return str;
}

void MainWindow::show_search_results(){
    QString strCond = assm_search_cond();

    //TODO
//    delete search->q;
//    delete search;
//    search = NULL;

    show_place_list(st.place_group, strCond.isEmpty()?NULL:strCond);
    set_level(LEVEL_LIST_PLACES);
}

void MainWindow::on_toolMenu_clicked()
{
    close();
}

void MainWindow::show_possible_selection_list(QString table, int base, QString col_name){
    QSqlQuery q(db);
    int row;
    QString str;

    qDebug()<<"possible selection SQL: "<<tr("SELECT %1 FROM %2;").arg(col_name).arg(base?"base_groups":table+tr("_groups"));

    q.exec(tr("SELECT %1 FROM %2;").arg(col_name).arg(
               base?tr("base_groups"):table+tr("_groups")
                    ));

    ui->list->clear();

    row = 0;
    while(q.next()){        
        str = q.value(col_name).toString();
        if(!str.isEmpty()) ui->list->insertItem(row++, str);
    }

}

void MainWindow::load_search_cond(int i, QLineEdit *line, QListWidget *list){
    //assert(i < nsearchables);

    qDebug()<<tr("load_search_cond %1 %2 %3").arg(line?tr("line "):tr("list ")).arg("i = ").arg(i);
    if(line){
        if(!search->strlistCond[i].isEmpty()){
            qDebug()<<tr("strlist is not empty at i");
            line->setText(search->strlistCond[i].at(0));
        }
    } else if(list){

        show_possible_selection_list(st.place_group,
                                     search->q->value("base").toInt(),
                                     search->q->value("col_name").toString()
                                     );

        for(int j = 0; j < search->strlistCond[i].count(); j++){
            qDebug()<<"search in cond"<<i;
            qDebug()<<"search for in list "<<search->strlistCond[i].at(j);
            ui->list->findItems(search->strlistCond[i].at(j), Qt::MatchExactly).at(0)->setSelected(true);
        }
    }

}

void MainWindow::on_toolNext_clicked()
{

//    assert(search->q);

    //store previous data!
    if(search->icond){

        qDebug()<<"next, store: isearch cond-1 "<<search->icond-1;

        switch(search->prev_ftype){
        case FIELD_LINE:

            if(ui->line->text().isEmpty()){
                search->strlistCond[search->icond-1].clear();
            } else {
                qDebug()<<tr("list[%1] << %2").arg(search->icond-1).arg(ui->line->text());
                search->strlistCond[search->icond-1] << ui->line->text();
                ui->line->clear();
            }

            break;

        case FIELD_LIST:

            if(ui->list->selectedItems().isEmpty()){
                qDebug()<<tr("empty list");
                search->strlistCond[search->icond-1].clear();
            } else {
                qDebug()<<tr("nselectedItems %1").arg(ui->list->selectedItems().count());
                for(int i = 0; i < ui->list->selectedItems().count(); i++){
                    qDebug()<<tr("list[%1] << %2").arg(search->icond-1).arg(ui->list->selectedItems().at(i)->text());
                    search->strlistCond[search->icond-1] << ui->list->selectedItems().at(i)->text();
                }
            }

            break;

        default:
            break;
        }
    }

    qDebug()<<"next: isearch cond "<<search->icond;
    if(!search->q->next()) {
        qDebug()<<"!search->q->next()";
        show_search_results();
        return;//do search
    }

    if(get_level() != LEVEL_SEARCHING){
        set_level(LEVEL_SEARCHING);
    } else {
        ui->toolPrev->show();
    }        

    ui->label->setText(search->q->value("col_sc_name").toString());

    switch(search->q->value("sel_size").toInt()) {

    case 0://text line
        ui->line->show();
        ui->list->hide();                

        qDebug()<<"load line";
        load_search_cond(search->icond, ui->line, NULL);
        qDebug()<<"done";

        ui->line->setFocus();

        search->prev_ftype = FIELD_LINE;

        search->icond++;

        break;

    case 1://limmited
    case 3:
        ui->line->hide();
        ui->list->clear();
        ui->list->show();

        load_search_cond(search->icond, NULL, ui->list);

        search->prev_ftype = FIELD_LIST;

        search->icond++;

        break;
    default:
        break;

    }    

}

void MainWindow::on_toolPrev_clicked()
{

    if(!search->q->previous()){
        qDebug()<<"!search->q->previous()";
        search->icond = 0;
        return;
    } else {
        search->icond--;
    }

    qDebug()<<"prev:search->icond = "<<search->icond;

    ui->label->setText(search->q->value("col_sc_name").toString());

    switch(search->q->value("sel_size").toInt()){

    case 0://text line
        ui->line->show();
        ui->list->hide();
        load_search_cond(search->icond, ui->line, NULL);
        ui->line->setFocus();
        break;

    case 1://limmited
    case 3:
        ui->line->hide();
        ui->list->clear();
        ui->list->show();
        load_search_cond(search->icond, NULL, ui->list);
        break;

    }

}

void MainWindow::do_swipe(){
    if(st.start_pt.x() - st.end_pt.x() < 0){
        QMessageBox::information(NULL, tr("swipe"), tr("RIGHT"));
    } else if(st.start_pt.x() - st.end_pt.x() > 0){
        QMessageBox::information(NULL, tr("swipe"), tr("LEFT"));
    } else {
        QMessageBox::information(NULL, tr("swipe"), tr("ZERO"));
    }
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event){

    QToolButton* tbtn;
    QComboBox* edit;
    QKeyEvent* key;
    QTextEdit* out;
    QMenu* menu;

    if(event->type() == QEvent::MouseButtonPress){
        //QMouseEvent mouseEvent = static_cast<QMouseEvent>(event);
        st.start_pt = ((QMouseEvent*)event)->pos();
        st.mouse_press = true;
    } else if(event->type() == QEvent::MouseButtonRelease){
        if(st.mouse_press){
            //QMouseEvent mouseEvent = static_cast<QMouseEvent>(event);
            st.end_pt = ((QMouseEvent*)event)->pos();
            st.mouse_press = false;
            do_swipe();
        }
    }

    if(event->type() == QEvent::TouchEnd){

    }

    if(obj->objectName() == tr("toolShut")){
        tbtn = dynamic_cast<QToolButton*>(obj);
        Q_ASSERT(tbtn);
    }

    if(event->type() == QEvent::KeyPress){

        if(((QKeyEvent*)event)->key() == Qt::Key_Back || ((QKeyEvent*)event)->key() == Qt::Key_MediaPrevious ){

            QMessageBox::information(NULL, "", "pressed back");

            switch( get_level() ){
            case LEVEL_START:
                    ::exit(0);
                break;
            case LEVEL_HOME:
                    ::exit(0);
                break;

            case LEVEL_LIST_PLACE_TYPES:
                    set_level(LEVEL_HOME);
                break;

            case LEVEL_LIST_PLACES:
                set_level(LEVEL_LIST_PLACE_TYPES);
                show_place_types_list();
                break;

            case LEVEL_SEARCHING:
                on_toolPrev_clicked();
                break;

            case LEVEL_SEARCH_RESULTS:
                on_toolPrev_clicked();
                break;

            default:
                break;

            }

            return true;
        }

    }

    return false;
}
