﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSqlDatabase>
#include <QListWidgetItem>

#include "def.h"

namespace Ui {
class MainWindow;
}

struct search_s {
    enum field_type prev_ftype;
    QSqlQuery* q;
    QString group;
    int nsearchables;
    int icond;
    QStringList strlistCond[MAXSEARCHCOND];
    QString str;
};

struct stat_s {
    enum level l;
    QString place_group, place_group_fa;
    QString place_name, place_name_fa;
    QPoint start_pt, end_pt;
    bool mouse_press;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void set_level(enum level l);

private slots:
    void on_list_itemClicked(QListWidgetItem *item);
    void on_toolButton_clicked();
    void on_toolSearch_clicked();
    void on_toolMenu_clicked();
    void on_toolNext_clicked();

    void on_toolPrev_clicked();

private:
    Ui::MainWindow *ui;

    struct stat_s st;
    struct search_s* search;
    QSqlDatabase db;

    enum level get_level() {return st.l;}
    struct search_s* new_search(QString group);
    void set_current_place_group(QString group, QString group_fa);
    void set_current_place(QString name, QString name_fa);
    int show_place_types_list();
    int show_place_list(QString place_type, QString cond);
    int show_place_det(QString place_name);
    void load_search_cond(int i, QLineEdit* line, QListWidget* list);
    void show_search_results();
    void show_possible_selection_list(QString table, int base, QString col_name);
    QString assm_search_cond();

    int init_db();
    int open_db();
    int encrypt_db();
    int decrypt_db();
    int check_db();
    int copy_db();
    QString get_db_target_path();

    int fill_list(QString table, QString fa_col_name, QString col_name, QString diff_col = tr(""), QString cond = tr(""));

    //ui
    void do_swipe();

protected:
    bool eventFilter(QObject *obj, QEvent *event);


};

#endif // MAINWINDOW_H
