﻿#ifndef DEF
#define DEF

//CONST
enum level {
    LEVEL_START,
    LEVEL_HOME,
    LEVEL_LIST_PLACE_TYPES,
    LEVEL_LIST_PLACES,
    LEVEL_SEARCHING,
    LEVEL_SEARCH_RESULTS,
    LEVEL_INVAL
};

enum field_type {
    FIELD_EMPTY,
    FIELD_LINE,
    FIELD_LIST,
    FIELD_INVAL
};

#define MAXSQL  2048
#define MAXTABNAME 512
#define MAXSEARCHCOND   20

//CONFIG
#define DEF_BG_COLOR    "#FF9800"
#define DEF_DB_NAME     "koja2.sqlite"
#define DEF_DB_DRIVER   "QSQLITE"
#ifdef ANDROID
#define DEF_DB_FILE_SOURCE     "assets:/"
#elif WIN32
#define DEF_DB_FILE_SOURCE     ""
#else
#define DEF_DB_FILE_SOURCE     ""
#endif

//MESSAGES
#define MSG_SELECT_WHERE_OR_SEARCH "کجا می روید ؟ می توانید جستجو کنید!"
#define MSG_DB_QUERY_FAIL   "مشکل ارتباط با پایگاه داده، لطفاً مجدداً تلاش نمایید."
#define MSG_DB_OPEN_FAIL "پایگاه داده باز نشد."
#define MSG_DB_INSTALLING "لطفاً تا زمان نصب پایگاه داده صبر نمایید..."
#define MSG_NO_FILE "فایل مورد نظر یافت نشد."
#define MSG_CRITICAL    "ایراد اساسی"
#define MSG_WARNING "اخطار!"
#define MSG_DB_NOCOPY  "پایگاه داده از %1 به %2 کپی نشد."
#define MSG_SELECT_PLACE_TYPE_FIRST "ابتدا نوع محل مورد نظر را انتخاب کنید."
#define MSG_DONT_CARE "اهمیتی ندارد؟ کلید -> را بفشارید!"
#define MSG_NOTHING_TO_SEARCH "چیزی برای جستجو نیست!"

//SQL
#define SQL_GET_ALL_SHOW "SELECT * FROM %1 WHERE show = 1;"
#define SQL_GET_ALL "SELECT * FROM %1;"
#define SQL_GET_ALL_NO_TRUNC "SELECT * FROM %1"
#define SQL_GET_BASE "SELECT * FROM base ORDER BY id;"
#define SQL_SELECT_SEARCH_FIELDS "SELECT * FROM %1_desc WHERE searchable = 1;"

#endif // DEF

