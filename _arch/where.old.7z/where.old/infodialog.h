﻿#ifndef INFODIALOG_H
#define INFODIALOG_H

#include <QDialog>

namespace Ui {
class infoDialog;
}

class infoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit infoDialog(QWidget *parent = 0);
    ~infoDialog();
    void setInfo(QString strData);

private slots:
    void on_toolClose_clicked();
    void on_toolCopyAll_clicked();

private:
    Ui::infoDialog *ui;

};

#endif // INFODIALOG_H
