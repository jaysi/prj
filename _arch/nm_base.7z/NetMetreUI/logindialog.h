﻿#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QString>

//#include "QNetMetreUI.h"
#include "netmetredb.h"
//#include "netmetre.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit LoginDialog(QWidget *parent = 0);    
    ~LoginDialog();
    void setShowSettings(bool show);
    void reConfig();
    
private slots:
    void on_btnLogin_clicked();

    void on_cbtnSettings_clicked();

private:
    Ui::LoginDialog *ui;    
    struct nm_session* nm;
    NetMetreDB* dbdlg;
    bool assertLogin(QString username, QString password);    
};

#endif // LOGINDIALOG_H
