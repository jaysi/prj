﻿#ifndef PROJECTVERSIONDIALOG_H
#define PROJECTVERSIONDIALOG_H

#include <QDialog>

#include "../netmetre/netmetre.h"

namespace Ui {
class ProjectVersionDialog;
}

class ProjectVersionDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ProjectVersionDialog(QWidget *parent = 0);
    ProjectVersionDialog(QWidget *parent = 0, struct nm_session* nm = 0, nm_pid_t pid = 0);
    ~ProjectVersionDialog();
    
private:
    Ui::ProjectVersionDialog *ui;
};

#endif // PROJECTVERSIONDIALOG_H
