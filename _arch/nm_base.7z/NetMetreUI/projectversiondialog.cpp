﻿#include "projectversiondialog.h"
#include "ui_projectversiondialog.h"

ProjectVersionDialog::ProjectVersionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectVersionDialog)
{
    ui->setupUi(this);
}

ProjectVersionDialog::ProjectVersionDialog(QWidget *parent, struct nm_session* nm, nm_pid_t pid) :
    QDialog(parent),
    ui(new Ui::ProjectVersionDialog)
{
    ui->setupUi(this);
}

ProjectVersionDialog::~ProjectVersionDialog()
{
    delete ui;
}
