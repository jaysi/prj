﻿#include "pricelistview.h"
#include "ui_pricelistview.h"

PriceListView::PriceListView(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PriceListView)
{
    ui->setupUi(this);
}

PriceListView::PriceListView(QWidget *parent, nm_listid_t id) :
    QMainWindow(parent),
    ui(new Ui::PriceListView)
{
    ui->setupUi(this);

    //table = tab;

}

PriceListView::~PriceListView()
{
    delete ui;    
}
