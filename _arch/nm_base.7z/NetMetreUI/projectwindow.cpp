﻿#include "projectwindow.h"
#include "ui_projectwindow.h"
#include "yesnocanceldialog.h"
#include "itempropertiesdialog.h"

#include "projectversiondialog.h"
#include "aboutdialog.h"
#include "pricelistview.h"
#include "projectmanagerdialog.h"

#include "netmetredb.h"

#include "../netmetre/netmetre.h"

#include <QCloseEvent>
#include <QString>
#include <QFile>
#include <QFileDialog>
#include <QMessageBox>
#include <assert.h>

ProjectWindow::ProjectWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ProjectWindow)
{
    ui->setupUi(this);
}

ProjectWindow::ProjectWindow(QWidget *parent, nm_pid_t _pid, struct nm_session* _nm) :
    QMainWindow(parent),
    ui(new Ui::ProjectWindow)
{

    QString lname;
    error13_t ret;

    ui->setupUi(this);

    nm = _nm;

    metretabexpanded = true;
    invoice_locked = false;
    morespace = false;

    this->setAnimated(true);

    if(!_pid){
        if((ret = nm_new_project(nm, &pid)) != E13_OK){
            QMessageBox::critical(this, trUtf8("سیستم"), trUtf8(e13_errmsg(&nm->error_s)));
            this->close();
        }
    } else {
        pid = _pid;
        if((ret = nm_open_project(nm, pid)) != E13_OK){
            QMessageBox::critical(this, trUtf8("سیستم"), trUtf8(e13_errmsg(&nm->error_s)));
            this->close();
        }
    }

    nm_set_prj_obj_ptr(nm, pid, this);

    lname = getProjectName();

    calc = new CalcDialog(0, lname);
    if(!calc){

    }

    setTitle(lname);

    updateOpenProjectList();

    updateOtherOpenProjectList();

    prepareProjectDB();    

    preparePriceLists();
    prepareContractInfo();
    prepareMultipliers();
    prepareMetre();
    prepareSumOfMetre();
    preparePrice();
    prepareSumOfPrice();
    prepareSessionsPrice();
    prepareTotalPrice();

    ui->btnHome->installEventFilter(this);
    ui->btnMetre->installEventFilter(this);    

}

QString ProjectWindow::getProjectName(){

    QString lname;
    char* name;

    name = nm_get_prjname(nm, pid);

    if(!name){
        QMessageBox::warning(this, trUtf8("سیستم"), trUtf8(e13_errmsg(&nm->error_s)));
    } else {
        lname = trUtf8(name);
    }

    return lname;
}

void ProjectWindow::prepareProjectDB(){

}

void ProjectWindow::preparePriceLists(){

}

void ProjectWindow::prepareContractInfo(){

}

void ProjectWindow::prepareMultipliers(){

}

void ProjectWindow::prepareMetre(){

}

void ProjectWindow::prepareSumOfMetre(){

}

void ProjectWindow::preparePrice(){

}

void ProjectWindow::prepareSumOfPrice(){

}

void ProjectWindow::prepareSessionsPrice(){

}

void ProjectWindow::prepareTotalPrice(){

}

void ProjectWindow::updateOpenProjectList(){    

    char** list;
    list = nm_get_open_prjlist(nm);
    if(list){
        ui->listwidgetOpenProjects->clear();
        while(list[i][0] != '\0') ui->listwidgetOpenProjects->addItem(trUtf8(list[i++]));
        nm_free_prjlist(list);
    }

    updateAllProjectList();

}

void ProjectWindow::updateAllProjectList(){

    char** list;
    list = nm_get_prjlist(nm);
    if(list){
        ui->tablewidgetAllProjects->clear();
        while(list[i][0] != '\0') /*ui->tablewidgetAllProjects->addItem(trUtf8(list[i++]))*/;
        nm_free_prjlist(list);
    }

}

bool ProjectWindow::destroyThis(){

    error13_t ret;

    if((ret = nm_close_project(nm, pid)) == E13_OK){
        return true;
    } else {
        QMessageBox::warning(this, trUtf8("سیستم"), trUtf8(e13_errmsg(&nm->error_s)));
        return false;
    }
}

ProjectWindow::~ProjectWindow()
{    
    delete ui;
}

void ProjectWindow::setTitle(QString name){

    this->name = name;
    this->setWindowTitle(name);
    calc->setProjectName(name);

}

int ProjectWindow::saveProject(){

    return nm_save_project(nm, pid);

}

bool ProjectWindow::prepareToExit(){

    YesNoCancelDialog* dlg;//1. save, 2. don't save, 3.cancel
    int act;

    if(nm_prj_change(nm, pid)){
        dlg = new YesNoCancelDialog(0, this->name);
        dlg->exec();
        act = dlg->getAct();
        //qDebug() << "returned" + act;
        switch(act){
            case YNC_SAVE:
                saveProject();
            break;
            case YNC_DONT:                
            break;
            default:                
            break;
        }

        delete dlg;

        return (act==YNC_CANCEL?false:true);

    } else return true;
}

void ProjectWindow::on_btnExitProject_clicked()
{        

    this->close();

}

void ProjectWindow::on_btnSave_clicked()
{
    setMessage(trUtf8(STR_USER_SYSTEM), trUtf8("در حال ثبت تغییرات..."));
    saveProject();

}

void ProjectWindow::closeEvent(QCloseEvent *event){

    if(!this->prepareToExit()){
        event->ignore();
    } else {
        //mainw->destroyProjectWindow( prjname, 0 );
        if(destroyThis()){
            prjptr = NULL;

            updateOtherOpenProjectList();

            event->accept();
        }
    }

}

void ProjectWindow::updateOtherOpenProjectList(){

    struct nm_project* prj;

    nm_enum_prjlist_start(nm);

    while((prj = nm_enum_prjlist(nm))){

        ((ProjectWindow*)(prj->obj))->updateOpenProjectList();
        ((ProjectWindow*)(prj->obj))->updateAllProjectList();
    }

    nm_enum_prjlist_end(nm);

}

void ProjectWindow::on_btnItemMgmt_clicked()
{
    ItemPropertiesDialog dlg;
    dlg.exec();

}

void ProjectWindow::on_checkInvoiceLock_clicked()
{

    if(!invoice_locked){
        if(ui->editInvoiceLockCode1->text().isEmpty()){
            QMessageBox::warning(this,  trUtf8("حفاظت داده"),
                                        trUtf8("طول کلید کوتاه است."));
            ui->checkInvoiceLock->setChecked(false);
            return;
        }
        if(ui->editInvoiceLockCode1->text() == ui->editInvoiceLockCode2->text())
        {
            invoice_locked = true;
            ui->editInvoiceLockCode2->setEnabled(false);
            ui->editInvoiceLockComments->setEnabled(false);
        } else {
            QMessageBox::warning(this,  trUtf8("حفاظت داده"),
                                        trUtf8("کلید های وارد شده یکسان نیستند.")
                                        );
            ui->checkInvoiceLock->setChecked(false);
        }
    } else {
        if(ui->editInvoiceLockCode1->text().isEmpty()){
            ui->checkInvoiceLock->setChecked(true);
        } else {
            invoice_locked = false;
            ui->editInvoiceLockCode2->setEnabled(true);
            ui->editInvoiceLockComments->setEnabled(true);
        }
    }

    ui->editInvoiceLockCode1->setText(tr(""));
    ui->editInvoiceLockCode2->setText(tr(""));

}

void ProjectWindow::on_checkMoreSpace_clicked()
{
    if(!morespace){
        morespace = true;
        ui->tabwidgetControl->hide();
    } else {
        morespace = false;
        ui->tabwidgetControl->show();
    }
}

void ProjectWindow::on_btnProjectNew_clicked()
{

    ProjectWindow* pwin = new ProjectWindow(NULL, 0, nm);

        pwin->move(
                    ui->cbtnSettings->mapToGlobal(
                    QPoint(this->frameGeometry().x()-10,
                           this->frameGeometry().y()-10
                           )
                    ));

    if(!pwin){
        QMessageBox::critical(this, trUtf8("منابع"), trUtf8("کمبود حافظه"));
        return;
    }

    pwin->show();
}

void ProjectWindow::on_btnProjectDelete_clicked()
{

}

void ProjectWindow::on_btnProjectEdit_clicked()
{
    nm_pid_t pid;

    ProjectManagerDialog* dlg = new ProjectManagerDialog(0, nm);

    dlg->show();

    pid = dlg->getPid();

    closeProject();
    openProject(pid);
}

int ProjectWindow::closeProject(){

    setMessage(trUtf8(STR_USER_DEBUG), trUtf8("closing project %1").arg(pid));

    return nm_close_project(nm, pid);

}

int ProjectWindow::openProject(nm_pid_t _pid){

    error13_t ret;

    setMessage(trUtf8(STR_USER_DEBUG), trUtf8("openning project %1").arg(pid));

    if((ret = nm_open_project(nm, _pid)) == E13_OK){
        pid = _pid;
    }

    return ret;
}

void ProjectWindow::on_btnProjectVersion_clicked()
{
    ProjectVersionDialog* dlg = new ProjectVersionDialog(0, nm, pid);
    if(!dlg){
        QMessageBox::critical(this, trUtf8("منابع"), trUtf8("کمبود حافظه"));
        return;
    }

    dlg->show();

}

void ProjectWindow::on_btnProjectBackup_clicked()
{
     QString fileName = QFileDialog::getSaveFileName(this,
         tr("Save NetMetre File"), "",
         tr("NetMetre (*%1);;All Files (*)").arg(trUtf8(DEF_DB_FILE_EXT)));

     if (fileName.isEmpty())
         return;
     else {

         QFile file(fileName);

         if (!file.open(QIODevice::WriteOnly)) {
             QMessageBox::information(this, trUtf8("فایل"),
                 file.errorString());
             return;
         }
    }
}

void ProjectWindow::on_btnProjectRestore_clicked()
{

     QString fileName = QFileDialog::getOpenFileName(this,
         tr("Open NetMetre File"), "",
         tr("NetMetre (*%1);;All Files (*)").arg(trUtf8(DEF_DB_FILE_EXT)));

     if (fileName.isEmpty())
         return;
     else {

         QFile file(fileName);

         if (!file.open(QIODevice::ReadOnly)) {
             QMessageBox::information(this, trUtf8("فایل"),
                 file.errorString());
             return;
         }
    }

}

void ProjectWindow::on_btnExit_clicked()
{

    struct nm_project* prj;

    nm_enum_prjlist_start(nm);
    nm_set_flag(nm, NM_SESSION_EXIT);
    while((prj = nm_enum_prjlist(nm))){
        //TODO: this could lead to dead lock
        if(prj->pid != pid) ((ProjectWindow*)(prj->obj))->close();
    }
    nm_enum_prjlist_end(nm);

    this->close();
}

void ProjectWindow::on_btnAbout_clicked()
{
    AboutDialog* dlg = new AboutDialog;
    if(!dlg){
        QMessageBox::critical(this, trUtf8("منابع"), trUtf8("کمبود حافظه"));
       return;
    }

    dlg->exec();
}

void ProjectWindow::on_listwidgetOpenProjects_itemDoubleClicked(QListWidgetItem *item)
{
    struct nm_project* prj;

    nm_enum_prjlist_start(nm);
    while((prj = nm_enum_prjlist(nm))){
        if(trUtf8(prj->name) == item->text()){
            ((ProjectWindow*)(prj->obj))->raise();
            break;
        }
    }

    nm_enum_prjlist_end(nm);

}

void ProjectWindow::on_checkMoreSpace2_clicked()
{
    if(metretabexpanded){
        metretabexpanded = false;
    } else {
        metretabexpanded = true;
    }

    ui->btnItemAdd->setVisible(metretabexpanded);
    ui->btnItemDelete->setVisible(metretabexpanded);
    ui->btnItemMgmt->setVisible(metretabexpanded);
    ui->btnItemInsert->setVisible(metretabexpanded);

    ui->groupItemProperties->setVisible(metretabexpanded);
    ui->groupItemRelatives->setVisible(metretabexpanded);

}

void ProjectWindow::on_editContractSubject_editingFinished()
{

    struct project_list* entry;

    if(ui->editContractSubject->text().isEmpty()) return;

    for(entry = nm->prjfirst; entry; entry = entry->next){
        assert(entry->prj);
        if(entry->prj != prjptr){
            if(((ProjectWindow*)entry->prj)->name == ui->editContractSubject->text()){
                setMessage(trUtf8(STR_USER_SYSTEM), trUtf8("نام پروژه استفاده شده است"));
                return;
            }
        }
    }

    setTitle(ui->editContractSubject->text());

    updateOpenProjectList();

    updateOtherOpenProjectList();

}

void ProjectWindow::on_tabwidgetData_selected(const QString &arg1)
{
    if(arg1 == trUtf8("tabPriceList")){

    }
}

void ProjectWindow::on_btnShowPriceList_clicked()
{

    PriceListView* plview = new PriceListView;
    plview->show();

}

bool ProjectWindow::eventFilter(QObject *obj, QEvent *event){

    //QPushButton* btn = dynamic_cast<QPushButton*>(obj);
    QToolButton* tbtn;

    if(obj->objectName() == tr("btnHome")){

        tbtn = dynamic_cast<QToolButton*>(obj);

        Q_ASSERT(tbtn);


        if(event->type() == QEvent::Enter){
            tbtn->setIcon(QIcon(":/images/16x16/home_accept.png"));
        } else if(event->type() == QEvent::Leave){
            tbtn->setIcon(QIcon(":/images/16x16/home.png"));
        }

    } else if(obj->objectName() == tr("btnMetre")){

        tbtn = dynamic_cast<QToolButton*>(obj);

        Q_ASSERT(tbtn);

        if(event->type() == QEvent::Enter){
            tbtn->setIcon(QIcon(":/images/16x16/edit_page.png"));
        } else if(event->type() == QEvent::Leave){
            tbtn->setIcon(QIcon(":/images/16x16/full_page.png"));
        }

    }

    return false;
}

void ProjectWindow::on_btnHome_clicked()
{
    ui->tabwidgetControl->setCurrentWidget(ui->tabProject);
    ui->tabwidgetData->setCurrentWidget(ui->tabContract);
}

void ProjectWindow::on_btnMetre_clicked()
{
    ui->tabwidgetControl->setCurrentWidget(ui->tabSort);
    ui->tabwidgetData->setCurrentWidget(ui->tabMetre);
}

void ProjectWindow::on_btnCalc_clicked()
{
    calc->show();
    calc->raise();
}

void ProjectWindow::setMessage(QString from, QString msg){

    if(msg.isEmpty()) return;
    QString message = from.append(tr(" :{ "));
    message.append(msg).append(tr(" };"));
    ui->listMessages->addItem(message);

    ui->listMessages->scrollToBottom();

    ui->tabwidgetControl->setTabIcon(ui->tabwidgetControl->indexOf(ui->tabContacts),
                                  QIcon(":/images/16x16/mail_receive.png"));
}

void ProjectWindow::setMessage(QString from, QStringList msglist){

    QString ml;
    QString message = from.append(tr(" :{"));
    ui->listMessages->addItem(message);

    foreach(ml, msglist){
        ml.prepend(tr(" "));
        ui->listMessages->addItem(ml);
    }

    ui->listMessages->addItem(tr(" };"));

    ui->listMessages->scrollToBottom();

    ui->tabwidgetControl->setTabIcon(ui->tabwidgetControl->indexOf(ui->tabContacts),
                                  QIcon(":/images/16x16/mail_receive.png"));
}

void ProjectWindow::on_tabwidgetControl_currentChanged(QWidget *arg1)
{
    if(arg1 == ui->tabContacts){        
        ui->tabwidgetControl->setTabIcon(ui->tabwidgetControl->indexOf(ui->tabContacts),
                                      QIcon(":/images/16x16/mail.png"));
    }
}

void ProjectWindow::on_lineMessage_returnPressed()
{
    setMessage(tr(STR_USER_THIS), ui->lineMessage->text());
    ui->lineMessage->clear();
}

void ProjectWindow::on_toolSendMessage_clicked()
{
    on_lineMessage_returnPressed();
}
