﻿#ifndef FB_OBJ_H
#define FB_OBJ_H

/*
 *  object id pool block shape, shows empty object ids
 *  HEADER-START_OBJ_ID-BITMAP
*/

#endif // FB_OBJIDPOOL_H
