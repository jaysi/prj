﻿#ifndef FB_MAP_H
#define FB_MAP_H

#include "fb_intern.h"

#define FB_MAP_CMP_BTYPE	(0x01<<0)
#define FB_MAP_CMP_DTYPE	(0x01<<1)
#define FB_MAP_CMP_TID		(0x01<<2)
#define FB_MAP_CMP_NFUL     (0x01<<3)	/* this flag is different from
                                           other flags as long as the
                                           map entry value must be less
                                           than the requested value */

/*
    map blocks only address table_def, cell_main and index blocks
*/
#define FB_MAP_BLK_HDR_PACKSTR  "HL"
struct fb_map_blk_hdr {
//    uchar type;   //these are not needed, as long as the position of such
//    uchar flags;  //blocks are fixed

    fb_bent_t nset;	//number of entries set
    h13_crc32_t crc32;		//crc of the block including header
}__attribute__((packed));

#define FB_MAP_BLK_ENTRY_PACKSTR    "CCHQ"
struct fb_map_blk_entry {
    fb_blk_t blk_type;
    /*
       dtype:
       in CELL_DATA_*       block data type
       in INDEX             index type
     */
    fb_data_t dtype;
    fb_bent_t nful;//you might want to change it to some kind of flag to show if block has empty slots or not
    fb_tid_t tid;
    /*
       the tid field is not needed in GLOBAL blocks like snapshots,
       thus, it means:
            total bytes used in block: snapshot
    */
    /*
       fb_bid_t bid;
       don't need this, there is a formula to find the bid if there is
       a map entry for each block, that is:
       assuming if map_order = 0 then map_bid = 0;
       map_bid = map_order*(map_entry_capacity + 1);
       bid = map_bid + blk_entry_inside_the_map;
     */
}__attribute__((packed));

struct fb_map_blk {
    struct fb_memblk_hdr memhdr;
    struct msegid13_t mseg;//mempool segment
    size_t bitmapsize;
    bitmap13_t change_bmap;
    struct fb_map_blk_hdr* hdr;
    struct fb_map_blk_entry *entry;
    //struct fb_map_blk *next;
};

#ifdef __cplusplus
    extern "C" {
#endif

#define _fb_max_nful(h, btype) ((h)->hdr.bent[btype])

#ifdef __cplusplus
    }
#endif

#endif // FB_MAP_H
