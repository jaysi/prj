﻿#ifndef FB_DB13_H
#define FB_DB13_H

#include "flashback.h"

#ifdef __cplusplus
    extern "C" {
#endif

error13_t xfb_init(struct db13* h);    /*inits fb handle*/

error13_t xfb_connect(   struct db13* h,
                        char* db,
                        struct db13_db_conf* conf); /*connects to a db*/

error13_t xfb_disconnect(struct db13* h,
                        char* db);      /*disconnects from db*/

error13_t xfb_open(  struct db13* h,
                    char* db,
                    char* alias,
                    db13_openflag_t flags); /*opens a db handle*/

error13_t xfb_close( struct db13* h,
                    char* alias,
                    db13_openflag_t flags);/*closes a db handle*/

error13_t xfb_destroy(struct db13* h);

//tables
error13_t xfb_open_table(struct db13* h,
                        char* alias,
                        char* table,
                        objid13_t ncols,
                        struct db13_col* col,
                        db13_tableflag_t flags);

error13_t xfb_trunc_table(	struct db13* h,
                            char* alias,
                            char* table);

error13_t xfb_delete_table(  struct db13* h,
                            char* alias,
                            char* table);

char** xfb_list_tables(  struct db13* h,
                        char* alias);

//row
error13_t xfb_insert_row(	struct db13* h,
                            char* db,
                            char* table,
                            struct db13_row* row);

error13_t xfb_delete_row(	struct db13* h,
                            char* alias,
                            char* table,
                            struct db13_filter* filter);

error13_t xfb_update_row(	struct db13* h,
                            char* alias,
                            char* table,
                            struct db13_row* row,
                            struct db13_filter* filter);

//columns
error13_t xfb_insert_col(	struct db13* h,
                            char* alias, char* table,
                            char pos, /*see COLPOS*/
                            char* name, /*the position related column*/
                            objid13_t ncols,
                            struct db13_col* col);

error13_t xfb_delete_col(	struct db13* h,
                            char* alias,
                            char* table,
                            objid13_t ncols,
                            struct db13_col* col);

error13_t xfb_update_col(	struct db13* h,
                            char* alias,
                            char* table,
                            struct db13_col* old_col,
                            struct db13_col* new_col);

//select
error13_t xfb_select(struct db13* h,
                    char* alias,
                    char* table,
                    objid13_t ncols,
                    struct db13_col* col,
                    struct db13_filter* filter,
                    struct db13_rowset* rowset,
                    db13_fetchflag_t flags);

struct db13_row* xfb_fetch_row(  struct db13* h,
                                struct db13_rowset* rowset,
                                db13_fetchflag_t flags);

struct db13_field* xfb_fetch_field(  struct db13* h,
                                    struct db13_row* row,
                                    char* colname,
                                    db13_fetchflag_t flags);

//pro
error13_t xfb_trans(struct db13* h, char* alias);//starts transaction
error13_t xfb_commit(struct db13* h, char* alias);
error13_t xfb_rollback(struct db13* h, char* alias);

//error
error13_t xfb_get_last_error(struct db13* h);

#ifdef __cplusplus
    }
#endif

#endif // FB_DB13_H
