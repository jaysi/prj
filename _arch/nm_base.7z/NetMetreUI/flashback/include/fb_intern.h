﻿#ifndef FB_INTERN_H
#define FB_INTERN_H

#include "../../lib13/include/lib13.h"
#include "fb_types.h"
#include "fb_mem.h"
#include "fb_block.h"
#include "fb_map.h"
#include "fb_lock.h"

//header takes 1 block
struct fb_db_hdr{

    fb_dbhdrflag_t flags;

    fb_bent_t bent[FB_BLK_VOID];//no locking needed

    fb_bid_t max_blocks;//no locking needed
    fb_bid_t nblocks;
//    fb_bid_t nmaps; //this is unnecessary, you might calc it from nblocks
//    fb_bent_t map_changebitmap_size;

};

struct flashback_db{

    fb_dbhandleflag_t flags;

    struct fb_db_hdr db_hdr;

    struct io13 io;

};

#define _fb_set_handle_flag(h, flag, lock) MACRO(   if(lock){_fb_lock_handle(h);}\
                                                    (h)->flags|=flag;\
                                                    if(lock){_fb_unlock_handle(h);} )

#endif // FB_INTERN_H
