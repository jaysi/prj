﻿#ifndef FB_MEM_H
#define FB_MEM_H

#include "fb_intern.h"

//all blocks must have this header
struct fb_blockbuf_hdr{
    msegid13_t mseg;
    void* buf;
};

struct fb_blockbuf{
    struct m13_mempool* pool;
};

#ifdef __cplusplus
extern "C" {
#endif

error13_t _fb_init_blockbuf(struct fb_blockbuf* h,
                            fb_bsize_t bsize,
                            fb_bid_t initblocks,
                            size_t bucksize);
error13_t _fb_get_blockbuf(struct fb_blockbuf* h, fb_bid_t bid, fb_blk_t type, struct fb_blockbuf_hdr* hdr);
error13_t _fb_free_blockbuf(struct fb_blockbuf* h, fb_bid_t bid);
error13_t _fb_destroy_blockbuf(struct fb_blockbuf* h);
//void* _fb_blockbuf(struct fb_blockbuf* h, struct fb_blockbuf_hdr* hdr);
#define _fb_blockbuf(h, hdr) ((hdr)->buf)

#ifdef __cplusplus
}
#endif

#endif // FB_MEM_H
