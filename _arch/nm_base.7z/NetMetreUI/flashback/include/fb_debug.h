﻿#ifndef FB_DEBUG_H
#define FB_DEBUG_H

#include "../../lib13/include/debug13.h"

#define DEBUGLEVEL  1

#define _g(level, fmt, args...) _DebMsgL(level, fmt, ## args)

#endif // FB_DEBUG_H
