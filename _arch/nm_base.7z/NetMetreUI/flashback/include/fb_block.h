﻿#ifndef FB_BLOCK_H
#define FB_BLOCK_H

#include "fb_types.h"
#include "fb_mem.h"
typedef objid13_t fb_bid_t;

//constraints
#define FB_MAX_BSIZE		65536
#define FB_MIN_BSIZE		1024
#define FB_HASH32_INVAL		0xffffffff
#define FB_HASH32_EMPTY		0x00000000
#define FB_ID_INVAL         0xffffffff
#define FB_SIZE_INVAL		0xffffffff
#define FB_ID_EMPTY         0x00000000
#define FB_BENT_INVAL		0xffff

enum fb_block_type{
    FB_BLK_EMPTY,
    FB_BLK_MAP,
    FB_BLK_TYPEDEF,
    FB_BLK_TABLEDEF,
    FB_BLK_COLTYPEDEF,
    FB_BLK_CELLDEF,
    FB_BLK_CELLDATA,//memmory allocation
    FB_BLK_CELLDATAVAR,
    FB_BLK_CELLDATAFIX,
    FB_BLK_CELLDATAPTR,
    FB_BLK_INDEX,
    FB_BLK_TABLEFAV,
    FB_BLK_SNAPSHOT,
    FB_BLK_OBJIDPOOL,
    FB_BLK_VOID //memmory allocation
};

#define FB_BLOCK_TYPE(enum_type) ((uint8_t)enum_type)

#define FB_BLOCK_TYPE1_HDR_PACKSTR  "CCL"
struct fb_blk_type1_hdr{

    fb_blk_t type;
    fb_blkflag_t flags;

    h13_hash32_t crc32;		//crc of the block including header

}__attribute__((packed));

#define FB_MEMBLKF_WR   (0x01<<0)//writing, do not interfere!
//standard header of in-memmory blocks
struct fb_memblk_hdr{
    fb_blockbuf_hdr blockbuf;
    fb_bid_t bid;
    int write;
    //fb_bent_t changebitmap_size;
    bitmap13_t changebitmap;
    fb_memblkflag_t flags;
};

struct _fb_block_param{
    char* hdrpackstr;
    char* entrypackstr;
    fb_bent_t nent;//number of entries, computed at run-time
} fb_blk_param[] =
{
    {"", "", FB_BENT_INVAL},//empty
    {FB_MAP_BLK_HDR_PACKSTR, FB_MAP_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//map
    {FB_TYPEDEF_BLK_HDR_PACKSTR, FB_TYPEDEF_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//typedef
    {FB_TABLEDEF_BLK_HDR_PACKSTR, FB_TABLEDEF_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//tabledef
    {FB_COLTYPEDEF_BLK_HDR_PACKSTR, FB_COLTYPEDEF_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//col typedef
    {FB_CELLDEF_BLK_HDR_PACKSTR, FB_CELLDEF_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//celldef
    {FB_CELLDATAVAR_BLK_HDR_PACKSTR, FB_CELLDATAVAR_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//celldata var
    {FB_CELLDATAFIX_BLK_HDR_PACKSTR, FB_CELLDATAFIX_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//celldata fix
    {FB_CELLDATAPTR_BLK_HDR_PACKSTR, FB_CELLDATAPTR_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//celldata ptr
    {FB_INDEX_BLK_HDR_PACKSTR, FB_INDEX_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//index
    {FB_TABLEFAV_BLK_HDR_PACKSTR, FB_TABLEFAV_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//table fav
    {FB_SNAPSHOT_BLK_HDR_PACKSTR, FB_SNAPSHOT_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//snapshot
    {FB_OBJIDPOOL_BLK_HDR_PACKSTR, FB_OBJIDPOOL_BLK_ENTRY_PACKSTR, FB_BENT_INVAL},//objid-pool
    {"", "", FB_BENT_INVAL},//void
};

#define FB_START_CREATE_BLOCK(h)    MACRO( _fb_lock_hdr(h);\
                                    (h)->hdr.nblocks++;\
                                    bid = (h)->hdr.nblocks - 1;\
                                    _fb_unlock_hdr(h);\
                                    _fb_set_handle_flag(h, FB_HANDLEF_WRHDR, 1); )

#define FB_UNDO_CREATE_BLOCK(h) MACRO(  _fb_lock_hdr(h);\
                                        (h)->hdr.nblocks--;\
                                        _fb_unlock_hdr(h);\
                                        /*_fb_unset_handle_flag(h, FB_HANDLEF_WRHDR, 1); others might have set this*/\
                                        )



#endif // FB_BLOCK_H
