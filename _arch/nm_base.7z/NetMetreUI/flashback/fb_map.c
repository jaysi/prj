﻿/*
 *  there is only one way to resolve the locking problem easily...
 *  ORDER do not REQUEST! i.e. list_ and find_ functions must be replaced
*/

#include "flashback.h"

error13_t _fb_init_map(struct flashback* h){    
    return m13_pool_init(   &h->map,
                            sizeof(struct fb_map_blk),
                            h->conf.map_pool_buck,
                            h->conf.map_pool_buck,
                            MEM13_EXPANDING,
                            MEM13_DEF_FLAGS);
}

error13_t _fb_create_map_blk(struct flashback *h)
{
    msegid13_t mseg;
    fb_bid_t bid;
    struct fb_map_blk* map;

    FB_START_CREATE_BLOCK(h);

    //_fb_lock_map(h); the pool_alloc handles locking

    map = m13_pool_alloc(&h->map, &mseg);
    if (!map) {
        FB_UNDO_CREATE_BLOCK(h);
        return e13_error(E13_NOMEM);
    }

    //map->memhdr.flags = FB_MEMBLKF_WR;//the mempool has locking
    map->mseg = mseg;

    //_fb_unlock_map(h);

    if((ret = _fb_get_blockbuf( &(h->blockbuf),
                                bid,
                                FB_BLK_MAP,
                                &(map->memhdr.blockbuf))
            )!= E13_OK){
        m13_pool_unlock(&h->map, mseg);
        m13_pool_free(&h->map, map->mseg);
        FB_UNDO_CREATE_BLOCK(h);
        return ret;
    }

    map->hdr = (struct fb_map_blk_hdr*)_fb_blockbuf(&h->blockbuf,
                                                    &map->memhdr.blockbuf);

    map->entry = (struct fb_map_blk_entry*)(_fb_blockbuf(&h->blockbuf,
                                                         &map->memhdr.blockbuf)+
                                                sizeof(struct fb_map_blk_hdr));

    map->memhdr.changebitmap =
            map->entry +
            sizeof(struct fb_map_blk_entry) * h->hdr.bent[FB_BLK_MAP];

    memset((void *)map->hdr, '\0', sizeof(struct fb_map_blk_hdr));
    memset((void *)map->entry, '\0',
           sizeof(struct fb_map_blk_entry) * h->hdr.bent[FB_BLK_MAP]);
    //map->bitmapsize = BITMAPSIZE(h->hdr.bent[FB_BLK_MAP]);
    memset(map->memhdr.changebitmap, 0xff, h->hdr.map_changebitmap_size);

    map->memhdr.write = 1;

    if (!h->nmap) {
        map->memhdr.bid = (fb_bid_t)0;
    } else if ((map->memhdr.bid = h->map_list.last->bid + h->hdr.bent[FB_BLK_MAP] + 1) >=
           h->hdr.max_blocks) {
        m13_pool_unlock(&h->map, mseg);
        m13_pool_free(&h->map, mseg);
        FB_UNDO_CREATE_BLOCK(h);
        return e13_error(E13_FULL);
    }

    m13_pool_unlock(&h->map, mseg);

    return 0;
}

/*
int _fb_set_map_entry(struct fb_handle *h,
               struct fb_map *map,
               fb_bent_t map_bent,
               fb_blk_t btype,
               fb_data_t dtype, fb_tid_t tid, fb_bent_t nful)
{

    if (map->entry[map_bent].blk_type == FB_BTYPE_EMPTY &&
        btype != FB_BTYPE_EMPTY) {
        map->hdr->nset++;
    } else if (map->entry[map_bent].blk_type != FB_BTYPE_EMPTY &&
           btype == FB_BTYPE_EMPTY) {
        map->hdr->nset--;
    }

    map->entry[map_bent].blk_type = btype;
    map->entry[map_bent].dtype = dtype;
    map->entry[map_bent].tid = tid;
    map->entry[map_bent].nful = nful;
    map->write++;

    return 0;
}
*/
static inline struct fb_map_blk* _fb_get_map_ptr_by_bid(struct flashback* h,
                                                    fb_bid_t bid){
    msegid13_t seg, max;
    struct fb_map_blk* map;
    max = m13_pool_upper(&h->map);
    for(seg = 0; seg < max; seg++){
        map = m13_pool_buf(&h->map, seg);
        if(map){
            if(map->memhdr.bid == bid) return map;
            m13_pool_unlock(&h->map, seg);
        }
    }

    return NULL;
}

//static inline struct fb_map_blk_entry* _fb_get_map_entry_ptr(
//                    struct flashback* h, fb_bid_t bid){
//    struct fb_map_blk* map;

//    if(!(map = _fb_get_map_ptr_by_bid(h, bid))) return NULL;
//    assert(_FB_MAP_BENT(bid, h->hdr.map_bent) <= h->hdr.map_bent);
//    return &map->entry[_FB_MAP_BENT(bid, h->hdr.bent[FB_BLK_MAP])];
//}

//TODO: request or order?
fb_data_t _fb_get_block_dtype(struct flashback* h, fb_bid_t bid){

    struct fb_map_blk* map;
    struct fb_map_blk_entry* m_ent;
    fb_data_t dtype;

    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map) return FB_DATA_T(FB_DATATYPE_EMPTY);

    assert(_FB_MAP_BENT(bid, h->hdr.bent[FB_BLK_MAP]) < h->hdr.bent[FB_BLK_MAP]);

    ment = &map->entry[_FB_MAP_BENT(bid, h->hdr.bent[FB_BLK_MAP])];
    dtype = m_ent->dtype;

    m13_pool_unlock(h->map, map->mseg);

    return dtype;
}

error13_t _fb_set_map_nful_by_bid(struct flashback *h, fb_bid_t bid,
                            fb_bent_t nful)
{
    fb_bent_t map_bent;
    struct fb_map_blk *map;

    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map){
        return e13_error(E13_NOTFOUND);
    }

    map_bent = bid - map->memhdr.bid - 1;

    map->entry[map_bent].nful = nful;

    BITMAPON(map->memhdr.changebitmap, map_bent);

    map->memhdr.write++;

    m13_pool_unlock(&h->map, map->mseg);

    return E13_OK;
}

error13_t _fb_inc_map_nful_by_bid(struct flashback *h, fb_bid_t bid, fb_bent_t n)
{
    fb_bent_t map_bent;
    struct fb_map_blk *map;

    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map){
        return e13_error(E13_NOTFOUND);
    }

    map_bent = bid - map->memhdr.bid - 1;

    map->entry[map_bent].nful += n;

    BITMAPON(map->memhdr.changebitmap, map_bent);

    map->memhdr.write++;

    m13_pool_unlock(&h->map, map->mseg);

    return E13_OK;
}

error13_t _fb_dec_map_nful_by_bid(struct flashback *h, fb_bid_t bid, fb_bent_t n)
{
    fb_bent_t map_bent;
    struct fb_map_blk *map;
    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map){
        return e13_error(E13_NOTFOUND);
    }

    map_bent = bid - map->memhdr.bid - 1;

    map->entry[map_bent].nful -= n;

    BITMAPON(map->memhdr.changebitmap, map_bent);

    map->memhdr.write++;

    m13_pool_unlock(&h->map, map->mseg);

    return E13_OK;
}

static inline error13_t _fb_get_map_nful_by_bid(struct flashback *h, fb_bid_t bid, fb_bent_t* nful)
{
    fb_bent_t map_bent;
    struct fb_map_blk *map;
    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map){
        return e13_error(E13_NOTFOUND);
    }

    map_bent = bid - map->memhdr.bid - 1;
    *nful = map->entry[map_bent].nful;

    //m13_pool_unlock(pool, map->mseg);

    return E13_OK;
}

//TODO: is this a request or order?
fb_bid_t _fb_get_empty_map_entry(   struct flashback * h, fb_blk_t btype,
                                    fb_data_t dtype, fb_tid_t tid,
                                    fb_bent_t nful)
{
    struct fb_map_blk *map;
    fb_bent_t bent;
    fb_bid_t bid;
    msegid13_t max, seg;

    max = m13_pool_upper(&h->map);

    for(seg = 0; seg < max; seg++){
        map = m13_pool_buf(pool, seg);
        if(map){

            if (map->hdr->nset >= h->hdr.map_bent) continue;

after_new_created:
            for (bent = 0; bent < h->hdr.bent[FB_BLK_MAP]; bent++) {
                if (map->entry[bent].blk_type == FB_ID_EMPTY) {
                    map->entry[bent].blk_type = btype;
                    map->entry[bent].dtype = dtype;
                    map->entry[bent].tid = tid;
                    map->entry[bent].nful = nful;

                    BITMAPON(map->memhdr.changebitmap, bent);

                    map->memhdr.write++;
                    map->hdr->nset++;

                    bid = _fb_calc_bid(map->bid, bent);

                    m13_pool_unlock(&h->map, seg);

                    return bid;
                }
            }

            m13_pool_unlock(&h->map, seg);

        }

    }

    if (_fb_create_map(h) != E13_OK) {
        return FB_ID_INVAL;
    }

    seg = m13_pool_upper(&h->map);

    map = m13_pool_buf(&h->map, seg);

    goto after_new_created;

    return FB_ID_INVAL;
}

/*

int _fb_get_empty_map_entries(struct fb_handle *h, fb_blk_t * btype,
                   fb_data_t * dtype, fb_tid_t * tid,
                   fb_bent_t * nful, fb_bid_t * bid, fb_bid_t n)
{

    struct fb_map *map;
    fb_bent_t bent;
    fb_bid_t i;
    int ret;

    i = 0UL;

    for (map = h->map_list.first; map; map = map->next) {
        if (map->hdr->nset >= h->hdr.map_bent)
            continue;
        for (bent = 0; bent < h->hdr.map_bent; bent++) {
            if (map->entry[bent].blk_type == FB_ID_EMPTY) {
                map->entry[bent].blk_type = btype[i];
                map->entry[bent].dtype = dtype[i];
                map->entry[bent].tid = tid[i];
                map->entry[bent].nful = nful[i];
                bid[i++] = _fb_calc_bid(map->bid, bent);
                map->write++;
                map->hdr->nset++;
                if (i == n)
                    return 0;
            }
        }
    }

    while (1) {

        if ((ret = _fb_create_map(h)) < 0) {
            _wdeb_map(L"_fb_create_map() fails, bid: %u", bid[i]);
            return ret;
        }

        map = h->map_list.last;

        for (bent = 0; bent < h->hdr.map_bent; bent++) {
            map->entry[bent].blk_type = btype[i];
            map->entry[bent].dtype = dtype[i];
            map->entry[bent].tid = tid[i];
            map->entry[bent].nful = nful[i];
            bid[i++] = _fb_calc_bid(map->bid, bent);
            map->hdr->nset++;
            if (i == n)
                return 0;
        }
    }

    return -JE_UNK;
}

*/

error13_t _fb_rm_map_bid_entries(struct flashback *h, fb_bid_t * bid, fb_bid_t n)
{
    struct fb_map_blk *map;
    fb_bid_t i, removed = 0UL;
    fb_bent_t map_bent;

    for (i = 0; i < n; i++) {

        map = _fb_get_map_ptr_by_bid(h, bid[i]);
        if(!map) continue;

        map_bent = bid[i] - map->memhdr.bid - 1;
        map->entry[map_bent].blk_type = FB_BLOCK_TYPE(FB_BLK_EMPTY);
        bid[i] = FB_ID_INVAL;
        removed++;
        map->hdr->nset--;

        BITMAPON(map->memhdr.changebitmap, map_bent);

        map->memhdr.write++;

        m13_pool_unlock(&h->map, map->mseg);
    }        

    _fb_lock_hdr(h);
    h->hdr.nblocks -= removed;
    _fb_unlock_hdr(h);
    _fb_set_handle_flag(h, FB_HANDLEF_WRHDR, 1);

    if (removed == n)
        return E13_OK;
    return e13_error(E13_NOTFOUND);
}

error13_t _fb_rm_map_bid_entry(struct flashback *h, fb_bid_t bid)
{
    struct fb_map_blk *map;
    fb_bent_t map_bent;

    map = _fb_get_map_ptr_by_bid(h, bid);
    if(!map){
        return e13_error(E13_NOTFOUND);
    }
    map_bent = bid - map->memhdr.bid - 1;
    map->entry[map_bent].blk_type = FB_BTYPE_EMPTY;
    map->hdr->nset--;
    map->memhdr.write++;

    BITMAPON(map->memhdr.changebitmap, bent);

    m13_pool_unlock(&h->map, map->mseg);

    _fb_lock_hdr(h);
    h->hdr.nblocks--;
    _fb_unlock_hdr(h);
    _fb_set_handle_flag(h, FB_HANDLEF_WRHDR, 1);

    return E13_OK;
}

//fb_bid_t _fb_find_first_map_match(  struct flashback * h, fb_blk_t btype,
//                                    fb_data_t dtype, fb_tid_t tid,
//                                    fb_bent_t nful, uint8_t cmp_flags)
//{
//    struct fb_map_blk *map;
//    fb_bent_t i;
//    int match_needed = 0, matches;
//    msegid13_t max, seg;

//    if (cmp_flags & FB_MAP_CMP_BTYPE) {
//        match_needed++;
//    }
//    if (cmp_flags & FB_MAP_CMP_DTYPE) {
//        match_needed++;
//    }
//    if (cmp_flags & FB_MAP_CMP_TID) {
//        match_needed++;
//    }

//    if (cmp_flags & FB_MAP_CMP_NFUL) {
//        match_needed++;
//    }

//    max = m13_pool_upper(&h->map);

//    for (seg = 0; seg < max; seg++) {

//        map = m13_pool_buf(&h->map, seg);
//        if(!map) continue;

//        for (i = 0; i < h->hdr.bent[FB_BLK_MAP]; i++) {
//            matches = 0;
//            if (cmp_flags & FB_MAP_CMP_BTYPE) {
//                if (map->entry[i].blk_type != btype)
//                    continue;
//                matches++;
//            }
//            if (cmp_flags & FB_MAP_CMP_DTYPE) {
//                if (map->entry[i].dtype != dtype)
//                    continue;
//                matches++;
//            }
//            if (cmp_flags & FB_MAP_CMP_TID) {
//                if (map->entry[i].tid != tid)
//                    continue;
//                matches++;
//            }

//            if (cmp_flags & FB_MAP_CMP_NFUL) {
//                if (map->entry[i].nful >= nful)
//                    continue;
//                matches++;
//            }

//            if (matches == match_needed){
//                bid = _fb_calc_bid(map->memhdr.bid, i);
//                m13_pool_unlock(&h->map, map->mseg);
//                return bid;
//            }
//        }

//        m13_pool_unlock(&h->map, map->mseg);

//    }

//    return FB_ID_INVAL;
//}

//error13_t _fb_list_map_match(   struct fb_handle *h, fb_blk_t btype, fb_data_t dtype,
//                                fb_tid_t tid, fb_bent_t nful, uchar cmp_flags,
//                                fb_bid_t ** bid, fb_bid_t * n)
//{
//    struct fb_map_blk *map;
//    fb_bent_t i;
//    int match_needed = 0, matches;
//    int buck_cnt = 0;

//    *n = 0UL;
//    *bid = NULL;

//    if (cmp_flags & FB_MAP_CMP_BTYPE) {
//        match_needed++;
//    }
//    if (cmp_flags & FB_MAP_CMP_DTYPE) {
//        match_needed++;
//    }
//    if (cmp_flags & FB_MAP_CMP_TID) {
//        match_needed++;
//    }
//    if (cmp_flags & FB_MAP_CMP_NFUL) {
//        match_needed++;
//    }
//    for (map = h->map_list.first; map; map = map->next) {
//        for (i = 0; i < h->hdr.map_bent; i++) {
//            matches = 0;
//            if (cmp_flags & FB_MAP_CMP_BTYPE) {
//                if (map->entry[i].blk_type != btype)
//                    continue;
//                matches++;
//            }
//            if (cmp_flags & FB_MAP_CMP_DTYPE) {
//                if (map->entry[i].dtype != dtype)
//                    continue;
//                matches++;
//            }
//            if (cmp_flags & FB_MAP_CMP_TID) {
//                if (map->entry[i].tid != tid)
//                    continue;
//                matches++;
//            }
//            if (cmp_flags & FB_MAP_CMP_NFUL) {
//                if (map->entry[i].nful >= nful)
//                    continue;
//                matches++;
//            }
//            if (matches == match_needed) {
//                if (!(*bid)) {
//                    *bid = (fb_bid_t *)
//                        malloc(sizeof(fb_bid_t) *
//                           h->hdr.map_list_buck);
//                    if (!(*bid)){
//                        return -JE_MALOC;
//                    }
//                    buck_cnt = 0;
//                } else {
//                    if (buck_cnt == h->hdr.map_list_buck) {
//                        *bid = realloc(*bid,
//                            sizeof(fb_bid_t)*(h->hdr.map_list_buck*
//                                    (((*n)+h->hdr.map_list_buck)/h->hdr.map_list_buck)));
//                        if (!(*bid)){
//                            return -JE_MALOC;
//                        }


//                        buck_cnt = 0;
//                    }
//                }
//                (*bid)[(*n)++] = _fb_calc_bid(map->bid, i);
//                buck_cnt++;
//            }
//        }
//    }
//    _wdeb_list_map(L"buck cnt is %i, *n = %u", buck_cnt, *n);
//    return 0;
//}

int _fb_load_map(struct flashback *h)
{

    int ret;
    fb_bid_t bid = 0UL;
    fb_bid_t nmaps;
    struct fb_map_blk *map;

    _fb_lock_hdr(h);

    nmaps = _fb_calc_nmaps(h);

    _fb_unlock_hdr(h);



    while (nmaps) {
        map = (struct fb_map *)malloc(sizeof(struct fb_map));

        map->blockbuf = _fb_get_blockbuf(h, FB_BTYPE_MAP, 0,
                    FB_CHANGE_BMAP_SIZE(h->hdr.map_bent));
        if(!map->blockbuf){
            return -JE_MALOC;
        }

        map->hdr = (struct fb_map_blk_hdr*)map->blockbuf;
        map->entry = (struct fb_map_blk_entry*)(map->blockbuf +
                sizeof(struct fb_map_blk_hdr));
        map->memhdr.changebitmap = map->entry +
            (sizeof(struct fb_map_blk_entry)*h->hdr.map_bent);

        map->bid = bid;
        map->next = NULL;
        map->write = 0;

        if ((ret = _fb_read_map_blk(h, map)) < 0) {
            _fb_release_blockbuf(h, map->blockbuf);
            free(map);
            _fb_cleanup_handle(h);
            return ret;
        }

        memset(	map->memhdr.changebitmap , '\0',
            FB_CHANGE_BMAP_SIZE(h->hdr.map_bent));

        nmaps--;
        bid += h->hdr.map_bent + 1;

        if (!h->map_list.first) {
            h->map_list.first = map;
            h->map_list.last = map;
            h->map_list.cnt = 1UL;
        } else {
            h->map_list.last->next = map;
            h->map_list.last = map;
            h->map_list.cnt++;
        }
    }

    return 0;
}
/*
int _fb_write_map(struct fb_handle *h)
{
    int ret = 0, fret;
    struct fb_map *map;

    //_fb_enter_lock(h, FB_LK_MAP_WR | FB_LK_MAP_RD);

    for (map = h->map_list.first; map; map = map->next) {
        if (map->write) {
            fret = _fb_write_map_blk(h, map);
            if (fret < 0) {
                ret = fret;
            } else {
                map->write = 0;
            }
        }
    }

    //_fb_exit_lock(h, FB_LK_MAP_WR | FB_LK_MAP_RD);

    return ret;
}
*/
int _fb_map_chg_proc(struct fb_handle* h, fb_bid_t bid, struct fb_table* table, fb_bid_t map_bid){
    int cntr;
    int exists = 0;

    if(h->hdr.flags & FB_O_WR_THREAD){
        for(cntr = 0; cntr < table->map_chg_ptr; cntr++){
            if(table->map_chg_list[cntr] == map_bid){
                _wdeb_tm(L"found m_c_l[ %u ] = %u", cntr, map_bid);
                exists = 1;
                break;
            }
        }
        if(cntr == table->map_chg_list_size){
            _wdeb_tm(L"cntr[ %u ] = m_c_l_size %u", cntr,
                    table->map_chg_list_size);
            table->map_chg_list_size += FB_MAP_CHG_LIST_BUCK;
            table->map_chg_list = realloc(table->map_chg_list,
                        table->map_chg_list_size);
            if(!table->map_chg_list){
                return -JE_MALOC;
            }
            table->map_chg_ptr = table->map_chg_list_size -
                        FB_MAP_CHG_LIST_BUCK + 1;
            table->map_chg_list[table->map_chg_ptr-1] = map_bid;
            _wdeb_tm(L"m_c_l_size now %u, set pos %u to %u",
                table->map_chg_list_size,
                table->map_chg_list_size -
                    FB_MAP_CHG_LIST_BUCK, map_bid);
        } else {
            if(!exists){
                _wdeb_tm(L"cntr[ %u ] set to %u",cntr,map_bid);
                table->map_chg_list[cntr] = map_bid;
                table->map_chg_ptr++;
            }
        }
    }
    return 0;
}

int _fb_rm_map_entries_by_tid(struct fb_handle *h, fb_tid_t tid)
{
    struct fb_map *map;
    fb_bent_t i;
    fb_bid_t removed = 0;

    for (map = h->map_list.first; map; map = map->next) {
        for (i = 0; i < h->hdr.map_bent; i++){
            if (map->entry[i].tid == tid){
                map->entry[i].blk_type = FB_BTYPE_EMPTY;
                map->hdr->nset--;

                BITMAPON(map->memhdr.changebitmap, i);

                map->write++;
                removed++;
            }
        }
    }

    _fb_lock_handle(h, FB_LK_HDR, FB_LK_WR);

    _wdeb_rm(L"removed = %u", removed);

    h->hdr.nblocks-=removed;
    //h->hdr.ndata_ptrs++;
    _fb_set_handle_flag(h, FB_HMODIF, 0);
    _fb_unlock_handle(h, FB_LK_HDR, FB_LK_WR);

    return 0;
}


