﻿#include "netmetredb.h"
#include "ui_netmetredb.h"
#include "logindialog.h"

#include <QMessageBox>

NetMetreDB::NetMetreDB(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NetMetreDB)
{
    ui->setupUi(this);
}

NetMetreDB::NetMetreDB(QWidget *parent, struct nm_session* _nm) :
    QDialog(parent),
    ui(new Ui::NetMetreDB)
{
    ui->setupUi(this);

    setDBParam(  trUtf8(NM_DEF_DB_DRIVER),
                trUtf8(NM_DEF_DB_HOSTNAME),
                trUtf8(NM_DEF_DB_NAME),
                trUtf8(NM_DEF_DB_USERNAME),
                trUtf8(NM_DEF_DB_PASSWORD));

    this->hide();

    this->setWindowFlags(Qt::FramelessWindowHint);    

    nm = _nm;

    //setTablePattern();
}

NetMetreDB::~NetMetreDB()
{
    delete ui;
}

NetMetreDB::hideEvent(QHideEvent *event){
    (LoginDialog*)(this->parent())->reConfig();
    event->accept();
}

void NetMetreDB::setDBParam(QString driver,
                            QString hostname,
                            QString name,
                            QString username,
                            QString password){

    ui->editDBDriver->setText(driver);
    ui->editDBHostname->setText(hostname);
    ui->editDBName->setText(name);
    ui->editDBUsername->setText(username);
    ui->editDBPassword->setText(password);
}

db13_engine NetMetreDB::getEngineId(QString name){

    if(name == trUtf8("CSV")) return DB13_ENGINE_CSV;
    if(name == trUtf8("SQLITE")) return DB13_ENGINE_SQLITE3;
    if(name == trUtf8("MYSQL")) return DB13_ENGINE_MYSQL;

    return DB13_ENGINE_DEFAULT;
}

void NetMetreDB::getDBParam(struct db13_db_conf* conf){

    conf->engine = getEngineId(ui->editDBDriver);
    conf->host = ui->editDBHostname->text().toUtf8().data();
    conf->username = ui->editDBUsername->text().toUtf8().data();
    conf->password = ui->editDBPassword->text().toUtf8().data();

    conf->oflags = DB13_OPEN_DEFAULT;

}

bool NetMetreDB::initSys(){

    return true;
}
