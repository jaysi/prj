﻿#include "projectmanagerdialog.h"
#include "ui_projectmanagerdialog.h"

#include <QMessageBox>

ProjectManagerDialog::ProjectManagerDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectManagerDialog)
{
    ui->setupUi(this);
}

ProjectManagerDialog::ProjectManagerDialog(QWidget *parent, struct nm_session* _nm) :
    QDialog(parent),
    ui(new Ui::ProjectManagerDialog)
{

    char** list;

    ui->setupUi(this);

    nm = _nm;

    list = nm_get_prjlist(nm);
    if(list){
        showProjectList(list);
        nm_free_prjlist(list);
    } else {
        QMessageBox::warning(this, trUtf8("سیستم"), trUtf8(e13_errmsg(&nm->error_s)));
    }
}

ProjectManagerDialog::~ProjectManagerDialog()
{
    delete ui;
}

void ProjectManagerDialog::showProjectList(char **list){

}

nm_pid_t ProjectManagerDialog::getPid(){
    return 0ULL;
}
