﻿#ifndef PRICELISTVIEW_H
#define PRICELISTVIEW_H

#include <QMainWindow>
#include <QtSql>

#include "netmetre.h"

namespace Ui {
class PriceListView;
}

class PriceListView : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit PriceListView(QWidget *parent = 0);
    explicit PriceListView(QWidget *parent = 0, nm_listid_t id);
    ~PriceListView();
    
private:
    Ui::PriceListView *ui;    
};

#endif // PRICELISTVIEW_H
