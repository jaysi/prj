﻿#include "yesnocanceldialog.h"
#include "ui_yesnocanceldialog.h"

YesNoCancelDialog::YesNoCancelDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::YesNoCancelDialog)
{
    act = YNC_CANCEL;
    ui->setupUi(this);
}

YesNoCancelDialog::YesNoCancelDialog(QWidget *parent, QString& prjName) :
    QDialog(parent),
    ui(new Ui::YesNoCancelDialog)
{
    act = YNC_CANCEL;
    ui->setupUi(this);
    ui->labelProjectName->setText(prjName);

}

YesNoCancelDialog::~YesNoCancelDialog()
{
    delete ui;
}

void YesNoCancelDialog::on_btnSave_clicked()
{
    act = YNC_SAVE;
    this->accept();
}

void YesNoCancelDialog::on_btnDontSave_clicked()
{
    act = YNC_DONT;
    this->accept();
}


void YesNoCancelDialog::on_btnCancel_clicked()
{
    act = YNC_CANCEL;
    this->accept();
}

int YesNoCancelDialog::getAct(){
    return act;
}
