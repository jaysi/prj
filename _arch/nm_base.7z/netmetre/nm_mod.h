#ifndef NM_MOD_H
#define NM_MOD_H

#include "../lib13/include/lib13.h"

typedef objid13_t nm_modid_t;
typedef objid13_t nm_comodid_t;

struct nm_mod{
    nm_modid_t id;
    char* path;
};

struct nm_comod{
    nm_modid_t modid;
    nm_comodid_t id;
    char* alias;
};

#endif // NM_MOD_H
