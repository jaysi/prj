#ifndef NM_PROJECT_H
#define NM_PROJECT_H

#include "../lib13/include/lib13.h"

struct nm_session;

typedef objid13_t nm_pid_t;

#define NM_PRJ_DEF_NAME    "project"
#define NM_PRJ_DEF_NAME_FMT "%s_%u"
#define NM_PRJ_DEF_NEW     "new_project"
#define NM_PRJ_DEF_EMPTY   "empty"

struct nm_prj_mult{

};

struct nm_prj_spec{
    char* name;
    uint32_t nmult;
    struct nm_prj_mult* mult;
};

#define NM_PRJ_MAX_CHANGE   1000//maximum changes before autosave trigger

#define NM_PRJF_SAVE        (0x01<<0) //save project if changed
#define NM_PRJF_NOREQ       (0x01<<1) //no more request to project

#define NM_PRJF_DEF 0x00

struct nm_project{

    uint8_t flags;

    void* obj;      //project custom object

    char* name;
    nm_pid_t id;    //project id;
    nm_pid_t pid;   //parent project id;

    unsigned short max_change;//maximum allowed changes before autosave
    unsigned short nchanges;//total number of changes

    struct nm_db* basedb;
    struct nm_db* prjdb;

    struct nm_session* sess;

    struct nm_project* next;
};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_prj_add(struct nm_session* sess, char* name, char* parent);
    error13_t nm_prj_rm(struct nm_session* sess, char* name);

    error13_t nm_prj_open(struct nm_session* sess, char* name);
    error13_t nm_prj_close(struct nm_session* sess, char* name);

    error13_t nm_prj_set_spec(struct nm_session* sess, struct nm_prj_spec* spec);

#ifdef __cplusplus
    }
#endif



#endif // NM_PROJECT_H
