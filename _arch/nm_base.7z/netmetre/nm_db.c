#include "nm_db.h"

error13_t nm_db_init(struct nm_db* db,
                     enum nm_db_drv_id driver){

    if(nm_db_isinit(db)){
        return e13_ierror(&db->e, E13_MISUSE, "s", "already init");
    }

    if(e13_init(&db->e, E13_MAX_WARN_DEF, E13_MAX_ESTR_DEF, LIB13_NMDB) != E13_OK){
        return e13_error(E13_SYSE);
    }

    db->driver = driver;

    db->name = NM_DB_DEF_NAME;
    db->host = NM_DB_DEF_HOSTNAME;
    db->port = NM_DB_DEF_PORT;
    db->flags = NM_DB_DEF_FLAGS;
    db->username = NM_DB_DEF_USERNAME;
    db->password = NM_DB_DEF_PASSWORD;
    db->dbms = NULL;

    db->magic = MAGIC13_NMDB;

    return E13_OK;

}

error13_t nm_db_open(struct nm_db *db,
                     char *host,
                     char *port,
                     char *username,
                     char *password,
                     char *name){

    sqlite3* sqlite;

    size_t hlen, plen, ulen, slen, nlen;

    if(!nm_db_isinit(db)) return e13_error(E13_MISUSE);

    switch(db->driver){
    case NM_DB_DRV_NULL:
        db->dbms = NULL;
        break;
    case NM_DB_DRV_SQLITE:

        if(sqlite3_open(name, &sqlite) != SQLITE_OK){
            return e13_ierror(&db->e, E13_SYSE, "s", "dbms_open");
        }

        db->dbms = sqlite;

        break;
    default:
        return e13_ierror(&db->e, E13_IMPLEMENT, "s", "driver not supported");
        break;
    }

    hlen = strlen(host);
    plen = strlen(port);
    ulen = strlen(username);
    slen = strlen(password);
    nlen = strlen(name);

    db->name = (char*)malloc(hlen + plen + ulen + slen + nlen + 5);

    db->host = db->name + nlen + 1;
    db->port = db->host + hlen + 1;
    db->username = db->port + plen + 1;
    db->password = db->username + ulen + 1;

    strcpy(db->name, name);
    strcpy(db->host, host);
    strcpy(db->port, port);
    strcpy(db->username, username);
    strcpy(db->password, password);

    return E13_OK;
}

error13_t nm_db_close(struct nm_db *db){

    if(!nm_db_isinit(db)) return e13_error(E13_MISUSE);    

    switch(db->driver){
    case NM_DB_DRV_NULL:
        break;
    case NM_DB_DRV_SQLITE:
        sqlite3_close(SQLITE(db->dbms));
        break;
    default:
        return e13_ierror(&db->e, E13_IMPLEMENT, "s", "driver not supported");
        break;
    }

    free(db->name);

    db->magic = MAGIC13_INV;

    return E13_OK;

}


