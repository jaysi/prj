#ifndef NM_SESS_H
#define NM_SESS_H

#include "../lib13/include/lib13.h"
#include "nm_obj.h"
#include "nm_project.h"
#include "nm_mod.h"

typedef uint16_t nm_sessid_t;
struct netmetre;

#define NM_SESSF_EXIT (0x01<<0) /*exiting session, project list has been
                                  locked and there is no need to lock the
                                  list during nm_close_project call*/

#define NM_SESSF_DEF   0x00

struct nm_session{

    magic13_t magic;
    uint8_t flags;

    time_t create_time;

    th13_t thid;

    nm_refcount_t ref;
    nm_sessid_t id;

    char* name;

    struct nm_q* q_first, *q_last;

    nm_objid_t nprj;
    struct nm_project* prj_first, *prj_last;    

    struct nm_comod* com_first, *com_last;

    struct netmetre* nm;

    struct nm_session* next;

};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_sess_create(struct netmetre* nm, char* name);
    error13_t nm_sess_destroy(struct netmetre* nm, char* name);

    error13_t nm_sess_get(struct netmetre* nm, char* name, struct nm_session** sess);
    error13_t nm_sess_free(struct netmetre* nm, struct nm_session* sess);

#ifdef __cplusplus
    }
#endif

#endif // NM_SESS_H
