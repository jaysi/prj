﻿#include "netmetre.h"
#include "../lib13/include/lib13.h"

#include <stdlib.h>

error13_t nm_init(struct netmetre* nm){

    error13_t ret;

#ifndef NM_MX_NDEBUG
    th13_mutexattr_t mxattr;
#endif

    if((ret = e13_init(&nm->e, NM_DEF_MAX_WARN, NM_DEF_MAX_ESTR, LIB13_NETMETRE)) != E13_OK){
        return ret;
    }

#ifndef NM_MX_NDEBUG
    th13_mutexattr_init(&mxattr);
    pthread_mutexattr_setkind_np(&mxattr, PTHREAD_MUTEX_ERRORCHECK_NP);
#endif

    if(!th13_mutex_init(&nm->sess_mx,
#ifndef NM_MX_NDEBUG
                    &mxattr
#else
                    NULL
#endif
                    )){

#ifndef NM_MX_NDEBUG
    th13_mutexattr_destroy(&mxattr);
#endif
        e13_destroy(&nm->e);
        return e13_ierror(&nm->e, E13_SYSE, "s", "mutex init");

    }

#ifndef NM_MX_NDEBUG
    th13_mutexattr_destroy(&mxattr);
#endif

    nm->nsess = 0UL;
    nm->sess_first = NULL;
    nm->basedb = NULL;
    nm->ctldb = NULL;

    return E13_OK;

}

error13_t nm_destroy(struct netmetre *nm){

    struct nm_session* sess;

    //1. send sessions EXIT message

    for(sess = nm->sess_first; sess; sess = sess->next){

    }

    //2. wait until all sessions exit

}
