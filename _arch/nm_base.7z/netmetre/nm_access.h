#ifndef NM_ACCESS_H
#define NM_ACCESS_H

#include "../lib13/include/lib13.h"
#include "nm_user.h"

struct nm_session;

typedef uint8_t nm_acl_t;

struct nm_acl_entry{
    nm_acl_t type;
    nm_gid_t gid;
    nm_uid_t uid;
    struct nm_acl_entry* next;
};

struct nm_login_entry{
    nm_uid_t uid;
};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_login_user(struct nm_session* sess, char* username, char* password);
    error13_t nm_logout_user(struct nm_session* sess, char* username);

#ifdef __cplusplus
    }
#endif


#endif // NM_ACCESS_H
