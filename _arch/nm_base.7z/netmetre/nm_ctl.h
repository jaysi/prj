#ifndef NM_CTL_H
#define NM_CTL_H

#include "nm_access.h"
#include "nm_user.h"

#endif // NM_CTL_H
