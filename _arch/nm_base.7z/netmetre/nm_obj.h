#ifndef NM_OBJ_H
#define NM_OBJ_H

#include "../lib13/include/lib13.h"

struct nm_session;

typedef objid13_t nm_objid_t;
typedef uint32_t nm_refcount_t;

#define NM_OBJID_EMPTY    OBJID13_ZERO
#define NM_OBJID_INVAL    OBJID13_INVAL
#define NM_OBJID_MAX      OBJID13_MAX

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_obj_alloc(struct nm_session* sess, );

#ifdef __cplusplus
    }
#endif


#endif // NM_OBJ_H
