﻿#ifndef NM13_H
#define NM13_H

#include <sys/types.h>

#include "../lib13/include/lib13.h"
#include "nm_db.h"
#include "nm_project.h"
#include "nm_ctl.h"
#include "nm_sess.h"
#include "nm_mod.h"

#define NM_DEF_MAX_WARN    10
#define NM_DEF_MAX_ESTR    256

struct netmetre{
    th13_mutex_t mx;
    uint32_t nsess;
    struct nm_session* sess_first, *sess_last;
    struct nm_db* basedb;
    struct nm_db* ctldb;
    struct e13 e;
    struct nm_mod* mod_first, *mod_last;
};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_init(struct netmetre* nm);
    error13_t nm_destroy(struct netmetre* nm);

#ifdef __cplusplus
    }
#endif

#endif
