﻿#ifndef NM_DB_H
#define NM_DB_H

#include "../lib13/include/lib13.h"
#include "../sqlite/sqlite3.h"
#include "nm_table.h"

struct nm_session;

//WPT: WORK PRICE TABLE

#define NM_USE_SQLITE3

#define NM_DB_BASE          "base"
#define NM_DB_CTL           "ctl"
#define NM_DB_PRJ           "prj"

#define NM_DB_DEF_DRIVER   NM_DB_DRV_SQLITE
#ifdef WIN32
#define NM_DB_DEF_HOSTNAME "localhost"
#else
#define NM_DB_DEF_HOSTNAME "localhost.localdomain"
#endif
#define NM_DB_DEF_PORT     "65500"
#define NM_DB_DEF_NAME     NM_DB_BASE
#define NM_DB_DEF_USERNAME ""
#define NM_DB_DEF_PASSWORD ""

//base db
#define NM_DB_TABLE_WPT_  "wpt_def"

//base
#define NM_DB_TABLE_WPT               "wpt"

//project db tables, followed by a pid
#define NM_DB_TABLE_ATTACHMENTS       "attachments_"
#define NM_DB_TABLE_POSITIONS         "positions_"
#define NM_DB_TABLE_INVOICES          "invoices_"
#define NM_DB_TABLE_INVOICE_VERSIONS  "invoice_versions_"
#define NM_DB_TABLE_METRE_PRIFIX      "metre_"    /*followed by pid and */
#define NM_DB_TABLE_METRE_INFIX       "_"         /*followed by invoice number*/

//control db
#define NM_DB_TABLE_GROUP             "group"
#define NM_DB_TABLE_USER              "user"
#define NM_DB_TABLE_MEMBERSHIP        "membership"
#define NM_DB_TABLE_ACL               "acl"
#define NM_DB_TABLE_PRJLIST           "prjlist"
#define NM_DB_TABLE_FREEOBJ           "freeobj"

//CONTROL COLUMNS

//copyinfo
//program_copy_id, owner_name, owner_guid

//group
//id, name, stat

//user
//id, name, passhash(SHA512), last_login(YYYY-MM-DD-hh-mm-ss in shamsi), stat

//membership
//gid, uid

//acl
//gid, uid, objid, perm

//prjlist
//prj_objid, owner_uid, name, desc

//freeobj - free'ed object ids
//objid

//BASE TABLES

//copyinfo
//program_copy_id, owner_name, owner_guid

//wptclass
//objid, name

//wptbranch
//objid, name

//wpt
//objid, name, year, class_objid, branch_objid, type(basic, custom, ...)

//session - session definition
//objid, name, wpt_objid

//unit - unit definition
//objid, name

//type - type definition
//objid, name(main | surcharge_from_main_list | surcharge_from_preface), desc

//item
//objid, wpt_number, desc, unit_objid, wpt_objid, session_objid, type_objid, help

//relation
//objid, item_objid(A), item_objid(B), formula(A,B), desc

//sql query
#define NM_DB_CREATE_TABLE_PRE  "CREATE TABLE IF NOT EXIST "

#define NM_DB_STAT_ACTIVE     "active"
#define NM_DB_STAT_INACTIVE   "inactive"
#define NM_DB_STAT_ARCHIVE    "archive"
#define NM_DB_STAT_REMOVED    "removed"

#define SQLITE(dbms)   ((sqlite3*)dbms)

enum nm_db_drv_id{
    NM_DB_DRV_NULL,
    NM_DB_DRV_SQLITE,
    NM_DB_DRV_INVAL
};

struct nm_db_driver{

    char* name;
    char* ext;//extension

} nm_db_drv[] = {
{"null", ""},
{"sqlite", ".l83"},
{NULL, NULL}
};

#define NM_DB_FLAG_OPEN (0x01<<0)
#define NB_DB_DEF_FLAGS 0x00

struct nm_db{

    magic13_t magic;
    uint8_t flags;

    enum driver;
    char* host;
    char* port;
    char* username;
    char* password;

    char* name;

    void* dbms;

    struct e13 e;

    struct nm_db* next;

};

#ifdef __cplusplus
    extern "C" {
#endif

#define nm_db_isinit(db) ((db)->magic == MAGIC13_NMDB?true_:false_)

error13_t nm_db_init(struct nm_db* db,
                     enum nm_db_drv_id driver);
error13_t nm_db_open(struct nm_db* db,
                     char* host,
                     char* port,
                     char* username,
                     char* password,
                     char *name);
error13_t nm_db_close(struct nm_db* db);

#ifdef __cplusplus
    }
#endif


#endif // NM_DB_H
