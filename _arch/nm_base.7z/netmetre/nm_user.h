#ifndef NM_USER_H
#define NM_USER_H

#include "../lib13/include/lib13.h"

struct nm_session;

typedef uint32_t nm_uid_t;
typedef uint32_t nm_gid_t;

#define NM_USER_SYSTEM  "system"
#define NM_USER_MANAGER "manager"
#define NM_USER_DEBUG   "debug"
#define NM_USER_THIS    "this"

#define NM_UID_NONE 0x0000
#define NM_GID_NONE 0x0000
#define NM_UID_ANY  0xffff
#define NM_GID_ANY  0xffff

struct nm_group{

    char* name;
    nm_gid_t gid;

    struct nm_group* next;

};

struct nm_user{

    char* name;
    nm_uid_t uid;

    time_t login_time;

    struct nm_user* next;

};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_group_add(struct nm_session* sess, char* name);
    error13_t nm_group_rm(struct nm_session* sess, char* name);

    error13_t nm_user_add(struct nm_session* sess, char* name, char* password, char* group);
    error13_t nm_user_rm(struct nm_session* sess, char* name);

    error13_t nm_user_join_group(struct nm_session* sess, char* username, char* group);
    error13_t nm_user_leave_group(struct nm_session* sess, char* username, char* group);
    error13_t nm_user_group_check(struct nm_session* sess, char* username, char* group);

#ifdef __cplusplus
    }
#endif


#endif // NM_USER_H
