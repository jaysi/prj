#ifndef NM_QUEUE_H
#define NM_QUEUE_H

#include "nm_project.h"

struct nm_q{
    nm_pid_t pid;
    struct nm_q* next;
};

#endif // NM_QUEUE_H
