﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QListWidgetItem>
#include <QPushButton>

enum wglevel {
    LE_START,
    LE_HOME,
    LE_GROUPS,
    LE_PLACES,
    LE_INFO,
    LE_SEARCH,
    LE_SEARCH_RESULTS,
    LE_EXIT,
    LE_INVAL
};

struct wgstat {
    enum wglevel le;
    QString str_cur_group;
    QString str_cur_place;
    int nsearch_subs;
    int stack_index;
};

#define MSG_CRITICAL_SYS    "ایراد اساسی سیستم"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_listGroups_itemClicked(QListWidgetItem *item);

    void on_listPlaces_itemClicked(QListWidgetItem *item);

    void on_listSearch_itemClicked(QListWidgetItem *item);

    void on_pushSearch_clicked();

    void on_finish_stack_anim();

    void on_toolMenu_clicked();

private:
    Ui::MainWindow *ui;

    struct wgstat st;
    QPushButton* pushSearch;

    //functions
    bool init_look();
    void show_msg(QString msg, int modal, int fade);
    void slide_stacked_widget(int in, int out);

    void set_level(enum wglevel);
    enum wglevel get_level() {return st.le;}
};

#endif // MAINWINDOW_H
