﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QPushButton>
#include <QMessageBox>
#include <QDebug>
#include <QPropertyAnimation>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

#ifdef ANDROID
    showMaximized();
#endif

    if(!init_look()){
        show_msg(tr(MSG_CRITICAL_SYS), 1, 0);
        set_level(LE_EXIT);
    }

    set_level(LE_HOME);

}

MainWindow::~MainWindow()
{
    set_level(LE_EXIT);
    delete ui;
}

void MainWindow::show_msg(QString msg, int modal, int fade){
#ifndef ANDROID
    QMessageBox::information(0, tr(""), msg);
#else
#endif
}

bool MainWindow::init_look(){

//    QRect rect_place_list;
    QRect rect;

    pushSearch = new QPushButton(ui->listPlaces);
    pushSearch->setAttribute(Qt::WA_TranslucentBackground);
    pushSearch->setFlat(true);
    pushSearch->setIcon(QIcon(":/res/search-64.png"));
    rect = pushSearch->geometry();
    qDebug()<<tr("B:%1 T:%2 h:%3 w: %4").arg(rect.bottom()).arg(rect.top()).arg(rect.height()).arg(rect.width());
    rect.setBottom(ui->listPlaces->geometry().height());
    qDebug()<<tr("B:%1 T:%2 h:%3 w: %4").arg(rect.bottom()).arg(rect.top()).arg(rect.height()).arg(rect.width());

    pushSearch->setGeometry(rect);
    connect(pushSearch, SIGNAL(clicked()), this, SLOT(on_pushSearch_clicked()));

    return true;

}

void MainWindow::slide_stacked_widget(int in, int out){


    //widget_in: the widget that is in and wants to go out

    qDebug()<<tr("in: %1, out: %2").arg(in).arg(out);

    QWidget* widget_in = ui->stackMain->widget(in),
            *widget_out = ui->stackMain->widget(out);
    QRect rectin = widget_in->geometry();
    QRect rectout = widget_out->geometry();

    QPropertyAnimation *anim_out= new QPropertyAnimation(widget_in, "geometry");
    anim_out->setStartValue(rectin);
    anim_out->setEndValue(QRect(rectin.x(), rectin.y(), 0, rectin.height()));
    anim_out->setEasingCurve(QEasingCurve::OutInSine);
    anim_out->setDuration(500);
    anim_out->start(QAbstractAnimation::DeleteWhenStopped);
    widget_in->hide();

    widget_out->show();    
    QPropertyAnimation *anim_in= new QPropertyAnimation(widget_out, "geometry");
    anim_in->setStartValue(QRect(rectin.x(), rectin.y(), 0, rectin.height()));
    anim_in->setEndValue(rectin);
    anim_in->setEasingCurve(QEasingCurve::InOutSine);
    anim_in->setDuration(500);
    anim_in->start(QAbstractAnimation::DeleteWhenStopped);

    connect(anim_in, SIGNAL(finished()), this, SLOT(on_finish_stack_anim()));

}

void MainWindow::set_level(enum wglevel le){

    switch(le){

    case LE_START:
        break;

    case LE_HOME:
        ui->stackMain->setCurrentIndex(0);
        break;
    case LE_GROUPS:
        st.stack_index = 0;
        slide_stacked_widget(ui->stackMain->currentIndex(), 0);
        break;

    case LE_PLACES:
    case LE_SEARCH_RESULTS:
        st.stack_index = 1;
        slide_stacked_widget(ui->stackMain->currentIndex(), 1);
        break;

    case LE_SEARCH:
        st.stack_index = 3;
        slide_stacked_widget(ui->stackMain->currentIndex(), 3);
        break;

    case LE_INFO:
        st.stack_index = 2;
        slide_stacked_widget(ui->stackMain->currentIndex(), 2);
        break;

    case LE_EXIT:
        st.stack_index = -1;
        break;

        default:
        break;

    }

    st.le = le;

}

void MainWindow::on_listGroups_itemClicked(QListWidgetItem *item)
{
    //TODO: fill place list
    set_level(LE_PLACES);
}

void MainWindow::on_listPlaces_itemClicked(QListWidgetItem *item)
{
    //TODO: fill place info
    set_level(LE_INFO);
}

void MainWindow::on_listSearch_itemClicked(QListWidgetItem *item)
{

}

void MainWindow::on_pushSearch_clicked(){
    set_level(LE_SEARCH);
}

void MainWindow::on_finish_stack_anim(){
    if(st.stack_index < 0) return;
    ui->stackMain->setCurrentIndex(st.stack_index);
}

void MainWindow::on_toolMenu_clicked()
{
    set_level(LE_GROUPS);
}
