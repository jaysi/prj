﻿#include "initdialog.h"
#include "ui_initdialog.h"

InitDialog::InitDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::InitDialog)
{
    ui->setupUi(this);

#ifdef ANDROID
    showMaximized();
#endif

}

InitDialog::~InitDialog()
{
    delete ui;
}
