﻿#include "mainwindow.h"
#include "initdialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    InitDialog ini;

    ini.show();
    //check db
    //copy db check failed
    //decrypt db as a temporary file
    ini.hide();

    w.show();

    return a.exec();
}
