#ifndef _JCONST_H
#define _JCONST_H

#define J_MAX_USERNAME8	128
#define	J_MAX_PASSWORD8	128
#define J_MAX_PATHNAME8	512
#define J_MAX_FILENAME8	256

#endif
