#ifdef __cplusplus
extern "C" {
#endif

void *memmem (	const void *haystack, size_t haystack_len,
		const void *needle, size_t needle_len);

#ifdef __cplusplus
}
#endif
