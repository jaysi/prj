#include "debug.h"

#define _wdeb_start	_wdeb
#define _wdeb_pos	_wdeb
#define _wdeb_proc	_wdeb
#define _wdeb_reg	_wdeb
#define _wdeb_io	_wdeb

#define _wdeb_table_def(f, a...)
#define _wdeb_table(f, a...)
#define _wdeb_load	_wdeb
#define _wdeb_data_ptr	_wdeb
#define _wdeb_wr	_wdeb

#define _wdeb_data_ptr	_wdeb
#define _wdeb_add	_wdeb
#define _wdeb_find	_wdeb
#define _wdeb_crc(f, a...)
#define _wdeb_free(f, a...)

#define _wdeb_startup _wdeb

#define _wdeb_calc	_wdeb

#define _wdeb_map(f, a...)
#define _wdeb_upack _wdeb

#define _wdeb_alloc	_wdeb

#define _wdeb_type	_wdeb
#define _wdeb_ch	_wdeb

#define _wdeb_map(f, a...)
#define _wdeb_nful _wdeb
#define _wdeb_list_map(f, a...)
#define _wdeb_find	_wdeb
#define _wdeb_inc 	_wdeb
#define _wdeb_tm 	_wdeb
#define _wdeb_rm 	_wdeb


#define _wdeb_crc _wdeb
#define _wdeb_data _wdeb


#define _wdeb_type _wdeb
#define _wdeb_load _wdeb
#define _wdeb_data_ptr _wdeb
#define _wdeb_add _wdeb
#define _wdeb_find _wdeb


#define _wdeb_start(f, a...)
#define _wdeb_end(f, a...)
#define _wdeb_wr(f, a...)
