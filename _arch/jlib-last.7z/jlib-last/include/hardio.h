#ifndef HARDIO_H
#define HARDIO_H

int hard_read(int fd, char *buf, int count);
int hard_write(int fd, char *buf, int count);

#endif
