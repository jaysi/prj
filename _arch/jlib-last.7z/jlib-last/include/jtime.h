#ifndef _JTIME_H
#define _JTIME_H

#ifdef _WIN32
#define BASE_YEAR	1970
#else
#define BASE_YEAR	1900
#endif

#else

#endif
