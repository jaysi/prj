#ifndef __J2D_H
#define __J2D_H

#define J2D_ALLOC_ALL_FIX(array, nrows, ptr_size, col_size)
#define J2D_ALLOC_ALL_VAR(array, nrows, col_size_list)
#define J2D_ASSIGN_ALL_VAR(array, nrows, col_val_list...) va_
#define J2D_FREE(array)
#define J2D_ASSIGN_

#else
#endif
