
/*
uint32_t jn_pkt_gen(uchar ** buf, uint32_t hlt, uint32_t nhlt)
{

 
}
*/


