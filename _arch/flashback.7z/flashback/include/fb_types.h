﻿#ifndef FB_TYPES_H
#define FB_TYPES_H

#include "../../lib13/include/type13.h"
#include "../../lib13/include/obj13.h"
#include "../../lib13/include/bit13.h"
#include "../../lib13/include/hash13.h"

/*
 * objects accessible from outside must have an id field equivalent to objid,
 * examples are tables, rows, ... others don't need to, like blocks;
*/

typedef uint8_t fb_dbhdrflag_t;
typedef uint8_t fb_dbhandleflag_t;
typedef uint8_t fb_handleflag_t;
typedef uint8_t fb_lock_t;
typedef uint8_t fb_blk_t;
typedef uint16_t fb_bent_t;
typedef uint8_t fb_data_t;
typedef objid13_t fb_tid_t;
typedef uint32_t fb_bid_t;
typedef uint16_t fb_bsize_t;//max 64k blocks
typedef uint8_t fb_blkflag_t;
typedef uint8_t fb_memblkflag_t;

#endif // FB_TYPES_H
