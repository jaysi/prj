﻿#ifndef FLASHBACK_H
#define FLASHBACK_H

#include "fb_intern.h"

//db stat flags
#define FB_DBSTAT_EXIST     (0x01<<0)
#define FB_DBSTAT_READ      (0x01<<1)
#define FB_DBSTAT_WRITE     (0x01<<2)
#define FB_DBSTAT_STRUCT    (0x01<<3)//check structure, must have read perm

enum fb_data_type{
    FB_DATATYPE_EMPTY,
    FB_DATATYPE_RAW
};

#define FB_DATA_T(data_type_enum)   ((fb_data_t)(data_type_enum))

struct fb_conf{
    msegid13_t map_pool_buck;
};

#define FB_HANDLEF_WRHDR    (0x01<<0)//write header

struct flashback{
    fb_handleflag_t flags;
    struct lock13 lock;
    struct e13 e;
    struct m13_mempool map;
    struct fb_blockbuf blockbuf;
    struct fb_db_hdr hdr;
    struct fb_conf conf;
};

#ifdef __cplusplus
    extern "C" {
#endif

error13_t fb_init(struct flashback* h);    /*inits fb handle*/

error13_t fb_connect(   struct flashback* h,
                        char* db,
                        struct db13_db_conf* conf); /*connects to a db*/

error13_t fb_disconnect(struct flashback* h,
                        char* db);      /*disconnects from db*/

error13_t fb_open(  struct flashback* h,
                    char* db,
                    char* alias,
                    db13_openflag_t flags); /*opens a db handle*/

error13_t fb_close( struct flashback* h,
                    char* alias,
                    db13_openflag_t flags);/*closes a db handle*/

error13_t fb_destroy(struct flashback* h);

//tables
error13_t fb_open_table(struct flashback* h,
                        char* alias,
                        char* table,
                        objid13_t ncols,
                        struct db13_col* col,
                        db13_tableflag_t flags);

error13_t fb_trunc_table(	struct flashback* h,
                            char* alias,
                            char* table);

error13_t fb_delete_table(  struct flashback* h,
                            char* alias,
                            char* table);

char** fb_list_tables(  struct flashback* h,
                        char* alias);

//row
error13_t fb_insert_row(	struct flashback* h,
                            char* db,
                            char* table,
                            struct db13_row* row);

error13_t fb_delete_row(	struct flashback* h,
                            char* alias,
                            char* table,
                            struct db13_filter* filter);

error13_t fb_update_row(	struct flashback* h,
                            char* alias,
                            char* table,
                            struct db13_row* row,
                            struct db13_filter* filter);

//columns
error13_t fb_insert_col(	struct flashback* h,
                            char* alias, char* table,
                            char pos, /*see COLPOS*/
                            char* name, /*the position related column*/
                            objid13_t ncols,
                            struct db13_col* col);

error13_t fb_delete_col(	struct flashback* h,
                            char* alias,
                            char* table,
                            objid13_t ncols,
                            struct db13_col* col);

error13_t fb_update_col(	struct flashback* h,
                            char* alias,
                            char* table,
                            struct db13_col* old_col,
                            struct db13_col* new_col);

//select
error13_t fb_select(struct flashback* h,
                    char* alias,
                    char* table,
                    objid13_t ncols,
                    struct db13_col* col,
                    struct db13_filter* filter,
                    struct db13_rowset* rowset,
                    db13_fetchflag_t flags);

struct db13_row* fb_fetch_row(  struct flashback* h,
                                struct db13_rowset* rowset,
                                db13_fetchflag_t flags);

struct db13_field* fb_fetch_field(  struct flashback* h,
                                    struct db13_row* row,
                                    char* colname,
                                    db13_fetchflag_t flags);

//pro
error13_t fb_trans(struct flashback* h, char* alias);//starts transaction
error13_t fb_commit(struct flashback* h, char* alias);
error13_t fb_rollback(struct flashback* h, char* alias);

//error
error13_t fb_get_last_error(struct flashback* h);


#ifdef __cplusplus
    }
#endif


#endif // FLASHBACK_H
