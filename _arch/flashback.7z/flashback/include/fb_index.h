﻿#ifndef FB_INDEX_H
#define FB_INDEX_H

#ifndef _FB_INDEX_H
#define _FB_INDEX_H

#include "fb_intern.h"
#include "fb_block.h"

/*				indexes					*/

/*
 *  indexes are:
 *  global-unique       hash256->objid
 *  global-non-unique   hash128->objid
 *  local-unique        hash64->objid
 *  local-non-unique    hash32->objid
*/

//index types, set as map_entry's dtype field, length same as fb_data_t
#define FB_ITYPE1	0x01
#define FB_ITYPE2	0x02
#define FB_ITYPE3	0x03

#define FB_ITYPE_TNAME_TID  FB_ITYPE1

/*
    index type 0 (GLOBAL-UNIQUE), hash -> id
    Usage:
        TableNameHash -> TableID	TID_INX
        Allows table renaming.
*/

//for all types of indexes
typedef struct fb_blk_type1_hdr fb_index1_blk_hdr;

struct fb_index1_blk_entry{
    h13_hash256_t hash;
    objid13_t objid;//OBJID_INVAL for invalid/empty entries
}__attribute__((packed));

struct fb_index1_blk{
    struct fb_blockbuf_hdr blockbuf;
    int write;
    fb_bid_t bid;
    struct fb_index1_blk_hdr* hdr;
    struct fb_index1_blk_entry* entry;
    struct fb_index1_blk* next;
};

struct fb_index1_blk_list{
    uint32_t cnt;
    struct fb_index1_blk* first;
    struct fb_index1_blk* last;
};

/*
    index type 1 (LOCAL-UNIQUE), hash -> row, col
    Usage:
        FullDataHash -> Row, Column

        Allows fast data search
        limitations are support for exact data match only
*/

struct fb_index1_blk_entry {
    uint64_t hash64;
    uint32_t row;
    uint32_t col;
}__attribute__((packed));

struct fb_index1 {
    void* blockbuf;
    uint32_t write;

    struct fb_table *table;
    struct fb_index_blk_hdr* hdr;
    struct fb_index1_blk_entry *entry;
    struct fb_index1 *next;
};

struct fb_index1_list {
    fb_bid_t cnt;
    struct fb_index1 *first;
    struct fb_index1 *last;
};

/*
    index type 2 (LOCAL-NON_UNIQUE), hash -> row, col
    Usage:
        DataHash -> Row, Column

        Allows fast data search even for parts of data in a cell
        May return multiple results, Same record may not exist in
        a table, thus insertion is SLOW due to needed searches
*/

struct fb_index2_blk_entry {
    uint32_t hash32;
    uint32_t row;
    uint32_t col;
}__attribute__((packed));

struct fb_index2 {
    void* blockbuf;
    uint32_t write;

    struct fb_table *table;
    struct fb_index_blk_hdr* hdr;
    struct fb_index2_blk_entry *entry;
    struct fb_index2 *next;
};

struct fb_index2_list {
    fb_bid_t cnt;
    struct fb_index2 *first;
    struct fb_index2 *last;
};

#else

#endif


#endif // FB_INDEX_H
