﻿#ifndef FB_LOCK_H
#define FB_LOCK_H

#include "fb_types.h"
#include "../../lib13/include/lock13.h"

enum fb_lock_bit{
    FB_LK_HANDLE,
    FB_LK_HDR,
    FB_LK_MAP,
    FB_LK_DBLIST
};

#define FB_LOCK_SIZE    (FB_LK_DBLIST+1)

#define _fb_lock_init(h)    lock13_init(&((h)->lock), FB_LOCK_SIZE)

#define _fb_lock_handle(h)    lock13_bitlock(&((h)->lock), FB_LK_HANDLE)
#define _fb_unlock_handle(h)  lock13_bitunlock(&((h)->lock), FB_LK_HANDLE)

#define _fb_lock_hdr(h)    lock13_bitlock(&((h)->lock), FB_LK_HDR)
#define _fb_unlock_hdr(h)  lock13_bitunlock(&((h)->lock), FB_LK_HDR)

#define _fb_lock_map(h)     lock13_bitlock(&((h)->lock), FB_LK_MAP)
#define _fb_unlock_map(h)   lock13_bitunlock(&((h)->lock), FB_LK_MAP)

#define _fb_lock_db(h, dbname, type)    MACRO( lock13_bitlock(&((h)->lock), FB_LK_DBLIST); /*find db's objid, lock it too!*/ lock13_bitunlock(&((h)->lock), FB_LK_DBLIST);)
#define _fb_unlock_db(h, dbname, type)  MACRO( lock13_bitlock(&((h)->lock), FB_LK_DBLIST); /*find db's objid, lock it too!*/ lock13_bitunlock(&((h)->lock), FB_LK_DBLIST);)

#define _fb_lock_alias(h, aliasname, type) MACRO( lock13_bitlock(&((h)->lock), FB_LK_DBLIST); /*find db's objid, lock it too!*/ lock13_bitunlock(&((h)->lock), FB_LK_DBLIST);)
#define _fb_unlock_alias(h, aliasname, type) MACRO( lock13_bitlock(&((h)->lock), FB_LK_DBLIST); /*find db's objid, lock it too!*/ lock13_bitunlock(&((h)->lock), FB_LK_DBLIST);)

#endif // FB_LOCK_H
