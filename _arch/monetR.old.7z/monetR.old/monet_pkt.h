﻿#ifndef MONET_PKT_H
#define MONET_PKT_H

#include "../lib13/include/lib13.h"
#include "monet_user.h"
#include "monet_sess.h"
#include "../infolink/include/ilink_intern.h"

#define MN_PKT_DC   (ILINK_PKT_TYPE_RESERVED + 1)//dc request
//?#define MN_PKT_MOD  (ILINK_PKT_TYPE_RESERVED + 2)//module request
#define MN_PKT_UNPOLL (ILINK_PKT_TYPE_RESERVED + 3)//unpoll, pipe required
#define MN_PKT_POLL (ILINK_PKT_TYPE_RESERVED + 4)//poll, pipe required
#define MN_PKT_SESS_START   (ILINK_PKT_TYPE_RESERVED + 5)//start
#define MN_PKT_SESS_PAUSE   (ILINK_PKT_TYPE_RESERVED + 6)//pause, use start to resume
#define MN_PKT_SESS_END   (ILINK_PKT_TYPE_RESERVED + 7)//end
#define MN_PKT_SESS_JOIN   (ILINK_PKT_TYPE_RESERVED + 8)//end
#define MN_PKT_SESS_DEBUG   (ILINK_PKT_TYPE_RESERVED + 9)//end
#define MN_PKT_SESS_LIST   (ILINK_PKT_TYPE_RESERVED + 10)//end
#define MN_PKT_SESS_TRANS_START   (ILINK_PKT_TYPE_RESERVED + 11)//trans start
#define MN_PKT_SESS_TRANS_ACK   (ILINK_PKT_TYPE_RESERVED + 12)//trans
#define MN_PKT_SESS_TRANS_END   (ILINK_PKT_TYPE_RESERVED + 13)//trans

//payload structs
struct mn_pl_sess_start {
    mn_sessflag_t flags;
    uint32_t nuser;
    char* name;
    char** userlist;
};

#define _mn_pack_pl_sess_start(s, fl, nu, name, uli)

#endif // MONET_PKT_H
