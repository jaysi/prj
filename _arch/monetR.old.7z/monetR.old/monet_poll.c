﻿#include "monet_internal.h"

#define _deb1   _DebugMsg
#define _deb2   _DebugMsg
#define _deb3   _DebugMsg

//TODO: REPLACE UID WITH I IN THIS PIECE OF CODE FOR PERFORMANCE

enum _monet_proc_pkt_code {
    MN_PROC_PKT_EMPTY,    
    MN_PROC_PKT_DC,//disconnect request
    MN_PROC_PKT_UNPOLL,
    MN_PROC_PKT_NOPERM,//the user is not permitted to request this op
    MN_PROC_PKT_POLL,//add poll link
    MN_PROC_PKT_TEST,
    MN_PROC_PKT_INVAL
};

struct _mn_poll_add_s{
    struct infolink* link;
    ilink_poll_flag_t flags;
};

error13_t _monet_proc_pkt(struct monet* mn,
                          struct infolink* ilink,
                          enum _monet_proc_pkt_code* proc_code){

    ilink_data_t* data = NULL;
    ilink_datalen_t datalen;
    ilink_pkt_type_t type;
    error13_t ret;    
    //TODO: TEMPORARY, REMOVE LATER
    uid13_t uid[mn->user_array.nalloc];
    uid13_t i = 0, j;

    _deb3("called for sock %i.", ilink->sock);

    if((ret = ilink_explode_pkt(ilink, &data, &datalen, &type, 0)) != E13_OK){
        _deb3("%s", e13_codemsg(ret));
        return ret;
    }

    _deb3("hdr.type = %u, data = %s, datalen = %u", type, data, datalen);

    switch(type){

    case MN_PKT_DC:
        _deb3("dc");
        *proc_code = MN_PROC_PKT_DC;
        break;

    case MN_PKT_UNPOLL:
        _deb3("unpoll");
        *proc_code = MN_PROC_PKT_UNPOLL;
        ret = E13_CONTINUE;//continue processing the packet
        break;

    case MN_PKT_POLL:
        _deb3("poll");
        *proc_code = MN_PROC_PKT_POLL;
        ret = E13_CONTINUE;//add poll link
        break;

    case ILINK_PKT_TYPE_TEST:
        *proc_code = MN_PROC_PKT_TEST;
        //TODO: TEMPORARY, REMOVE LATER
        for(j = 0; j < mn->user_array.nalloc; j++){
            if(mn->user_array.array[j].user){
                uid[i++] = mn->user_array.array[j].user->id;
            }
        }
        //already locked
        _monet_request_send(mn, i, uid, data, datalen, type, 0, 1);
        _deb3("test data: %s", data);
        break;

    case MN_PKT_SESS_START:
        if(_monet_check_perm(mn, (((struct monet_user*)ilink->ext_ctx)->id), GID13_NONE, MN_PKT_SESS_START, data, datalen) != E13_OK){
            //TODO: send error _monet_request_send(mn, i, (((struct monet_user*)ilink->ext_ctx)->id), NULL, 0, MN_PKT_TYPE_ERROR)
        }

        break;

    default:
        ret = e13_error(E13_IMPLEMENT);
        _deb3("not implemented type %u", type);
        break;

    }

    //ilink_reset(link, ILINK_FLAG_RECV);

    if(e13_iserror(ret) && data) m13_free(data);

    return ret;

}

void* _monet_poll_thread(void* arg){

    struct _monet_poll_thread_arg* args = arg;
    struct infolink** ready, *entry, *tmplink;
    struct monet* mn = args->mn;
    struct monet_poll* pol = &(mn->poll);
    struct ilink_poll_list* list = &(pol->polist);
    uint32_t npolled, i;
    struct ilink_ctl_s ctl_nonblock, ctl_block;
    enum _monet_proc_pkt_code proc_code;
    error13_t ret;
    struct _mn_poll_add_s* s;

    ctl_nonblock.blocking = ILINK_MODE_NONBLOCK;
    ctl_block.blocking = ILINK_MODE_BLOCK;

    _deb1("index = %u, list->n = %u", args->index, list->n);    

    while(1) {

        list->tv.tv_sec = 0;
        list->tv.tv_usec = 0;

        _deb1("polling... rd_count = %i", list->readfds.fd_count);

        switch( (ret = ilink_poll(list, &npolled, &ready)) ) {

        case E13_OK://do something

            _deb1("OK, npolled = %u", npolled);

            for(i = 0; i < npolled; i++) {

                entry = *ready + i;

                _deb1("entry->sock = %i", entry->sock);

                if(entry->pollflags & ILINK_POLL_RD_READY){

                    ilink_ctl(entry, &ctl_nonblock, ILINK_CTL_BLOCK_MODE);

                    _deb1("rd_count = %i", list->readfds.fd_count);

                    switch( (ret = ilink_recv(entry, NULL, 0, NULL)) ){
                        case E13_OK:
                        _deb1("polling... rd_count = %i", list->readfds.fd_count);
                        _deb1("got OK, WHAT?");
                        break;
                        case E13_DONE://packet fully recieved
                        _deb1("DONE, process packet");
                        _deb1("rd_count = %i", list->readfds.fd_count);
                        switch((ret=_monet_proc_pkt(args->mn, entry, &proc_code)
                                )){
                            case E13_CONTINUE:
                                _deb1("rd_count = %i", list->readfds.fd_count);
                                //poll already locked, just add to list
                                if(proc_code == MN_PROC_PKT_POLL){                                    
                                    s = mn->pipelink_send.tmp_ctx;
                                    _deb1("POLL %i", s->link->sock);
                                    for(tmplink = s->link;
                                        tmplink;
                                        tmplink = tmplink->popnext) {

                                        ilink_poll_add(list,
                                                       tmplink,
                                                       s->flags);

                                    }

                                    m13_free(s);
                                }
                                if(proc_code == MN_PROC_PKT_UNPOLL){                                    
                                    s = mn->pipelink_send.tmp_ctx;
                                    _deb1("UNPOLL %i", s->link->sock);

                                    for(tmplink = s->link;
                                        tmplink;
                                        tmplink = tmplink->popnext) {

                                        ilink_poll_rm(list,
                                                      tmplink,
                                                      s->flags);

                                    }

                                    m13_free(s);
                                }
                                _deb1("rd_count = %i", list->readfds.fd_count);
                                _deb1("continue");
                                break;

                            case E13_OK:
                                _deb1("rd_count = %i", list->readfds.fd_count);
                                _deb1("ok");
                                break;

                            default:
                                _deb1("rd_count = %i", list->readfds.fd_count);
                                _deb1("other case _monet_proc_pkt = %i", ret);
                                break;
                            }
                        break;
                        case E13_CONTINUE:
                        _deb1("interrupted");
                        break;
                        case e13_error(E13_DC):
                        _deb1("disconnected %i", entry->sock);
                            ilink_poll_rm(list, entry, ILINK_POLL_ALL|ILINK_POLL_NOLOCK);
                        break;
                        default:
                        _deb1("other case! ilink_recv = %i", ret);
                        break;
                    }

                    ilink_ctl(entry, &ctl_block, ILINK_CTL_BLOCK_MODE);

                    entry->pollflags &= ~ILINK_POLL_RD_READY;

                }//ILINK_POLL_RD_READY

                if(entry->pollflags & ILINK_POLL_WR_READY){

                    _deb1("write got!");

                    ilink_ctl(entry, &ctl_nonblock, ILINK_CTL_BLOCK_MODE);

                    //send
                    switch(ret = ilink_send(entry, NULL, NULL, NULL)){
                        case E13_CONTINUE:
                        case E13_NEXT://there is packets inside
                        case E13_OK:
                        //continue polling
                        break;

                        case E13_DONE:
                            ilink_poll_rm(list, entry, ILINK_POLL_WR|ILINK_POLL_NOLOCK);
                        break;

                        case e13_error(E13_DC):
                            ilink_poll_rm(list, entry, ILINK_POLL_ALL|ILINK_POLL_NOLOCK);
                        break;

                        default:
                        break;


                    }

                    ilink_ctl(entry, &ctl_block, ILINK_CTL_BLOCK_MODE);


                    entry->pollflags &= ~ILINK_POLL_WR_READY;

                }//ILINK_POLL_WR_READY

                if(entry->pollflags & ILINK_POLL_EX_READY){

                    _deb1("exception got!");

                    entry->pollflags &= ~ILINK_POLL_EX_READY;

                }//ILINK_POLL_EX_READY                

            }

            if(ready) m13_free(ready);
            //do not forget to release poll list lock at the end.
            ilink_poll_unlock(list);

        break;//E13_OK

        case E13_CONTINUE:
            _deb1("continue, interrupted");
        break;//E13_CONTINUE

        case E13_TIMEOUT:
            _deb1("timeout should not happen!");
        break;//E13_TIMEOUT

        default:
            _deb1("other case ilink_poll ret = %i", ret);
        break;

        }
    }

}

error13_t _monet_add_poll_link(struct monet* mn,
                               struct infolink* link,
                               ilink_poll_flag_t flags,
                               int lock){

    //TODO: write code
    struct _mn_poll_add_s* s = (struct _mn_poll_add_s*)m13_malloc(sizeof(struct _mn_poll_add_s));
    s->flags = flags | ILINK_POLL_NOLOCK;

    if(lock) th13_mutex_lock(&mn->user_array.mx);

    s->link = link;
    s->link->popnext = NULL;

    ilink_prepare_pkt(&mn->pipelink_send, NULL, 0, MN_PKT_POLL, 0);
    mn->pipelink_send.tmp_ctx = s;
    ilink_send(&mn->pipelink_send, NULL, NULL, NULL);

    if(lock) th13_mutex_unlock(&mn->user_array.mx);

    return E13_OK;

}

error13_t _monet_request_send(struct monet* mn,
                              uid13_t nuid,
                              uid13_t* uidlist,
                              ilink_data_t* data,
                              ilink_datalen_t datalen,
                              ilink_pkt_type_t type,
                              ilink_ppkt_flag_t flags,
                              int nolock) {

    error13_t ret;
    uid13_t i, j;
    struct _mn_poll_add_s* s = (struct _mn_poll_add_s*)m13_malloc(sizeof(struct _mn_poll_add_s));
    s->flags = flags|ILINK_POLL_NOLOCK|ILINK_POLL_WR;
    s->link = NULL;
    struct infolink* last;

    if(!nolock) th13_mutex_lock(&mn->user_array.mx);

    for(j = 0; j < mn->user_array.nalloc; j++){
        for(i = 0; i < nuid; i++){
            if(     mn->user_array.array[j].user &&
                    mn->user_array.array[j].user->id == uidlist[i] &&
                    !(mn->user_array.array[j].user->link->flags & ILINK_FLAG_PIPE)//do not send to pipe
            ){
                if(!s->link){
                    s->link = mn->user_array.array[j].user->link;
                    s->link->popnext = NULL;
                    last = s->link;
                } else {
                    last->popnext = mn->user_array.array[j].user->link;
                    last = last->popnext;
                    last->popnext = NULL;
                }

                ret = ilink_prepare_pkt(last, data, datalen, type, flags);
                if(ret != E13_OK) goto end;

            }
        }
    }

    ilink_prepare_pkt(&mn->pipelink_send, NULL, 0, MN_PKT_POLL, 0);
    mn->pipelink_send.tmp_ctx = s;
    ilink_send(&mn->pipelink_send, NULL, NULL, NULL);

end:
    if(!nolock) th13_mutex_unlock(&mn->user_array.mx);

    return ret;

}
