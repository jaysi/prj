﻿#include "monet_internal.h"
#include <unistd.h>

#define _deb1   _DebugMsg
#define _deb_ins _DebugMsg
#define _deb_wait _DebugMsg

struct monet_conf def_conf = {

    MN_CONF_FLAG_DEF,
    MONET_OPMODE_SERVER,//mode
    1000,//max session
    10,//session buck size
    512,//max session name length in bytes
    1024,//session thread read pipe buffer size
    "64999",//port
    "64998",//pipe port
    "monetr",//path
    "monetr.conf",//config
    "monetr.acl",//acl
    "monetr.ctl",//control
    "root",//root user
    "root",//root password
    "guest",//guest user
    "guest",//guest password
    2,//acc_regid
    1000000,//max users
    1000, //max user on a session
    10 //user buck size

};

struct _mn_tmp_accept_arg {
    struct monet* mn;
    struct infolink* acceptlink;
};

error13_t mn_reconf(struct monet* mn, struct monet_conf* conf){

    memcpy(&mn->conf, conf, sizeof(struct monet_conf));

    return E13_OK;

}

error13_t mn_def_conf(struct monet_conf *conf){

    memcpy(conf, &def_conf, sizeof(struct monet_conf));

    return E13_OK;

}

error13_t mn_install(struct monet *mn, struct monet_conf *conf) {

    char base[MAXPATHNAME];
    char tmp[MAXPATHNAME];
    int new_install;
    error13_t ret;
    int fd;
    struct db13 db, ctldb;
    struct access13 ac;

    //1. check for previous installation

    p13_merge_path(p13_get_home(), conf->path, base);

    _deb_ins("check access");

    if(access(base, F_OK)){
        _deb_ins("ok");
        if(access(base, X_OK)){
            _deb_ins("perm");
            return e13_error(E13_PERM);
        }
        _deb_ins("new ins");
        new_install = 1;
    } else {
        _deb_ins("old ins");
        new_install = 0;
    }

    //2. create path

    if(new_install){

        if((ret = p13_create_dir_struct(base)) != E13_OK){
            _deb_ins("%s", e13_codemsg(ret));
            return ret;
        }

    }

    //3. create files

    p13_merge_path(base, conf->conf_file, tmp);

    if(new_install){

        if((fd = creat(tmp, S_IRUSR|S_IWUSR)) == -1){
            _deb_ins("%s", "create failed");
            return e13_error(E13_SYSE);

        }

    } else {

        if(access(tmp, W_OK|R_OK)){
            _deb_ins("%s", "perm");
            return e13_error(E13_PERM);

        }

    }

    p13_merge_path(base, conf->acl_file, tmp);

    if(new_install){

        if((ret = db_open(&db, NULL, NULL, NULL, NULL, conf->acl_file))
                != E13_OK){
            _deb_ins("%s", e13_codemsg(ret));
            return ret;
        }

    } else {

        if(access(tmp, W_OK|R_OK)){
            _deb_ins("%s", "perm");
            return e13_error(E13_PERM);

        }

    }

    p13_merge_path(base, conf->ctl_file, tmp);

    if(new_install){

        if((ret = db_open(&ctldb, NULL, NULL, NULL, NULL, conf->ctl_file))
                != E13_OK){
            _deb_ins("%s", e13_codemsg(ret));
            return ret;
        }

    } else {

        if(access(tmp, W_OK|R_OK)){
            _deb_ins("%s", "perm");
            return e13_error(E13_PERM);

        }

    }

    //4. setup defaults

    if((ret = acc_init(&ac, &db, conf->monet_acc_regid)) != E13_OK){
        _deb_ins("%s", e13_codemsg(ret));
        goto end;

    }

    if((ret = acc_user_add(&ac, conf->root_user, conf->root_pass)) != E13_OK){
        _deb_ins("%s", e13_codemsg(ret));
        goto end;

    }

    if((ret = acc_user_add(&ac, conf->guest_user, conf->guest_pass)) != E13_OK){
        _deb_ins("%s", e13_codemsg(ret));
        goto end;

    }

end:
    //5. free res

    acc_destroy(&ac);
    db_close(&db);

    _deb_ins("%s", "return");

    return ret;

}

error13_t mn_uninstall(struct monet* mn){
    _deb_ins("%s", "not implemented yet!");
    return e13_error(E13_IMPLEMENT);
}

error13_t mn_init(struct monet* mn, struct monet_conf* conf){

#ifdef _DEBUG_MUTEX
    th13_mutexattr_t attr;
#endif

    memcpy(&mn->conf, conf?conf:&def_conf, sizeof(struct monet_conf));

    mn->user_array.array = NULL;
    mn->sess_array.array = NULL;

    return E13_OK;

}

error13_t mn_destroy(struct monet* mn){
    _deb_ins("%s", "implement");
    return e13_error(E13_IMPLEMENT);
}

error13_t _mn_login_recv(struct monet *mn, struct infolink* link){

    //TODO: TEMPORARY
    static uid13_t uid = UID13_NONE;
    size_t i;
    struct monet_user* mn_user;

    _deb_ins("%s", "TODO: TEMP");

    //TODO: get login info

    ilink_recv(link, NULL, NULL, NULL);

    //alloc + init user struct
    mn_user = (struct monet_user*)m13_malloc(sizeof(struct monet_user));

    mn_user->i = i;
    mn_user->next = NULL;

    mn_user->link = link;
    mn_user->gid_array = NULL;
    mn_user->name = mn->conf.guest_user;//TODO: TEMP
    mn_user->id == ++uid;//TODO: TEMP

    th13_mutex_lock(&mn->user_array.mx);

    if(!mn->user_array.array){
        mn->user_array.array = (struct monet_user_array_entry*)m13_malloc(
                    sizeof(struct monet_user_array_entry)*
                    mn->conf.user_bulk_size);
        mn->user_array.nalloc = mn->conf.user_bulk_size;
        mn->user_array.nactive = 0UL;
        mn->user_array.npause = 0UL;
        for( i = 0; i < mn->conf.user_bulk_size; i++ ) {
            mn->user_array.array[i].user = NULL;
        }
        i = 0;
    } else {
        if(mn->user_array.nalloc == mn->user_array.nactive + mn->user_array.npause){
            mn->user_array.array = (struct monet_user_array_entry*)m13_realloc(
                        mn->user_array.array,
                        sizeof(struct monet_user_array_entry)*
                        (mn->conf.user_bulk_size + mn->user_array.nalloc));
            for(i = 0; i < mn->conf.user_bulk_size; i++){
                mn->user_array.array[i + mn->user_array.nalloc].user = NULL;
            }
            i = mn->user_array.nalloc;
            mn->user_array.nalloc += mn->conf.user_bulk_size;
        } else {
            for(i = 0; i < mn->user_array.nalloc; i++){
                if(!mn->user_array.array[i].user) break;
            }
        }
    }

    link->ext_ctx = mn_user;

    mn->user_array.array[i].user = mn_user;
    mn->user_array.nactive++;

    //do not unlock

    return E13_OK;

}

void* _mn_tmp_accept(void* arg){

    error13_t ret;
    struct _mn_tmp_accept_arg* args = (struct _mn_tmp_accept_arg*)arg;

    _deb_wait("%s", "tmp_accept_thread");

    ret = ilink_accept(args->acceptlink, &args->mn->pipelink_recv);

    _deb_wait("%s", e13_codemsg(ret));

    return NULL;
}

error13_t mn_wait(struct monet *mn){

    struct infolink *link, pipeaccept;
    error13_t ret;
    struct ilink_conf conf;
    char *path;
    struct db13 acdb;
    th13_t th;
    struct _monet_poll_thread_arg poll_arg;
    struct _mn_tmp_accept_arg arg;
#ifdef _DEBUG_MUTEX
    th13_mutexattr_t attr;
#endif

    ilink_def_conf(&conf);

    conf.type = ILINK_TYPE_LISTEN;
    conf.port = mn->conf.port;

    //0. init access db

    path = m13_malloc(MAXPATHNAME);
    if(!path) return e13_error(E13_NOMEM);

    p13_join_path(p13_get_home(), mn->conf.acl_file, path);

    if((ret = db_init(&acdb, DB_DRV_SQLITE)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        m13_free(path);
        return ret;
    }

    if((ret = db_open(&acdb, NULL, NULL, NULL, NULL, path)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        m13_free(path);
        return ret;
    }

    m13_free(path);

    if((ret = acc_init(&mn->ac, &acdb, mn->conf.monet_acc_regid)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        return ret;
    }

    //1. init accept link

    if((ret = ilink_init(&mn->acceptlink, &conf)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        return ret;
    }

    //2. init pipe link

    conf.type = ILINK_TYPE_SERVER;
    conf.port = mn->conf.pipe_port;

    if((ret = ilink_init(&pipeaccept, &conf)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        return ret;
    }

    conf.type = ILINK_TYPE_CLIENT;

    if((ret = ilink_init(&mn->pipelink_send, &conf)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        ilink_destroy(&pipeaccept);
        return ret;
    }

    //2a. connect pipe ends using a temp accept thread

    arg.mn = mn;
    arg.acceptlink = &pipeaccept;

    _deb_wait("%s", "create tmp accept");
    th13_create(&th, NULL, &_mn_tmp_accept, &arg);

    //TODO: FIX THIS, MUST WAIT FOR THREAD
    #ifdef WIN32
    _sleep(1);
    #else
    sleep(1);
    #endif // WIN32

    if((ret = ilink_connect(&mn->pipelink_send, &conf)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        ilink_destroy(&pipeaccept);
        return ret;
    }

    mn->pipelink_recv->flags |= ILINK_FLAG_PIPE;
    mn->pipelink_send.flags |= ILINK_FLAG_PIPE;

    //3. init poll list, add pipe link to the list, TODO
#ifdef _DEBUG_MUTEX
    _deb1("DEBUG_MUTEX ON");
    TH13_MUTEXATTR_INIT_ERRORCHECK(&attr);
    th13_mutex_init(&mn->user_array.mx, &attr);
#else
    th13_mutex_init(&mn->user_array.mx, NULL);
#endif
    if((ret = ilink_poll_init(&mn->poll.polist, 0, 0, &mn->user_array.mx)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        ilink_destroy(&pipeaccept);
        return ret;
    }

    if((ret = ilink_poll_add(&mn->poll.polist, mn->pipelink_recv, ILINK_POLL_RD)) != E13_OK){
        _deb_wait("%s", e13_codemsg(ret));
        db_close(&acdb);
        ilink_destroy(&pipeaccept);
        return ret;
    }

    //4. start poll thread

    poll_arg.mn = mn;
    poll_arg.index = 0;

    _deb_wait("%s", "create poll thread");

    th13_create(&mn->poll.th, NULL, &_monet_poll_thread, &poll_arg);

    while( 1 ) {

        //accept user

        _deb_wait("%s", "accept");
        if((ret = ilink_accept(&mn->acceptlink, &link)) != E13_OK){
            _deb_wait("%s", e13_codemsg(ret));
            return ret;
        }

        //login user

        //th13_mutex_lock(&mn->user_array.mx); login_recv locks user mx

        if((ret = _mn_login_recv(mn, link)) != E13_OK){
            _deb_wait("%s", e13_codemsg(ret));
            //do nothing, just continue
            ilink_disconnect(link, ILINK_DC_ALL);
            ilink_destroy(link);
            //TODO: stop on serious conditions
            th13_mutex_unlock(&mn->user_array.mx);
            continue;
        }

        _deb_wait("%s", "add poll link");
        _monet_add_poll_link(mn, link, ILINK_POLL_RD, 0);

        th13_mutex_unlock(&mn->user_array.mx);

        //loop

    }

    return E13_OK;


}

/***                        client side                         ***/

error13_t _mn_login_send(struct monet* mn,
                         char* username,
                         char* password){

    //TODO: write code

    struct ilink_ctl_s ios;

    //ios.send_time =

    return E13_OK;

}

error13_t mn_connect(struct monet* mn,
                     char* username,
                     char* password,
                     char* address,
                     char* port,
                     struct monet_user** user){

    error13_t ret;
    struct ilink_conf conf;

    *user = (struct monet_user*)m13_malloc(sizeof(struct monet_user));
    if(!(*user)) return e13_error(E13_NOMEM);

    (*user)->link = &mn->acceptlink;
    mn->acceptlink.ext_ctx = *user;

    ilink_def_conf(&conf);

    conf.type = ILINK_TYPE_CLIENT;

    conf.port = s13_malloc_strcpy(port?port:mn->conf.port, strlen(port?port:mn->conf.port)+1);
    conf.addr = s13_malloc_strcpy(address?address:MONET_LOCALHOST, strlen(address?address:MONET_LOCALHOST)+1);
    (*user)->name = s13_malloc_strcpy(username?username:mn->conf.guest_user, strlen(username?username:mn->conf.guest_user)+1);

    ret = ilink_connect(&mn->acceptlink, &conf);

    m13_free(conf.port);
    m13_free(conf.addr);

    if(ret != E13_OK) goto end;

    ret = _mn_login_send(mn, username, password);

end:

    if(ret != E13_OK){
        m13_free((*user)->name);
        m13_free(*user);
    }

    return ret;

}
