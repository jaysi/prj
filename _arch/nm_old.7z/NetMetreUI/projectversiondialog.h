﻿#ifndef PROJECTVERSIONDIALOG_H
#define PROJECTVERSIONDIALOG_H

#include <QDialog>

#include "../netmetre/netmetre.h"

namespace Ui {
class ProjectVersionDialog;
}

class ProjectVersionDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ProjectVersionDialog(QWidget *parent = 0);
    ProjectVersionDialog(QWidget *parent = 0, struct nm_session* _nm = 0, nm_pid_t pid = 0);
    ~ProjectVersionDialog();
    void setNmSession(struct nm_session* _nm);
    
private:    
    Ui::ProjectVersionDialog *ui;
    struct nm_session* nm;
};

#endif // PROJECTVERSIONDIALOG_H
