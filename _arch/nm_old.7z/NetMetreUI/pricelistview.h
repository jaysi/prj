﻿#ifndef PRICELISTVIEW_H
#define PRICELISTVIEW_H

#include <QMainWindow>

#include "../netmetre/netmetre.h"

namespace Ui {
class PriceListView;
}

class PriceListView : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit PriceListView(QWidget *parent = 0);
    ~PriceListView();

    void setNmSession(struct nm_session* _nm);
    
private:
    struct nm_session* nm;
    Ui::PriceListView *ui;    
};

#endif // PRICELISTVIEW_H
