#ifndef ITEMPROPERTIESDIALOG_H
#define ITEMPROPERTIESDIALOG_H

#include <QDialog>

namespace Ui {
class ItemPropertiesDialog;
}

class ItemPropertiesDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ItemPropertiesDialog(QWidget *parent = 0);
    ~ItemPropertiesDialog();
    
private slots:
    void on_btnOk_clicked();

    void on_btnCancel_clicked();

private:
    Ui::ItemPropertiesDialog *ui;
};

#endif // ITEMPROPERTIESDIALOG_H
