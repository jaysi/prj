﻿#include "pricelistview.h"
#include "ui_pricelistview.h"

PriceListView::PriceListView(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PriceListView)
{
    ui->setupUi(this);

    nm = NULL;
}

PriceListView::~PriceListView()
{
    delete ui;    
}

void PriceListView::setNmSession(struct nm_session *_nm){

    nm = _nm;

}
