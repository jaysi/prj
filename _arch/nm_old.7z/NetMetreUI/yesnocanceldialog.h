#ifndef YESNOCANCELDIALOG_H
#define YESNOCANCELDIALOG_H

#include <QDialog>

#define YNC_SAVE    1
#define YNC_DONT    2
#define YNC_CANCEL  3

namespace Ui {
class YesNoCancelDialog;
}

class YesNoCancelDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit YesNoCancelDialog(QWidget *parent = 0);
    explicit YesNoCancelDialog(QWidget *parent, QString& prjName);
    ~YesNoCancelDialog();
    int getAct();
    
private slots:
    void on_btnSave_clicked();

    void on_btnDontSave_clicked();

    void on_btnCancel_clicked();

private:
    Ui::YesNoCancelDialog *ui;
    int act;
};

#endif // YESNOCANCELDIALOG_H
