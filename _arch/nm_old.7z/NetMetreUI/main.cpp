#include <QApplication>
#include <QMessageBox>
#include "logindialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LoginDialog* login = new LoginDialog;

    if(!login){
        return -1;
    }

    login->show();

    return a.exec();
}
