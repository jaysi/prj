﻿#ifndef MESSAGE_H
#define MESSAGE_H

#define MSG_NOMEM   "کمبود حافظه"
#define MSG_SYS     "سیستم"
#define MSG_RES     "منابع"
#define MSG_ACCESS  "دسترسی"
#define MSG_BADLOGIN    "نام کاربر / کلمه عبور وارد شده صحیح نمیباشد"

#endif // MESSAGE_H
