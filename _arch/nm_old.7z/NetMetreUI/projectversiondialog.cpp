﻿#include "projectversiondialog.h"
#include "ui_projectversiondialog.h"

ProjectVersionDialog::ProjectVersionDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProjectVersionDialog)
{
    ui->setupUi(this);
    nm = NULL;
}

ProjectVersionDialog::ProjectVersionDialog(QWidget *parent, struct nm_session* _nm, nm_pid_t pid) :
    QDialog(parent),
    ui(new Ui::ProjectVersionDialog)
{
    ui->setupUi(this);
    nm = _nm;
}

ProjectVersionDialog::~ProjectVersionDialog()
{
    delete ui;
}

void ProjectVersionDialog::setNmSession(struct nm_session* _nm){
    nm = _nm;
}
