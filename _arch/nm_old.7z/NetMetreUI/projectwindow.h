﻿#ifndef PROJECTWINDOW_H
#define PROJECTWINDOW_H

#include <QMainWindow>
#include <QListWidget>

#include "../netmetre/netmetre.h"

namespace Ui {
class ProjectWindow;
}

class ProjectWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit ProjectWindow(QWidget *parent = 0);
    ProjectWindow(QWidget *parent, struct nm_session* _sess, char* name, char* pparent, int create);
    ~ProjectWindow();    
    bool prepareToExit();
    void setTitle(QString name);
    void updateOpenProjectList();
    void updateAllProjectList();
    void updateOtherOpenProjectList();
    void setMessage(QString from, QString msg);
    void setMessage(QString from, QStringList msglist);
    void setNmSession(struct nm_session* _nm);
    
private slots:
    void on_btnExitProject_clicked();
    void on_btnSave_clicked();

    void on_btnItemMgmt_clicked();    

    void on_checkInvoiceLock_clicked();

    void on_checkMoreSpace_clicked();

    void on_btnProjectNew_clicked();

    void on_btnProjectDelete_clicked();

    void on_btnProjectEdit_clicked();

    void on_btnProjectVersion_clicked();

    void on_btnProjectBackup_clicked();

    void on_btnProjectRestore_clicked();

    void on_btnExit_clicked();

    void on_btnAbout_clicked();

    void on_listwidgetOpenProjects_itemDoubleClicked(QListWidgetItem *item);

    void on_checkMoreSpace2_clicked();

    void on_editContractSubject_editingFinished();

    void on_tabwidgetData_selected(const QString &arg1);

    void on_btnShowPriceList_clicked();    

    void on_btnHome_clicked();

    void on_btnMetre_clicked();

    void on_btnCalc_clicked();

    void on_tabwidgetControl_currentChanged(QWidget *arg1);

    void on_lineMessage_returnPressed();

    void on_toolSendMessage_clicked();

private:
    Ui::ProjectWindow *ui;
    unsigned long nchanges;
    int saveProject();
    bool metretabexpanded;
    bool invoice_locked;
    bool morespace;
    struct nm_session* nm;
    nm_pid_t pid;
    bool destroyThis();

    QString name;    

    void preparePriceLists();
    void prepareContractInfo();
    void prepareMultipliers();
    void prepareMetre();
    void prepareSumOfMetre();
    void preparePrice();
    void prepareSumOfPrice();
    void prepareSessionsPrice();
    void prepareTotalPrice();
    QString getProjectName();

    void prepareProjectDB();    

    int closeProject();
    int openProject(nm_pid_t pid);

protected:
    void closeEvent(QCloseEvent *);
    bool eventFilter(QObject *, QEvent *);

};

#endif // PROJECTWINDOW_H
