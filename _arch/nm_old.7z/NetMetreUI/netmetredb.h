﻿#ifndef NETMETREDB_H
#define NETMETREDB_H

#include <QDialog>
#include <QCloseEvent>

#include "../netmetre/netmetre.h"

namespace Ui {
class NetMetreDB;
}

class NetMetreDB : public QDialog
{
    Q_OBJECT
    
public:
    explicit NetMetreDB(QWidget *parent = 0);
    explicit NetMetreDB(QWidget *parent = 0, struct nm_session* _nm = 0);
    ~NetMetreDB();

    void setDBParam(QString driver,
                    QString hostname,
                    QString name,
                    QString username,
                    QString password);

    void getDBParam(QString *driver, QString *hostname, QString *name, QString *username, QString *password);

    bool initSys();

    void setNmSession(struct nm_session* _nm);

private:
    Ui::NetMetreDB *ui;
    struct nm_session* nm;

    //db13_engine getEngineId(QString name);

protected:
    void hideEvent(QHideEvent *);

};

#endif // NETMETREDB_H
