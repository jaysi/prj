﻿#ifndef PROJECTMANAGERDIALOG_H
#define PROJECTMANAGERDIALOG_H

#include <QDialog>

#include "../netmetre/netmetre.h"

namespace Ui {
class ProjectManagerDialog;
}

class ProjectManagerDialog : public QDialog
{
    Q_OBJECT
    
public:
    explicit ProjectManagerDialog(QWidget *parent = 0);
    ProjectManagerDialog(QWidget *parent = 0, struct nm_session* _nm = 0);
    ~ProjectManagerDialog();
    nm_pid_t getPid();

    void setNmSession(struct nm_session* _nm);
    
private:
    Ui::ProjectManagerDialog *ui;
    struct nm_session* nm;
    void showProjectList(char** list);
};

#endif // PROJECTMANAGERDIALOG_H
