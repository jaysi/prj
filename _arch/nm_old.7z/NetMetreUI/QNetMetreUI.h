﻿#ifndef QNETMETREUI_H
#define QNETMETREUI_H

//#include <QtSql/QtSql>
#include <QString>

#define DEF_PRJ_NAME    "پروژه"
#define DEF_PRJ_FMT     "%1_%2"
#define DEF_NEW_PRJ     "جدید"
#define DEF_EMPTY_PRJ   "خالی"

#define STR_USER_SYSTEM "سیستم"
#define STR_USER_MANAGER "مدیر"
#define STR_USER_DEBUG  "عیب یابی"
#define STR_USER_THIS   "شما"

#define DEF_DB_FILE_EXT ".nmdb"
#define DEF_DB_BASE     "base"
#define DEF_DB_CTL      "ctl"

#define DEF_DB_DRIVER   "QSQLITE"
#define DEF_DB_HOSTNAME "localhost"
#define DEF_DB_NAME     DEF_DB_BASE
#define DEF_DB_USERNAME STR_USER_MANAGER
#define DEF_DB_PASSWORD ""

//base db
#define TABLE_PRICE_LIST_YEARS  "pricelist_years"
#define TABLE_PRICE_LIST_IDS    "pricelist_ids"

//base and project dbs
#define TABLE_PRICE_LISTS               "pricelists"
#define TABLE_PRICE_LIST_RELATIONS_EXT  "_relations"

//project db tables, followed by a pid
#define TABLE_ATTACHMENTS       "attachments_"
#define TABLE_POSITIONS         "positions_"         /*موقعیتها*/
#define TABLE_INVOICES          "invoices_"
#define TABLE_INVOICE_VERSIONS  "invoice_versions_"  /*نسخه ها*/
#define TABLE_METRE_PRIFIX      "metre_"    /*followed by pid and */
#define TABLE_METRE_INFIX       "_"         /*followed by invoice number*/

//control db, including acl, stat
#define TABLE_INFO              "info"
#define TABLE_STAT              "stat"
#define TABLE_GROUPS            "groups"
#define TABLE_USERS             "users"
#define TABLE_MEMBERSHIP        "membership"
#define TABLE_ACL               "acl"
#define TABLE_PROJECTS          "project_list"

#define STAT_ACTIVE "active"
#define STAT_INACTIVE "inactive"
#define STAT_ARCHIVE "archive"
#define STAT_REMOVED    "removed"

/*
 *  Tables:
 *      - Definitions: ids [name, table_name, id]
 *          they define things like price list ids, etc...
 *      - Price Lists:  pl_YEAR
 *          these are price lists announced by mporg
 *      - Price Balance Lists: plb_YEAR_QUARTER
 *          these keep price balance lists of mporg
*/

enum sql_table_patterns{

    /*control tables*/

    INF_PATT,
    STAT_PATT,
    GROUPS_PATT,
    USERS_PATT,
    MEMBERSHIPS_PATT,
    ACL_PATT,
    PRJLIST_PATT

    /*base tables*/

};

#define CTL_TABLE_PATT_START    INF_PATT
#define CTL_TABLE_PATT_END      PRJLIST_PATT

struct project_list{
    void* prj; //the pointer to the project object
    char* name;
    uint64_t pid;//project id
    uint64_t ppid;//parent project id
    struct project_list* next;
};

struct QNetMetreUI{

    //configuration

    QString db_driver;
    QString db_hostname;
    QString db_name;
    QString db_username;
    QString db_password;

    int nopenprj;

    struct project_list *prjfirst, *prjlast;

};

/*

 base database tables:

    pricelist_years(plist_years_year INTEGER);
    pricelist_ids(plist_ids_name TEXT, plist_ids_id INTEGER);
 //plists_type: پایه، غیر پایه، تعدیل پایه، تعدیل غیر پایه
    pricelists(plists_name TEXT, plists_year INTEGER, plists_year_quarter INTEGER, plists_type TEXT, plists_id INTEGER, plists_table TEXT);
    pricelist_years(plist_years_year INTEGER);
  //plist_relate_type: اضافه بها، طبق مقدمه فصل، طبق مقدمه فهرست
    $(plist_table)_relations(plist_relate_source_item TEXT, plist_relate_target_item TEXT, plist_relate_type TEXT, plist_relate_fmul TEXT);

 project database tables:

    contr_info_$(pid)(contr_subject TEXT,contr_owner TEXT, contr_manager TEXT, contr_consultant TEXT, contr_supervisor TEXT, contr_contractor TEXT, contr_number TEXT, contr_date TEXT, contr_doc_number TEXT, contr_base_session INTEGER, contr_year INTEGER, contr_duration_month INTEGER, contr_duration_days INTEGER, contr_train_transfer_date TEXT, contr_legal_end_date TEXT, contr_revenue_type INTEGER, contr_base_type INTEGER, contr_early_price INTEGER, contr_outfit_price INTEGER, contr_update_id INTEGER);
    contr_attach_$(pid)(contr_attach_title TEXT, contr_attach_price INTEGER, contr_attach_date TEXT, contr_attach_month INTEGER, contr_attach_day INTEGER);
    pricelists_$(pid)(plists_name TEXT, plists_year INTEGER, plists_year_quarter INTEGER, plists_type TEXT, plists_id INTEGER, plists_table TEXT);
    $(plist_table)_relations_$(pid)(plist_relate_source_item TEXT, plist_relate_target_item TEXT, plist_relate_type TEXT, plist_relate_fmul TEXT);
    positions_$(pid)(pos_name TEXT);
    invoice_versions_$(pid)(inv_ver_name TEXT, inv_ver_color_name TEXT, inv_ver_color INTEGER, inv_ver_proxy NAME, inv_ver_proxy_sign BLOB);
    invoices_$(pid)(inv_number INTEGER, inv_ver TEXT, inv_date TEXT, inv_prev_number INTEGER, inv_prev_ver TEXT, inv_val INTEGER, inv_bal_prev INTEGER, inv_bal_prev_ver TEXT, inv_locked INTEGER, metre_table TEXT);
    metre_($pid)_$(inv_number)(metre_ref_plist_code INTEGER, metre_row INTEGER, metre_sub_row INTEGER, metre_item TEXT, metre_desc TEXT, metre_item_type TEXT, metre_num TEXT, metre_length TEXT, metre_width TEXT, metre_height TEXT, metre_weight TEXT, metre_sub_sum TEXT, metre_total_sum REAL, metre_remarks TEXT, metre_pos TEXT, metre_comments TEXT);

 control tables:

    info(inf_db_title TEXT, inf_db_desc TEXT, inf_engine_ver INT, inf_db_ver INT)
    stat(st_high_prj_id INTEGER, st_free_prj_id INTEGER);
    groups(group_name TEXT, group_stat TEXT);
    users(user_name TEXT, user_stat TEXT, user_pass_hash TEXT);
    membership(mem_user TEXT, mem_group TEXT);
  //acl_type: user / group
    acl(acl_name TEXT, acl_type TEXT, acl_res TEXT, acl_acc INTEGER);
    project_list(prjlist_name TEXT, prjlist_pid INTEGER, prjlist_ppid INTEGER, prjlist_stat TEXT);

*/

#endif // QNETMETREUI_H
