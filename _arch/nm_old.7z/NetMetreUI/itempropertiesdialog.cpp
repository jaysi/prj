#include "itempropertiesdialog.h"
#include "ui_itempropertiesdialog.h"

ItemPropertiesDialog::ItemPropertiesDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ItemPropertiesDialog)
{
    ui->setupUi(this);
}

ItemPropertiesDialog::~ItemPropertiesDialog()
{
    delete ui;
}

void ItemPropertiesDialog::on_btnOk_clicked()
{
    this->close();
}

void ItemPropertiesDialog::on_btnCancel_clicked()
{
    this->close();
}
