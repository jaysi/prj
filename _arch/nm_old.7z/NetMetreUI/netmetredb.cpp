﻿#include "netmetredb.h"
#include "ui_netmetredb.h"
#include "logindialog.h"

#include <QMessageBox>

NetMetreDB::NetMetreDB(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::NetMetreDB)
{
    ui->setupUi(this);
    nm = NULL;
}

NetMetreDB::NetMetreDB(QWidget *parent, struct nm_session* _nm) :
    QDialog(parent),
    ui(new Ui::NetMetreDB)
{
    ui->setupUi(this);

    setDBParam(  trUtf8(NMDB_DEF_DRIVER),
                trUtf8(NMDB_DEF_HOSTNAME),
                trUtf8(NMDB_DEF_NAME),
                trUtf8(NMDB_DEF_USERNAME),
                trUtf8(NMDB_DEF_PASSWORD));

    this->hide();

    this->setWindowFlags(Qt::FramelessWindowHint);    

    nm = _nm;

    //setTablePattern();
}

NetMetreDB::~NetMetreDB()
{
    delete ui;
}

NetMetreDB::hideEvent(QHideEvent *event){
    (LoginDialog*)(this->parent())->reConfig();
    event->accept();
}

void NetMetreDB::setDBParam(QString driver,
                            QString hostname,
                            QString name,
                            QString username,
                            QString password){

    ui->editDBDriver->setText(driver);
    ui->editDBHostname->setText(hostname);
    ui->editDBName->setText(name);
    ui->editDBUsername->setText(username);
    ui->editDBPassword->setText(password);
}

enum nmdb_drv_id NetMetreDB::getEngineId(QString name){

    if(name == trUtf8("SQLITE")) return DB_DRV_SQLITE;

    return NMDB_DRV_INVAL;
}

void NetMetreDB::getDBParam(QString* driver,
                            QString* hostname,
                            QString* name,
                            QString* username,
                            QString* password){


    driver = ui->editDBDriver;
    hostname = ui->editDBHostname;
    username = ui->editDBUsername;
    password = ui->editDBPassword;
    name = ui->editDBName;

}

void NetMetreDB::setNmSession(struct nm_session* _nm){
    nm = _nm;
}

bool NetMetreDB::initSys(){

    return true;
}
