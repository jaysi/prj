﻿#include "logindialog.h"
#include "ui_logindialog.h"
#include "projectwindow.h"
#include "netmetredb.h"
#include "message.h"

#include <QMessageBox>

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{    

    error13_t errcode;

    ui->setupUi(this);

    nm = new struct netmetre;
    if(!nm){
        QMessageBox::critical(this, trUtf8(MSG_RES), trUtf8(MSG_NOMEM));
        ::exit(-1);
    }

    if((errcode = nm_init(nm)) != E13_OK){
        QMessageBox::critical(this, trUtf8(MSG_SYS), trUtf8(e13_code_msg(errcode)));
        ::exit(-1);
    }

    dbdlg = new NetMetreDB(this, nm);
    if(!dbdlg){
        QMessageBox::critical(this, trUtf8(MSG_RES), trUtf8(MSG_NOMEM));
        ::exit(-1);
    }

}

LoginDialog::~LoginDialog()
{
    if(nm){
        nm_destroy(nm);
        delete nm;
    }
    delete ui;
}

void LoginDialog::reConfig(){

    int ret;

    dbdlg->getDBParam(&conf);

    nm_end_session(nm);

    if((ret = nm_set_db_conf(nm, &conf)) != E13_OK){
        QMessageBox::critical(this, trUtf8(MSG_SYS), trUtf8(e13_errmsg(nm->error_s)));
        ::exit(1);
    }

    if((ret = nm_start_session(nm)) != E13_OK){
        QMessageBox::critical(this, trUtf8(MSG_SYS), trUtf8(e13_errmsg(nm->error_s)));
        ::exit(1);
    }

    ui->comboUsername->clear();
    ui->comboUsername->addItems(getUserList());

}

void LoginDialog::on_btnLogin_clicked()
{

    struct db13_db_conf conf;

    reConfig();

    if(!assertLogin(ui->comboUsername->currentText(), ui->editPassword->text())){
        QMessageBox::warning(this, trUtf8(MSG_ACCESS),
                        trUtf8("نام کاربر / کلمه عبور وارد شده صحیح نمیباشد"));
        return;
    }

    dbdlg->setVisible(false);

    ProjectWindow* prjwin = new ProjectWindow(NULL, 0, nm);

    if(!prjwin){
        QMessageBox::critical(this, trUtf8("منابع"), trUtf8("کمبود حافظه"));
        ::exit(-1);

    }

    prjwin->show();

    this->~LoginDialog();
}

void LoginDialog::on_cbtnSettings_clicked()
{        

    if(dbdlg->isHidden()){
        dbdlg->move(
                    ui->cbtnSettings->mapToGlobal(
                    QPoint(ui->cbtnSettings->frameGeometry().x()-dbdlg->width(),
                           ui->cbtnSettings->frameGeometry().y()-dbdlg->height()
                           )
                    ));
        dbdlg->setModal(false);
        dbdlg->show();
    } else {        
        dbdlg->hide();
    }    
}

bool LoginDialog::assertLogin(QString username, QString password){

    int ret;

    if((ret = nm_login(nm, username.toUtf8().data(), password.toUtf8().data()))
            != E13_OK){

        return false;

    }

    return true;
}

QStringList LoginDialog::getUserList(){

    char** usernamelist;
    QStringList list;
    int i = 0;

    usernamelist = nm_get_userlist(nm);
    if(usernamelist){

        while(usernamelist[i][0] != '\0') list << trUtf8(usernamelist[i++]);

        nm_free_userlist(usernamelist);

    }

    return list;
}
