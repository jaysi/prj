#ifndef NM_PKT_H
#define NM_PKT_H

#include "nm_types.h"

#define NM_PKT_HDR_PACK "LHH"
#define NM_PKT_HDR_NPARAM_PACK "L"

struct nm_cmd_pkt{
	nm_pid_t pid;//which project? there is reserved pids, see nm_project.h
	nm_cmd_t cmd;//what command
	uint16_t nparam;
	uint32_t* paramlen;
	char* paramlist;
};

#ifdef _cplusplus
	extern "C" {
#endif



#ifdef _cplusplus
	}
#endif

#endif //NM_PKT_H