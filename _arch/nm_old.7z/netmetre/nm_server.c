﻿#include "nm_server.h"
#include "netmetre.h"

error13_t nm_wait(struct netmetre *nm, struct nm_wait_conf *conf){

    //This is TEMP, for local

    return E13_OK;

}
