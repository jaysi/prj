﻿#include "nm_sess.h"

error13_t nm_sess_create(struct netmetre* nm, char* name, struct nm_session_conf* conf){

    return E13_OK;
}

error13_t nm_sess_destroy(struct netmetre* nm, char* name){
    return E13_OK;
}

error13_t nm_sess_get(struct netmetre* nm, char* name, struct nm_session** sess){
    return E13_OK;
}

error13_t nm_sess_free(struct netmetre* nm, struct nm_session* sess){
    return E13_OK;
}

