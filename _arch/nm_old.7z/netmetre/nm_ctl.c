﻿#include "nm_ctl.h"
#include "netmetre.h"
#include "nm_table.h"

#define ADB ((nm)->ctldb)

error13_t nm_init_access(struct netmetre* nm){

    if(!db_isopen(ADB)){
        return e13_error(E13_MISUSE);
    }

    if((ret = db_set_table_slots(ADB, NMDB_CTL_TID_END-NMDB_CTL_TID_START+1)) != E13_OK){
        return ret;
    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_INFO,
                                NMDB_TABLE_INFO,
                                DB_TABLEF_CORE|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_INFO_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "owner",
                                DB_T_TEXT,
                                "مالک",
                                "",
                                0,

                                "masterpass",
                                DB_T_TEXT,
                                "کلمه عبور",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_GROUP,
                                NMDB_TABLE_GROUP,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_GROUP_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "id",
                                DB_T_INT|DB_COLF_AUTO,
                                "شناسه",
                                "",
                                DB_COLF_SINGULAR,

                                "name",
                                DB_T_TEXT,
                                "نام",
                                "",
                                DB_COLF_SINGULAR,

                                "stat",
                                DB_T_INT,
                                "وضعیت",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_USER,
                                NMDB_TABLE_USER,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_USER_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "id",
                                DB_T_INT,
                                "شناسه",
                                "",
                                DB_COLF_SINGULAR|DB_COLF_AUTO,

                                "name",
                                DB_T_TEXT,
                                "نام",
                                "",
                                DB_COLF_SINGULAR,

                                "pass",
                                DB_T_TEXT,
                                "کلمه عبور",
                                "",
                                0,

                                "last",
                                DB_T_TEXT,
                                "آخرین ورود",
                                "",
                                0,

                                "stat",
                                DB_T_INT,
                                "وضعیت",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_MEMBERSHIP,
                                NMDB_TABLE_MEMBERSHIP,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_MEMBERSHIP_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "nrow",
                                DB_T_BIGINT,
                                "ردیف",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "gid",
                                DB_T_INT,
                                "گروه",
                                "@group:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "uid",
                                DB_T_INT,
                                "کاربر",
                                "@user:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "stat",
                                DB_T_INT,
                                "وضعیت",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_ACL,
                                NMDB_TABLE_ACL,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_ACL_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "nrow",
                                DB_T_BIGINT,
                                "ردیف",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "gid",
                                DB_T_INT,
                                "گروه",
                                "@group:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "uid",
                                DB_T_INT,
                                "کاربر",
                                "@user:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "objid",
                                DB_T_BIGINT,
                                "objid",
                                "",
                                0,

                                "perm",
                                DB_T_INT,
                                "دسترسی",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

    if((ret = db_define_table(  ADB,
                                NMDB_TABLE_PRJLIST,
                                NMDB_TABLE_PRJLIST,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                NMDB_TABLE_PRJLIST_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "nrow",
                                DB_T_BIGINT,
                                "ردیف",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "gid",
                                DB_T_INT,
                                "گروه",
                                "@group:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "uid",
                                DB_T_INT,
                                "کاربر",
                                "@user:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "objid",
                                DB_T_BIGINT,
                                "objid",
                                "",
                                0,

                                "perm",
                                DB_T_INT,
                                "دسترسی",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }


    if(db_istable(ADB, NMDB_TABLE_INFO) != E13_OK){

    }

}

error13_t nm_login_user(netmetre *nm, char* username, char* password){
    return E13_OK;
}

error13_t nm_logout_user(netmetre *nm, char* username){
    return E13_OK;
}

