﻿#ifndef NM_SESS_H
#define NM_SESS_H

#include "../lib13/include/lib13.h"
#include "nm_obj.h"
#include "nm_project.h"
#include "nm_mod.h"

typedef uint16_t nm_sessid_t;
struct netmetre;

enum nm_session_mode{
    NM_SESS_MODE_EMPTY,
    NM_SESS_MODE_LOCAL,
    NM_SESS_MODE_NET,
    NM_SESS_MODE_INVAL
};

struct nm_session_conf{
    enum nm_session_mode mode;
};


#define NM_SESSF_EXIT (0x01<<0) /*exiting session, project list has been
                                  locked and there is no need to lock the
                                  list during nm_close_project call*/

#define NM_SESSF_DEF   0x00

struct nm_session{

    magic13_t magic;
    uint8_t flags;

    struct nm_session_conf conf;

    time_t create_time;

    th13_t thid;

    nm_refcount_t ref;
    nm_sessid_t id;

    char* name;

    struct nm_q* q_first, *q_last;

    nm_objid_t nprj;
    struct nm_project* prj_first, *prj_last;

    struct nm_comod* com_first, *com_last;

    struct netmetre* nm;//this is a pointer to the main nm handle

    struct nm_session* next;

};

typedef uint8_t nm_sess_op;

//session ops 0x0?
#define NM_SESS_OP_NOP          0x00
#define NM_SESS_OP_CREATE       0x01
#define NM_SESS_OP_JOIN         0x02
#define NM_SESS_OP_LEAVE        0x03
#define NM_SESS_OP_DESTROY      0x04
#define NM_SESS_OP_PAUSE        0x05
#define NM_SESS_OP_RESUME       0x06
//project ops   0x1?
#define NM_SESS_OP_PRJ_NOP      0x10
#define NM_SESS_OP_PRJ_CREATE   0x11
#define NM_SESS_OP_PRJ_OPEN     0x12
#define NM_SESS_OP_PRJ_CLOSE    0x13
#define NM_SESS_OP_PRJ_REMOVE   0x14
//table ops 0x2? & 0x3?
#define NM_SESS_OP_TAB_NOP      0x20
#define NM_SESS_OP_TAB_SAVE     0x21
#define NM_SESS_OP_TAB_UNDO     0x22
#define NM_SESS_OP_TAB_REDO     0x23

#define NM_SESS_OP_INVAL        0xff

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_sess_create(struct netmetre* nm, char* name, struct nm_session_conf *conf);
    error13_t nm_sess_destroy(struct netmetre* nm, char* name);

    error13_t nm_sess_list(struct netmetre* nm, char** list);

    error13_t nm_sess_get(struct netmetre* nm, char* name, struct nm_session** sess);
    error13_t nm_sess_free(struct netmetre* nm, struct nm_session* sess);

#ifdef __cplusplus
    }
#endif

#endif // NM_SESS_H
