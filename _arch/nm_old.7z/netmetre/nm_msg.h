﻿#ifndef NM_MSG_H
#define NM_MSG_H

#define NM_MSG_NOMEM    "no memmory has been left"
#define NM_MSG_NOTINIT   "not initialized"
#define NM_MSG_ALREADYINIT  "already initialized"
#define NM_MSG_DRIVERNOTSUPPORTED   "driver not supported"

#endif // NM_MSG_H
