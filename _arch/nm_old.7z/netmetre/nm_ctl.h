﻿#ifndef NM_CTL_H
#define NM_CTL_H

#include "../lib13/include/lib13.h"

struct nm_session;

typedef uint32_t nm_uid_t;
typedef uint32_t nm_gid_t;

#define NM_USER_SYSTEM  "system"
#define NM_USER_MANAGER "manager"
#define NM_USER_DEBUG   "debug"
#define NM_USER_THIS    "this"

#define NM_UID_NONE 0x0000
#define NM_GID_NONE 0x0000
#define NM_UID_ANY  0xffff
#define NM_GID_ANY  0xffff

struct nm_group{

    char* name;
    nm_gid_t gid;

    struct nm_group* next;

};

struct nm_user{

    char* name;
    nm_uid_t uid;

    time_t login_time;

    struct nm_user* next;

};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_group_add(struct netmetre* nm, char* name);
    error13_t nm_group_rm(struct netmetre* nm, char* name);
    error13_t nm_group_chk(struct netmetre* nm, char* name);

    error13_t nm_user_add(struct netmetre* nm, char* name, char* password, char* group);
    error13_t nm_user_rm(struct netmetre* nm, char* name);
    error13_t nm_user_chk(struct netmetre* nm, char* name);

    error13_t nm_user_join_group(struct netmetre* nm, char* username, char* group);
    error13_t nm_user_leave_group(struct netmetre* nm, char* username, char* group);
    error13_t nm_user_group_check(struct netmetre* nm, char* username, char* group);

#ifdef __cplusplus
    }
#endif

    /***        ***ACL***       ***/

//NM PERMISSIONS
typedef uint8_t nm_perm_t;
#define NM_PRD  (0x01<<0)
#define NM_PWR  (0x01<<1)
#define NM_PEX  (0x01<<2)

typedef uint8_t nm_acl_t;

struct nm_acl_entry{
    nm_acl_t type;
    nm_gid_t gid;
    nm_uid_t uid;
    struct nm_acl_entry* next;
};

struct nm_login_entry{
    nm_uid_t uid;
};

#ifdef __cplusplus
    extern "C" {
#endif

    error13_t nm_init_access(struct netmetre* nm);
    error13_t nm_login_user(struct netmetre* nm, char* username, char* password);
    error13_t nm_logout_user(struct netmetre* nm, char* username);

#ifdef __cplusplus
    }
#endif

#endif // NM_CTL_H
