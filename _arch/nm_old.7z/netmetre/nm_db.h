﻿#ifndef NMDB_H
#define NMDB_H

#define DB13_USE_SQLITE3

#include "../lib13/include/lib13.h"

struct netmetre;

/***            SOME DBMS RELATED DEFS          ***/

enum nmdb_db_id {
    NMDB_DB_EMPTY,
    NMDB_DB_CTL,
    NMDB_DB_BASE,
    NMDB_DB_PRJ,
    NMDB_DB_INVAL
};

#define NMDB_CTL_TID  1
#define NMDB_BASE_TID 2
#define NMDB_PRJ_TID  -1

//databases
#define NMDB_BASE          "base"
#define NMDB_CTL           "ctl"
#define NMDB_PRJ           "prj_"//followed by $id

struct nmdb_db_s{

    const char* name;
    const char* path;

} nmdb_db[] = {
{"", ""},//empty
{"ctl", ""},//ctl
{"base", ""},//base
{"prj_", ""},//prj
{NULL, NULL}//inval
};

#endif // NMDB_H
