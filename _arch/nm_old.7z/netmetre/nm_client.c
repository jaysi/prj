﻿#include "nm_client.h"
#include "netmetre.h"

error13_t nm_connect(struct netmetre *nm, struct nm_connect_conf *conf){

    //TODO: this is temporary for local version, just check username/password

    return E13_OK;
}
