﻿#ifndef NM_TABLE_H
#define NM_TABLE_H

#define NMDB_MAX_TABLENAME 20

enum nmdb_table_id{
    NMDB_TABLE_NULL,

    //control db
    NMDB_TABLE_INFO,
    NMDB_TABLE_GROUP,
    NMDB_TABLE_USER,
    NMDB_TABLE_MEMBERSHIP,
    NMDB_TABLE_ACL,
    NMDB_TABLE_PRJLIST,
    NMDB_TABLE_FREEOBJ,    

    //base
    NMDB_TABLE_WPT_CLASS,
    NMDB_TABLE_WPT_BRANCH,
    NMDB_TABLE_WPT_DEF,//WORK PRICE TABLE DEFINITIONS
    NMDB_TABLE_SESS_DEF,//session definition
    NMDB_TABLE_UNIT_DEF,//unit def
    NMDB_TABLE_ITEMTYPE_DEF,
    NMDB_TABLE_ITEMTAG_DEF,
    NMDB_TABLE_MULT_DEF,//multipliers definition
    NMDB_TABLE_WPT,//WORK PRICE TABLE
    NMDB_TABLE_ITEMRELATE_DEF,//

    //project
    NMDB_TABLE_PRJ_DEF,

    NMDB_TABLE_INVAL
};

#define NMDB_CTL_TID_START  NMDB_TABLE_INFO
#define NMDB_CTL_TID_END    NMDB_TABLE_FREEOBJ
#define NMDB_BASE_TID_START NMDB_TABLE_WPT_CLASS
#define NMDB_BASE_TID_END   NMDB_TABLE_ITEMRELATE_DEF
#define NMDB_PRJ_TID_START  NMDB_TABLE_PRJ_DEF
#define NMDB_PRJ_TID_END    NMDB_TABLE_PRJ_DEF

#define NMDB_TABLE_FIRST    NMDB_TABLE_NULL
#define NMDB_TABLE_LAST     NMDB_TABLE_INVAL

//base db
#define NMDB_TABLE_WPT_DEF  "wpt_def"

//base
#define NMDB_TABLE_WPT      "wpt"
#define NMDB_TABLE_MULT_DEF "mult_def"

//project db tables, followed by a pid
#define NMDB_TABLE_ATTACHMENT       "attachment_"
#define NMDB_TABLE_POSITION         "position_"
#define NMDB_TABLE_INVOICE          "invoice_"
#define NMDB_TABLE_INVOICE_VERSION  "invoiceversion_"
#define NMDB_TABLE_METRE_PRIFIX      "metre_"    /*followed by pid and */
#define NMDB_TABLE_METRE_INFIX       "_"         /*followed by invoice number*/

//control db
#define NMDB_TABLE_INFO              "cinf"
#define NMDB_TABLE_GROUP             "group"
#define NMDB_TABLE_USER              "user"
#define NMDB_TABLE_MEMBERSHIP        "membership"
#define NMDB_TABLE_ACL               "acl"
#define NMDB_TABLE_PRJLIST           "prjlist"
#define NMDB_TABLE_FREEOBJ           "freeobj"

//CONTROL COLUMNS

//copyinfo
#define NMDB_TABLE_INFO_COLS    4
//RegID, owner, masterpass(hash), FLAGS(FAKE)

//group
#define NMDB_TABLE_GROUP_COLS    5
//RegID, id, name, stat, FLAGS(FAKE)

//user
#define NMDB_TABLE_USER_COLS    7
//RegID, id, name, pass(hashSHA512), last(loginYYYY-MM-DD-hh-mm-ss in shamsi), stat, FLAGS(FAKE)

//membership
#define NMDB_TABLE_MEMBERSHIP_COLS    6
//RegID, nrow, gid, uid, stat, FLAGS(FAKE)

//acl
#define NMDB_TABLE_ACL_COLS    7
//RegID, nrow, gid, uid, objid, perm, FLAGS(FAKE)

//prjlist
#define NMDB_TABLE_PRJLIST_COLS    6
//RegID, prj_objid, owner_uid, name, desc, FLAGS(FAKE)

//freeobj - free'ed object strs
//RegID, objid, FLAGS(FAKE)

//BASE TABLES

//wptclass
//RegID, objid, name, FLAGS(FAKE)

//wptbranch
//RegID, objid, name, FLAGS(FAKE)

//wptdef
//RegID, objid, name, year, class_objid, branch_objid, type(basic, custom, ...), FLAGS(FAKE)

//session - session definition
//RegID, objid, name, wpt_objid, FLAGS(FAKE)

//unit - unit definition
//RegID, objid, name, FLAGS(FAKE)

//itemtype - type definition
//RegID, objid, name(main | surcharge_from_main_list | surcharge_from_preface), desc, FLAGS(FAKE)

//tag - tag definition
//RegID, objid, name, FLAGS(FAKE)

//wptitem
//RegID, objid, wpt_number, desc, unit_objid, wpt_objid, session_objid, type_objid, tag_name_list(;sep), help, FLAGS(FAKE)

//relation
//RegID, objid, item_objid(A), item_objid(B), formula(A,B), desc, FLAGS(FAKE)

#else

#endif
