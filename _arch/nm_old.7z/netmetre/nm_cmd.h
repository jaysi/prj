﻿#ifndef NM_CMD_H
#define NM_CMD_H

//global cmds -- 
#define NM_CMD_NOP			0x0000
#define NM_CMD_FAIL			0x0001

//transaction cmds -- from 0x0030 to 0x004f
#define NM_CMD_TRANS		0x0030
#define NM_CMD_TRANS_BEGIN	(NM_CMD_TRANS+0x0001)	// params are ncmd, total cmd len;
#define NM_CMD_TRANS_END	(NM_CMD_TRANS+0x0002)	// 
#define NM_CMD_TRANS_TERM	(NM_CMD_TRANS+0x0003)	// terminate transaction

//project cmds -- from 0x0020 to 0x003f
#define NM_CMD_PROJECT		0x0020
#define NM_CMD_PROJECT_OPEN	(NM_CMD_PROJECT+0x0001)	// params are 
#define NM_CMD_PROJECT_CLOSE (NM_CMD_PROJECT+0x0002) // 
#define NM_CMD_PROJECT_ADD	(NM_CMD_PROJECT+0x0003)
#define NM_CMD_PROJECT_RM	(NM_CMD_PROJECT+0x0004)
#define NM_CMD_PROJECT_LIST	(NM_CMD_PROJECT+0x0005)
#define NM_CMD_PROJECT_LIST_USER (NM_CMD_PROJECT+0x0006) //list project users

//user cmds -- from 0x0040 to 0x006f
#define NM_CMD_USER			0x0040
#define NM_CMD_USER_ADD		(NM_CMD_USER+0x0001)
#define NM_CMD_USER_RM		(NM_CMD_USER+0x0002)
#define NM_CMD_USER_KICK	(NM_CMD_USER+0x0003)
#define NM_CMD_USER_BAN		(NM_CMD_USER+0x0004)
#define NM_CMD_USER_UNBAN	(NM_CMD_USER+0x0005)
#define NM_CMD_USER_LIST	(NM_CMD_USER+0x0006)
#define NM_CMD_USER_LIST_PROJECT (NM_CMD_USER+0x0007) //list user projects
#define NM_CMD_USER_CHAT	(NM_CMD_USER+0x0008)
#define NM_CMD_USER_CHAT_PVT (NM_CMD_USER+0x0009)
#define NM_CMD_USER_LIST_GROUP (NM_CMD_USER+0x000a)

//group cmds -- from 0x0070 to 0x008f
#define NM_CMD_GROUP		0x0070
#define NM_CMD_GROUP_ADD	(NM_CMD_GROUP+0x0001)
#define NM_CMD_GROUP_RM		(NM_CMD_GROUP+0x0002)
#define NM_CMD_GROUP_JOIN	(NM_CMD_GROUP+0x0003)
#define NM_CMD_GROUP_LEAVE	(NM_CMD_GROUP+0x0004)
#define NM_CMD_GROUP_LIST	(NM_CMD_GROUP+0x0005)
#define NM_CMD_GROUP_LIST_USER	(NM_CMD_GROUP+0x0006)

//invoice cmds -- from 0x0090 to 0x00ff
#define NM_CMD_INVOICE		0x0090
#define NM_CMD_INVOICE_OPEN	(NM_CMD_INVOICE+0x0001)
#define NM_CMD_INVOICE_CLOSE (NM_CMD_INVOICE+0x0002)
#define NM_CMD_INVOICE_ADD	(NM_CMD_INVOICE+0x0003)
#define NM_CMD_INVOICE_RM	(NM_CMD_INVOICE+0x0004)
#define NM_CMD_INVOICE_LIST	(NM_CMD_INVOICE+0x0005)
#define NM_CMD_INVOICE_LIST_USER (NM_CMD_INVOICE+0x0006)
#define NM_CMD_INVOICE_MODIFY (NM_CMD_INVOICE+0x0007)

#define NM_CMD_INVAL		0xffff

//
struct nm_cmd_def_s {
	nm_cmd_t cmd;
	uint16_t nparam;
	const char* name;
	const char* desc;
} nm_cmd_def[] = {

	{NM_CMD_NOP, 0, "nop", "no operation"},
	{NM_CMD_FAIL, 0, "fail", "operation failed"},
	
	{NM_CMD_TRANS_BEGIN, 0, "trans_begin", "transaction begin"},
	{NM_CMD_TRANS_END, 0, "trans_end", "transaction end"},
	{NM_CMD_TRANS_TERM, 0, "trans_term", "transaction termination"},
	
	{NM_CMD_PROJECT_OPEN, 0, "prj_open", "project open"},
	{NM_CMD_PROJECT_CLOSE, 0, "prj_close", "project close"},
	{NM_CMD_PROJECT_ADD, 0, "prj_add", "project add"},
	{NM_CMD_PROJECT_RM, 0, "prj_rm", "project remove"},
	{NM_CMD_PROJECT_LIST, 0, "prj_list", "project list"},
	{NM_CMD_PROJECT_LIST_USER, 0, "prj_list_user", "project list users"},
	
	{NM_CMD_USER_ADD, 0, "user_add", "user add"},
	{NM_CMD_USER_RM, 0, "user_rm", "user remove"},
	{NM_CMD_USER_KICK, 0, "user_kick", "user kick"},
	{NM_CMD_USER_BAN, 0, "user_ban", "user ban"},
	{NM_CMD_USER_UNBAN, 0, "user_unban", "user unban"},
	{NM_CMD_USER_LIST, 0, "user_list", "user list"},
	{NM_CMD_USER_LIST_PROJECT, 0, "user_list_prj", "user list projects"},
	{NM_CMD_USER_CHAT, 0, "user_chat", "user public chat"},
	{NM_CMD_USER_CHAT_PVT, 0, "user_chat_pvt", "user private chat"},
	{NM_CMD_USER_LIST_GROUP, 0, "user_list_group", "user list groups"},

	{NM_CMD_GROUP_ADD, 0, "group_add", "group add"},
	{NM_CMD_GROUP_RM, 0, "group_rm", "group remove"},
	{NM_CMD_GROUP_JOIN, 0, "group_join", "group join"},
	{NM_CMD_GROUP_LEAVE, 0, "group_leave", "group leave"},
	{NM_CMD_GROUP_LIST, 0, "group_list", "group list"},
	{NM_CMD_GROUP_LIST_USER, 0, "group_list_user", "group list users"},
	
	{NM_CMD_INVAL, 0, NULL, NULL},
	
};

//used in packets
struct nm_cmd{
	nm_cmd_t cmd;
	uint16_t nparam;
	char** param;
};

#ifdef __cplusplus
	extern "C" {
#endif

struct nm_cmd_def_s _nm_cmd_find(nm_cmd_t cmd);
struct nm_cmd_def_s _nm_cmd_find_byname(char* name);

#ifdef __cplusplus
	}
#endif

#endif //NM_CMD_H
