﻿#ifndef NM_CLIENT_H
#define NM_CLIENT_H

#include "../lib13/include/lib13.h"

struct netmetre;

struct nm_client {
	nm_thid_t threadid;
	struct nm_link* link;
	nm_pid_t nprj;//number of connected projects
	nm_pid_t* pidlist;
	
	//command packet buffer
	uint32_t cmdpkt_bufsize;
	char* cmdpkt_buf;
	
	//transaction buffer
	struct nm_trans* trans;
	
	struct nm_client* next;
};

#ifdef __cplusplus
    extern "C" {
#endif

    //client side
    error13_t nm_connect(struct netmetre* nm, struct nm_connect_conf* conf);

#ifdef __cplusplus
    }
#endif


#endif // NM_CLIENT_H
