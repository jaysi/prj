﻿#include "nm_dbi.h"
#include "nm_msg.h"

/*
 *
 *prjlist
    #define ACC_TABLE_PRJLIST_COLS    6
//RegID, prj_objid, owner_uid, name, desc, FLAGS(FAKE)
#define ACC_TABLE_PRJLIST           "prjlist"

      if((ret = db_define_table(  db,
                                ACC_TABLE_PRJLIST,
                                ACC_TABLE_PRJLIST,
                                DB_TABLEF_CTL|DB_TABLEF_ENCRYPT|DB_TABLEF_MALLOC,
                                ACC_TABLE_PRJLIST_COLS,

                                "RegID",
                                DB_T_INT,
                                "شماره ثبت",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "nrow",
                                DB_T_BIGINT,
                                "ردیف",
                                "",
                                DB_COLF_HIDE|DB_COLF_AUTO,

                                "gid",
                                DB_T_INT,
                                "گروه",
                                "@group:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "uid",
                                DB_T_INT,
                                "کاربر",
                                "@user:id>name",
                                DB_COLF_LIST|DB_COLF_TRANSL,

                                "objid",
                                DB_T_BIGINT,
                                "objid",
                                "",
                                0,

                                "perm",
                                DB_T_INT,
                                "دسترسی",
                                "",
                                0,

                                "flags",
                                DB_T_INT,
                                "پرچم",
                                "",
                                DB_COLF_VIRTUAL|DB_COLF_HIDE,

                    )) != E13_OK){

        return e13_error(E13_NOLFS);

    }

*/

//the default base and ctl dbs are provided to the program
error13_t _nmdb_install_base(struct netmetre* nm){

    if(!nmdb_isinit(nm)){
        return e13_ierror(&nm->e, E13_MISUSE, "s", NM_MSG_ALREADYINIT);
    }

    return E13_OK;
}

error13_t _nmdb_create_table_range(db13 *db, db_table_id start, db_table_id end){

    return e13_error(E13_IMPLEMENT);

}
