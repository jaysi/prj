﻿#ifndef NM_TYPE_H
#define NM_TYPE_H

typedef long long int nm_ival_t;
typedef long double nm_fval_t;
typedef uint16_t nm_cmd_t;
typedef uint32_t nm_clientid_t;
typedef uint32_t nm_transid_t;
typedef uint32_t nm_pid_t;
typedef int nm_sock_t;

#endif // NM_TYPE_H
