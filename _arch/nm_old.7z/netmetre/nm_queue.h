#ifndef NM_QUEUE_H
#define NM_QUEUE_H

#include "nm_project.h"
#include "nm_types.h"
#include "nm_cmd.h"

struct nm_trans{
	nm_clientid_t cid;
	nm_transid_t transid;
	uint16_t ncmd;
	struct nm_cmd* cmd;
};

struct nm_q{
    nm_pid_t pid;
    struct nm_q* next;
};

#endif // NM_QUEUE_H
