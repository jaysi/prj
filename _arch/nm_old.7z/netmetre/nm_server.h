﻿#ifndef NM_SERVER_H
#define NM_SERVER_H

#include "../lib13/include/lib13.h"

struct netmetre;

#ifdef __cplusplus
    extern "C" {
#endif

    //server side
    error13_t nm_wait(struct netmetre* nm, struct nm_wait_conf* conf);

#ifdef __cplusplus
    }
#endif


#endif // NM_SERVER_H
