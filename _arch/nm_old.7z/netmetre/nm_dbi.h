﻿#ifndef NM_DBI_H
#define NM_DBI_H

#include "nm_db.h"

#ifdef __cplusplus
    extern "C" {
#endif

error13_t _nmdb_create_table_range(struct db13* db, enum nmdb_table_id start, enum nmdb_table_id end);

#ifdef __cplusplus
    }
#endif

#endif // NM_DBI_H
