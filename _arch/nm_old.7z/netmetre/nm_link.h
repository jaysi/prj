#ifndef NM_LINK_H
#define NM_LINK_H

struct nm_link{
	nm_sock_t sockfd;	
};

#endif // NM_LINK_H