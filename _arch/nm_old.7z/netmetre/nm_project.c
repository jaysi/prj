﻿#include "nm_project.h"

error13_t nm_prj_add(struct nm_session* sess, char* name, char* parent){
    return E13_OK;
}

error13_t nm_prj_rm(struct nm_session* sess, char* name){
    return E13_OK;
}

error13_t nm_prj_open(struct nm_session* sess, char* name){
    return E13_OK;
}

error13_t nm_prj_close(struct nm_session* sess, char* name){
    return E13_OK;
}

error13_t nm_prj_set_spec(struct nm_session* sess, char* name, struct nm_prj_spec* spec){
    return E13_OK;
}

error13_t nm_prj_set_ptr(nm_session *sess, char* name, void *ptr){
    return E13_OK;
}

error13_t nm_prj_get_ptr(nm_session* sess, char* name, void **ptr){
    return E13_OK;
}

