﻿#ifndef NM_INVOICE_H
#define NM_INVOICE_H

#include "../lib13/include/lib13.h"

//this way every one could ensure that this is the real invoice copy he is using.
typedef char nm_inv_copy_hash[SHA512_HASH_LEN];

#endif // NM_INVOICE_H
