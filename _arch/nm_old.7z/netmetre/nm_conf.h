﻿#ifndef NM_CONF_H
#define NM_CONF_H

#define NM_DEF_MAX_WARN    10
#define NM_DEF_MAX_ESTR    256

#define NM_MODE_NONE    0x00
#define NM_MODE_SERVER  0x01
#define NM_MODE_CLIENT  0x02

#define NM_HOST_LOCAL   "localhost"
#define NM_DEF_HOST NM_HOST_LOCAL
#define NM_DEF_PORT "13130"

#ifdef linux
#define NM_DEF_PATH "~"
#else
#define NM_DEF_PATH "."
#endif

struct nm_wait_conf {
    char* port;
};

struct nm_connect_conf {
    char* host;
    char* port;
    char* username;
    char* password;
};

#endif // NM_CONF_H
