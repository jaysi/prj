﻿#include "nm_dbi.h"
#include "netmetre.h"

/*
 *  init, open base, ctl database
*/

error13_t nmdb_init(struct netmetre* nm){

    char path[MAXPATHNAME];

    error13_t ret;

    nm->basedb = (struct db13*)m13_malloc(sizeof(struct db13));
    if(!nm->basedb){
        return e13_error(E13_NOMEM);
    }
    nm->ctldb = (struct db13*)m13_malloc(sizeof(struct db13));
    if(!nm->ctldb){
        m13_free(nm->basedb);
        return e13_error(E13_NOMEM);
    }

    if((ret = db_init(nm->basedb, DB_DRV_SQLITE)) != E13_OK){
        e13_copy(&nm->e, &nm->basedb->e);
        return ret;
    }

    if((ret = db_init(nm->ctldb, DB_DRV_SQLITE)) != E13_OK){
        e13_copy(&nm->e, &nm->ctldb->e);
        return ret;
    }

    snprintf(path, MAXPATHNAME, "%s/%s", nm->path?nm->path:"", NMDB_DB_BASE);

    if((ret = db_open(nm->basedb, DB_DEF_HOSTNAME, DB_DEF_PORT, DB_DEF_USERNAME, DB_DEF_PASSWORD, path)) != E13_OK){
        e13_copy(&nm->e, &nm->basedb->e);
        return ret;
    }

    snprintf(path, MAXPATHNAME, "%s/%s", nm->path?nm->path:"", NMDB_DB_CTL);

    if((ret = db_open(nm->ctldb, DB_DEF_HOSTNAME, DB_DEF_PORT, DB_DEF_USERNAME, DB_DEF_PASSWORD, path)) != E13_OK){
        e13_copy(&nm->e, &nm->ctldb->e);
        return ret;
    }

    return E13_OK;

}

error13_t nmdb_destroy(struct netmetre* nm){

    db_close(nm->basedb);
    db_close(nm->ctldb);

    return E13_OK;

}
