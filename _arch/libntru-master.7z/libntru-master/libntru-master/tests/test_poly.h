int test_poly();
