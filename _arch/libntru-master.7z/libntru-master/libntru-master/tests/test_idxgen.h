#ifndef TEST_IDXGEN_H
#define TEST_IDXGEN_H

int test_idxgen();

#endif
