﻿#include <unistd.h>
#include <stddef.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "../lib13/include/lib13.h"
#include "db13.h"

#include "db13_msg_en.h"

#define TABSEP ":"
#define COLSEP "->"
#define REFSEP ","

#define SQLITE3H(db) ((db)->h)
#define SQLITE3ST(stmt) ((stmt)->h)

#define ASSERTTID(tid) (tid > (db)->ntables?false_:tid <= DB13_TID_INVAL?false_:true_)
#define ASSERTCOLID(tid, colid) (colid > (db)->table_info[tid].ncols?false_:colid <= DB13_COLID_INVAL?false_:true_)
#define CKTID(tid) if(!ASSERTTID(tid)) return e13_error(E13_RANGE)
#define CKCOLID(tid, colid) if(!ASSERTCOLID(tid, colid)) return e13_error(E13_RANGE)

#define MAXSQL  2048
#define MAXTABLENAME 50

#define NA  ""
#define ERR ""

struct logic_sign_s{
    char* sign;
} logic_sign[] = {
    {"LIKE"},
    {"NOT LIKE"},
    {"="},
    {"<>"},
    {"<"},
    {"<="},
    {">"},
    {">="},
    {"BETWEEN"},
    {NULL}
};

struct logic_comb_sign_s{
    char* sign;
} logic_comb_sign[] = {
    {" "},
    {"AND"},
    {"OR"},
    {"NOT"},
    {NULL}
};

struct coltype_name{
    char* name;
} type_name[] = {
{"INT"},
{"INT"},
{"REAL"},
{"TEXT"},
{"INT"},
{"INT"},
{"BLOB"},
{NULL}
};

struct db13* db13_find_path(struct db13* first, char* path){
    struct db13* db;
    for(db = first; db; db = db->next){
        if(!strcmp(path, db->path)) return db;
    }
    return NULL;
}

struct db13* db13_find_alias(struct db13* first, char* alias){
    struct db13* db;
    for(db = first; db; db = db->next){
        if(!strcmp(alias, db->alias)) return db;
    }
    return NULL;
}

char* db13_alias(struct db13* db){
    return db->alias;
}

char* db13_t_name(struct db13* db, db13_tid_t id){
    if(!ASSERTTID(id)) return NULL;
    return db->table_info[id].name;
}

char* db13_t_alias(struct db13* db, db13_tid_t id){
    if(!ASSERTTID(id)) return NULL;
    return db->table_info[id].alias;
}

char* db13_col_alias(struct db13* db, db13_tid_t id, db13_colid_t col){
    if(!ASSERTTID(id)) return NULL;
    if(!ASSERTCOLID(id, col)) return NULL;
    return db->table_info[id].col_alias[col];
}

char* db13_col_name(struct db13* db, db13_tid_t id, db13_colid_t col){
    if(!ASSERTTID(id)) return NULL;
    if(!ASSERTCOLID(id, col)) return NULL;
    return db->table_info[id].col_name[col];
}

db13_tid_t db13_id_table(struct db13* db, char* name){
    db13_tid_t ret;
    for(ret = 0; ret < db->ntables; ret++){
        if(!strcmp(name, db->table_info[ret].name)) break;
    }

    return ret==db->ntables?DB13_TID_INVAL:ret;
}

db13_tid_t db13_id_table_alias(struct db13* db, char* alias){
    db13_tid_t ret;
    for(ret = 0; ret < db->ntables; ret++){
        if(!strcmp(alias, db->table_info[ret].alias)) break;
    }

    return ret==db->ntables?DB13_TID_INVAL:ret;
}

db13_colid_t db13_id_col(struct db13* db, db13_tid_t id, char* name){
    int ret;

    if(!ASSERTTID(id)) return DB13_COLID_INVAL;

    for(ret = 0; ret < db->table_info[id].ncols; ret++){
        if(!strcmp(name, db->table_info[id].col_name[ret])) break;
    }

    return ret==db->table_info[id].ncols?DB13_COLID_INVAL:ret;
}

db13_colid_t db13_id_col_alias(struct db13* db, db13_tid_t id, char* alias){
    int ret;

    if(!ASSERTTID(id)) return DB13_COLID_INVAL;

    for(ret = 0; ret < db->table_info[id].ncols; ret++){
        if(!strcmp(alias, db->table_info[id].col_alias[ret])) break;
    }

    return ret==db->table_info[id].ncols?DB13_COLID_INVAL:ret;
}

db13_colid_t db13_table_cols(struct db13* db, db13_tid_t id){
    if(!ASSERTTID(id)) return DB13_COLID_INVAL;
    return db->table_info[id].ncols;
}

db13_colid_t db13_table_fakes(struct db13* db, db13_tid_t id){
    if(!ASSERTTID(id)) return DB13_COLID_INVAL;
    return db->table_info[id].nfakes;
}


db13_rowid_t db13_table_rows(struct db13* db, db13_tid_t id){

    return DB13_ROWID_INVAL;
}

enum db13_type_id db13_id_coltype(struct db13* db, db13_tid_t tid, db13_colid_t col){

    if(!ASSERTTID(tid)) return DB13_TY_INVAL;
    if(!ASSERTCOLID(tid, col)) return DB13_TY_INVAL;

    return db->table_info[tid].col_type[col];
}

db13_col_flag_t db13_col_flag(struct db13* db, db13_tid_t tid, db13_colid_t col){

    if(!ASSERTTID(tid)) return 0;
    if(!ASSERTCOLID(tid, col)) return 0;

    return db->table_info[tid].flags[col];
}

error13_t db13_set_col_flag(struct db13* db, db13_tid_t tid, db13_colid_t col, db13_col_flag_t flag){

    CKTID(tid);
    CKCOLID(tid, col);

    db->table_info[tid].flags[col] |= flag;

    return E13_OK;
}

error13_t db13_unset_col_flag(struct db13* db,db13_tid_t tid, db13_colid_t col, db13_col_flag_t flag){

    CKTID(tid);
    CKCOLID(tid, col);

    db->table_info[tid].flags[col] &= ~flag;

    return E13_OK;
}

error13_t db13_create_table(struct db13* db, db13_tid_t id){

    char sql[MAXSQL];
    size_t len = 0;
    int i;
#define RLEN (MAXSQL - len)

    CKTID(id);

    switch(db->engine){
    case DB13_ENGINE_SQLITE:

        snprintf(sql + len, RLEN, "CREATE TABLE IF NOT EXISTS %s( ", db->table_info[id].name);

    len = strlen(sql);

    for(i = 0; i < db->table_info[id].ncols; i++){
        snprintf(sql + len, RLEN, "%s %s%s",
                 db->table_info[id].col_name[i],
                 type_name[db->table_info[id].col_type[i]].name,
                 i == db->table_info[id].ncols - 1?",urid INT PRIMARY KEY);":", ");
        len = strlen(sql);
    }

#undef RLEN

    if(sqlite3_exec(SQLITE3H(db), sql, NULL, NULL, &emsg) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    break;

    default:
    return e13_error(E13_IMPLEMENT);
    break;
    }


    return E13_OK;

}

error13_t db13_create_db(struct db13* db){

    db13_tid_t id;
    error13_t e;
    char* emsg;

    for(id = 0; id < db->ntables; id++){
        if(!(db->table_info[id].flags & DB13_TABF_FAKE)){
            if((e = db13_create_table(db, id)) != E13_OK){
                return e;
            }
        }
    }

    switch(db->engine){

    case DB13_ENGINE_SQLITE:

    if(sqlite3_exec(SQLITE3H(db), "CREATE TABLE tctl(name text, urid INT);", NULL, NULL, &emsg) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", emsg);
    }

    break;

    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }

    return E13_OK;

}

error13_t _db13_fill_urid(struct db13* db){

    sqlite3_stmt* stmt;

    switch(db->engine){
    case DB13_ENGINE_SQLITE:

    if(sqlite3_prepare_v2(SQLITE3H(db), "SELECT MAX(urid) FROM ?1;", -1, &stmt, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    for(db13_tid_t i = 0; i < db->ntables; i++){

        if(sqlite3_bind_text(stmt, 1, db->table_info[i].name, -1, NULL) != SQLITE_OK){
            return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
        }

        switch(sqlite3_step(stmt)){
            case SQLITE_ROW:
            case SQLITE_DONE:
            db->table_info[i].urid = (db13_urid_t)sqlite3_column_int64(stmt, 0);
            break;

        default:
            return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            break;

        }

        sqlite3_reset(stmt);

    }

    sqlite3_finalize(stmt);
    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }
    return E13_OK;

}

error13_t db13_open(struct db13* db,
                    enum db13_engine_t engine,
                    char* name, char* alias,
                    struct db13_table_info* table_info,
                    db13_tid_t ntables){
    sqlite3* sdb;
    //sqlite3_stmt stmt;
    int do_create = false_;
    error13_t e;

    if(access(name, F_OK)) do_create = true_;

    db->table_info = table_info;
    db->ntables = ntables;
    db->engine = engine;

    db->next = NULL;

    switch(db->engine){
    case DB13_ENGINE_SQLITE:
    if(sqlite3_open(name, &sdb) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    db->h = sdb;

    //enable foerign keys
    if(sqlite3_exec(SQLITE3H(db), "PRAGMA foreign_keys = ON", NULL, NULL, &emsg) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;

    }

    if(do_create){
        if((e = db13_create_db(db)) != E13_OK){
            return e;
        }
    }

    if((e = _db13_fill_urid(db)) != E13_OK){
        return e;
    }

    db->alias = (char*)malloc(strlen(alias)+1);
    strcpy(db->alias, alias);

    db->path = (char*)malloc(strlen(name)+1);
    strcpy(db->path, name);

    return E13_OK;
}

error13_t db13_close(struct db13* db){

    switch(db->engine){
    case DB13_ENGINE_SQLITE:
    if(SQLITE3H(db)) sqlite3_close(SQLITE3H(db));
    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }

    if(db->alias) free(db->alias);
    if(db->alias) free(db->path);
    return E13_OK;
}

error13_t db13_select_all(struct db13* db, db13_tid_t id, struct db13_stmt *st){

    char sql[MAXSQL];

    sqlite3_stmt* stmt = NULL;

    CKTID(id);

    switch(db->engine){
    case DB13_ENGINE_SQLITE:

    snprintf(sql, MAXSQL, "SELECT * FROM %s;", t_name(id), db->this_id);

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }

    st->h = stmt;
    st->db = db;
    st->magic = DB13_STMT_MAGIC;

    return E13_OK;

}

error13_t db13_trunc_table(struct db13* db, db13_tid_t tid){
    char sql[MAXSQL];

    CKTID(tid);

    switch(db->engine){
    case DB13_ENGINE_SQLITE:

    snprintf(sql, MAXSQL, "DELETE FROM %s;", t_name(tid));
    if(sqlite3_exec(SQLITE3H(db), sql, NULL, NULL, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }
    return E13_OK;
}

error13_t db13_next(struct db13_stmt* stmt){

    switch(stmt->db->engine){
    case DB13_ENGINE_SQLITE:

    switch(sqlite3_step(SQLITE3ST(stmt))){

    case SQLITE_ROW:
        return E13_CONTINUE;
        break;

    case SQLITE_DONE:
    case SQLITE_OK:
        return E13_OK;
        break;

    default:
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    break;

        break;

    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }

    }
}

int db13_getcol_int(struct db13_stmt* stmt, db13_colid_t col){

    switch(stmt->db->engine){

    case DB13_ENGINE_SQLITE:
    return sqlite3_column_int(SQLITE3ST(stmt), col);
    break;

    default:
        return e13_error(E13_IMPLEMENT);
        break;

    }
}

const char* db13_getcol_text(struct db13_stmt* stmt, db13_colid_t col){

    switch(stmt->db->engine){
    case DB13_ENGINE_SQLITE:
    return (const char*)sqlite3_column_text(SQLITE3ST(stmt), col);
        break;
        default:
            return e13_error(E13_IMPLEMENT);
            break;
        }
}

double db13_getcol_double(struct db13_stmt* stmt, db13_colid_t col){

    switch(stmt->db->engine){
    case DB13_ENGINE_SQLITE:
    return sqlite3_column_double(SQLITE3ST(stmt), col);
        break;
        default:
            return e13_error(E13_IMPLEMENT);
            break;
        }
}

int64_t db13_getcol_int64(struct db13_stmt* stmt, db13_colid_t col){

    switch(stmt->db->engine){
    case DB13_ENGINE_SQLITE:
    return sqlite3_column_int64(SQLITE3ST(stmt), col);
        break;
        default:
            return e13_error(E13_IMPLEMENT);
            break;
        }
}

error13_t db13_finalize(struct db13_stmt* stmt){

    if(stmt->magic != DB13_STMT_MAGIC) return e13_error(E13_MISUSE);

    switch(stmt->db->engine){
    case DB13_ENGINE_SQLITE:

    if(sqlite3_finalize(SQLITE3ST(stmt)) == SQLITE_OK){
        stmt->magic = 0;
        return E13_OK;
    }

    return e13_uerror(&stmt->db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));

        break;
        default:
            return e13_error(E13_IMPLEMENT);
            break;
        }

}

error13_t db13_reset(struct db13_stmt* st){
    if(st->magic != DB13_STMT_MAGIC) return e13_error(E13_MISUSE);

    switch(st->db->engine){
    case DB13_ENGINE_SQLITE:

    sqlite3_reset(SQLITE3ST(stmt));

    break;
    default:
        return e13_error(E13_IMPLEMENT);
        break;
    }
    return E13_OK;
}

db13_urid_t db13_get_urid(struct db13* db, db13_tid_t id){
    CKTID(id);
    return (db->table_info[id].urid++);
}

error13_t db13_insert(struct db13* db, db13_tid_t id,
                      char** col,size_t* colsize,
                      struct db13_stmt* st){

    int i;
    char sql[MAXSQL];
    size_t len = 0;
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[D13_ITEMS];
    db13_urid_t urid;

    CKTID(id);

    if(st->magic == DB13_STMT_MAGIC){
        db13_reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "INSERT INTO %s(", db->table_info[id].name);
    len = strlen(sql);

    for(i = 0; i < db->table_info[id].ncols; i++){
        if(i == db->table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "%s, urid",db->table_info[id].col_name[i]);
        } else {
            snprintf(sql+len, RLEN, "%s, ",db->table_info[id].col_name[i]);
        }
        len = strlen(sql);
    }

    snprintf(sql+len, RLEN, ") VALUES(");
    len = strlen(sql);

    for(i = 0; i < db->table_info[id].ncols; i++){
        if(i == db->table_info[id].ncols - 1){
            snprintf(sql+len, RLEN, "?%i, ?%i", i+1, i+2);
        } else {
            snprintf(sql+len, RLEN, "?%i, ",i+1);
        }
        len = strlen(sql);
    }

    snprintf(sql+len, RLEN, ");");

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    st->h = stmt;
    st->magic = DB13_STMT_MAGIC;
    st->db = db;

    if(!col) return E13_CONTINUE;

bind_data:

    printf("ncols = %i", db->table_info[id].ncols);

    for(i = 0; i < db->table_info[id].ncols; i++){

        perr(col[i]);

        switch(id_coltype(id, i)){

        case DB13_TY_BOOL:
        case DB13_TY_INT:
            if(sqlite3_bind_int(SQLITE3ST(stmt), i+1, atoi(col[i])) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        case DB13_TY_INT64:
            if(sqlite3_bind_int64(SQLITE3ST(stmt), i+1, atoll(col[i])) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        case DB13_TY_DOUBLE:
            if(sqlite3_bind_double(SQLITE3ST(stmt), i+1, atof(col[i])) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        case DB13_TY_DATE:
            d13_resolve_date(col[i], date);
            if(sqlite3_bind_int(SQLITE3ST(stmt), i+1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        case DB13_TY_TEXT:
            if(sqlite3_bind_text(SQLITE3ST(stmt), i+1, col[i], -1, NULL) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        case DB13_TY_RAW:
            if(sqlite3_bind_blob(SQLITE3ST(stmt), i+1, col[i], colsize[i], NULL) != SQLITE_OK){
                return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
            }
            break;

        default:
            break;
        }

    }

    //bind urid
    urid = db13_get_urid(db, id);
    if(urid == DB13_ROWID_INVAL) return e13_uerror(&db->e, E13_FULL, "s", "No more ROWID!");
    if(sqlite3_bind_int64(SQLITE3ST(stmt), i+1, (int64_t)urid) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    switch(sqlite3_step(SQLITE3ST(stmt))){
    case SQLITE_OK:
    case SQLITE_DONE:
        break;
    default:
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
        break;
    }

    return E13_OK;
}

error13_t db13_assm_logic(char* sql, int nlogic, struct db13_logic_s* logic, int base){
    int i;
    size_t len;
    if(nlogic){

        snprintf(sql + len, RLEN, " WHERE ", db->table_info[id].name);
        len = strlen(sql);

        for(i = base; i < nlogic + base; i++){

            if(!(logic[i-1].flags & LOGICF_COL_CMP)){

                snprintf(sql + len, RLEN, "%s %s %s ?%i",
                         i == base?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         i
                        );

            } else {

                snprintf(sql + len, RLEN, "%s %s %s %s",
                         i == base?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         logic[i-1].sval
                        );

            }

            len = strlen(sql);

        }

    }

    return E13_OK;
}

db13_colid_t db13_collect(struct db13* db,
                         db13_tid_t id,
                         char** cols,
                         int nlogic, struct db13_logic_s* logic,
                         char* sortcol, enum db13_sort_t stype,
                         struct db13_stmt* st){

    char sql[MAXSQL];
    size_t len = 0;
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    int i;
    int date[D13_ITEMS];

    snprintf(sql + len, RLEN, "SELECT ");
    len = strlen(sql);

    if(!cols){
        snprintf(sql + len, RLEN, "* ");
        len = strlen(sql);
    } else {
        while(*cols){
            snprintf(sql + len, RLEN, "%s%s", *cols, (cols+1)?",":" ");
            len = strlen(sql);
            cols++;
        }
    }

    snprintf(sql + len, RLEN, "FROM %s", db->table_info[id].name);
    len = strlen(sql);

    if(nlogic){

        snprintf(sql + len, RLEN, " WHERE ", db->table_info[id].name);
        len = strlen(sql);

        for(i = 1; i < nlogic + 1; i++){

            if(!(logic[i-1].flags & LOGICF_COL_CMP)){

                snprintf(sql + len, RLEN, "%s %s %s ?%i",
                         i == 1?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         i
                        );

            } else {

                snprintf(sql + len, RLEN, "%s %s %s %s",
                         i == 1?"":logic_comb_sign[logic[i-1].comb].sign,
                         col_name(id, logic[i-1].col),
                         logic_sign[logic[i-1].logic].sign,
                         logic[i-1].sval
                        );

            }

            len = strlen(sql);

        }

    }

    if(sortcol){
        snprintf(sql + len, RLEN, " ORDER BY %s %s", sortcol, stype == DB13_SO_DEC?"DESC":"");
        len = strlen(sql);
    }
#undef RLEN
    strcat(sql, ";");

    assert(db);
    assert(SQLITE3H(db));

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    if(nlogic){

        for(i = 1; i < nlogic + 1; i++){

            if(!(logic[i-1].flags & LOGICF_COL_CMP)){

                switch(id_coltype(id, logic[i-1].col)){

                case DB13_TY_BOOL:
                case DB13_TY_INT:
                    if(sqlite3_bind_int(stmt, i, logic[i-1].ival) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                break;

                case DB13_TY_INT64:
                    if(sqlite3_bind_int64(stmt, i, logic[i-1].llval) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                break;

                case DB13_TY_DOUBLE:
                    if(sqlite3_bind_int64(stmt, i, logic[i-1].dval) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                break;

                case DB13_TY_DATE:
                    if(d13_resolve_date(logic[i-1].sval, date) != E13_OK){
                        //perr2(logic[i-1].sval);
                        continue;
                    }

                    if(sqlite3_bind_int(stmt, i, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                    break;

                case DB13_TY_TEXT:
                    p("bind %s at %i", logic[i-1].sval, i);
                    if(sqlite3_bind_text(stmt, i, logic[i-1].sval, -1, NULL) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                break;

                case DB13_TY_RAW:
                    p("bind %s at %i", logic[i-1].sval, i);
                    if(sqlite3_bind_blob(stmt, i, logic[i-1].sval, logic[i-1].datasize, NULL) != SQLITE_OK){
                        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
                    }
                    break;

                default:
                    break;

                }

            }

        }

    }

    st->h = stmt;
    st->db = db;
    st->magic = DB13_STMT_MAGIC;

    return E13_OK;

}

error13_t update_col_byid(struct db13* db,
                          db13_tid_t tid,
                          int nlogic, struct db13_logic_s* logic,
                          db13_colid_t col,
                          char* val,
                          struct db13_stmt* st){

    char sql[MAXSQL];
#define RLEN (MAXSQL - len)
    sqlite3_stmt* stmt;
    //INSERT INTO table(list...) VALUES(list...);
    int date[D13_ITEMS];

    if(st->magic == DB13_STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    snprintf(sql, MAXSQL, "UPDATE %s SET %s = ?1 WHERE id = ?2", db->table_info[tid].name, col_name(tid, col));

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(SQLITE3H(db)));
        return false_;
    }

    st->h = stmt;
    st->magic = DB13_STMT_MAGIC;

bind_data:

    switch(id_coltype(tid, col)){

    case DB13_TY_BOOL:
    case DB13_TY_INT:
        if(sqlite3_bind_int(SQLITE3ST(stmt), 1, atoi(val)) != SQLITE_OK){
            perrdb(sqlite3_errmsg(SQLITE3H(db)));
            return false_;
        }
        break;

    case DB13_TY_DATE:
        d13_resolve_date(val, date);
        if(sqlite3_bind_int(SQLITE3ST(stmt), 1, (int)d13_jdayno(date[0], date[1], date[2])) != SQLITE_OK){
            perrdb(sqlite3_errmsg(SQLITE3H(db)));
            return false_;
        }
        break;

    case DB13_TY_TEXT:
        if(sqlite3_bind_text(SQLITE3ST(stmt), 1, val, -1, NULL) != SQLITE_OK){
            perrdb(sqlite3_errmsg(SQLITE3H(db)));
            return false_;
        }
        break;

    default:
        if(sqlite3_bind_blob(SQLITE3ST(stmt), 1, val, strlen(val)+1, NULL) != SQLITE_OK){
            perrdb(sqlite3_errmsg(SQLITE3H(db)));
            return false_;
        }
        break;
    }

    switch(sqlite3_step(SQLITE3ST(stmt))){
    case SQLITE_DONE:
        if(!sqlite3_changes(SQLITE3H(db))) return continue_;
        break;
    default:
        perrdb(sqlite3_errmsg(SQLITE3H(db)));
        return false_;
        break;
    }

    perr("UPDATE TRUE");
    return E13_OK;
}

//originally get_last_id
int db13_get_ipeak(struct db13* db, db13_tid_t tid, char* colname){

    char sql[MAXSQL];
    int row;

    sqlite3_stmt* stmt;

    CKTID(tid);

    snprintf(sql, MAXSQL, "SELECT * FROM %s ORDER BY %s DESC;", db->table_info[tid].name, colname);

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }

    switch(sqlite3_step(stmt)){
    case SQLITE_ROW:
        row = sqlite3_column_int(stmt, id_col(tid, colname));
        sqlite3_finalize(stmt);
        return row;
        break;

    case SQLITE_DONE:
    case SQLITE_OK:
        sqlite3_finalize(stmt);
        //no entries
        return 0;
        break;
    default:
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
        break;

    }

    return e13_error(E13_ERROR);
}

error13_t db13_rollback(struct db13* db){
    //TODO
    if(sqlite3_exec(SQLITE3H(db), "ROLLBACK TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    return E13_OK;
}

error13_t db13_start_trans(struct db13* db){
    //TODO
    if(sqlite3_exec(SQLITE3H(db), "BEGIN TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    return E13_OK;
}

error13_t db13_end_trans(struct db13* db){
    //TODO
    if(sqlite3_exec(SQLITE3H(db), "COMMIT TRANSACTION;", NULL, NULL, NULL) != SQLITE_OK){
        return e13_uerror(&db->e, E13_ERROR, "s", sqlite3_errmsg(SQLITE3H(db)));
    }
    return E13_OK;
}

static inline int countsub(char* str, char* sub){
    int ret = 0;
    char* needle = str;
    while(needle = strstr(needle, sub)){
        needle += strlen(sub);
        ret++;
    }
}

error13_t db13_transl_xref(struct db13* db,
                           char* xref,
                           char* xrefval,
                           size_t xrefvalsize,
                           char** val,
                           size_t* valsize){

    sqlite3_stmt stmt;
    error13_t ret;
    char* col[2];
    struct db13_logic_s logic;
    db13_tid_t tid;
    db13_colid_t colid;
    db13_type_id type;

    char* table, *keycolname, *refcolname, *needle;

    char* base = (char*)malloc(strlen(xref)+1);
    strcpy(base, xref);

    table = base;
    needle = strstr(base, TABSEP);
    if(!needle) return e13_error(E13_MISUSE);
    *needle = '\0';

    keycolname = needle + strlen(TABSEP);
    needle = strstr(keycolname, COLSEP);
    if(!needle) return e13_error(E13_MISUSE);
    *needle = '\0';

    refcolname = needle + strlen(COLSEP);
    needle = strstr(refcolname, REFSEP);
    if(needle){
        *needle = '\0';
        needle += strlen(REFSEP);
    }

    //resolve to value
    col[0] = refcolname;
    col[1] = NULL;

    tid = db13_id_table(db, table);
    colid = db13_id_col(db, tid, keycolname);
    type = db13_id_coltype(db13, tid, colid);

    logic.col = colid;
    logic.comb  = DB13_LOGICOMB_NONE;
    logic.flags = 0;

    switch(type){
        case DB13_TY_TEXT:
        case DB13_TY_RAW:
        logic.logic = DB13_LOGIC_LIKE;
        logic.sval = xrefval;
        logic.datasize = xrefvalsize;
        break;
    default:
        logic.logic = DB13_LOGIC_EQ;
        break;
    }

    switch(type){
        case DB13_TY_DATE:
        case DB13_TY_BOOL:
        case DB13_TY_INT:
            logic.ival = (int)(*xrefval);
            break;
        case DB13_TY_INT64:
            logic.llval = (long long)(*xrefval);
            break;
        case DB13_TY_DOUBLE:
            logic.dval = (double)(*xrefval);
            break;
    default:
        break;
    }

    if((ret = db13_collect(db, tid, col, 1, &logic, NULL, DB13_SO_INC, &stmt)) != E13_OK){
        return ret;
    }

    colid = db13_id_col(db, tid, refcolname);

    switch(type){
        case DB13_TY_DATE:
        case DB13_TY_BOOL:
        case DB13_TY_INT:
            *val = db13_getcol_int(stmt, colid);
            break;
        case DB13_TY_INT64:
            *val = db13_getcol_int64(stmt, colid);
            break;
        case DB13_TY_DOUBLE:
            *val = db13_getcol_double(stmt, colid);
            break;
    case DB13_TY_TEXT:
            *val = db13_getcol_text(stmt, colid);
        break;
    case DB13_TY_RAW:
            *valsize = sqlite3_column_blob();
        break;
    default:
        break;
    }

    if(needle){
        return e13_error(E13_IMPLEMENT);
        ret = db13_transl_xref(db, needle, *val, *valsize, val, valsize);
    }

    free(base);
    return ret;

}

int delete_id(struct db13* db, db13_tid_t tid, char* col, int id, int store_id, struct db13_stmt* st){

    char sql[MAXSQL];
    sqlite3_stmt* stmt;
    static int has_store_id;

    if(st->magic == DB13_STMT_MAGIC){
        reset(st);
        goto bind_data;
    }

    if(id_col(tid, "store_id") > -1) has_store_id = 1;
    else has_store_id = 0;

    snprintf(sql, MAXSQL, "DELETE FROM %s WHERE %s = ?1%s", db->table_info[tid].name, col, has_store_id?" AND store_id = ?2;":";");

    if(sqlite3_prepare_v2(SQLITE3H(db), sql, -1, &stmt, NULL) != SQLITE_OK){
        perrdb(sqlite3_errmsg(SQLITE3H(db)));
        return false_;
    }

    st->h = stmt;
    st->magic = DB13_STMT_MAGIC;

bind_data:

    if(sqlite3_bind_int(stmt, 1, id) != SQLITE_OK){
        perrdb(sqlite3_errmsg(SQLITE3H(db)));
        return false_;
    }

    if(has_store_id){
        if(sqlite3_bind_int(stmt, 2, store_id) != SQLITE_OK){
            perrdb(sqlite3_errmsg(SQLITE3H(db)));
            return false_;
        }
    }

    if(sqlite3_step(stmt) != SQLITE_DONE){
        perrdb(sqlite3_errmsg(SQLITE3H(db)));
        return false_;
    }

    return E13_OK;

}

char* create_multi_field(int n, struct mval* val){

    size_t bufsize = 0, pos = 0;
    int i;

    char* buf;

    if(!n){
        return NULL;
    }

    for(i = 0; i < n; i++){
        bufsize += strlen(val[i].name) + strlen(val[i].val) + 2;
    }

    snprinte2("bufsize = %u", bufsize);
    printe2();

    bufsize++;

    buf = (char*)malloc(bufsize);

    for(i = 0; i < n; i++){
        snprintf(buf + pos, bufsize - pos, "%s:%s%s", val[i].name, val[i].val, i < n - 1?";":"");
        pos += strlen(buf);
    }

    snprinte2("pos = %u", pos);
    printe2();

    return buf;
}

struct mval* parse_multi_field(char* mstr, int* n){
    char* pack[2];
    char** ary, **ary1;
    struct mval* val;
    int i;    
    pack[0] = "\"";
    pack[1] = NULL;
    *n = s13_exparts(mstr, ";", pack, '\\');
    if(!(*n)) return NULL;
    val = (struct mval*)malloc((*n)*sizeof(struct mval));
    ary = s13_exmem(*n);
    s13_explode(mstr, ";", pack, '\\', ary);
    i = s13_exparts(ary[0], ":", pack, '\\');
    if(!i) return NULL;
    ary1 = s13_exmem(i);
    for(i = 0; i < *n; i++){
        perr(ary[i]);
        s13_explode(ary[i], ":", pack, '\\', ary1);
        (val)[i].name = ary1[0];
        perr(ary1[0]);
        (val)[i].val = ary1[1];
        perr(ary1[1]);
    }

    s13_free_exmem(ary);
    s13_free_exmem(ary1);

    return val;
}

char* dyn_copy_str(char* str){
    unsigned len;
    if(str) len = strlen(str);
    else len = 0;

    char* buf = (char*)(malloc(len+1));
    if(len) strcpy(buf, str);
    else *buf = 0;
    return buf;
}
