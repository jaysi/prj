﻿#include "db13_sqlite3.h"

#include "../sqlite/sqlite3.h"
#include "../lib13/include/lib13.h"

#define _deb_sql _DebugMsg

char* _db13_sqlite3_type_text( db13_datatype_t type ){
    switch(type){
        case DB13_DATA_BLOB:
            return DB13_SQLITE3_DATA_BLOB;
        break;
        case DB13_DATA_DATE:
            return DB13_SQLITE3_DATA_NA;
        break;
        case DB13_DATA_INT:
            return DB13_SQLITE3_DATA_INT;
        break;
        case DB13_DATA_LONG_INT:
            return DB13_SQLITE3_DATA_LONG_INT;
        break;
        case DB13_DATA_NULL:
            return DB13_SQLITE3_DATA_NULL;
        break;
        case DB13_DATA_REAL:
            return DB13_SQLITE3_DATA_REAL;
        break;
        case DB13_DATA_TEXT:
            return DB13_SQLITE3_DATA_TEXT;
        break;
        default:
            return DB13_SQLITE3_DATA_NA;
        break;
    }
}

db13_datatype_t _db13_sqlite3_convert_type_to_db13( int sqlite3_type ){
    switch( sqlite3_type ){
        case SQLITE_FLOAT:
            return DB13_DATA_REAL;
        break;
        case SQLITE_INTEGER:
            return DB13_DATA_INT;
        break;
        case SQLITE_TEXT:
            return DB13_DATA_TEXT;
        break;
        case SQLITE_BLOB:
            return DB13_DATA_BLOB;
        break;
        case SQLITE_NULL:
            return DB13_DATA_NULL;
        break;
        default:
            return DB13_DATA_BLOB;
        break;
    }
}

error13_t _db13_sqlite3_convert_error( int sqlite3_err ){

	switch( sqlite3_err ){
		case SQLITE_OK:
			return E13_OK;
		case SQLITE_ERROR:
			return e13_error(E13_ERROR);
		case SQLITE_INTERNAL:
			return e13_error(E13_INTERNAL);
		case SQLITE_PERM:
			return e13_error(E13_PERM);
		case SQLITE_ABORT:
			return e13_error(E13_ABORT);
		case SQLITE_BUSY:
			return e13_error(E13_BUSY);
		case SQLITE_LOCKED:
			return e13_error(E13_LOCKED);
		case SQLITE_NOMEM:
			return e13_error(E13_NOMEM);
		case SQLITE_READONLY:
			return e13_error(E13_READONLY);
		case SQLITE_INTERRUPT:
			return e13_error(E13_INTERRUPT);
		case SQLITE_IOERR:
			return e13_error(E13_IOERR);
		case SQLITE_CORRUPT:
			return e13_error(E13_CORRUPT);
		case SQLITE_NOTFOUND:
			return e13_error(E13_NOTFOUND);
		case SQLITE_FULL:
			return e13_error(E13_FULL);
		case SQLITE_CANTOPEN:
			return e13_error(E13_CANTOPEN);
		case SQLITE_PROTOCOL:
			return e13_error(E13_PROTOCOL);
		case SQLITE_EMPTY:
			return e13_error(E13_EMPTY);
		case SQLITE_SCHEMA:
			return e13_error(E13_CHANGE);
		case SQLITE_TOOBIG:
			return e13_error(E13_TOOBIG);
		case SQLITE_CONSTRAINT:
			return e13_error(E13_CONSTRAINT);
		case SQLITE_MISMATCH:
			return e13_error(E13_MISMATCH);
		case SQLITE_MISUSE:
			return e13_error(E13_MISUSE);
		case SQLITE_NOLFS:
			return e13_error(E13_NOLFS);
		case SQLITE_AUTH:
			return e13_error(E13_AUTH);
		case SQLITE_FORMAT:
			return e13_error(E13_FORMAT);
		case SQLITE_RANGE:
			return e13_error(E13_RANGE);
		case SQLITE_NOTADB:
			return e13_error(E13_FORMAT);
		case SQLITE_ROW:
            return e13_error(E13_CONTINUE);
		case SQLITE_DONE:
			return e13_error(E13_DONE);
		default:
			return e13_error(E13_ERROR);
		break;
	}

}

int _db13_sqlite3_bind( sqlite3_stmt* stmt, int index, char* val,
                        size_t len, db13_datatype_t type){

    switch(type){

        case DB13_DATA_BLOB:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_blob(stmt, index, val, len, SQLITE_STATIC)
                );
        break;

        case DB13_DATA_DATE:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_text(stmt, index, val, len, SQLITE_STATIC)
                );
        break;

        case DB13_DATA_INT:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_int(stmt, index, *val)
                );
        break;

        case DB13_DATA_LONG_INT:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_int64(stmt, index, (sqlite3_int64)(*val))
                );
        break;

        case DB13_DATA_NULL:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_null(stmt, index)
                );
        break;

        case DB13_DATA_REAL:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_double(stmt, index, (double)(*val))
                );
        break;

        case DB13_DATA_TEXT:
            return _db13_sqlite3_convert_error(
                sqlite3_bind_text(  stmt, index, (const char*)val,
                                    strlen((const char*)val)+1,
                                    SQLITE_STATIC)
                );
        break;

        default:
            return e13_error(E13_MISUSE);
        break;

    }

}

int _db13_sqlite3_init(struct db13* db13){
	return E13_OK;
}

int _db13_sqlite3_connect(  struct db13* db13,
                            char* db,
                            struct db13_db_conf* conf,
                            void** dbms_h, void** dbms_conf){

    int ret;
    sqlite3* h;    

    ret = sqlite3_open(db, &h);
    //db13->engine[DB13_ENGINE_SQLITE3].dbms_h = (void*)h;

    *dbms_h = h;
    *dbms_conf = NULL;

    return _db13_sqlite3_convert_error(ret);

}

int _db13_sqlite3_disconnect(  struct db13* db13,
                               char* db){


}

int _db13_sqlite3_open(	struct db13* db13,
                        char* dbname,
                        char* alias,
                        db13_openflag_t flags){

    int ret;
    sqlite3_stmt* stmt;
    char sql[] = "";

    ret = sqlite3_open(filename, &h);
    db13->engine[DB13_ENGINE_SQLITE3].dbms_h = (void*)h;

    return _db13_sqlite3_convert_error(ret);
}

int _db13_sqlite3_close(struct db13* db13, char* alias){

	return _db13_sqlite3_convert_error(

                    sqlite3_close((sqlite3*)db13->engine[DB13_ENGINE_SQLITE3].dbms_h)

					);

}

int _db13_sqlite3_create_table(struct db13* db13,
                               char* alias,
                               char* table,
                               db13_objid_t ncols,
                               struct db13_col* col,
                               db13_tableflag_t flags){

    char* buf;
    db13_objid_t i, bind_index = 0UL;
    size_t bufsize, len;
    sqlite3_stmt* stmt;
    int ret;

    if(!ncols){
        return e13_error(E13_CONSTRAINT);
    }

    /*CREATE TABLE ?table_name(?column_name DATA_TYPE, ...);*/

    bufsize =   strlen(DB13_SQL_CREATE_VIRTUAL_TABLE) +
                (alias?strlen(alias)+strlen(DB13_SQLITE3_ALIAS_SIGN):0) +
                strlen(table) +
                ncols*(strlen(DB13_SQLITE3_BIND_SIGN) + 5 + //5 for bind sign/number and space
                    + strlen(DB13_SQLITE3_DATA_LONG_INT)) + //longest type name
                strlen(DB13_SQL_CLOSE_PARENTHESES);

    buf = (char*)m13_malloc(bufsize);
    if(!buf) return e13_error(E13_NOMEM);

    if(flags & DB13_TABLE_VIRTUAL) strcpy(buf, DB13_SQL_CREATE_VIRTUAL_TABLE);
    else strcpy(buf, DB13_SQL_CREATE_TABLE);

    len = strlen(buf);

    if(alias){

        snprintf(   buf + len, bufsize - len, " %s%i%s",
                    DB13_SQLITE3_BIND_SIGN,
                    (int)bind_index++,
                    DB13_SQLITE3_ALIAS_SIGN);

        len = strlen(buf);
    }

    snprintf(   buf + len, bufsize - len, "%s%i(",
                DB13_SQLITE3_BIND_SIGN,
                (int)bind_index);

    len = strlen(buf);

    i = 0;

    //ncols + 1 for binding table name, 1 if alias exists

    for(; bind_index < ncols + 1 + (alias?1:0); bind_index++){

        snprintf(buf + len, bufsize - len, "%s%i %s",
                DB13_SQLITE3_BIND_SIGN,
                (int)bind_index,
                _db13_sqlite3_type_text(col[i].type));

        if(i == ncols - 1){
            strcat(buf, DB13_SQL_CLOSE_PARENTHESES);
        } else {
            strcat(buf, DB13_SQL_COL_SEP);
        }

        len = strlen(buf);

        i++;
    }

    _deb_sql(   "SQL: %s, bufsize: %i, strlen(buf): %i",
                buf,
                bufsize,
                strlen(buf)
                );

    if((ret = sqlite3_prepare_v2((sqlite3*)db13->engine[DB13_ENGINE_SQLITE3].dbms_h,
                                buf, strlen(buf)+1, &stmt, NULL)))
    {
        m13_free(buf);
        return _db13_sqlite3_convert_error(ret);
    }

    bind_index = 0;

    if(alias){
        if((ret = sqlite3_bind_text(stmt, bind_index++, alias, strlen(alias)+1,
                SQLITE_STATIC))){
            m13_free(buf);
            return _db13_sqlite3_convert_error(ret);
        }
    }

    if((ret = sqlite3_bind_text(stmt, bind_index++, table, strlen(table)+1,
            SQLITE_STATIC))){
        m13_free(buf);
        return _db13_sqlite3_convert_error(ret);
    }


    for(i = 0; i < ncols; i++){

        if((ret = sqlite3_bind_text(stmt, bind_index++, col[i].name,
                strlen(col[i].name)+1,
                SQLITE_STATIC))){
            m13_free(buf);
            return _db13_sqlite3_convert_error(ret);
        }

    }

    ret = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    m13_free(buf);

    return _db13_sqlite3_convert_error(ret);
}

int _db13_sqlite3_delete_table(struct db13 *db13, char *alias, char *table){

    char* sql = (char*)malloc(0);
    return e13_error(E13_IMPLEMENT);

}

int _db13_sqlite3_trunc_table(struct db13 *db13, char *alias, char *table){

    size_t maxsql = strlen(DB13_SQL_TRUNC_TABLE) + 10;
    char* sql = (char*)m13_malloc(maxsql);
    sqlite3_stmt* stmt;
    int ret;

    if(!sql) return e13_error(E13_NOMEM);

    if(alias){
        snprintf(sql, maxsql, "%s%s%i%s%s%i%s",
                    DB13_SQL_TRUNC_TABLE,
                    DB13_SQLITE3_BIND_SIGN,
                    1,
                    DB13_SQLITE3_ALIAS_SIGN,
                    DB13_SQLITE3_BIND_SIGN,
                    2,
                    DB13_SQL_CLOSE);
    } else {
        snprintf(sql, maxsql, "%s%s%i%s",
                    DB13_SQL_TRUNC_TABLE,
                    DB13_SQLITE3_BIND_SIGN,
                    1,
                    DB13_SQL_CLOSE);
    }

    ret = sqlite3_prepare_v2((sqlite3*)db13->engine[DB13_ENGINE_SQLITE3].dbms_h,
                                sql, strlen(sql), &stmt, NULL
                            );
    if(ret != SQLITE_OK){
        m13_free(sql);
        return _db13_sqlite3_convert_error(ret);
    }

    if(alias){

        ret = sqlite3_bind_text(stmt, 1, alias, strlen(alias)+1, SQLITE_STATIC);
        if(ret != SQLITE_OK){
            m13_free(sql);
            return _db13_sqlite3_convert_error(ret);
        }

        ret = sqlite3_bind_text(stmt, 2, table, strlen(table)+1, SQLITE_STATIC);
        if(ret != SQLITE_OK){
            m13_free(sql);
            return _db13_sqlite3_convert_error(ret);
        }

    } else {
        ret = sqlite3_bind_text(stmt, 1, table, strlen(table)+1, SQLITE_STATIC);
        if(ret != SQLITE_OK){
            m13_free(sql);
            return _db13_sqlite3_convert_error(ret);
        }

    }

    m13_free(sql);
    return _db13_sqlite3_convert_error(sqlite3_step(stmt));

}

char** _db13_sqlite3_list_tables(struct db13 *db13, char *alias){
    return NULL;
}

int _db13_sqlite3_insert_row(	struct db13* db13,
                                char* alias,
                                char* table,
                                struct db13_row* row){

    int ret;
    size_t maxsql, copylen;
    char* sql;
    int bind_index;
    db13_objid_t i;
    sqlite3_stmt* stmt;

    /*INSERT INTO ?table_name(?column_name, ...) VALUES(?data, ...);*/

    maxsql =strlen(DB13_SQL_INSERT_INTO) +
            strlen(DB13_SQLITE3_BIND_SIGN) + 1 +
            row->nfields*(5) + 2 +
            strlen(DB13_SQL_VALUES) +
            row->nfields*(5) + 3;

    sql = (char*)m13_malloc(maxsql);
    if(!sql) return e13_error(E13_NOMEM);

    bind_index = 0;

    if(alias){
        snprintf(   sql, maxsql, "%s%s%i%s%s%i(",
                    DB13_SQL_INSERT_INTO,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++,
                    DB13_SQLITE3_ALIAS_SIGN,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++
                );
    } else {
        snprintf(   sql, maxsql, "%s%s%i(",
                    DB13_SQL_INSERT_INTO,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++
                );
    }

    copylen = strlen(sql);

    for(i = 0; i < row->nfields; i++){
        if(i == row->nfields - 1){//close
            snprintf(sql + copylen, maxsql - copylen, "%s%i)",
                    DB13_SQLITE3_BIND_SIGN, bind_index++);
        } else {
            snprintf(sql + copylen, maxsql - copylen, "%s%i, ",
                    DB13_SQLITE3_BIND_SIGN, bind_index++);
        }
        copylen = strlen(sql);
    }

    copylen = strlen(sql);

    snprintf(sql + copylen, maxsql - copylen, "%s", DB13_SQL_VALUES);
    copylen += strlen(DB13_SQL_VALUES);

    for(i = 0; i < row->nfields; i++){
        if(i == row->nfields - 1){//close
            snprintf(sql + copylen, maxsql - copylen, "%s%i);",
                    DB13_SQLITE3_BIND_SIGN, bind_index++);
        } else {
            snprintf(sql + copylen, maxsql - copylen, "%s%i, ",
                    DB13_SQLITE3_BIND_SIGN, bind_index++);
        }
        copylen = strlen(sql);
    }

    _deb_sql("sql: %s, maxsql: %i, strlen: %i", sql, maxsql, strlen(sql));

    /*  PREPARE STATEMENT   */

    if((ret = sqlite3_prepare_v2(
                    (sqlite3*)db13->engine[DB13_ENGINE_SQLITE3].dbms_h,
                    sql, strlen(sql),
                    &stmt, NULL)) != SQLITE_OK){

        return _db13_sqlite3_convert_error(ret);
    }

    /*  BIND VALUES */

    i = 0;

    if(alias){
        _db13_sqlite3_bind(stmt, i++, alias, strlen(alias)+1, DB13_DATA_TEXT);
    }

    _db13_sqlite3_bind(stmt, i, table, strlen(table) + 1, DB13_DATA_TEXT);

    for(i = 0; i < row->nfields + 1 + (alias?1:0); i++){
        _db13_sqlite3_bind(stmt, i,
                            (char*)row->field[i].col,
                            strlen((char*)row->field[i].col)+1,
                            row->field[i].type);
    }

    return E13_OK;
}

/*
 * resolve entry logic and
*/
int _db13_sqlite3_resolve_filter_entry_to_sql(      char* buf, size_t bufsize,
                                                    int* bind_index,
                                                    struct db13_filter_entry* entry){


    if( entry->prev &&
        (
            ( !entry->branch ) ||
            ( entry->branch && (entry->flags & DB13_FILTER_BRANCH_ENUM) )
        )
    ){

        buf += strlen(buf);
        bufsize -= strlen(buf);

        switch(entry->prev->logic & DB13_FILTER_RELATE_MASK){

            case DB13_FILTER_AND:
                snprintf(buf, bufsize, " AND ");
            break;

            case DB13_FILTER_OR:
                snprintf(buf, bufsize, " OR ");
            break;

            case DB13_FILTER_NOT:
                snprintf(buf, bufsize, " NOT ");
            break;

            case DB13_FILTER_XOR:
                snprintf(buf, bufsize, " XOR ");
            break;

            default:
                return e13_error(E13_CONSTRAINT);
            break;
        }
    }

    buf += strlen(buf);
    bufsize -= strlen(buf);

    switch(entry->logic & DB13_FILTER_LOGIC_MASK){

        case DB13_FILTER_EQ:
            snprintf(buf, bufsize, "%s%i = ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_GT:
            snprintf(buf, bufsize, "%s%i > ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_LT:
            snprintf(buf, bufsize, "%s%i < ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_NE:
            snprintf(buf, bufsize, "%s%i <> ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_GE:
            snprintf(buf, bufsize, "%s%i >= ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_LE:
            snprintf(buf, bufsize, "%s%i <= ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_LIKE:
            snprintf(buf, bufsize, "%s%i LIKE ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        case DB13_FILTER_NOTLIKE:
            snprintf(buf, bufsize, "%s%i NOT LIKE ", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);
        break;

        default:
            return e13_error(E13_CONSTRAINT);
        break;

    }

    buf += strlen(buf);
    bufsize -= strlen(buf);

    snprintf(buf, bufsize, "%s%i", DB13_SQLITE3_BIND_SIGN, (*bind_index)++);


    return E13_OK;
}


int _db13_sqlite3_convert_filter(   char* buf, size_t bufsize,
                                    int* bind_index,
                                    struct db13_filter* filter,
                                    struct db13_filter_entry* entry){

    int ret;
    size_t len;

    if(filter->type == DB13_FILTER_SQL){
        s13_strcpy(buf, filter->exp, bufsize);
        return E13_OK;
    }

    //resolve cell, set the rowset
    if((ret = _db13_sqlite3_resolve_filter_entry_to_sql( buf, bufsize, bind_index,
                                                entry)) < 0) return ret;

    if(entry->branch && !(entry->flags & DB13_FILTER_BRANCH_ENUM)){
        entry->flags |= DB13_FILTER_BRANCH_ENUM;
        snprintf(buf, bufsize, "(");
        len = strlen(buf);
        if((ret = _db13_sqlite3_convert_filter( buf + len, bufsize - len,
                                                bind_index, filter,
                                                entry->branch)) < 0) return ret;
    }

    if(entry->next){
        len = strlen(buf);
        if((ret = _db13_sqlite3_convert_filter( buf + len, bufsize - len,
                                                bind_index, filter,
                                                entry->next)) < 0) return ret;
    }

    len = strlen(buf);
    snprintf( buf + len, bufsize - len, ")" );    

    return 0;
}

static inline int _db13_sqlite3_bind_filter_vals_enum(  sqlite3* stmt,
                                                        struct db13_filter* filter,
                                                        struct db13_filter_entry* entry
                                                        ,
                                                        int* index){

    int ret;

    _db13_sqlite3_bind( stmt, (*index)++, entry->src,
                        entry->srclen, DB13_DATA_TEXT);

    _db13_sqlite3_bind( stmt, (*index)++, entry->dst,
                        entry->dstlen, DB13_DATA_TEXT);

    entry->flags &= ~DB13_FILTER_BRANCH_ENUM;

    if(entry->branch && !(entry->flags & DB13_FILTER_BRANCH_ENUM)){
        entry->flags |= DB13_FILTER_BRANCH_ENUM;

        if((ret = _db13_sqlite3_bind_filter_vals_enum(  stmt,
                                                        filter,
                                                        entry->branch,
                                                        index)) < 0) return ret;
    }

    if(entry->next){
        if((ret = _db13_sqlite3_bind_filter_vals_enum(  stmt,
                                                        filter,
                                                        entry->next,
                                                        index)) < 0) return ret;
    }

    return 0;
}

int _db13_sqlite3_bind_sql_filter_vals( sqlite3_stmt* stmt, struct db13_filter* filter, int* index){

    return _db13_sqlite3_bind_filter_vals_enum(stmt, filter, filter->first, index);

}

/*
 *  TODO: possible memmory leach here! not free()ing all field->cols after mem
 *  alloc fail.
*/
int _db13_sqlite3_stmt_to_row(sqlite3_stmt* stmt, struct db13_row* row){

    db13_objid_t i;

    row->nfields = sqlite3_column_count(stmt);
    row->field = (struct db13_field*)m13_malloc(sizeof(struct db13_field));
    if(!row->field){
        return e13_error(E13_NOMEM);
    }

    for(i = 0; i < row->nfields; i++){

        row->field[i].col = (char*)m13_malloc(strlen(sqlite3_column_name(stmt, i)));
        if(!row->field[i].col){
            m13_free(row->field);
            return e13_error(E13_NOMEM);
        }

        row->field[i].datalen = sqlite3_column_bytes(stmt, i);

        row->field[i].type = _db13_sqlite3_convert_type_to_db13(
                                                sqlite3_column_type(stmt, i));
        row->field[i].data = m13_malloc(row->field[i].datalen);
        if(!row->field[i].data){
            m13_free(row->field[i].col);
            m13_free(row->field);
            return e13_error(E13_NOMEM);
        }

        memcpy(row->field[i].data, sqlite3_column_blob(stmt, i), row->field[i].datalen);

    }

    return E13_OK;

}

int _db13_sqlite3_select(   struct db13* db13,
                            char* alias,
                            char* table,
                            db13_objid_t ncols,
                            struct db13_col* col,
                            struct db13_filter* filter,
                            struct db13_rowset* rowset){

    char* sql;
    size_t maxsql;
    int bind_index = 0, i;
    sqlite3_stmt* stmt;
    int ret;

    sql = (char*)m13_malloc(maxsql);
    if(!sql) return e13_error(E13_NOMEM);

    if(alias){
        snprintf(   sql, maxsql, "%s%s%i%s%s%i",
                    DB13_SQL_SELECT_ALL,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++,
                    DB13_SQLITE3_ALIAS_SIGN,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++
                    );
    } else {
        snprintf(   sql, maxsql, "%s%s%i",
                    DB13_SQL_SELECT_ALL,
                    DB13_SQLITE3_BIND_SIGN,
                    bind_index++);
    }

    if(filter){

        strcat(sql, DB13_SQL_WHERE);

        if((ret = _db13_sqlite3_convert_filter( sql + strlen(sql),
                                                maxsql - strlen(sql),
                                                &bind_index,
                                                filter, filter->first)) !=
                                                    E13_OK){
            m13_free(sql);
            return ret;
        }
    }

    strcat(sql, ");");

    _deb_sql(   "sql: %s, maxsql: %i, strlen(sql): %i, bind: %i",
                sql, maxsql,
                strlen(sql), bind_index);

    if((ret = sqlite3_prepare_v2(   db13->engine[DB13_ENGINE_SQLITE3].dbms_h,
                                    sql,
                                    strlen(sql), &stmt, NULL)) != E13_OK){
        m13_free(sql);
        return _db13_sqlite3_convert_error(ret);
    }

    i = 0;

    if(alias){
        _db13_sqlite3_bind(stmt, i++, alias, strlen(alias) + 1, DB13_DATA_TEXT);
    }

    _db13_sqlite3_bind(stmt, i++, table, strlen(table) + 1, DB13_DATA_TEXT);

    //bind column name/values

    _db13_sqlite3_bind_sql_filter_vals(stmt, filter, &i);

    _deb_sql("binded_index: %i", i);

    //

    m13_free(sql);

    rowset->nrows = sqlite3_data_count(stmt);
    rowset->row = (struct db13_row*)m13_malloc(rowset->nrows*sizeof(struct db13_row));

    if(!rowset->row){
        sqlite3_finalize(stmt);
        return e13_error(E13_NOMEM);
    }

    i = 0;

    while((ret = sqlite3_step(stmt)) == SQLITE_ROW){
        if((ret = _db13_sqlite3_stmt_to_row(stmt, &rowset->row[i++]))!= E13_OK){
            sqlite3_finalize(stmt);
            m13_free(rowset->row);
            return ret;
        }
    }

    sqlite3_finalize(stmt);

    switch(ret){

        case SQLITE_DONE:
        break;

        default:
            return _db13_sqlite3_convert_error(ret);
        break;

    }

    return E13_OK;

}

