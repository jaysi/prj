﻿#ifndef DB13_SQLITE3_H
#define DB13_SQLITE3_H

#include "db13.h"

#define DB13_SQLITE3_BIND_SIGN  "?"
#define DB13_SQLITE3_ALIAS_SIGN "."
#define DB13_SQLITE3_INNER_SEP  ","

#define DB13_SQLITE3_DATA_BLOB  "BLOB"
#define DB13_SQLITE3_DATA_NA    "NA" /*this should cause a syntax error*/
#define DB13_SQLITE3_DATA_INT   "INT"
#define DB13_SQLITE3_DATA_LONG_INT   "INT"
#define DB13_SQLITE3_DATA_NULL  "NULL"
#define DB13_SQLITE3_DATA_REAL  "REAL"
#define DB13_SQLITE3_DATA_TEXT  "TEXT"

#ifdef __cplusplus
	extern "C" {
#endif

int _db13_sqlite3_init( struct db13* db13);

int _db13_sqlite3_connect(  struct db13* db13,
                            char* db,
                            struct db13_conf* conf);

int _db13_sqlite3_disconnect(struct db13* db13,
                             char* db);

int _db13_sqlite3_open(	struct db13* h,
                        char* db,
                        char* alias,
                        db13_openflag_t flags);

int _db13_sqlite3_close(struct db13* db13,
                        char* alias);

int _db13_sqlite3_create_table(struct db13* db13,
                               char* db,
                               char* table,
                               db13_objid_t ncols,
                               struct db13_col* col,
                               db13_tableflag_t flags);

int _db13_sqlite3_delete_table(	struct db13* db13,
                                char* alias,
                                char* table);

int _db13_sqlite3_trunc_table(	struct db13* db13,
                                char* alias,
                                char* table);

char** _db13_sqlite3_list_tables(   struct db13* db13,
                                    char* alias);

int _db13_sqlite3_insert_row(	struct db13* db13,
                                char* alias,
                                char* table,
                                struct db13_row* row);

int _db13_sqlite3_delete_row(	struct db13* db13,
                                char* alias,
                                char* table,
                                struct db13_filter* filter);

int _db13_sqlite3_update_row(	struct db13* db13,
                                char* alias,
                                char* table,
                                struct db13_row* row,
                                struct db13_filter* filter);

int _db13_sqlite3_insert_col(	struct db13* db13,
                                char* alias,
                                char* table,
                                char pos,
                                char* name,
                                db13_objid_t ncols,
                                struct db13_col* col);

int _db13_sqlite3_delete_col(	struct db13* db13,
                                char* alias,
                                char* table,
                                db13_objid_t ncols,
                                struct db13_col* col);

int _db13_sqlite3_update_col(	struct db13* db13,
                                char* alias,
                                char* table,
                                struct db13_col* old_col,
                                struct db13_col* new_col);


int _db13_sqlite3_select(   struct db13* db13,
                            char* alias,
                            char* table,
                            db13_objid_t ncols,
                            struct db13_col* col,
                            struct db13_filter* filter,
                            struct db13_rowset* rowset);

struct db13_row* _db13_sqlite3_fetch_row( struct db13* db13,
                                          struct db13_rowset* rowset,
                                          db13_fetchflag_t flags);

struct db13_field* _db13_sqlite3_fetch_field(   struct db13* db13,
                                                struct db13_row* row,
                                                char* colname,
                                                db13_fetchflag_t flags);

int _db13_sqlite3_trans(struct db13* db13, char* alias);
int _db13_sqlite3_commit(struct db13* db13, char* alias);
int _db13_sqlite3_rollback(struct db13* db13, char* alias);

#ifdef __cplusplus
	}
#endif

#endif // DB13_SQLITE3_H
