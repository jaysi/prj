﻿#ifndef DB13_H
#define DB13_H

#include "../sqlite/sqlite3.h"
#include "../lib13/include/lib13.h"

/*
 * the base of db13 is a positive unique row id called urid,
 * the urid borns with row but does not die with it!
 * ofcourse, this limmits total number of inserts in a table
 * to 2^64-1, a purge call may be implemented later to clean this mess up!
*/

#define DB13_STMT_MAGIC  0xd1ef

#define DB13_MAX_COLS   100

typedef uint16_t db13_col_flag_t;
typedef uint64_t db13_urid_t;
typedef uint8_t db13_tviewer_t;//table viewer, e.g. god, mgr, usr, etc...
typedef uint32_t db13_tid_t;
typedef uint32_t db13_colid_t;
typedef uint32_t db13_rowid_t;
typedef uint8_t db13_tflag_t;

#define DB13_COLF_AUTO       (0x0001<<0)
#define DB13_COLF_HIDE       (0x0001<<1)
#define DB13_COLF_TRANSL     (0x0001<<2)//translated
#define DB13_COLF_SINGULAR   (0x0001<<3)
#define DB13_COLF_ONETIMEFIX (0x0001<<4)//defined once!
#define DB13_COLF_LIST       (0x0001<<5)
#define DB13_COLF_FAKE       (0x0001<<6)
#define DB13_COLF_ACCEPTNULL (0x0001<<7)
#define DB13_COLF_END        0

#define DB13_COLID_INVAL ((uint32_t)-1)
#define DB13_ROWID_INVAL ((uint32_t)-1)
#define DB13_TID_INVAL  ((uint32_t)-1)

#define DB13_TABF_FAKE  (0x01<<0)

#define DB13_BOOL_NO     0
#define DB13_BOOL_YES    1
#define DB13_BOOL_NEUT   2

/*
 * the control table
 * rows are table names, cols are: urid (the last used urid),
*/
#define DB13_TCTL   "tctl"

enum db13_type_id{
    DB13_DATA_INT,
    DB13_DATA_INT64,
    DB13_DATA_DOUBLE,
    DB13_DATA_TEXT,
    DB13_DATA_DATE,
    DB13_DATA_BOOL,
    DB13_DATA_RAW,
    DB13_DATA_INVAL
};

enum db13_engine_t{
    DB13_ENGINE_NULL,
    DB13_ENGINE_SQLITE,
    DB13_ENGINE_INVAL
};

//the -> is a special sign in the column name,
//it defines depency to another table or THIS table
//this helps much when TRANSL flag is on; %table name%_%column name%

/*
 * the external refrence is defined as below
 * assuming the column c exists with value i, refering to the column name
 * at the table with the key value i at the column id, the following
 * means: translate value i to the name with id = i
 * table:id->name
 * chains are allowed in the following format
 * table1:col1->col2,table2:col2->col3...
*/

struct db13_table_info{
    char* name;
    char* alias;
    db13_urid_t urid;//filled auto with system
    db13_tflag_t tflags;//TABF
    db13_tviewer_t tviewer;//viewer types
    db13_colid_t ncols;
    db13_colid_t nfakes;
    char* col_name[DB13_MAX_COLS];
    db13_type_id col_type[DB13_MAX_COLS];
    char* col_alias[DB13_MAX_COLS];
    db13_col_flag_t flags[DB13_MAX_COLS];//COLF
};

struct db13{

    enum db13_engine_t engine;
    void* h;
    char* alias;
    char* path;

    db13_tid_t ntables;
    struct db13_table_info* table_info;

    struct e13 e;

    struct db13* next;

};

struct db13_stmt{
    unsigned short magic;
    void* h;
    struct db13* db;
};

enum db13_sort_t{

    DB13_SO_DEC,
    DB13_SO_INC //increase, from small to large!

};

enum db13_logic_comb_t{
    DB13_LOGICOMB_NONE,
    DB13_LOGICOMB_AND,
    DB13_LOGICOMB_OR,
    DB13_LOGICOMB_INVAL
};

enum db13_logic_t{

    DB13_LOGIC_LIKE,
    DB13_LOGIC_NOTLIKE,
    DB13_LOGIC_EQ,
    DB13_LOGIC_NE,
    DB13_LOGIC_LT,
    DB13_LOGIC_LE,
    DB13_LOGIC_GT,
    DB13_LOGIC_GE,
    DB13_LOGIC_BETWEEN,

    DB13_LOGIC_INVAL
};

#define LOGICF_COL_CMP  (0x01<<0) //compare columns
#define LOGICF_POPEN    (0x01<<1) //open parenthesis
#define LOGICF_PCLOSE   (0x01<<1) //close parenthesis

struct db13_logic_s{
    char flags;
    enum db13_logic_comb_t comb;
    db13_colid_t col;
    enum db13_logic_t logic;
    char* sval;
    int ival;
    long long llval;
    double dval;
    size_t datasize;
};

struct mval{
    char* name;
    char* val;
};

#ifdef __cplusplus
extern "C"{
#endif



#ifdef __cplusplus
}
#endif

#endif // DB_H
