<?php
    
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<base target="_blank"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<p>
<strong>تبلیغات<br /></strong>
آگهی میتواند شامل فایلهای Gift یا Flash باشد.<br />
موتور این سایت با توجه به مکانهای مورد علاقه آگهی متناسب را نمایش خواهد داد.
</p>

</body>
</html>