﻿<?php
    require_once 'config.php';
	if(!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] != URL.'/links.php'){
		header('location: main.php');
		exit();
	}	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<form action="send_mail_result.php" method="post">
<table border="0px" width="500px"/>
<tr align="right" valign="middle">
<th width="150px"><label for="name">نام و نام خانوادگي</label></th>
<td><input class="transparent" id="name" maxlength="50" name="name" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th><label for="email">پست الكترونيكي</label></th>
<td><input class="transparent" id="email" maxlength="50" name="email" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th><label for="subject">موضوع</label></th>
<td><input class="transparent" id="subject" maxlength="50" name="subject" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th><label for="body">متن پيام</label></th>
<td><textarea class="transparent" id="body" maxlength="1000" name="body" rows="5" style="width: 100%"></textarea></td>
</tr>

<tr align="right" valign="middle" dir="ltr">
<?php
  require_once('extern/recaptchalib.php');
  $publickey = RECAPTPUBKEY; // you got this from the signup page
  echo recaptcha_get_html($publickey);
?>
</tr>

<tr align="center" valign="middle">
<td colspan="2"><input style="width: 100%;" type="submit" value="ارسال"/></td>
</tr>
</table>
</form>
<?php $_SESSION['gf_ref'] = $_SERVER['PHP_SELF']; require_once 'givefeed.php'; ?>
</body>
</html>