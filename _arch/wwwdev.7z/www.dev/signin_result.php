<?php
	require_once("config.php");	
	session_start();	
	if(!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] != URL.'/signin.php'){
		header('location: index.php');
		exit();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="rtl">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/signin.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	require_once('db.php');

	$user = new user();
	$usertype = 'guest';
	
	if($_POST['username'] == MASTER){
		if(CRYPT_MD5 == 1){
			if(crypt($_POST['password'], MASTERPW) == MASTERPW){
				
				$_SESSION['username'] = 'admin';
				$_SESSION['usertype'] = 'admin';
				
				header('location: signin.php');
				exit();				
				
			} else {
				echo "نام کاربر/کلمه عبور معتبر نیست";
			}
		} else {
			echo "ایراد داخلی";
		}
	} else {

		if($user->login($_POST['username'], $_POST['password'], $usertype) == true){
			
			$_SESSION['username'] = $_POST['username'];
			$_SESSION['usertype'] = 'user';
			
			//echo mysql_error();
			
			header('location: signin.php');
			exit();
		
		} else {
			echo "نام کاربر/کلمه عبور معتبر نیست";			
		}
	
	}
	
	//sleep(5);
	
	//header('location: signin.php');
	//exit();
	
	echo '<a style="float:left" href="'.URL.'/signin.php" target="signinFrame">بــازگــشـت</a>';
?>
</body>
</html>