<?php
    
    require_once 'config.php';
	session_start();	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/uboard.css" rel="stylesheet" type="text/css"/>
<base target="_self"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: nrepeat;">
<?php

	require_once 'db.php';
	
	if(isset($_POST['id']) || isset($_POST['idm'])){
		if(isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] == URL."/uboard.php"){
			$ub = new uboard();
			if(isset($_POST['submit']) && $_POST['submit'] == 'ثبت'){
				$ub->insert($_POST['id'], $_POST['pid'], $_POST['username'], $_POST['comments']);
			}
			if(isset($_POST['submit']) && $_POST['submit'] == 'حذف'){
				$ub->delete($_POST['idm']);
			}
			
			header('location: uboard.php');
			exit();
		}
	}
	
	function show_message($id, $username, $time, $text){
		
		$db = new database();		
		
		echo '<li>';
		echo '<table border="0px" width="100%">';		
		echo '<tr align="right" valign="middle">';
		echo '<th width="5%">'.$db->farsi_num($username).'</th>';		
		echo '<td>'.$db->farsi_num($text).'<a href="#">'.'...'.'</a></td>';
		echo '<td width="1%">'.$db->farsi_num($time).'</td></tr>';
		
		if(isset($_SESSION['username']) && $_SESSION['username'] == $username){
			echo '<form action="uboard.php" method="post" enctype="utf-8">';
			echo '<input type="hidden" name="idm" value="'.$id.'"/>';
			//echo '<input type="hidden" name="delete" value="1"/>';
			echo '<td colspan="2"><input name="submit" type="submit" dir="rtl" lang="fa"  value="حذف" style="width: 5%;"/></td>';
			echo '</form>';
		}
		
		echo "</table>";	
		echo '</li>';
		echo '<br />';
	}	

	function show_time(){
		$d = new jCalendar();
		echo '<br />امروز '.$d->date(LONGTIMEFMT ,NULL ,TZ).'<br />';
	}
	
	function show_ip(){
		echo '<table border="0px" width="100%" style="css\uboard.css"/>';
		echo '<tr align="center" valign="middle"><td width="100%">'.' آدرس شما'.$_SERVER['REMOTE_ADDR'].'</td></tr>';
		echo '</table>';
	}
	
	function show_give_post(){
		if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == "guest"){
			echo '<br />'.'برای ایجاد پیام ثبت نام کنید!'.'<br />';
			return;
		}
		
		$ub = new uboard();
		
		echo '<table border="0px" width="50%" style="css\uboard.css"/>';
		echo '<form action="uboard.php" method="post" enctype="utf-8">';
		echo '<tr align="right" valign="middle">';
		echo '<th><label for="body">پیام</label></th>';
		echo '<td><textarea class="transparent" id="body" maxlength="1000" name="comments" rows="2" style="width: 100%"></textarea></td>';
		echo '</tr>';
		echo '<input type="hidden" name="username" value="'.$_SESSION['username'].'"/>';
		echo '<input type="hidden" name="pid" value="0"/>';
		//echo '<input type="hidden" name="insert" value="1"/>';
		$id = $ub->get_id();
		echo '<input type="hidden" name="id" value="'.$id.'"/>';
		echo '<tr align="left" valign="middle">';
		echo '<td colspan="0"><input name="submit" type="submit" dir="rtl" lang="fa"  value="ثبت" style="width: 100%;"/></td>';
		echo '</tr>';
		echo '</table>';
	}
	
	function show_last_posts($n){
		$ub = new uboard();
		
		$result = $ub->get_all();
		echo '<table border="0px" width="100%" style="css\uboard.css"/>';
		echo '<tr align="center" valign="middle"><td width="100%">'.'=============آخرین نوشته ها============='.'</td></tr>';
		echo '</table>';
		echo '<ul class="link">';
		if($result == false || mysql_num_rows($result) == 0){
			mysql_free_result($result);			
			show_message(0, 'مدیر سایت','الان!','پیام بگذارید');
		} else {					
			while($row = mysql_fetch_assoc($result)){
				show_message($row['id'], $row['username'],$row['time'],$row['text']);
			}
			
		}
		echo '</ul>';	
	}
	
	show_time();
	
	show_give_post();
	
	show_last_posts(0);
	
	show_ip();
	
	$_SESSION['gf_ref'] = $_SERVER['PHP_SELF'];
	require_once 'givefeed.php';
?>
</body>
</html>