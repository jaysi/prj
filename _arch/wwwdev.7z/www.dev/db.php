<?php

	//define('groups', 'http://localhost');
		
	require_once('config.php');
	require_once('extern/jcalendar.class.php');
	
	class database{
		private $link = null;
		//private $tablename = null;
		
		public function __construct(){
			//if($tablename == null) $tablename = $tname;			
			$this->connect();
		}
		
		public function __destruct(){			
			$this->close();
		}
		
		public function connect(){
			if($this->link == null || !mysql_ping($this->link)){				
				$this->link = mysql_connect(HOST, USER, PASS) or die(mysql_error());
			}
			mysql_select_db(DB);
			mysql_query('SET NAMES \'UTF8\'');
		}
		
		private function close(){
			mysql_close($this->link);
			$this->link = null;
		}
		
		function CorrectFarsi($text)
		{
			$CorrectionArr = array(
				'لله'=>array('ﷲ'),
				'آ'=>array('ﺁ', 'ﺂ'),
				'أ'=>array('ﺃ', 'ﺄ'),
				'ؤ'=>array('ﺅ', 'ﺆ'),
				'إ'=>array('ﺇ', 'ﺈ'),
				'ئ'=>array('ﺉ', 'ﺊ', 'ﺋ', 'ﺌ'),
				'ا'=>array('ﺍ', 'ﺎ'),
				'ب'=>array('ﺏ', 'ﺐ', 'ﺑ', 'ﺒ'),
				'پ'=>array('ﭖ', 'ﭗ', 'ﭘ', 'ﭙ'),
				'ة'=>array('ﺓ', 'ﺔ'),
				'ت'=>array('ﺕ', 'ﺖ', 'ﺗ', 'ﺘ'),
				'ث'=>array('ﺙ', 'ﺚ', 'ﺛ', 'ﺜ'),
				'ج'=>array('ﺝ', 'ﺞ', 'ﺟ', 'ﺠ'),
				'چ'=>array('ﭺ', 'ﭻ', 'ﭼ', 'ﭽ'),
				'ح'=>array('ﺡ', 'ﺢ', 'ﺣ', 'ﺤ'),
				'خ'=>array('ﺥ', 'ﺦ', 'ﺧ', 'ﺨ'),
				'د'=>array('ﺩ', 'ﺪ'),
				'ذ'=>array('ﺫ', 'ﺬ'),
				'ر'=>array('ﺭ', 'ﺮ'),
				'ز'=>array('ﺯ', 'ﺰ'),
				'ژ'=>array('ﮊ', 'ﮋ'),
				'س'=>array('ﺱ', 'ﺲ', 'ﺳ', 'ﺴ'),
				'ش'=>array('ﺵ', 'ﺶ', 'ﺷ', 'ﺸ'),
				'ص'=>array('ﺹ', 'ﺺ', 'ﺻ', 'ﺼ'),
				'ض'=>array('ﺽ', 'ﺾ', 'ﺿ', 'ﻀ'),
				'ط'=>array('ﻁ', 'ﻂ', 'ﻃ', 'ﻄ'),
				'ظ'=>array('ﻅ', 'ﻆ', 'ﻇ', 'ﻈ'),
				'ع'=>array('ﻉ', 'ﻊ', 'ﻋ', 'ﻌ'),
				'غ'=>array('ﻍ', 'ﻎ', 'ﻏ', 'ﻐ'),
				'ف'=>array('ﻑ', 'ﻒ', 'ﻓ', 'ﻔ'),
				'ق'=>array('ﻕ', 'ﻖ', 'ﻗ', 'ﻘ'),
				'ک'=>array('ﻙ', 'ﻚ', 'ﻛ', 'ﻜ', 'ﮎ', 'ﮏ', 'ﮐ', 'ﮑ'),
				'گ'=>array('ﮒ', 'ﮓ', 'ﮔ', 'ﮕ'),
				'ل'=>array('ﻝ', 'ﻞ', 'ﻟ', 'ﻠ'),
				'م'=>array('ﻡ', 'ﻢ', 'ﻣ', 'ﻤ'),
				'ن'=>array('ﻥ', 'ﻦ', 'ﻧ', 'ﻨ'),
				'ه'=>array('ﻩ', 'ﻪ', 'ﻫ', 'ﻬ', 'ﮤ', 'ﮥ', 'ﮦ', 'ﮪ', 'ﮫ', 'ﮬ', 'ﮭ'),
				'و'=>array('ﻭ', 'ﻮ'),
				'ی'=>array('ﻯ', 'ﻰ', 'ﻱ', 'ﻲ', 'ﻳ', 'ﻴ', 'ﯼ', 'ﯽ', 'ﯾ', 'ﯿ'),
				'لآ'=>array('ﻵ', 'ﻶ'),
				'لأ'=>array('ﻷ', 'ﻸ'),
				'لإ'=>array('ﻹ', 'ﻺ'),
				'لا'=>array('ﻻ', 'ﻼ'),
				'ء'=>array('ﺀ'),
				'‌'=>array('﻿'),
				'ّ'=>array('ﹼ', 'ﹽ'),
				'ِ'=>array('ﹺ', 'ﹻ'),
				'ُ'=>array('ﹸ', 'ﹹ'),
				'َ'=>array('ﹶ', 'ﹷ'),
				'ٍ'=>array('ﹴ', '﹵'),
				'ٌ'=>array('ﹲ', 'ﹳ'),
				'ً'=>array('ﹰ', 'ﹱ')
			);
			foreach($CorrectionArr as $h=>$A)
				foreach($A as $a)
					$text = str_replace($a, $h, $text);
			return $text;
		}
		
		function farsi_num($str){
			$latin = array(0,1,2,3,4,5,6,7,8,9);
			$farsi = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
			//$str = date('H:i:s');
			$farsistr = str_replace($latin, $farsi, $str);
			return $farsistr;
		}
		function latin_num($str){
			$latin = array(0,1,2,3,4,5,6,7,8,9);
			$farsi = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
			//$str = date('H:i:s');
			$farsistr = str_replace($farsi, $latin, $str);
			return $farsistr;
		}
		
		public function count_rows($table){
			$this->connect();
			$table = mysql_real_escape_string($table);			
			$sql = "SELECT * FROM {$table};";
			//echo $sql;
			$result = mysql_query($sql);			
			return mysql_num_rows($result);
		}
		
	}
	
	class base{
		
		public function get_tables(){
			$db = new database();
			$db->connect();
			$result = mysql_query('SELECT * FROM base;');
			return $result;
		}
		
		public function get_table_by_id($id){
			$db = new database();
			$db->connect();			
			$sql = "SELECT * FROM base WHERE id='{$id}';";
			$result = mysql_query($sql);
			//echo $sql;
			//echo mysql_error();
			if($result !== false && mysql_num_rows($result) > 0) {
				if($row = mysql_fetch_assoc($result)) {
					return $row['table_name'];
				}
			}
			return false;
		
		}
		
		public function get_table_sc_name($name){
			$db = new database();
			$db->connect();
			$name = mysql_real_escape_string($name);
			$sql = "SELECT * FROM base WHERE table_name LIKE '{$name}';";
			$result = mysql_query($sql);
			//echo $sql;
			//echo mysql_error();
			if($result !== false && mysql_num_rows($result) > 0) {
				if($row = mysql_fetch_assoc($result)) {
					return $row['table_sc_name'];
				}
			}
			return false;
		}		
		
	}
	
	class desc{
		public function get($domain){
			$db = new database();
			$db->connect();
			$domain = mysql_real_escape_string($domain);
			$sql = "SELECT * FROM {$domain}_desc;";
			$result = mysql_query($sql);
			//echo mysql_error();
			return $result;
		}
		
		public function get_sc_name($domain, $col_name){
			$db = new database();
			$db->connect();
			$name = mysql_real_escape_string($domain);
			$sql = "SELECT * FROM {$domain}_desc WHERE col_name LIKE '{$col_name}';";
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) == 0){
				mysql_free_result($result);
				return false;
			}
			$row = mysql_fetch_assoc($result);
			mysql_free_result($result);
			return $row['col_sc_name'];
		}
		
		public function get_desc($domain, $col_name){
			$db = new database();
			$db->connect();
			$name = mysql_real_escape_string($domain);
			$sql = "SELECT * FROM {$domain}_desc WHERE col_name LIKE '{$col_name}';";
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) == 0){
				mysql_free_result($result);
				return false;
			}
			$row = mysql_fetch_assoc($result);
			mysql_free_result($result);
			return $row;			
		}
		
	}
	
	class groups{
				
		public function select_all(){
			$db = new database();
			$db->connect();
			$result = mysql_query('SELECT * FROM base_groups;');
			return $result;			
		}
			
		public function get_sub_groups($name){
			$db = new database();
			$db->connect();
			$name = mysql_real_escape_string($name);
			$sql = "SELECT * FROM {$name}_groups;";
			$result = mysql_query($sql);
			return $result;
		}
				
		public function isexists($domain, $name, $field_name){
			
			$db = new database();
			$db->connect();

			//in case of field_name = area or main_street the domain must be base
			$sql = "SELECT * FROM {$domain}_groups WHERE {$field_name} LIKE '{$name}';";
			
			//echo $sql.'<br />';
			
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) == 0){
				return false;
			}
			return true;
		}
		
		public function create_group_entry($domain, $name, $field_name){
			
			$db = new database();
			$db->connect();
			
			$sql = "INSERT INTO {$domain}_groups($field_name) VALUES('{$name}');";
			
			//echo $sql.'<br />';
			
			$result = mysql_query($sql);
			if($result == false){
				echo "could not create group entry {$name} in domain {$domain} field {$field_name}<br />";
				return false;
			}
			echo "group entry {$name} created in domain {$domain} field {$field_name}<br />";
			return true;
		}
		
		public function check($table, $group, $isbase){
			$ret = array();
			$i = 0;
			$base = new base();
			//$domain ='';
			
			if($isbase == "1") $domain = 'base';
			else $domain = $table;
			
			$data = new data();			

			$result = $data->get_all_records($table);
			if($result !== false && mysql_num_rows($result) > 0){
				while($row = mysql_fetch_assoc($result)){					
					if($this->isexists($domain, $row[$group], $group) == false){
						$ret[$i++] = $row['id'];
						echo $row['name'].': '.$row['id'].' [ term '.$row[$group].' not exists in '.$domain.": ".$group." ]<br .>";
					}
				}
				
			}
				
			return $ret;
		}
		
		public function collect($table, $group, $isbase){
			$ret = array();
			$i = 0;
			$base = new base();
			//$domain ='';
			
			if($isbase == "1") return false;
			else $domain = $table;
			
			$data = new data();			

			$result = $data->get_all_records($table);
			if($result !== false && mysql_num_rows($result) > 0){
				while($row = mysql_fetch_assoc($result)){					
					if($this->isexists($domain, $row[$group], $group) == false){
						//$ret[$i++] = $row['id'];
						//echo $row['name'].': '.$row['id'].' [ term '.$row[$group].' not exists in '.$domain.": ".$group." ]<br .>";
						if($this->create_group_entry($domain, $row[$group], $group) == false) return false;
					}
				}
				
			}
				
			return true;
		}
		
		public function create($table, $group, $groupname, $isbase){
			$ret = array();
			$i = 0;
			$base = new base();
			//$domain ='';
			
			if($isbase == "1") return false;
			else $domain = $table;
			
			if($this->isexists($domain, $groupname, $group) == false){
				if($this->create_group_entry($domain, $groupname, $group) == false) return false;
			}
				
			return true;
		}		
				
	}
	
	class data{
		
		private function assm_search_all($table, $text){
			$table = mysql_real_escape_string($table);
			$text = mysql_real_escape_string($text);
			$sql = "SELECT * FROM {$table}_data WHERE name LIKE '%{$text}%' OR address LIKE '%{$text}%';";
			return $sql;
		}
		
		public function get_all_records($table){
			$db = new database();
			$db->connect();
			$table = mysql_real_escape_string($table);
			$sql = "SELECT * FROM {$table}_data ORDER BY name;";
			$result = mysql_query($sql);
			return $result;			
		}
		
		public function get_n_records($table, $n){
			$db = new database();
			$db->connect();
			$table = mysql_real_escape_string($table);
			$sql = "SELECT * FROM {$table}_data ORDER BY name LIMIT {$n};";
			$result = mysql_query($sql);
			return $result;			
		}		
		
		public function get_record_by_name($table, $name, $diff){
			$db = new database();
			$db->connect();
			
			$table = mysql_real_escape_string($table);
			$name = mysql_real_escape_string($name);
			$diff = mysql_real_escape_string($diff);

			$sql = "SELECT * FROM {$table}_data WHERE name LIKE '{$name}' AND diff LIKE '{$diff}';";
			$result = mysql_query($sql) or die(mysql_error());
			return $result;						
		}
		
		public function inc_nhits($table, $id){
			$db = new database();
			$db->connect();
			
			$table = mysql_real_escape_string($table);
			//$name = mysql_real_escape_string($name);
			//$diff = mysql_real_escape_string($diff);			
			
			$sql = "SELECT * FROM {$table}_data WHERE id='{$id}';";
			$result = mysql_query($sql) or die(mysql_error());
			
			if($result !== false && mysql_num_rows($result) > 0){
				$row = mysql_fetch_assoc($result);
				$row['nhits']++;
				$sql = "UPDATE {$table}_data SET nhits='{$row['nhits']}' WHERE id='{$id}';";
				mysql_query($sql);				
			}
		}
		
		public function get_by_id($domain, $id){
			$db = new database();
			$db->connect();
			
			$domain = mysql_real_escape_string($domain);
			$id = mysql_real_escape_string($id);		
		
			$sql = "SELECT * FROM {$domain}_data WHERE id='{$id}';";
			return mysql_query($sql);
		}
		
		public function delete($domain, $id){
			$db = new database();
			$db->connect();
			
			$domain = mysql_real_escape_string($domain);
			$id = mysql_real_escape_string($id);		
		
			$sql = "DELETE FROM {$domain}_data WHERE id='{$id}';";
			return mysql_query($sql);
		}
		
		public function create($domain, $fields, $data){
			$db = new database();
			$db->connect();
			
			$sql = "INSERT INTO {$domain}_data(";
			
			$n = count($fields);
			for($i = 0; $i < $n; $i++){				
				$sql .= "{$fields[$i]}";
				if($i < $n - 1) $sql .= ",";
			}
			
			$sql .= ") VALUES(";
			
			$n = count($data);
			for($i = 0; $i < $n; $i++){
				$tmp = str_replace("_", " ", $data[$i]);				
				$sql .= "'{$tmp}'";
				if($i < $n - 1) $sql .= ",";
			}
			
			$sql .= ");";
			
			mysql_query($sql);
			
		}
		
		public function update($domain, $fields, $data){
			$db = new database();
			$db->connect();
			
			//$sql = "UPDATE users SET stat='active' WHERE key LIKE '{$key}' LIMIT 1;";
			
			$sql = "UPDATE {$domain}_data SET";
			
			$n = count($fields);
			for($i = 1; $i < $n; $i++){
				$tmp = str_replace("_", " ", $data[$i]);
				$sql .= "{$fields[$i]}='{$tmp}'";
				if($i < $n - 1) $sql .= ",";
			}
			
			
			$sql .= " WHERE id={$fields[0]} LIMIT 1;";
			
			echo $sql;
			
			mysql_query($sql);
			
			echo mysql_error();
		}
		
		public function reset_access_counters($domain){
			$db = new database();
			$db->connect();
			
			$sql = "UPDATE {$domain}_data SET nhits=0;";
			
			mysql_query($sql);
			
			echo mysql_error();					
		}
		
		public function get_id($domain){
			$db = new database();
			$db->connect();
			$sql = "SELECT * FROM {$domain}_data ORDER BY id DESC;";
			$result = mysql_query($sql);
			if($result != false && mysql_num_rows($result) > 0){
				$row = mysql_fetch_assoc($result);
				$n = $row['id'] + 1;
			} else {
				$n = 1;
			}
			mysql_free_result($result);
			return $n;
		}
	}
	
	class user{//user record: username, passhash, stat[active/inactive/logged_in], type[guest/user/admin], last_login, key, email, realname
		
		public function create_temp($username, $password, $email, $realname, $body){
			
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			$password = mysql_real_escape_string($password);
			$email = mysql_real_escape_string($email);
			$realname = mysql_real_escape_string($realname);
			$body = mysql_real_escape_string($body);
			$key = "";
			
			if (CRYPT_MD5 == 1) {
				$hash = crypt($password);
				$key = crypt($email.$password."randomQuote", $username);
			} else {
				//echo '1.';
				return false;
			}
				
			$sql = "SELECT * FROM users WHERE username LIKE '{$username}' OR email LIKE '{$email}';";
			$result = mysql_query($sql);
			if(mysql_num_rows($result) > 0){
				//echo '2.';
				return false;
			}			
			
			//$sql = "INSERT INTO users(username, passhash, stat, type, last_login, email, realname, body, key) VALUES('{$username}', '{$hash}', 'inactive', 'user', '0', '{$email}', '{$realname}', '{$body}', '{$key}');";			
			$sql = "INSERT INTO users(username, passhash, stat, type, email, realname, body, the_key) VALUES('{$username}', '{$hash}', 'inactive', 'user', '{$email}', '{$realname}', '{$body}', '{$key}');";
			if(!mysql_query($sql)){
				//echo '<br />3.'.mysql_error().'<br />';
				return false;
			}
			return $key;
		}
		
		public function activate_by_key($key){
			
			$db = new database();
			$db->connect();
			
			$key = mysql_real_escape_string($key);
			
			$sql = "SELECT * FROM users WHERE the_key LIKE '{$key}' LIMIT 1;";
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) == 0){
				echo '<br />3.'.mysql_error().'<br />';
				return false;
			}
			
			$row = mysql_fetch_assoc($result);
			mysql_free_result($result);
			if($row['stat'] == 'banned') return false;
			
			$sql = "UPDATE users SET stat='active' WHERE the_key LIKE '{$key}' LIMIT 1;";
			if(!mysql_query($sql)){
				echo '<br />3.'.mysql_error().'<br />';
				return false;
		
			}
			return true;
		}
		
		public function activate($username){
			
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			
			$sql = "UPDATE users SET stat='active' WHERE username LIKE '{$username}' LIMIT 1;";
			mysql_query($sql);			
		}

		
		public function disable($username){
			
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			
			$sql = "UPDATE users SET stat='inactive' WHERE username LIKE '{$username}' LIMIT 1;";
			mysql_query($sql);			
			
		}
		
		public function ban($username){
			
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			
			$sql = "UPDATE users SET stat='banned' WHERE username LIKE '{$username}' LIMIT 1;";
			mysql_query($sql);			
			
		}		
		
		public function check_login($username, $password, $usertype){
			
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			$password = mysql_real_escape_string($password);
			$usertype = mysql_real_escape_string($usertype);
			
			$sql = "SELECT * from users WHERE username LIKE '{$username}' LIMIT 1;";
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) <= 0){
			//	echo 'not found in db.';
				return false;
			}
			$row = mysql_fetch_assoc($result);
			
			if($row['stat'] == 'inactive' || $row['stat'] == 'banned'){
			//	echo 'inactive.';
				return false;
			}
			
			if(CRYPT_MD5 == 1){
				if(crypt($password, $row['passhash']) == $row['passhash']){
					$usertype = $row['type'];
					return true;
				}
			} else {
			//echo 'no sha512.';
				return false;
			}
			
		//	echo 'donno what.';
			
			return false;
		}

		public function change_password($username, $oldpassword, $newpassword){
					
			$db = new database();
			$db->connect();			
			
			//if($this->check_login($username, $password, $usertype) == false) return false;
			
			if (CRYPT_MD5 == 1) {
				$hash = crypt($newpassword);
				$sql = "UPDATE users SET passhash='{$hash}' WHERE username LIKE '{$username}' LIMIT 1;";
				mysql_query($sql);
				return true;
			} else {
				return false;
			}
			return false;
		}

		public function login($username, $password, $usertype){
						
			$c = new jCalendar();
			
			if($this->check_login($username, $password, $usertype) == false) return false;
			
			$db = new database();
			$db->connect();			
			
			$t = $c->date(TIMELOGFMT, NULL, TZ);
			$sql = "UPDATE users SET stat='logged_in',last_login='{$t}' WHERE username LIKE '{$username}' LIMIT 1;";
			mysql_query($sql);
						
			return true;			
		}

		public function logout($username){
			$db = new database();
			$db->connect();	

			$username = mysql_real_escape_string($username);
			
			$sql = "UPDATE users SET stat='active' WHERE username LIKE'{$username}' LIMIT 1;";
			mysql_query($sql);			
			
			return true;			
		}

		public function delete($username){
			
			$db = new database();
			$db->connect();	

			$username = mysql_real_escape_string($username);
			
			$sql = "DELETE FROM users WHERE username LIKE '{$username}' LIMIT 1;";
			mysql_query($sql);			
			
			return true;
			
		}

		public function list_users(){
			$db = new database();
			$db->connect();	
			
			$sql = "SELECT * FROM users;";
				
			return mysql_query($sql);
		}
		
		public function list_users_by_stat($stat){
			$db = new database();
			$db->connect();	
			mysql_real_escape_string($stat);
			$sql = "SELECT * FROM users WHERE stat LIKE '{$stat}';";
				
			return mysql_query($sql);
						
		}
		
		public function get_last_login($username){
			$db = new database();
			$db->connect();	
		
			mysql_real_escape_string($username);
			
			$sql = "SELECT * FROM users WHERE username LIKE '{$username}';";
			return mysql_query($sql);
		}
		
	}
	
	class user_feed{
		
		public function get_feed($username, $domain, $id){
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			$domain = mysql_real_escape_string($domain);
			$id = mysql_real_escape_string($id);

			$sql = "SELECT * FROM user_feedback WHERE username LIKE '{$username}' AND domain LIKE '{$domain}' AND id LIKE '{$id}';";
			$result = mysql_query($sql);
			return $result;
		}
		
		public function set_feed($username, $domain, $id, $score, $comments){
			$db = new database();
			$db->connect();		

			$username = mysql_real_escape_string($username);
			$domain = mysql_real_escape_string($domain);
			$id = mysql_real_escape_string($id);
			$score = mysql_real_escape_string($score);
			$comments = mysql_real_escape_string($comments);
			
			$sql = "SELECT * FROM user_feedback WHERE username LIKE '{$username}' AND domain LIKE '{$domain}' AND id LIKE '{$id}';";
			$result = mysql_query($sql);
			if($result == false || mysql_num_rows($result) == 0){
				$sql = "INSERT INTO user_feedback(username, domain, id, score, comments) VALUES('{$username}', '{$domain}', '{$id}', '{$score}', '{$comments}');";
				$ret = false;
			} else {
				$sql = "UPDATE user_feedback SET id='{$id}', score='{$score}', comments='{$comments}' WHERE username LIKE '{$username}' AND domain LIKE '{$domain}' AND id LIKE '{$id}';";
				$ret = $result;
			}
			
			//echo $sql;
			
			mysql_query($sql);
			
			return $ret;
		}
		
		public function get_all_feeds($username, $domain, $id){
			$db = new database();
			$db->connect();
			
			$username = mysql_real_escape_string($username);
			$domain = mysql_real_escape_string($domain);
			$id = mysql_real_escape_string($id);
			
			$sql = "SELECT * FROM user_feedback";
			$need_and = false;
			
			if($username !== ''){
				if($need_and) $sql .= " AND";
				else $sql .= " WHERE";				
				$sql .= " username LIKE '{$username}'";
				$need_and = true;
			}
			
			if($domain !== ''){
				if($need_and) $sql .= " AND";
				else $sql .= " WHERE";
				$sql .= " domain LIKE '{$domain}'";
				$need_and = true;
			}
			
			if($id !== -1){
				if($need_and) $sql .= " AND";
				else $sql .= " WHERE";				
				$sql .= " id={$id}";
				$need_and = true;
			}
			
			$sql .= ";";
			
			//echo $sql.'<br />';
			
			return mysql_query($sql);
		}
		
		public function calc_user_score($domain, $id){
			$score = 0;
			$n = 0;
						
			$result = $this->get_all_feeds('', $domain, $id);
			
			if($result !== false && mysql_num_rows($result) > 0){
				while($row = mysql_fetch_assoc($result)){
					$score += $row['score'];
					$n++;
				}
			}
			if($n == 0) $n++;
			return intval($score/$n);
		}
		
		
	}
	
	
	class stats{
		public function track_visit($domain, $username, $ip){
			$db = new database();
			$db->connect();

			$username = mysql_real_escape_string($username);
			$domain = mysql_real_escape_string($domain);
			$ip = mysql_real_escape_string($ip);
			
			$c = new jCalendar();
			$t = $c->date(TIMELOGFMT, NULL, TZ);
			
			$sql = "INSERT INTO visit_stats(ip, time, username, domain) VALUES('{$ip}', '{$t}', '{$username}', '{$domain}');";
			mysql_query($sql);
		}
		
		public function get_all(){
			$db = new database();
			$db->connect();
			$sql = "SELECT * FROM visit_stats;";
			$result = mysql_query($sql);
			return $result;
		}
		
		public function get_visits($domain, $username, $ip, $yy, $mm, $dd, $h, $m, $s){
			$db = new database();
			$db->connect();
			
			$need_and = false;
			
			$username = mysql_real_escape_string($username);
			$domain = mysql_real_escape_string($domain);
			$ip = mysql_real_escape_string($ip);
			
			$sql = "SELECT * FROM visit_stats";
			
			if(isset($domain) && $domain != "" && $domain != false){
				$sql .= " WHERE domain LIKE '{$domain}'";
				$need_and = true;
			}
			
			if(isset($username) && $username != "" && $username != false){
				if($need_and == true){
					$sql .= " AND";
				} else $sql .= " WHERE";
				
				$sql .= " username LIKE '{$username}'";
				
				$need_and = true;
			}

			if(isset($ip) && $ip != "" && $ip != false){
				if($need_and == true){
					$sql .= " AND";
				} else $sql .= " WHERE";
				
				$sql .= " ip LIKE '{$ip}'";
				
				//$need_and = true;
			}
			
			$sql .= ";";
			
			$result = mysql_query($sql);
			
			return $result;
		}
		
		public function get_domain_hit($domain){
			$db = new database();
			$db->connect();
			
			$sql = "SELECT * FROM visit_stats WHERE domain LIKE '{$domain}'";
			if(($result = mysql_query($sql)) == false){
				return 0;
			}
			
			$n = mysql_num_rows($result);
			mysql_free_result($result);
			return $n;
		}
		
		public function get_most_hit_domain(){
			$ret = '';
			$nret = 0;
			$base = new base();
			
			$tables = $base->get_tables();
			if($tables == false){
				return false;
			}
			
			while($table = mysql_fetch_assoc($tables)){
				if(($n = $this->get_domain_hit($table['table_name'])) > $nret){
					$nret = $n;
					$ret = $table['table_name'];
				}
			}
			
			mysql_free_result($tables);
			
			$ret = $base->get_table_sc_name($ret);
			
			return $ret;
		}
		
		public function list_domain_hits(){
			$base = new base();
			
			$tables = $base->get_tables();
			if($tables == false){
				return false;
			}
			$total = 0;
			while($table = mysql_fetch_assoc($tables)){
				$n = $this->get_domain_hit($table['table_name']);
				$total += $n;				
				echo "domain {$table['table_name']} has {$n} hits.<br />";
			}
			echo "total hits are: {$total}<br />";
			
			mysql_free_result($tables);
			
		}
	}
	
	class uboard{
		public function insert($id, $pid, $username, $text){
			$db = new database();
			$db->connect();			
			if($id == 0) return;
			$id = mysql_real_escape_string($id);
			$username = mysql_real_escape_string($username);
			$text = mysql_real_escape_string($text);			
			$c = new jCalendar();
			$time = $c->date(LONGTIMEFMT, NULL, TZ);
			$sql = "INSERT INTO user_board(id, pid, username, text, time, plus, minus) VALUES('{$id}', '{$pid}', '{$username}', '{$text}', '{$time}', 0, 0)";
			mysql_free_result(mysql_query($sql));
		}
		public function get_all(){
			$db = new database();
			$db->connect();			
			$sql = "SELECT * FROM user_board ORDER BY id DESC;";
			return mysql_query($sql);
		}
		public function get_id(){
			$db = new database();
			$db->connect();
			$sql = "SELECT * FROM user_board ORDER BY id DESC;";
			$result = mysql_query($sql);
			if($result != false && mysql_num_rows($result) > 0){
				$row = mysql_fetch_assoc($result);
				$n = $row['id'] + 1;
			} else {
				$n = 1;
			}
			mysql_free_result($result);
			return $n;
		}
		public function delete($id){
			$db = new database();
			$db->connect();			
			$sql = "DELETE FROM user_board WHERE id={$id} LIMIT 1;";
			return mysql_query($sql);
		}		
	}
	
	class givefeed{
		public function insert($id, $parent, $username, $text){
			$db = new database();
			$db->connect();			
			if($id == 0) return;
			$id = mysql_real_escape_string($id);
			$username = mysql_real_escape_string($username);
			$text = mysql_real_escape_string($text);			
			$c = new jCalendar();
			$time = $c->date(TIMELOGFMT, NULL, TZ);
			$sql = "INSERT INTO give_feed(id, parent, username, text, time) VALUES('{$id}', '{$parent}', '{$username}', '{$text}', '{$time}')";
			mysql_free_result(mysql_query($sql));
		}
		public function get_all(){
			$db = new database();
			$db->connect();			
			$sql = "SELECT * FROM give_feed ORDER BY id DESC;";
			return mysql_query($sql);
		}
		public function get_id(){
			$db = new database();
			$db->connect();
			$sql = "SELECT * FROM give_feed ORDER BY id DESC;";
			$result = mysql_query($sql);
			if($result != false && mysql_num_rows($result) > 0){
				$row = mysql_fetch_assoc($result);
				$n = $row['id'] + 1;
			} else {
				$n = 1;
			}
			mysql_free_result($result);
			return $n;
		}
		public function delete($id){
			$db = new database();
			$db->connect();			
			$sql = "DELETE FROM give_feed WHERE id={$id} LIMIT 1;";
			return mysql_query($sql);
		}		
	}	
		
	
?>
