<?php
	require_once 'config.php';
	require_once 'db.php';
	
	session_start();
	
//	unset($_SESSION["usertype"]);//allowed user types are guest, user, admin
//	unset($_SESSION["page"]);
	
	if(!isset($_SESSION["usertype"])){
		$_SESSION["usertype"] = "guest";
	}
	if(!isset($_SESSION["username"])){
		$_SESSION["username"] = "guest";
	}
	
	$_SESSION["page"] = "main";
	
	$track = new stats();
	$track->track_visit('main', '', $_SERVER['REMOTE_ADDR']);	
	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset='utf-8'/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>

<frameset rows="100px,50px,*">
	<frameset cols="80%, 20%">    	
        <frame frameborder="0" style="border:thin dashed #666" name="topFrame" noresize="true" scrolling="no" src="top.php"/>
        <frame frameborder="0", style="border:thin dashed #666", name="signinFrame", noresize="true", scrolling="no" src="signin.php"/>
   <frame src="UntitledFrame-30"></frameset>
	<frameset cols="0px, 100%">
		<frame frameborder="0", name="nullFrame", noresize="true", scrolling="no" src="null.php"/>
        <frame frameborder="0", name="gotoFrame", noresize="true", scrolling="no" src="goto.php"/>
    <frame src="UntitledFrame-21"><frame src="UntitledFrame-22"></frameset>    
	<frameset cols="15%, *, 20%">
	    <frame frameborder="0" name="adsFrame" noresize="true" scrolling="yes" src="ads.php"/>
		<frame frameborder="0" name="mainFrame" noresize="true" scrolling="yes" src="main.php"/>
		<frame frameborder="0" name="linksFrame" noresize="true" scrolling="no" src="links.php"/>        
	</frameset>    
</frameset>

<!--
<iframe width="20%" height="100px" frameborder="1" style="border:thin dashed #666" name="signinFrame" noresize="true" scrolling="no" src="signin.php"/></iframe>
<iframe width="70%" height="100px" frameborder="1" style="border:thin dashed #666" name="topFrame" noresize="true" scrolling="no" src="top.php"/></iframe>
<iframe width="99%" height="50px" frameborder="1" style="border:thin dashed #666", name="gotoFrame", noresize="true", scrolling="no" src="goto.php"/></iframe>
<iframe width="14%" height="500px" frameborder="1" style="border:thin dashed #666" name="linksFrame" noresize="true" scrolling="no" src="links.php"/></iframe>
<iframe width="64%" height="500px" frameborder="1" style="border:thin dashed #666" name="mainFrame" noresize="true" scrolling="yes" src="main.php"/></iframe>
<iframe width="19%" height="500px" frameborder="1" style="border:thin dashed #666" name="adsFrame" noresize="true" scrolling="yes" src="ads.php"/></iframe>
-->
<noframes>
<body bgcolor="#E3E3E3">
خطا: مرورگر شما از فریمها پشتیبانی نمیکند.
</body>
</noframes>
</html>
