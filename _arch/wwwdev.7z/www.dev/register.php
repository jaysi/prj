﻿<?php
	require_once("config.php");	
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php
	if($_SESSION['usertype'] == 'guest' || !isset($_SESSION['usertype'])){
		echo 'جهت استفاده از امکانات این بخش باید با نام کاربر معتبر وارد سایت بشوید';
		echo '<br /><a style="float:left" href="'.URL.'/index.php" target="_top">بــازگــشـت</a>';
	} else {
		echo '<p><strong>معرفی</strong></br>';
		echo 'با استفاده از فرم زیر میتوانید یک مکان یا مناسبت جدید را به <u>شهـــر قـــشنگ</u> معرفی کنید؛ بدیهی است موارد پیشنهاد شده پس از بررسی توسط مدیر به سایت اضافه خواهند شد.</p>';
		echo '<form action="register_result.php" method="post">';
		echo '<table border="0px" width="500px"/>';
		//echo '<tr align="right" valign="middle">';
		echo '<tr align="right" valign="middle">';
		echo '<th><label for="subject">موضوع</label></th>';
		echo '<td><input class="transparent" id="subject" maxlength="50" name="subject" style="width: 100%;" type="text"/></td>';
		echo '</tr>';
		echo '<tr align="right" valign="middle">';
		echo '<th><label for="body">پيام برای مدیر سایت</label></th>';
		echo '<td><textarea class="transparent" id="body" name="body" rows="3" style="width: 100%"></textarea></td>';
		echo '</tr>';
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" value="ارسال"/></td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
	}
	
	echo '<br /><br /><br />';
	require_once 'givefeed.php';
	
?>
</body>
</html>