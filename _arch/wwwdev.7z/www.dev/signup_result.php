<?php
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	require_once 'db.php';
	
  
  require_once('extern/recaptchalib.php');
  $privatekey = RECAPTPRIVKEY;
  $resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);

  if (!$resp->is_valid) {
    // What happens when the CAPTCHA was entered incorrectly
    die('عبارت امنیتی را صحیح وارد نمایید. میتوانید دوباره امتحان کنید.');
  } else {
    // Your code here to handle a successful verification
  }
  	

    $flag = true;
    $vars = array('realname', 'username', 'password', 'password2', 'email', 'body');
    foreach($vars as $var) {
        if(!isset($_POST[$var]) || $_POST[$var] == '') {
            $flag = false;
        }
    }
    if($flag && isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] == URL.'/signup.php') {
		
		/*
		//temporary registeration and getting the key.
		
		//create email headers
        $to = $_POST['email'];
		
        $headers = '';
        $headers .= 'From: '.EMAIL."\r\n";
        $headers .= 'Reply-To: '.EMAIL."\r\n";
        $headers .= 'X-Mailer: PHP/'.phpversion();
		
		$msg = $_POST['body'];
		
        $sent = @mail($to, 'قبول ثبت نام در شهـــر قـــشنگ', $msg, $headers);		
		
        echo $sent ? 'پيام با موفقيت ارسال شد.' : 'پيام ارسال نشد. لطفاً دوباره تلاش كنيد.';		
		*/
		
		if($_POST['password'] != $_POST['password2']){
			echo 'رمز عبور یکسان نمیباشد.';
		}
		
		$user = new user();
		
		if(($key = $user->create_temp($_POST['username'], $_POST['password'], $_POST['email'], $_POST['realname'], $_POST['body'])) != false){
			
			$to = $_POST['email'];
			
			$headers = '';
			$headers .= 'From: '.EMAIL."\r\n";
			$headers .= 'Reply-To: '.EMAIL."\r\n";
			$headers .= 'X-Mailer: PHP/'.'4';//.phpversion();
			
			$msg = '';
			$msg .= 'کاربر محترم، با سلام:'."\r\n";
			$msg .= 'با تشکر از اقدام شما برای عضویت در شهـــر قـــشنگ'."\r\n";
			$msg .= 'لطفا جهت تکمیل مراحل ثبت نام برروی پیوند زیر کلیک کنید.'."\r\n";
			$msg .= URL.'/signup_finish.php?key='.$key;
			
			$sent = @mail($to, 'قبول ثبت نام در وب سایت شهـــر قـــشنگ', $msg, $headers);
			
			if($sent){
				echo 'درخواست شما با موفقیت ثبت شد؛ لطفا جهت تکمیل مراحل ثبت نام به پست الکترونیک خود مراجعه نمایید.';
			} else {
				$user->delete($_POST['username']);
				echo 'پيام ارسال نشد. لطفاً دوباره تلاش كنيد.';
			}
		} else {
			echo 'عدم موفقیت در ثبت کاربر.';
		}
		
    } else {
		echo 'لطفا اطلاعات خواسته شده را وارد کنید.';
	}
	
	//echo '<a href="'.URL.'/index.php" target="_top">بازگشت به صفحه اصلي</a><br/>';
?>
<br/>
</body>
</html>