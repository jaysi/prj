<?php  
    require_once 'config.php';
	session_start();	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">

<ul class="link">
<li><a href="<?PHP echo URL; ?>/main.php" target="mainFrame">صفحه اصلی</a></li>
<li><a href="<?PHP echo URL; ?>/uboard.php" target="mainFrame">تخته سیاه</a></li>
<li><a href="<?PHP echo URL; ?>/register.php" target="mainFrame">معرفی</a></li>
<li><a href="<?PHP echo URL; ?>/guide.php" target="mainFrame">راهنما</a></li>
<!--li><a href="<?PHP /*echo URL;*/ ?>/gallery.php?height=100&width=100&items=4" target="_blank">آلبوم تصاوير</a></li><-->
<li><a href="<?PHP echo URL; ?>/contact.php" target="mainFrame">ارتباط با ما</a></li>
<li><a href="<?PHP echo URL; ?>/about.php" target="mainFrame">درباره ما</a></li>
</ul>
<?php $_SESSION['gf_ref'] = $_SERVER['PHP_SELF']; require_once 'givefeed.php'; ?>
</body>
</html>