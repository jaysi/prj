<?php
	require_once("config.php");	
	session_start();	
	if(!isset($_SERVER['HTTP_REFERER']) || $_SERVER['HTTP_REFERER'] != URL.'/signin.php'){
		header('location: index.php');
		exit();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/signin.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<?php
	require_once('db.php');
	$user = new user();
	$user->logout($_SESSION['username']);
	$_SESSION['username'] = 'guest';
	$_SESSION['usertype'] = 'guest';
	header('location: signin.php');
?>
</body>
</html>