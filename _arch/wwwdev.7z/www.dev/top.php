<?php
    //Copyright محمد مصطفي شهركي @ http://www.ncis.ir
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body class="nomargin;" style="background-image: url(main.jpg); background-repeat: repeat;">
<a href="<?php echo URL; ?>" target="_top"><img src="title.png" style="height:100px; width:81%"/></a>
</body>
</html>