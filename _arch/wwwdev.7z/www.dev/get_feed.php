<?php
	require_once 'config.php';
	
	session_start();
	
	if(!isset($_SERVER['HTTP_REFERER']) || strstr($_SERVER['HTTP_REFERER'], URL.'/go_select.php') == FALSE ){
		header('location: main.php');
		exit();
	}
	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset='utf-8'/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<base target="mainFrame"/>
<?php
	require_once('db.php');
	
	if($_POST['score'] > -6 && $_POST['score'] < 6){
		
		$uf = new user_feed();
		$uf->set_feed($_POST['username'], $_POST['domain'], $_POST['id'], $_POST['score'], $_POST['comments']);
		echo 'ممنون از نظرات شما!<br />';
	} else {
		echo 'ممنون از نظرات شما#<br />';
	}	
		
	echo '<a style="float:left" href="'.URL.'/go.php?where='.$_POST['domain'].'" target="mainFrame">بــازگــشـت</a>';
?>
</body>
</html>