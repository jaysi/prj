<?php    
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<base target="_blank"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php
    $flag = true;
    $vars = array('height', 'width', 'items');
    foreach($vars as $var) {
        if(!isset($_GET[$var]) || $_GET[$var] == '' || !is_numeric($_GET[$var])) {
            $flag = false;
        }
    }
    if(!$flag) {
        header('location: main.php');
        exit();
    }
    $thumbs = scandir('thumbs');
    foreach($thumbs as $thumb) {
        $pi = pathinfo('thumbs/'. $thumb);
        if(isset($pi['extension']) && strtolower($pi['extension']) == 'jpg') {
            unlink('thumbs/'.$thumb);
        }
    }
    $images = scandir('images');
    foreach($images as $image) {
        $pi = pathinfo('images/'.$image);
        if(isset($pi['extension']) && strtolower($pi['extension']) == 'jpg') {
            $src = imagecreatefromjpeg('images/'.$image);
            $dst = imagecreatetruecolor($_GET['width'], $_GET['height']);
            imagecopyresized($dst, $src, 0, 0, 0, 0, $_GET['width'], $_GET['height'], imagesx($src), imagesy($src));
            imagejpeg($dst, 'thumbs/'.$image, 100);
            imagedestroy($src);
            imagedestroy($dst);
        }
    }
    echo '<table border="0px" width="100%">'."\n";
    $thumbs = scandir('thumbs');
    $count = 0;
    foreach($thumbs as $thumb) {
        $pi = pathinfo('thumbs/'.$thumb);
        if(isset($pi['extension']) && strtolower($pi['extension']) == 'jpg') {
            if($count == 0) {
                echo '<tr align="center" valign="middle">'."\n";
            }
            echo '<td>';
            echo '<a href="'.URL.'/images/'.$thumb.'">';
            echo '<img src="'.URL.'/thumbs/'.$thumb.'"/>';
            echo '</a>';
            echo '</td>'."\n";
            $count++;
            if($count == $_GET['items']) {
                echo '</tr>'."\n";
                $count = 0;
            }
        }
    }
    if($count != 0) {
        while($count < $_GET['items']) {
            echo '<td>&nbsp;</td>'."\n";
            $count++;
        }
        echo '</tr>'."\n";
    }
    echo '</table>'."\n";
?>
</body>
</html>