﻿<?php
	
	ini_set('error_reporting', FALSE);
	error_reporting(0);//E_ALL);
	ini_set('log_errors',FALSE);
	ini_set('html_errors',FALSE);
	//ini_set('error_log','c:/www/php_err.log');	
	ini_set('display_errors',FALSE);
	
	define('TITLE', 'شهـــر قـــشنگ');
	define('URL', 'http://www.shahreghashang.ir');
	define('HOST', 'shahreghashang.ir');//mysql host
	define('EMAIL', 'contact@shahreghashang.ir');
	define('USER', 'shahregh_user');
	define('PASS', 'GlubDubDr1b');
	define('DB', 'shahregh_db1');
	define('MASTER', 'admin');
	define('MASTERPW', '$1$4k/.595.$RWD9ptVm47EDa.oqaw6Si0');//Google+isD3AD

	define('LONGTIMEFMT', 'l j/F/Y H:i:s');
	define('SHORTTIMEFMT', '');
	define('TIMELOGFMT', 'Y-m-d-H-i-s');
	define('TZ', 16200);
	
	define ('RECAPTPUBKEY', '');
	define ('RECAPTPRIVKEY', '');
	
?>