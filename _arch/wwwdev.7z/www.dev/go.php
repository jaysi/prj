<?php
	require_once("config.php");
	session_start();
	
	if( !isset($_SERVER['HTTP_REFERER']) || ($_SERVER['HTTP_REFERER'] != URL.'/goto.php' && strstr($_SERVER['HTTP_REFERER'], URL.'/go_select.php') == false && strstr($_SERVER['HTTP_REFERER'], URL.'/select_result.php') == false && strstr($_SERVER['HTTP_REFERER'], URL.'/get_feed.php') == false) ){
		header('location: main.php');
		exit();
	}
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/go.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php
	
	//show base select menu instead of links menu
		
	echo '<script language="JavaScript" type="text/javascript">';
	echo "parent.linksFrame.location=\"".URL."/select.php?where={$_GET['where']}\";";
	echo '</script>';
	
    require_once 'db.php';
	require_once 'pub.php';
	$track = new stats();
	$data = new data();
	$db = new database();
	
	$track->track_visit($_GET['where'], $_SESSION['username'], $_SERVER['REMOTE_ADDR']);
	
	$result = $data->get_all_records($_GET['where']) or die();	
	if($result !== false && mysql_num_rows($result) > 0) {
		echo '<ul class="link">';
		while($row = mysql_fetch_assoc($result)){
			
			//$name = str_replace(" ", "_", $row['name']);
			//$diff = str_replace(" ", "_", $row['diff']);
			
			//if($diff == '') $diffstr = $row['main_street'];
			//else $diffstr = $diff;
			
			//$name = $row['name'];			
			//if($row['diff'] != ""){
			//	$diff = "&nbsp&nbsp&nbsp[ ".$db->farsi_num($row['diff'])." ]";
			//} else {
			//	$diff = "";
			//}
			//$name = $db->farsi_num($row['name']);
			echo "<li>";
			//echo"<a href=".URL."/go_select.php?where={$_GET['where']}&id={$row['id']} target=\"mainFrame\">{$name}{$diff}</a>";
			create_goto_link($_GET['where'], $row['id'], $row['name'], $row['diff'], $db);
			echo "</li>";
		}
		echo '</ul>';
	}
	
	$_SESSION['gf_ref'] = $_SERVER['PHP_SELF'];
	require_once 'givefeed.php';
?>
</body>
</html>