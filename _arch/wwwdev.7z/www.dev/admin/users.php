<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == 'guest'){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

    require_once '../db.php';
	
	$user = new user();
	
	$result = $user->list_users();
		
	if($result !== false && mysql_num_rows($result) > 0) {
		
		echo "found ".count($result)." user(s);<br /><br />";
		
		echo '<p>';
		
		while($row = mysql_fetch_row($result)){
			for($i = 0; $i < mysql_num_fields($result); $i++){
				echo '<strong>'.mysql_field_name($result, $i).":</strong> ".$row[$i]."<br />";
			}
			
			//active/delete/inactive buttons			
			echo '<FORM ACTION="users_act.php" METHOD=POST>';
			echo '<INPUT TYPE="radio" NAME="act" VALUE="enable"/>Enable';
			echo '<INPUT TYPE="radio" NAME="act" VALUE="disable"/>Disable';
			echo '<INPUT TYPE="radio" NAME="act" VALUE="delete"/>Delete';
			echo '<INPUT TYPE="radio" NAME="act" VALUE="ban"/>Ban';
			echo '<INPUT TYPE="hidden" name="username" value="'.$row[0].'"/>';
			echo '<input type="submit" value="submit"/>';
			echo '</form>';
			echo "<strong>+++++++++++++</strong>";
		}
		
		echo '</p>';
	}	
?>
</body>
</html>
