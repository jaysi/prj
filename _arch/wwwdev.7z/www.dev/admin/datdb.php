<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(
		!isset($_SESSION['usertype']) ||
		(
		 $_SESSION['usertype'] != 'admin' &&
		 $_SESSION['usertype'] != 'op'
		)
	){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

    require_once('../db.php');
	
	function show_select($where, $base, $col_name, $col_sc_name, $sel_type){
		$groups = new groups();
		echo '<tr align="left" valign="middle">';
		echo '<th width="10%"><label for="'.$col_name.'">'.$col_sc_name.'</label></th>';		
		echo '<td><select class="transparent" id="'.$col_name.'" maxlength="50" name="'.$col_name.'" style="width: 100%;" type="'.$sel_type.'"/>';
		
		if($base == 0){
			$result = $groups->get_sub_groups($where);		
		} else {
			$result = $groups->select_all();
		}
		
		if($result !== false && mysql_num_rows($result) > 0) {
			while($row = mysql_fetch_assoc($result)) {
				if($row[$col_name] != ''){
						$tmp = str_replace(" ", "_", $row[$col_name]);
						echo '<option value="'.$tmp.'">'.$row[$col_name].'</option>';
				}
			}
		}
		echo '</select>';
		echo '</td></tr>';
	}
	
	function show_selected($where, $base, $col_name, $col_sc_name, $sel_type, $default){
		$groups = new groups();
		echo '<tr align="left" valign="middle">';
		echo '<th width="10%"><label for="'.$col_name.'">'.$col_sc_name.'</label></th>';		
		echo '<td><select class="transparent" id="'.$col_name.'" maxlength="50" name="'.$col_name.'" style="width: 100%;" type="'.$sel_type.'"/>';
		
		$tmp = str_replace(" ", "_", $default);
		echo '<option value="'.$tmp.'">'.$default.'</option>';
		
		if($base == 0){
			$result = $groups->get_sub_groups($where);		
		} else {
			$result = $groups->select_all();
		}
		
		if($result !== false && mysql_num_rows($result) > 0) {
			while($row = mysql_fetch_assoc($result)) {
				if($row[$col_name] != '' && $row[$col_name] != $default){
						$tmp = str_replace(" ", "_", $row[$col_name]);
						echo '<option value="'.$tmp.'">'.$row[$col_name].'</option>';
				}
			}
		}
		echo '</select>';
		echo '</td></tr>';
	}	
	
	//$all = new data();
	$groups = new groups();
	$base = new base();
	$tables = $base->get_tables();	
	
	if(!isset($_POST['domain'])){
		$base = new base();
		$result = $base->get_tables();
		echo 'select domain please.<br />';
		echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';
		echo '<table border="0px" width="200px"/>';
		echo '<tr align="left" valign="middle">';
		echo '<th width="50px"><label for "domain">domain:</label></th>';
		echo '<td><select mutiple="single" name="domain" type="text" dir="rtl" lang="fa" style="width: 100%;"/>';
		if($result != false && mysql_num_rows($result) > 0){
			while($row = mysql_fetch_assoc($result)){
				echo '<option value="'.$row['table_name'].'">'.$row['table_name'].' - '.$row['table_sc_name'].'</option>';
			}
		}
		echo '</select>';
		echo '</td></tr>';
		mysql_free_result($result);
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" value="select"/></td>';
		echo '</tr>';
		echo '</table></form>';
	} else {
		if(!isset($_POST['act'])){
			$data = new data();
			$result = $data->get_all_records($_POST['domain']);
			if($result == false){
				die('could not get records: '.mysql_error());
			}
			
			echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';			

			echo '<input type="hidden" name="domain" value="'.$_POST['domain'].'" />';
			
			echo '<table border="1px" width="100%"/>';
			echo '<tr align="left" valign="middle">';
			echo '<th width="5%"><label for "id">enter id:</label></th>';
			echo '<td colspan="2">';
			echo '<input type="text" name="id" style="width: 20%;"/>';		
			echo '<input style="width: 10%;" type="submit" name="act" value="edit"/>';
			echo '<input style="width: 10%;" type="submit" name="act" value="delete"/>';
			echo '<input style="width: 10%;" type="submit" name="act" value="new"/>';
			echo '<input style="width: 10%;" type="submit" name="act" value="reset_access_counters"/>';
			echo '</td>';
			echo '</tr>';

			while($row = mysql_fetch_row($result)){
				$i = 0;
				while($i < mysql_num_fields($result)){
					echo '<tr align="left" valign="middle">';
					echo '<th>'.mysql_field_name($result, $i).'</th><td>'.$row[$i].'</td>';
					echo '</tr>';
					$i++;
				}
				echo '<tr><th>NEXT</th><td align="middle"><strong>********************</strong></td></tr>';
			}
			
			mysql_free_result($result);
			
			echo '</table></form>';
		} else {
			$data = new data();
			$desc = new desc();			
			switch($_POST['act']){
				case "edit":
					$result = $data->get_by_id($_POST['domain'], $_POST['id']);
					if($result == false){
						die('could not get records: '.mysql_error());
					}
					$row = mysql_fetch_row($result);
					echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';

					echo '<input type="hidden" name="domain" value="'.$_POST['domain'].'" />';

					echo '<table border="1px" width="100%"/>';					
					$i = 0;
					while($i < mysql_num_fields($result)){
						echo '<tr align="left" valign="middle">';
						$field = mysql_field_name($result, $i);
						$descrow = $desc->get_desc($_POST['domain'], $field);
						if($i == 0){
							echo '<th width="20%"><label for "id">id</label></th><td width="80%"><input type="text" readonly="true" name="id" value="'.
								$_POST['id'].'" style="width: 100%;"></td>';
							echo '</tr>';	
						} else {
							switch($descrow['group']){
								case "0":
									echo '<th width="20%"><label for "'.$field.'">'.$desc->get_sc_name($_POST['domain'], $field).
											'</label></th><td width="80%"><input type="text" name="'.$field.'" value="'.$row[$i].'" style="width: 100%;"></td>';
									echo '</tr>';
								break;
								case "1":
									show_selected($_POST['domain'], $descrow['base'], $descrow['col_name'], $descrow['col_sc_name'], $descrow['sel_type'], $row[$i]);
								break;
								default:
								break;
							}
						}
						$i++;
					}
					
					mysql_free_result($result);
					
					echo '<tr align="left" valign="middle">';					
					echo '<td colspan="2">';
					echo '<input style="width: 20%;" type="submit" name="act" value="update"/>';
					echo '</td>';
					echo '</tr>';					
					
					echo '</table></form>';
										
				break;
				
				case "delete":
					$data->delete($_POST['domain'], $_POST['id']);
					echo 'done.';					
				break;
				
				case "new":
					$result = $data->get_n_records($_POST['domain'], 1);
					if($result == false){
						die('could not get records: '.mysql_error());
					}
					
					echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';
					
					echo '<input type="hidden" name="domain" value="'.$_POST['domain'].'" />';

					echo '<table border="1px" width="100%"/>';

					$i = 0;
					while($i < mysql_num_fields($result)){
						echo '<tr align="left" valign="middle">';
						$field = mysql_field_name($result, $i);
						$descrow = $desc->get_desc($_POST['domain'], $field);
						if($i == 0){
							echo '<th width="20%"><label for "id">id</label></th><td width="80%"><input type="text" readonly="true" name="id" value="'.
								$data->get_id($_POST['domain']).'" style="width: 100%;"></td>';
							echo '</tr>';	
						} else {
							switch($descrow['group']){
								case "0":
									echo '<th width="20%"><label for "'.$field.'">'.$desc->get_sc_name($_POST['domain'], $field).
											'</label></th><td width="80%"><input type="text" name="'.$field.'" style="width: 100%;"></td>';
									echo '</tr>';
								break;
								case "1":
									show_select($_POST['domain'], $descrow['base'], $descrow['col_name'], $descrow['col_sc_name'], $descrow['sel_type']);
								break;
								default:
								break;
							}
						}
						$i++;
					}
					
					mysql_free_result($result);
					
					echo '<tr align="left" valign="middle">';					
					echo '<td colspan="2">';
					echo '<input style="width: 20%;" type="submit" name="act" value="create_new"/>';
					echo '</td>';
					echo '</tr>';					
					
					echo '</table></form>';
					
				break;
				
				case "create_new":
					echo 'creating record, please wait...';					
					$result = $data->get_n_records($_POST['domain'], 1);
					if($result == false){
						die('could not get records: '.mysql_error());
					}
					$i = 0;
					$fields = array();
					$info = array();
					while($i < mysql_num_fields($result)){
						$field = mysql_field_name($result, $i);
						if($i == 0 && $field == '') $field = 'id';
						$fields[$i] = $field;
						$info[$i] = $_POST[$field];
						$i++;
					}
					
					$data->create($_POST['domain'], $fields, $info);
										
				break;
				
				case "update":
					echo 'updating record, please wait...';					
					$result = $data->get_n_records($_POST['domain'], 1);
					if($result == false){
						die('could not get records: '.mysql_error());
					}
					$i = 0;
					$fields = array();
					$info = array();
					while($i < mysql_num_fields($result)){
						$field = mysql_field_name($result, $i);
						if($i == 0 && $field == '') $field = 'id';
						$fields[$i] = $field;
						$info[$i] = $_POST[$field];
						$i++;
					}
					
					$data->update($_POST['domain'], $fields, $info);
										
				break;
				
				case "reset_access_counters":
					$data->reset_access_counters($_POST['domain']);
				break;
				
				default:
				break;
			}
			
		}
	}
	
?>
</body>
</html>
