<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 $_SERVER['HTTP_REFERER'] != URL.'/signin.php' &&
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(
		!isset($_SESSION['usertype']) ||
		(
		 $_SESSION['usertype'] != 'admin' &&
		 $_SESSION['usertype'] != 'op'
		)
	){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	echo '<script language="JavaScript" type="text/javascript">';
	echo "parent.linksFrame.location=\"".URL."/admin/deck.php\";";
	echo '</script>';

    require_once '../db.php';
	$user = new user();
	$stat = new stats();
	
	function show_total_visitors(){
		$stat = new stats();
		
		$result = $stat->get_all();
		if($result == false) echo "error found in database: ".mysql_error()."<br />";
		else echo "total visitors: <u>".mysql_num_rows($result)."</u><br />";
		mysql_free_result($result);
	}
	
	function show_total_members(){
		$user = new user();
		
		$result = $user->list_users();
		if($result == false) echo "error found in database: ".mysql_error()."<br />";
		else echo "total registered users: <u>".mysql_num_rows($result)."</u><br />";
		mysql_free_result($result);
		
		$result = $user->list_users_by_stat('logged_in');
		if($result == false) echo "error found in database: ".mysql_error()."<br />";
		else echo "total logged in users: <u>".mysql_num_rows($result)."</u><br />";
		mysql_free_result($result);
			
		$result = $user->list_users_by_stat('active');
		if($result == false) echo "error found in database: ".mysql_error()."<br />";
		else echo "total active users: <u>".mysql_num_rows($result)."</u><br />";
		mysql_free_result($result);
		
	}
	
	function show_domain_hits(){
		$stat = new stats();
		echo '<br /><strong>domain hits:</strong><br />';
		$stat->list_domain_hits();
	}
		
	echo '<strong>website statistics:</strong><br />';
	
	show_total_visitors();
	
	//show_this_year_visitors();
	
	//show_this_month_visitors();
	
	//show_today_visitors();
	
	show_total_members();
	
	show_domain_hits();
		
?>
</body>
</html>
