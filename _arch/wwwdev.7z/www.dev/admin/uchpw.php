<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == 'guest'){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	echo '<script language="JavaScript" type="text/javascript">';
	echo "parent.linksFrame.location=\"".URL."/admin/udeck.php\";";
	echo '</script>';

    require_once '../db.php';
	
	if(!isset($_POST['newpass'])){
		echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';
		echo '<table border="0px" width="200px"/>';
		echo '<tr align="left" valign="middle">';
		echo '<th width="50px"><label for "newpass">new password:</label></th>';
		echo '<td><input name="newpass" type="text" dir="ltr" lang="fa" style="width: 100%;"/></td></tr>';	
		echo '<tr align="left" valign="middle">';
		echo '<td colspan="2"><input name="submit" type="submit" dir="ltr" lang="fa"  value="submit" style="width: 100%;"/></td>';
		echo '</tr>';
		echo '</table>';
		echo '</form>';
		
	} else {
		$user = new user();
		if($user->change_password($_SESSION['username'], "", $_POST['newpass']) == true){
			echo 'password changed successfully.<br />';
		} else {
			echo 'could not change password.<br />';
		}
	}
	
?>
</body>
</html>
