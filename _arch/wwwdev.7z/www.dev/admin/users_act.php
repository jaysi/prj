<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == 'guest'){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

    require_once '../db.php';
	
	$user = new user();
	
	//echo $_POST['act'];
	
	if(isset($_POST['act'])){
		switch($_POST['act']){
			case "enable":
			$user->activate($_POST['username']);
			break;
			case "disable":
			$user->disable($_POST['username']);
			break;
			case "delete":
			$user->delete($_POST['username']);
			break;
			case "ban":
			$user->ban($_POST['username']);
			break;
			default:
			break;			
		}
	}
	
	//echo mysql_error();
	header('location: users.php');
	exit();
	
?>
</body>
</html>
