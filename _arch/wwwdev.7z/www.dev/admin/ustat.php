<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == 'guest'){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	echo '<script language="JavaScript" type="text/javascript">';
	echo "parent.linksFrame.location=\"".URL."/admin/udeck.php\";";
	echo '</script>';

    require_once '../db.php';
	
	function logtimetostrtime($logtime){
		$c = new jCalendar();
		$db = new database();
		
		$t = $db->latin_num($logtime);
		$t = explode("-", $logtime);

		for($i = 0; $i < count($t); $i++){
			if($t[$i] == "*"){
								
				if($i == 3 && $t[$i] == "*"){
					if($t[$i+1] == "*" && $t[$i+2] == "*") break;
				} else {
					$str .= " - ";
				}

				switch($i){
					case 0:
					$str = "�� ���";					
					break;
					case 1:
					$str .= "�� ���";					
					break;
					case 2:
					$str .= "�� ���";
					break;
					case 3:
					$str .= "��� �����";
					break;
					case 4:
					$str .= "��� �����";
					break;
					case 5:
					$str .= "��� ����� ��";
					break;
					default:
					break;
				}
			} else {
				
				switch($i){
					case 0:
					$str = "��� ";					
					break;
					case 1:
					$str .= "��� ";					
					break;
					case 2:
					$str .= "��� ";
					break;
					case 3:
					$str .= "���� ";
					break;
					case 4:
					$str .= "����� ";
					break;
					case 5:
					$str .= "����� ";
					break;
					default:
					break;
				}
				
				$str .= $t[$i];
				
			}
			
			if($i<2) $str .= "/";
			else if($i==2) {}
			else if($i < 5) $str .= ":";
		}
		/*
		for($i = 0; $i < count($t); $i++){
			echo $i.'->'.$t[$i].'.';
		}
		
		$timestamp = $c->mktime(	$t[3]=="*"?0:$t[3]=="*"?0:$t[3], $t[4]=="*"?0:$t[4],
									$t[5]=="*"?0:$t[5], $t[1]=="*"?0:$t[1],
									$t[2]=="*"?0:$t[2], $t[0]=="*"?0:$t[0]);
		
		return $c->date(LONGTIMEFMT, $timestamp, TZ);
		*/
		
		return $str;//'<span dir="rtl">'.$str.'</span>';
	}	
		
	function show_visits(){
		$stat = new stats();
		
		$result = $stat->get_visits('', $_SESSION['username'], '', '', '', '', '', '', '');
		if($result == false || mysql_num_rows($result) == 0){
			mysql_free_result($result);
			return;
		}
		
		while($row = mysql_fetch_assoc($result)){
			echo "@ ".logtimetostrtime($row['time'])." in ".$row['domain']." from ".$row['ip']."<br />";
		}
	}
	
	echo '<strong>Visited section list:</strong><br />';
	
	show_visits();
?>
</body>
</html>
