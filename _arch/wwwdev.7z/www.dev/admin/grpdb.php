<?php    
    require_once('../config.php');
	session_start();
	
	if(
		!isset($_SERVER['HTTP_REFERER']) ||
		(
		 !strstr($_SERVER['HTTP_REFERER'], URL.'/admin/') &&
		 $_SERVER['HTTP_REFERER'] != $_SERVER['PHP_SELF']
		)
	){
		header('location: ../main.php');
		exit();
	}
	
	if(
		!isset($_SESSION['usertype']) ||
		(
		 $_SESSION['usertype'] != 'admin' &&
		 $_SESSION['usertype'] != 'op'
		)
	){
		header('location: ../main.php');
		exit();		
	}
?>
<!doctype html>
<html dir="ltr">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="../css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

    require_once('../db.php');
	
	//$all = new data();
	$groups = new groups();
	$base = new base();
	$tables = $base->get_tables();	
	
	if(!isset($_POST['domain'])){
		$base = new base();		
		$result = $base->get_tables();
		echo 'select domain please.<br />';
		echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';
		echo '<table border="0px" width="200px"/>';
		echo '<tr align="left" valign="middle">';
		echo '<th width="50px"><label for "domain">domain:</label></th>';
		echo '<td><select mutiple="single" name="domain" type="text" dir="rtl" lang="fa" style="width: 100%;"/>';
		if($result != false && mysql_num_rows($result) > 0){
			while($row = mysql_fetch_assoc($result)){
				echo '<option value="'.$row['table_name'].'">'.$row['table_name'].' - '.$row['table_sc_name'].'</option>';
			}
		}
		echo '</select>';	
		echo '</td></tr>';
		mysql_free_result($result);
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" value="select"/></td>';
		echo '</tr>';
		echo '</table></form>';
	} else if(!isset($_POST['field'])) {
		$desc = new desc();
		$descres = $desc->get($_POST['domain']);
		//$result = $base->get_tables();
		echo "using domain <u>{$_POST['domain']}</u>; select <u>field</u> please.<br />";
		echo '<form action="'.$_SERVER['PHP_SELF'].'" method="post" enctype="utf-8">';
		echo '<table border="0px" width="400px"/>';
		echo '<tr align="left" valign="middle">';
		echo '<th width="50px"><label for "field">field:</label></th>';
		echo '<td><select mutiple="single" name="field" type="text" dir="rtl" lang="fa" style="width: 100%;"/>';
		if($descres !== false && mysql_num_rows($descres) > 0){
			while($descrow = mysql_fetch_assoc($descres)){
				if($descrow['group'] == 1){
						echo '<option value="'.$descrow['col_name'].'-'.$descrow['base'].'">'.$descrow['col_name'].' - '.$descrow['col_sc_name'].' / base = '.$descrow['base'].'</option>';
				}
			}
		}
		mysql_free_result($result);
		echo '</select>';	
		echo '</td></tr>';
		
		echo '<tr align="left" valign="middle">';
		echo '<th width="50px"><label for "groupname">groupname:</label></th>';
		echo '<td><input type="text" name="groupname"></td></tr>';
		
		echo "<input type=\"hidden\" value={$_POST['domain']} name=\"domain\" id=\"domain\";/>";		
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" name="choice" value="check"/></td>';
		echo '</tr>';
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" name="choice" value="collect"/></td>';
		echo '</tr>';
		echo '<tr align="center" valign="middle">';
		echo '<td colspan="2"><input style="width: 100%;" type="submit" name="choice" value="new"/></td>';
		echo '</tr>';		
		echo '</table></form>';
	} else {
		switch($_POST['choice']){
			
			case "check":		
			$f = explode("-", $_POST['field']);
			
			echo "checking groups in domain <u>{$_POST['domain']}</u>, field <u>{$f[0]}</u>,";
			
			if($f[1] == "1"){
				echo " in <u>global</u> groups";
			} else {
				echo " in <u>local</u> groups";
			}
			
			echo " please wait...<br />";
			
			$result = $groups->check($_POST['domain'], $f[0], $f[1]);
			
			echo "done, found <u>".count($result)."</u> bogus entries.<br />";
			
			/*
			for($i = 0; $i < count($result); $i++){						
				echo 'id: '.$result[$i].'<br />';
				
			}
			*/
			//mysql_free_result($result);
			break;
			
			case "collect":
			$f = explode("-", $_POST['field']);
			
			echo "collecting groups in domain <u>{$_POST['domain']}</u>, field <u>{$f[0]}</u>,";
			
			if($f[1] == "1"){
				echo " in <u>global</u> groups";
			} else {
				echo " in <u>local</u> groups";
			}
			
			echo " please wait...<br />";
			
			$result = $groups->collect($_POST['domain'], $f[0], $f[1]);
			
			if($result == false){
				echo 'failed: '.mysql_error().'<br />';
			} else {
				echo 'done.<br />';
			}
			
			
			break;
			
			case "new":
			$f = explode("-", $_POST['field']);
			
			echo "creating group in domain <u>{$_POST['domain']}</u>, field <u>{$f[0]}</u>,";
			
			if($f[1] == "1"){
				echo " in <u>global</u> groups";
			} else {
				echo " in <u>local</u> groups";
			}
			
			echo " please wait...<br />";
			
			$result = $groups->create($_POST['domain'], $f[0], $_POST['groupname'], $f[1]);
			
			if($result == false){
				echo 'failed: '.mysql_error().'<br />';
			} else {
				echo 'done.<br />';
			}
			
			
			break;			
			
			default:
				echo 'value '.$_POST['choice'].' selected<br />';
			break;		
		}
	}
	
?>
</body>
</html>
