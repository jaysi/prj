<?php    
    require_once '../config.php';
	session_start();
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] != 'admin'){
		header('location: ../links.php');
		exit();		
	}
?>	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?PHP echo TITLE; ?></title>
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<base target="mainFrame"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<ul class="link">
<li><a href="<?PHP echo URL; ?>/admin/admin.php">صفحه اصلی</a></li>
<li><a href="<?PHP echo URL; ?>/admin/users.php">کاربران</a></li>
<li><a href="<?PHP echo URL; ?>/admin/grpdb.php">کنترل  گروهها</a></li>
<li><a href="<?PHP echo URL; ?>/admin/datdb.php">کنترل  داده ها</a></li>
</ul>
</body>
</html>