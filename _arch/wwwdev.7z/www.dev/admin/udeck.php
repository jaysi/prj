<?php    
    require_once '../config.php';
	session_start();
	
	if(!isset($_SESSION['usertype']) || $_SESSION['usertype'] == 'guest'){
		header('location: ../links.php');
		exit();		
	}	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?PHP echo TITLE; ?></title>
<link href="../css/style.css" rel="stylesheet" type="text/css"/>
<base target="mainFrame"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<ul class="link">
<li><a href="<?PHP echo URL; ?>/admin/uacc.php">صفحه اصلی</a></li>
<li><a href="<?PHP echo URL; ?>/admin/ustat.php">آمار</a></li>
<li><a href="<?PHP echo URL; ?>/admin/uchpw.php">تعویض رمز عبور</a></li>
</ul>
</body>
</html>