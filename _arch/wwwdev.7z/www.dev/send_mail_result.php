<?php    
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

  require_once('extern/recaptchalib.php');
  $privatekey = RECAPTPRIVKEY;
  $resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);

  if (!$resp->is_valid) {
    // What happens when the CAPTCHA was entered incorrectly
    die('عبارت امنیتی را صحیح وارد نمایید. میتوانید دوباره امتحان کنید.');
  } else {
    // Your code here to handle a successful verification
  }


    $flag = true;
    $vars = array('name', 'email', 'subject', 'body');
    foreach($vars as $var) {
        if(!isset($_POST[$var]) || $_POST[$var] == '') {
            $flag = false;
        }
    }
    if($flag && isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] == URL.'/contact.php') {
        $to = EMAIL;
        $headers = '';
        $headers .= 'From: '.$_POST['email']."\r\n";
        $headers .= 'Reply-To: '.$_POST['email']."\r\n";
        $headers .= 'X-Mailer: PHP/'.'4';//.phpversion();
        $sent = @mail($to, $_POST['subject'], $_POST['body'], $headers);
        echo $sent ? 'پيام با موفقيت ارسال شد.' : 'پيام ارسال نشد. لطفاً دوباره تلاش كنيد.';
    }
?>
<br/>
<a href="<?php echo URL; ?>/index.php" target="_top">بازگشت به صفحه اصلي</a><br/>
</body>
</html>