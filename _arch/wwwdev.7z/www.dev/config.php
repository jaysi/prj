<?php

	ini_set('error_reporting', E_ALL);
	error_reporting(E_ALL);
	ini_set('log_errors',TRUE);
	ini_set('html_errors',FALSE);
	ini_set('error_log','c:/wamp/www/php_err.log');	
	ini_set('display_errors',FALSE);

	define('TITLE', 'شهـــر قـــشنگ');
	define('URL', 'http://localhost');
	define('HOST', 'localhost');
	define('EMAIL', '');
	define('USER', 'root');
	define('PASS', '');
	define('DB', 'koja2');
	define('MASTER', 'admin');
	define('MASTERPW', '$1$lZ2.KB4.$cDBPnzkMyod4/eY5e88VW1');
	
	define('LONGTIMEFMT', 'l j/F/Y H:i:s');
	define('SHORTTIMEFMT', '');
	define('TIMELOGFMT', 'Y-m-d-H-i-s');
	define('TZ', 16200);
	
	define ('RECAPTPUBKEY', '6LetL9MSAAAAAEUa0kj34gVn4l7LRMpB3B8kllHR');
	define ('RECAPTPRIVKEY', '6LetL9MSAAAAAKiH6m0SIRakR9RIabphcLRYGthC');

?>