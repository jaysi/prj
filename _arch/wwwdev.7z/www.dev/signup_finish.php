<?php
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	require_once 'db.php';	
	
	if(!isset($_GET['key'])){
		echo '!';
	} else {
		$user = new user;
		switch($user->activate_by_key($_GET['key'])){
			case true:
				echo 'ثبت نام شما تکمیل شد؛ میتوانید در شهـــر قـــشنگ وارد شده و از کلیه امکانات سایت استفاده کنید.';
			break;
			default:
				echo 'تکمیل ثبت نام با مشکل مواجه شد، لطفا دوباره تلاش کنید.';
			break;
		}
	}
	
	
?>