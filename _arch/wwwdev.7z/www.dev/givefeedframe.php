<?php
    
    require_once 'config.php';
	session_start();	

	require_once 'db.php';
	
	function gf_show_message($id, $username, $time, $text){
		
		$db = new database();
		
		echo '<li>';
		echo '<table border="0px" width="100%" style="css\givefeed.css"/>';
		echo '<tr align="right" valign="middle">';
		echo '<th width="5%">'.$db->farsi_num($username).'</th>';		
		echo '<td>'.$db->farsi_num($text).'</a></td>';
		echo '<td width="1%">'.$db->farsi_num($time).'</td></tr>';
		
		/*
		if(isset($_SESSION['username']) && $_SESSION['username'] == $username){
			echo '<form action="givefeed.php" method="post" enctype="utf-8">';
			echo '<input type="hidden" name="gf_idm" value="'.$id.'"/>';
			//echo '<input type="hidden" name="delete" value="1"/>';
			echo '<td colspan="2"><input name="gf_submit" type="submit" dir="rtl" lang="fa"  value="حذف" style="width: 5%;"/></td>';
			echo '</form>';
		}
		*/
		
		echo "</table>";	
		echo '</li>';
		echo '<br />';
	}	
	
	function gf_show_last_posts($n){
		$gf = new givefeed();
		
		$result = $gf->get_all();
		echo '<table border="0px" width="100%" style="a"/>';
		echo '<tr align="center" valign="middle"><td width="100%">'.'=============نظر دیگران============='.'</td></tr>';
		echo '</table>';
		echo '<ul class="link">';
		if($result == false || mysql_num_rows($result) == 0){
			mysql_free_result($result);			
			show_message(0, 'مدیر سایت','الان!','پیام بگذارید');
		} else {					
			while($row = mysql_fetch_assoc($result)){
				show_message($row['id'], $row['username'],$row['time'],$row['text']);
			}
			
		}
		echo '</ul>';	
	}
	
	function gf_show_give_post(){
		
		$gf = new givefeed();
		
		
		echo '<table border="0px" align="left" width="100%" style="font-size:small"/>';
		echo '<tr align="center" valign="middle"><td>'.'[ نــظر شــما ]'.'</td></tr>';
		echo '<form action="givefeedframe.php" method="post" enctype="utf-8">';
		echo '<tr align="right" valign="middle">';
		//echo '<th width="5%"><label for="body">پیام</label></th>';
		echo '<td><textarea noresize="true" row="1" type="text" class="transparent" maxlength="100" name="gf_comments" dir="rtl" style="width: 100%"></textarea></td>';
		echo '</tr>';
		//echo '<input type="hidden" name="gf_username" value="'.$_SESSION['username'].'"/>';
		//echo '<input type="hidden" name="gf_pid" value="0"/>';
		//echo '<input type="hidden" name="insert" value="1"/>';
		$id = $gf->get_id();
		echo '<input type="hidden" name="gf_id" value="'.$id.'"/>';
		//echo '<input type="hidden" name="gf_ref" value="'.$_GET['gf_ref'].'"/>';
		
		echo '<tr align="left" valign="middle">';
		echo '<td colspan="0"><input name="gf_submit" type="submit" dir="rtl" lang="fa"  value="ثبت" style="width: 100%;"/></td>';
		echo '</tr>';
		echo '</table>';
		
	}	
	
	if(isset($_POST['gf_id']) || isset($_POST['gf_idm'])){		
		$gf = new givefeed();
		if(isset($_POST['gf_submit']) && $_POST['gf_submit'] == 'ثبت'){
			$gf->insert($_POST['gf_id'], $_SESSION['gf_ref'], $_SESSION['username'], $_POST['gf_comments']);
		}
		if(isset($_POST['gf_submit']) && $_POST['gf_submit'] == 'حذف'){
			$gf->delete($_POST['gf_idm']);
		}
		//header("location: {$_SERVER['PHP_SELF']}");
		echo '<table border="0px" align="left" width="100%" style="font-size:small"/>';
		echo '<tr align="center" valign="middle"><td>'.'[ با تشکر از مشارکت شما ]'.'</td></tr>';
		echo '</table>';
		exit();
	} else {
		gf_show_give_post();	
	}
	

?>
