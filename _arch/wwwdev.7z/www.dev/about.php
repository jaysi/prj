<?php
    
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<base target="_blank"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<table border="0px" width="50%">
<tr align="right" valign="middle">
<th width="250px">برنامه نويس</th><td>بابک آخوندی</td>
</tr>
<tr align="right" valign="middle">
<th>گردآوری</th><td>سعید بهکام</td>
</tr>
<tr align="right" valign="middle">
<th>پست الكترونيكي</th><td><a href="mailto:contact@shahreghashang.com">contact@shahreghashang.com</a></td>
</tr>
<!--
<tr align="right" valign="middle">
<th>تلفن تماس</th><td><span dir="ltr">-نــداریــم-</span></td>
</tr>
-->
</table>
<a href="<?php echo URL; ?>/index.php" style="float:left" target="_top">بازگشت</a><br/>
<?php $_SESSION['gf_ref'] = $_SERVER['PHP_SELF']; require_once 'givefeed.php'; ?>
</body>
</html>