<?php
    
    require_once 'config.php';
	session_start();	

	require_once 'db.php';
	
		
	echo '<br /><br /><iframe align="left" src="givefeedframe.php?ref=$_SESSION[gf_ref]" scrolling="no" height="120" width="200" frameborder="1" style="border:thin dashed #666">';
	
	echo '</iframe>';
	
	
?>
