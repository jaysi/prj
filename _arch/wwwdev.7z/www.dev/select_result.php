<?php
	require_once 'config.php';
	
	session_start();
	
	if(!isset($_SERVER['HTTP_REFERER']) || strstr($_SERVER['HTTP_REFERER'], URL.'/select') == FALSE ){
		header('location: main.php');
		exit();
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/go.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php
	require_once('db.php');
	require_once('pub.php');
		
	$need_and = false;
	
	//echo $_POST['where'].count($_POST);
	
	//echo '<form action="register_result.php" method="post">';	
	
	$sql = "SELECT * FROM {$_POST['where']}_data";
	
	//echo '<input type="hidden" name="where" id="where" value="{$_POST["where"]}";>';
	
	$desc = new desc();
	
	$descres = $desc->get($_POST['where']);
	//echo mysql_error();
	if($descres !== false && mysql_num_rows($descres) > 0){
		while($descrow = mysql_fetch_assoc($descres)){
			if($descrow['searchable'] == 1){
				//echo $descrow['col_name'].' is searchable';
				if(isset($_POST[$descrow['col_name']]) && $_POST[$descrow['col_name']] != ""){
					
					//echo '<input type="hidden" name="$descrow[\'col_name\']" id="$descrow[\'col_name\']" value="{$_POST[$descrow[\'col_name\']]}";>';
					
					//echo ' and is set';
					if($descrow['group'] == 1){
						//echo ', grouped';
						if($need_and) $sql .= " AND";
						else $sql .= " WHERE";
						$arr = $_POST[$descrow['col_name']];
						$i = 0;
						if(count($arr) > 1) $sql .= "(";
						foreach($arr as $a){
							if($i != 0){
								$sql .= " OR";
							}
							$tmp = str_replace("_", " ", $a);
							$sql .= " {$descrow['col_name']} LIKE '%{$tmp}%'";
							$i++;
						}
						if(count($arr) > 1) $sql .= ")";
						$need_and = true;
					} else {
						//echo ', not grouped';
						$tmp = str_replace("_", " ", $_POST[$descrow['col_name']]);
						if($need_and) $sql .= " AND";
						else $sql .= " WHERE";
						$sql .= " {$descrow['col_name']} LIKE '%{$tmp}%'";
						$need_and = true;									
					}
				} else {
					//echo ' but not set';
				}
			} else {
				//echo $descrow['col_name'].' is not searchable';
			}
			//echo "<br />";
		}
	}
	
	$sql .= " ORDER BY name;";
	
	//echo $sql."<br />";
	
	$db = new database();
	$db->connect();
	$result = mysql_query($sql);
	//echo mysql_error();
	if($result !== false && mysql_num_rows($result) > 0) {
		echo '<ul class="link">';
		while($row = mysql_fetch_assoc($result)){
			/*
			if($row['diff'] != ""){
				$diff = "&nbsp&nbsp&nbsp[ ".$db->farsi_num($row['diff'])." ]";
			} else {
				$diff = "";
			}
			$name = $db->farsi_num($row['name']);
			*/
			echo "<li>";			
			//echo "<a href=".URL."/go_select.php?where={$_POST['where']}&id={$row['id']} target=\"mainFrame\">{$name}{$diff}</a>";
			create_goto_link($_POST['where'], $row['id'], $row['name'], $row['diff'], $db);
			echo "</li>";
		}
		echo '</ul>';
	}
	
	echo '<a style="float:left" href="'.URL.'/go.php?where='.$_POST['where'].'" target="mainFrame">بــازگــشـت</a>';
	//echo '<input style="width: 20%;" align="left" type="submit" value="بازگشت"/>';
	//echo '</form>';
	

?>
</body>
</html>