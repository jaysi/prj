<?php    
    require_once 'config.php';
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<form action="signup_result.php" method="post">
<table border="0px" width="500px"/>
<tr align="right" valign="middle">
<th width="150px"><label for="realname">نام و نام خانوادگي</label></th>
<td><input class="transparent" id="realname" maxlength="50" name="realname" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th width="150px"><label for="username">نام کاربری</label></th>
<td><input class="transparent" id="username" maxlength="50" name="username" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th width="150px"><label for="password">رمز عبور</label></th>
<td><input class="transparent" id="password" maxlength="50" name="password" style="width: 100%;" type="password"/></td>
</tr>
<tr align="right" valign="middle">
<th width="150px"><label for="password2">تکرار رمز عبور</label></th>
<td><input class="transparent" id="password2" maxlength="50" name="password2" style="width: 100%;" type="password"/></td>
</tr>
<tr align="right" valign="middle">
<th><label for="email">پست الكترونيكي</label></th>
<td><input class="transparent" id="email" maxlength="50" name="email" style="width: 100%;" type="text"/></td>
</tr>
<tr align="right" valign="middle">
<th><label for="body">پيام</label></th>
<td><textarea class="transparent" id="body" maxlength="1000" name="body" rows="5" style="width: 100%"></textarea></td>
</tr>

<tr align="right" valign="middle" dir="ltr">
<?php
  require_once('extern/recaptchalib.php');
  $publickey = RECAPTPUBKEY; // you got this from the signup page
  echo recaptcha_get_html($publickey);
?>
</tr>

<tr align="center" valign="middle">
<td colspan="2"><input style="width: 100%;" type="submit" value="ارسال درخواست ثبت نام"/></td>
</tr>
</table>
</form>
<?php $_SESSION['gf_ref'] = $_SERVER['PHP_SELF']; require_once 'givefeed.php'; ?>
</body>
</html>