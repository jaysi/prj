<?php
    
    require_once 'config.php';
	require_once 'extern/jcalendar.class.php';
	require_once 'db.php';
	
	function get_random_where_to_go(){
		
		$db = new database();
		$base = new base();
		$data = new data();
		
		while(!isset($table) || $table==false || $table=="" || $table=="history"){
			$tid = rand(0, $db->count_rows('base'));
			$table = $base->get_table_by_id($tid);
		}
		
		while(!isset($row) || $row==false){
			$rid = rand(0, $db->count_rows($table."_data"));
			$row = mysql_fetch_assoc($data->get_by_id($table, $rid));
		}
		
		$na = $db->farsi_num($row['name']);
		return "<a href=".URL."/go_select.php?where={$table}&id={$rid} target=\"mainFrame\">{$na}</a>";
		
	}
	
	function create_goto_link($domain, $id, $name, $diff, $db){
		if($diff != ""){
			$di = "&nbsp&nbsp&nbsp[ ".$db->farsi_num($diff)." ]";
		} else {
			$di = "";
		}
		$na = $db->farsi_num($name);
		echo "<a href=".URL."/go_select.php?where={$domain}&id={$id} target=\"mainFrame\">{$na}{$di}</a>";
	}
	
	function logtimetostrtime($logtime){
		$c = new jCalendar();
		$db = new database();
		
		$t = $db->latin_num($logtime);
		$t = explode("-", $logtime);

		for($i = 0; $i < count($t); $i++){
			if($t[$i] == "*"){
								
				if($i == 3 && $t[$i] == "*"){
					if($t[$i+1] == "*" && $t[$i+2] == "*") break;
				} else {
					$str .= " - ";
				}

				switch($i){
					case 0:
					$str = "هر سال";					
					break;
					case 1:
					$str .= "هر ماه";					
					break;
					case 2:
					$str .= "هر روز";
					break;
					case 3:
					$str .= "همه ساعات";
					break;
					case 4:
					$str .= "همه دقایق";
					break;
					case 5:
					$str .= "همه ثانیه ها";
					break;
					default:
					break;
				}
			} else {
				
				switch($i){
					case 0:
					$str = "سال ";					
					break;
					case 1:
					$str .= "ماه ";					
					break;
					case 2:
					$str .= "روز ";
					break;
					case 3:
					$str .= "ساعت ";
					break;
					case 4:
					$str .= "دقیقه ";
					break;
					case 5:
					$str .= "ثانیه ";
					break;
					default:
					break;
				}
				
				$str .= $t[$i];
								
			}
			
			if($i<2) $str .= "/";
			else if($i==2) {}
			else if($i < 5) $str .= ":";
		}
		/*
		for($i = 0; $i < count($t); $i++){
			echo $i.'->'.$t[$i].'.';
		}
		
		$timestamp = $c->mktime(	$t[3]=="*"?0:$t[3]=="*"?0:$t[3], $t[4]=="*"?0:$t[4],
									$t[5]=="*"?0:$t[5], $t[1]=="*"?0:$t[1],
									$t[2]=="*"?0:$t[2], $t[0]=="*"?0:$t[0]);
		
		return $c->date(LONGTIMEFMT, $timestamp, TZ);
		*/
		
		return '<span dir="rtl">'.$str.'</span>';
	}
	
?>
