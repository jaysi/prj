﻿<?php
	
	ini_set('error_reporting', FALSE);
	error_reporting(E_ALL);
	ini_set('log_errors',FALSE);
	ini_set('html_errors',FALSE);
	//ini_set('error_log','c:/www/php_err.log');	
	ini_set('display_errors',FALSE);
	
	define('TITLE', 'شهـــر قـــشنگ');
	define('URL', 'http://koja.host56.com');
	define('HOST', 'mysql9.000webhost.com');
	define('EMAIL', 'admin@koja.host56.com');
	define('USER', 'a4625672_user');
	define('PASS', 'n0pa$$word');
	define('DB', 'a4625672_koja1');
	define('MASTER', 'admin');
	define('MASTERPW', '$1$lZ2.KB4.$cDBPnzkMyod4/eY5e88VW1');

	define('LONGTIMEFMT', 'l j/F/Y H:i:s');
	define('SHORTTIMEFMT', '');
	define('TIMELOGFMT', 'Y-m-d-H-i-s');
	define('TZ', 30600);
	
	define ('RECAPTPUBKEY', '6LetL9MSAAAAAEUa0kj34gVn4l7LRMpB3B8kllHR');
	define ('RECAPTPRIVKEY', '6LetL9MSAAAAAKiH6m0SIRakR9RIabphcLRYGthC');
	
?>