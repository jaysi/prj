<?php    
    require_once('config.php');
	session_start();
	
	if(!isset($_SERVER['HTTP_REFERER']) ||
			(
			strstr($_SERVER['HTTP_REFERER'], URL.'/go.php') == FALSE &&
			strstr($_SERVER['HTTP_REFERER'], URL.'/select_result.php') == FALSE &&
			strstr($_SERVER['HTTP_REFERER'], URL.'/main.php') == FALSE
			) 
		){
		header('location: main.php');
		exit();
	}
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/go.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">

<?php
function show_give_feedback($id){
	$db = new database();
	echo '<table border="0px" width="25%" style="signin.css"/>';
	echo '<form action="get_feed.php" method="post" enctype="utf-8">';
	echo '<th width="50px"><label for "score">امتیاز</label></th>';
	echo '<td><select class="transparent" name="score" type="number" id="score" dir="ltr" lang="fa" style="width: 100%;"/>';
	
	echo '<option value="0">معمولی</option>';
	echo '<option value="2">عالی</option>';
	echo '<option value="1">خوب</option>';
	echo '<option value="-1">ضعیف</option>';
	echo '<option value="-2">افتضاح</option>';	
		
	echo '</select>';
	echo '</td>';
	echo '</tr>';								
	echo '<tr align="right" valign="middle">';
	echo '<th><label for="body">نظر</label></th>';
	echo '<td><textarea class="transparent" id="body" maxlength="1000" name="comments" rows="2" style="width: 100%"></textarea></td>';
	echo '</tr>';
	echo '<input type="hidden" name="username" value="'.$_SESSION['username'].'"/>';
	echo '<input type="hidden" name="domain" value="'.$_GET['where'].'"/>';
	echo '<input type="hidden" name="id" value="'.$id.'"/>';
	echo '<tr align="left" valign="middle">';
	echo '<td colspan="2"><input name="submit" type="submit" dir="rtl" lang="fa"  value="ثبت" style="width: 100%;"/></td>';
	echo '</tr>';
	echo '</table>';
}

function show_user_score(){
	$uf = new user_feed();
	$db = new database();
	switch($uf->calc_user_score($_GET['where'], $_GET['id'])){
		case -2:
			$score="افتضاح";
		break;
		case -1:
			$score="ضعیف";
		break;
		case 0:
			$score="معمولی";
		break;
		case 1:
			$score="خوب";
		break;
		case 2:
			$score="عالی";
		break;
		default:
			$score="-";
		break;
	}
	echo '<table border="0px" width="50%">';
	echo '<tr align="right" valign="middle">';
	echo '<th width="100px">'.'امتیاز کاربران'.'</th><td>'.$score.'</td></tr>';
	echo "</table>";
}

function show_row($domain, $row){
	
	$desc = new desc();
	$db = new database();
	
	echo '<table border="0px" width="100%">';
	
	$descres = $desc->get($domain);
	if($descres !== false && mysql_num_rows($descres) > 0){
		while($descrow = mysql_fetch_assoc($descres)){			
			if($descrow['show'] == 1 && $row[$descrow['col_name']] != ''){
				$str = str_replace(" ", "&nbsp", $row[$descrow['col_name']]);
				$str = $db->farsi_num($str);
				
				if($descrow['sel_type']=='date'){
					$str = logtimetostrtime($str);
				}
				
				if($descrow['col_name']=='score'){
					switch($db->latin_num($str)){
						case -2:
							$str="افتضاح";
						break;
						case -1:
							$str="ضعیف";
						break;
						case 0:
							$str="معمولی";
						break;
						case 1:
							$str="خوب";
						break;
						case 2:
							$str="عالی";
						break;
						default:
							$str="-";
						break;
					}
				}
				
				
				echo '<tr align="right" valign="middle">';
				echo '<th width="100px">'.$descrow['col_sc_name'].'</th><td>'.$str.'</td></tr>';				
				
			}
		}
	}
	
	echo "</table>";
}

?>

<?php	
	
    require_once 'db.php';
	require_once 'pub.php';
	$data = new data();
	$uf = new user_feed();
		
	$data->inc_nhits($_GET['where'], $_GET['id']);
	
	$result = $data->get_by_id($_GET['where'], $_GET['id']);
	if($result !== false && mysql_num_rows($result) > 0) {
		while($row = mysql_fetch_assoc($result)){
		
			show_row($_GET['where'], $row);
						
			show_user_score();
			
			echo "============= نـــظـــــرات =============<br />";

			$feeds = $uf->get_all_feeds('', $_GET['where'], $_GET['id']);
			if($feeds !== false && mysql_num_rows($feeds) > 0) {
				$i = 0;
				while($feed = mysql_fetch_assoc($feeds)){
					//echo $feed['username'];
					if($i != 0) echo '+++++++++++++<br />';
					show_row('feedback', $feed);
					$i++;
					
				}
			} else {
				echo 'در نظرخواهی شرکت کنید!<br />';
			}

			echo "============= نـــظـر شمـا =============<br />";
		
			if(isset($_SESSION['usertype']) && $_SESSION['usertype'] != 'guest'){
				show_give_feedback($row['id']);
			} else {
				echo "برای نظر دادن عضو شوید!<br />";
			}
			
			echo "============= کــجا بریـــم؟ =============<br />";
		}
	} else {
		echo 'ایراد داخلی!';
	}	
	
	echo '<a style="float:left" href="'.URL.'/go.php?where='.$_GET['where'].'" target="mainFrame">بــازگــشـت</a><br />';
		
	$_SESSION['gf_ref'] = $_SERVER['PHP_SELF'];
	require_once 'givefeed.php';
	
?>
</body>
</html>
	