<?php
if(isset($argv[1])){
		if (CRYPT_STD_DES == 1) {
			echo 'Standard DES: ' . crypt($argv[1]). "\n";
		}
		
		if (CRYPT_EXT_DES == 1) {
			echo 'Extended DES: ' . crypt($argv[1]). "\n";
		}
		
		if (CRYPT_MD5 == 1) {
			echo 'MD5:          ' . crypt($argv[1]). "\n";
		}
		
		if (CRYPT_BLOWFISH == 1) {
			echo 'Blowfish:     ' . crypt($argv[1]) . "\n";
		}
		
		if (CRYPT_SHA256 == 1) {
			echo 'SHA-256:      ' . crypt($argv[1]) . "\n";
		}
		
		if (CRYPT_SHA512 == 1) {
			echo 'SHA-512:      ' . crypt($argv[1]) . "\n";
		}
	
} else {
	echo "type phrase to hash please\n";
}

?>