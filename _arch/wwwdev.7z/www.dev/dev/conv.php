<?php
function CorrectFarsi($text)
{
    $CorrectionArr = array(
        'لله'=>array('ﷲ'),
        'آ'=>array('ﺁ', 'ﺂ'),
        'أ'=>array('ﺃ', 'ﺄ'),
        'ؤ'=>array('ﺅ', 'ﺆ'),
        'إ'=>array('ﺇ', 'ﺈ'),
        'ئ'=>array('ﺉ', 'ﺊ', 'ﺋ', 'ﺌ'),
        'ا'=>array('ﺍ', 'ﺎ'),
        'ب'=>array('ﺏ', 'ﺐ', 'ﺑ', 'ﺒ'),
        'پ'=>array('ﭖ', 'ﭗ', 'ﭘ', 'ﭙ'),
        'ة'=>array('ﺓ', 'ﺔ'),
        'ت'=>array('ﺕ', 'ﺖ', 'ﺗ', 'ﺘ'),
        'ث'=>array('ﺙ', 'ﺚ', 'ﺛ', 'ﺜ'),
        'ج'=>array('ﺝ', 'ﺞ', 'ﺟ', 'ﺠ'),
        'چ'=>array('ﭺ', 'ﭻ', 'ﭼ', 'ﭽ'),
        'ح'=>array('ﺡ', 'ﺢ', 'ﺣ', 'ﺤ'),
        'خ'=>array('ﺥ', 'ﺦ', 'ﺧ', 'ﺨ'),
        'د'=>array('ﺩ', 'ﺪ'),
        'ذ'=>array('ﺫ', 'ﺬ'),
        'ر'=>array('ﺭ', 'ﺮ'),
        'ز'=>array('ﺯ', 'ﺰ'),
        'ژ'=>array('ﮊ', 'ﮋ'),
        'س'=>array('ﺱ', 'ﺲ', 'ﺳ', 'ﺴ'),
        'ش'=>array('ﺵ', 'ﺶ', 'ﺷ', 'ﺸ'),
        'ص'=>array('ﺹ', 'ﺺ', 'ﺻ', 'ﺼ'),
        'ض'=>array('ﺽ', 'ﺾ', 'ﺿ', 'ﻀ'),
        'ط'=>array('ﻁ', 'ﻂ', 'ﻃ', 'ﻄ'),
        'ظ'=>array('ﻅ', 'ﻆ', 'ﻇ', 'ﻈ'),
        'ع'=>array('ﻉ', 'ﻊ', 'ﻋ', 'ﻌ'),
        'غ'=>array('ﻍ', 'ﻎ', 'ﻏ', 'ﻐ'),
        'ف'=>array('ﻑ', 'ﻒ', 'ﻓ', 'ﻔ'),
        'ق'=>array('ﻕ', 'ﻖ', 'ﻗ', 'ﻘ'),
        'ک'=>array('ﻙ', 'ﻚ', 'ﻛ', 'ﻜ', 'ﮎ', 'ﮏ', 'ﮐ', 'ﮑ'),
        'گ'=>array('ﮒ', 'ﮓ', 'ﮔ', 'ﮕ'),
        'ل'=>array('ﻝ', 'ﻞ', 'ﻟ', 'ﻠ'),
        'م'=>array('ﻡ', 'ﻢ', 'ﻣ', 'ﻤ'),
        'ن'=>array('ﻥ', 'ﻦ', 'ﻧ', 'ﻨ'),
        'ه'=>array('ﻩ', 'ﻪ', 'ﻫ', 'ﻬ', 'ﮤ', 'ﮥ', 'ﮦ', 'ﮪ', 'ﮫ', 'ﮬ', 'ﮭ'),
        'و'=>array('ﻭ', 'ﻮ'),
        'ی'=>array('ﻯ', 'ﻰ', 'ﻱ', 'ﻲ', 'ﻳ', 'ﻴ', 'ﯼ', 'ﯽ', 'ﯾ', 'ﯿ'),
        'لآ'=>array('ﻵ', 'ﻶ'),
        'لأ'=>array('ﻷ', 'ﻸ'),
        'لإ'=>array('ﻹ', 'ﻺ'),
        'لا'=>array('ﻻ', 'ﻼ'),
        'ء'=>array('ﺀ'),
        '‌'=>array('﻿'),
        'ّ'=>array('ﹼ', 'ﹽ'),
        'ِ'=>array('ﹺ', 'ﹻ'),
        'ُ'=>array('ﹸ', 'ﹹ'),
        'َ'=>array('ﹶ', 'ﹷ'),
        'ٍ'=>array('ﹴ', '﹵'),
        'ٌ'=>array('ﹲ', 'ﹳ'),
        'ً'=>array('ﹰ', 'ﹱ')
    );
    foreach($CorrectionArr as $h=>$A)
        foreach($A as $a)
            $text = str_replace($a, $h, $text);
    return $text;
}

function convertfile($myFile){
	$fh = fopen($myFile, 'r');
	$theData = fread($fh, filesize($myFile));
	fclose($fh);
	$converted = CorrectFarsi($theData);
	$fw = fopen($myFile.'.out', 'w+');	
	fwrite($fw, $converted, filesize($myFile));
	fclose($fw);
}

if(isset($argv[1])){
	convertfile($argv[1]);
} else {
	echo "need filename.\n";
}

?>