<?php
	require_once("config.php");	
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="rtl">
<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo TITLE; ?></title>
<link href="css/signin.css" rel="stylesheet" type="text/css"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php
if(!isset($_SESSION["usertype"]) || $_SESSION["usertype"] == 'guest'){
	echo '<form action="signin_result.php" method="post" enctype="utf-8">';
	echo '<table border="0px" width="200px"/>';
	echo '<tr align="left" valign="middle">';
	echo '<th width="50px"><label for "username">نام کاربر:</label></th>';
	echo '<td><input name="username" type="text" dir="rtl" lang="fa" style="width: 100%;"/></td>';
	echo '</tr>';
	echo '<tr align="left" valign="middle">';
	echo '<th width="50px"><label for "password">رمز عبور:</label></th>';
	echo '<td><input name="password" type="password" dir="rtl" lang="fa" style="width: 100%;"/></td>';
	echo '</tr>';
	echo '<tr align="left" valign="middle">';
	echo '<td colspan="2"><input name="login" type="submit" dir="rtl" lang="fa"  value="ورود" style="width: 100%;"/></td>';
	echo '</tr>';
	echo '</form>';
	echo '<tr align="middle" valign="middle" >';
	echo '<td colspan="2"><a href="'.URL.'/signup.php" target="_blank">ثــبــت نــام</a></td>';
	echo '</tr>';
	echo '</table>';
} else {
	echo '<table border="0px" width="200px" dir="rtl"/>';
	echo '<tr align="right" valign="middle">';
	echo '<td>'.' خوش آمدید '.'<u>'.$_SESSION["username"].'.</u></td>';	
	echo '</tr>';
	echo '<tr align="right" valign="middle">';
	echo '<td>'.'<a style="float:left" href="'.URL.'/admin/uacc.php" target="mainFrame">مـــدیریـــت حــــساب کاربــری</a>'.'</td>';
	echo '</tr>';
	if($_SESSION['usertype'] == 'admin'){
		echo '<tr align="right" valign="middle">';
		echo '<td>'.'<a style="float:right" href="'.URL.'/admin/admin.php" target="mainFrame">مـــدیریـــت سایت</a>'.'</td>';
		echo '</tr>';
	}	
	echo '<form action="signout.php" method="post" enctype="utf-8">';	
	echo '<tr align="left" valign="middle">';		
	echo '<td colspan="2"><input name="logout" type="submit" dir="rtl" lang="fa"  value="خروج" style="width: 100%;"/></td>';
	echo '</tr>';
	echo '</table>';
}

?>
</body>
</html>