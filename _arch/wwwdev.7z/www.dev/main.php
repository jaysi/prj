<?php
    
    require_once 'config.php';
	session_start();	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset="utf-8"/>
<title><?php echo TITLE; ?></title>
<link href="css/main.css" rel="stylesheet" type="text/css"/>
<base target="_self"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

	include 'extern/jcalendar.class.php';
	require_once 'db.php';
	require_once 'pub.php';
	
	function show_supported_crypts(){
		echo 'supported hashing algorithms ';
		if (CRYPT_STD_DES == 1) {
			echo 'Standard DES;';
		}
		
		if (CRYPT_EXT_DES == 1) {
			echo 'Extended DES;';
		}
		
		if (CRYPT_MD5 == 1) {
			echo 'MD5;';
		}
		
		if (CRYPT_BLOWFISH == 1) {
			echo 'Blowfish;';
		}
		
		if (CRYPT_SHA256 == 1) {
			echo 'SHA-256;';
		}
		
		if (CRYPT_SHA512 == 1) {
			echo 'SHA-512;';
		}
		echo '<br />';
	}
	
	
	function show_random_offer(){
		while(!isset($str) || $str==false || $str==""){
			$str = get_random_where_to_go();
		}
		
		echo '<p>';
		echo '<strong>یک پیشنهاد!<br /></strong>';
		echo 'چرا امروز به '.$str.' نمیروید؟';
		echo '<br /></p>';
	}
	
	function show_most_visited(){
		$stat = new stats();
		echo '<p>';
		echo '<strong>پر بیننده ترین بخشها<br /></strong>';
		echo 'پربیننده ترین بخش <u>'.$stat->get_most_hit_domain().'</u> است.';
		echo '</p>';
	}
	
	function show_admin_quote(){
		echo '<p>';
		echo '<strong>توصیه مدیر سایت<br /></strong>';
		echo 'برای دیدن صحیح این سایت از مرورگر firefox یا chrome استفاده کنید.';
		echo '</p>';		
	}
	
	function show_todays_event(){
		
		echo '<strong>امروز در تاریخ<br /></strong>';
		
		$nothing = true;								
		$data = new data();
		$db = new database();
		$c = new jCalendar();
		$result = $data->get_all_records('history');
		if($result !== false && mysql_num_rows($result) > 0){
			echo '<ul class="link">';
			while($row = mysql_fetch_assoc($result)){
				if($row['date_start'] == "x") continue;
				$sdd = $db->latin_num($row['date_start']);
				$edd = $db->latin_num($row['date_end']);
				$sd = explode("-",$sdd);
				$ed = explode("-",$edd);
				$ndd = $db->latin_num($c->date("Y-n-j", NULL, 16200));
				$nd = explode("-", $ndd);
				if($sd[0] == "*"){
					$numd = intval($nd[1])*100 + intval($nd[2]);
					$numds = intval($sd[1])*100 + intval($sd[2]);
					$numde = intval($ed[1])*100 + intval($ed[2]);
					//echo $numd."-".$numds."-".$numde."<br />";
					if($numd >= $numds && $numd <= $numde){
						echo "<li>";
						//echo "<a href=".URL."/go_select.php?where={$_POST['where']}&id={$row['id']} target=\"mainFrame\">{$name}{$diff}</a>";
						create_goto_link('history', $row['id'], $row['name'], $row['diff'], $db);
						echo "</li>";
						$nothing = false;
					}
				} else {					
					$numd = $nd[0]*10000 + $nd[1]*100 + $nd[2];
					$numds = $sd[0]*10000 + $sd[1]*100 + $sd[2];
					$numde = $ed[0]*10000 + $ed[1]*100 + $ed[2];
					//echo $numd."-".$numds."-".$numde."<br />";
					if($numd >= $numds && $numd <= $numde){
						echo "<li>";
						//echo "<a href=".URL."/go_select.php?where={$_POST['where']}&id={$row['id']} target=\"mainFrame\">{$name}{$diff}</a>";
						create_goto_link('history', $row['id'], $row['name'], $row['diff'], $db);
						echo "</li>";
						$nothing = false;
					}
				}
				
			}
			echo '</ul>';
		}
		if($nothing == true){
			echo 'اتفاق خاصی نیفتاده!';			
		}
		echo '</p>';
	}
	
	function show_time(){
		$d = new jCalendar();
		echo '<br />امروز '.$d->date(LONGTIMEFMT ,NULL ,TZ).'<br />';
	}
	
	function show_ip(){
		echo '<br />you are at '.$_SERVER['REMOTE_ADDR'].'<br />';
	}	
	
	show_random_offer();
	
	show_most_visited();
	
	show_todays_event();
	
	show_time();
	
	show_admin_quote();
	
	//show_supported_crypts();
	
	//show_ip();
	
	$_SESSION['gf_ref'] = $_SERVER['PHP_SELF'];
	require_once 'givefeed.php';
	
?>
</body>
</html>