<?php
	require_once 'config.php';
	
	session_start();
	
	if(!isset($_SERVER['HTTP_REFERER']) || strstr($_SERVER['HTTP_REFERER'], URL.'/go.php') == FALSE ){
		header('location: main.php');
		exit();
	}
	
?>
<!doctype html>
<html dir="rtl">
<head>
<meta charset='utf-8'/>
<title><?php echo TITLE; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" charset="utf-8"/>
</head>
<body style="background-image: url(main.jpg); background-repeat: repeat;">
<?php

function show_select($where, $base, $col_name, $col_sc_name, $sel_size, $sel_type){
	$groups = new groups();
	echo '<tr align="right" valign="middle">';
	echo '<th width="10%"><label for="'.$col_name.'[]">'.$col_sc_name.'</label></th>';		
	echo '<td><select class="transparent" id="'.$col_name.'[]" maxlength="50" name="'.$col_name.'[]" style="width: 100%;" type="'.$sel_type.'"/>';
	echo '<option value="">مهم نیست</option>';
	
	if($base == 0){
		$result = $groups->get_sub_groups($where);		
	} else {
		$result = $groups->select_all();
	}
	
	if($result !== false && mysql_num_rows($result) > 0) {
		while($row = mysql_fetch_assoc($result)) {
			if($row[$col_name] != ''){
					$tmp = str_replace(" ", "_", $row[$col_name]);
					echo '<option value="'.$tmp.'">'.$row[$col_name].'</option>';
			}
		}
	}
	echo '</select>';
	echo '</td></tr>';
}

function show_input($col_name, $col_sc_name, $sel_type){
	echo '<tr align="right" valign="middle">';
	echo '<th width="10%"><label for="'.$col_name.'">'.$col_sc_name.'</label></th>';
	echo '<td><input class="transparent" name="'.$col_name.'" type="'.$sel_type.'" dir="rtl" lang="fa" style="width: 100%;" value=""/></td></tr>';
}

?>
<form action="select_result.php" method="post" enctype="utf-8" target="mainFrame">
<table border="0px" width="100%"/>
<?php

	require_once('db.php');
		
	$desc = new desc();
	$base = new base();
	
	$descres = $desc->get($_GET['where']);
	$table = $base->get_table_sc_name($_GET['where']);
	
	echo '<table border="0px" width="100%">';
	echo '<tr align="middle" valign="middle">';
	echo "<th>"."جستجو کنید"."</th><td>{$table} را!</td></tr>";
	
	if($descres !== false && mysql_num_rows($descres) > 0){
		while($descrow = mysql_fetch_assoc($descres)){
			if($descrow['searchable'] == 1){
				if($descrow['group'] == 1){
					show_select($_GET['where'], $descrow['base'], $descrow['col_name'], $descrow['col_sc_name'], $descrow['sel_size'], $descrow['sel_type']);
				} else {
					show_input($descrow['col_name'], $descrow['col_sc_name'], $descrow['sel_type']);
				}
			}
		}
	}
	
	echo "<input type=\"hidden\" value={$_GET['where']} name=\"where\" id=\"where\";/>";
	echo "</table>";	
		
?>
</tr>
<tr align="center" valign="middle">
<td colspan="2"><input style="width: 100%;" type="submit" value="جستجو"/></td>
</tr>
</table>
</form>
<?php $_SESSION['gf_ref'] = $_SERVER['PHP_SELF']; require_once 'givefeed.php'; ?>
</body>
</html>