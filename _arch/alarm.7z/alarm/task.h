#ifndef TASK_H
#define TASK_H

#include <stdio.h>

typedef unsigned long inum_t;

#define bufsize 2048
#define chcomment '#'
#define chsep '\t'
#define datesep "/-. "

struct task {
    char* name;
    char* comments;
    char* date;
    char* remind_date;
    char* stat;
//    inum_t idate;
//    inum_t irdate;
    struct task* next;
    struct task* todaynext;
};

#ifdef __cplusplus
extern "C" {
#endif

int load_tasks(char *dbname, FILE** db, struct task** taskfirst, char *notes);
int check_today(struct task* taskfirst, struct task** todayfirst, int today[3]);
int write_tasks(FILE* db, struct task* taskfirst, char *notes);
int d13_today(int it13[3]);
int d13_jdayno2jdate(inum_t j_day_no, int jdate[3]);
inum_t d13_jdayno(int j_y, int j_m, int j_d);
int new_task(struct task** taskfirst, struct task** tasklast, char* name, char* comment, char* date, char* rdate);
int find_task(struct task* taskfirst, char* name, struct task** entry, struct task** prev);
int d13_resolve_date(char* date, int d[3]);
int inactivate_task(struct task *taskfirst, char* name);
int activate_task(struct task *taskfirst, char* name);
int update_task(struct task** taskfirst, struct task** tasklast, char* name, char* comment, char* date, char* rdate);
int delete_task_old(struct task** taskfirst, struct task** tasklast, char* name);

#ifdef __cplusplus
}
#endif

#endif // TASK_H
