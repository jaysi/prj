/********************************************************************************
** Form generated from reading UI file 'checkdialog.ui'
**
** Created: Wed Jul 24 18:03:59 2013
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHECKDIALOG_H
#define UI_CHECKDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCommandLinkButton>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_CheckDialog
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *labelRDate;
    QLabel *label_2;
    QLabel *labelToday;
    QListWidget *listToday;
    QPushButton *btnExit;
    QCommandLinkButton *clbtnReturn;

    void setupUi(QDialog *CheckDialog)
    {
        if (CheckDialog->objectName().isEmpty())
            CheckDialog->setObjectName(QString::fromUtf8("CheckDialog"));
        CheckDialog->resize(321, 174);
        CheckDialog->setLayoutDirection(Qt::RightToLeft);
        gridLayout = new QGridLayout(CheckDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(CheckDialog);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        labelRDate = new QLabel(CheckDialog);
        labelRDate->setObjectName(QString::fromUtf8("labelRDate"));
        labelRDate->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(labelRDate);

        label_2 = new QLabel(CheckDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        labelToday = new QLabel(CheckDialog);
        labelToday->setObjectName(QString::fromUtf8("labelToday"));
        labelToday->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(labelToday);


        gridLayout->addLayout(horizontalLayout, 1, 0, 2, 2);

        listToday = new QListWidget(CheckDialog);
        listToday->setObjectName(QString::fromUtf8("listToday"));

        gridLayout->addWidget(listToday, 0, 0, 1, 2);

        btnExit = new QPushButton(CheckDialog);
        btnExit->setObjectName(QString::fromUtf8("btnExit"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnExit->sizePolicy().hasHeightForWidth());
        btnExit->setSizePolicy(sizePolicy);

        gridLayout->addWidget(btnExit, 4, 0, 1, 1);

        clbtnReturn = new QCommandLinkButton(CheckDialog);
        clbtnReturn->setObjectName(QString::fromUtf8("clbtnReturn"));
        sizePolicy.setHeightForWidth(clbtnReturn->sizePolicy().hasHeightForWidth());
        clbtnReturn->setSizePolicy(sizePolicy);
        clbtnReturn->setAutoFillBackground(false);

        gridLayout->addWidget(clbtnReturn, 4, 1, 1, 1);


        retranslateUi(CheckDialog);

        QMetaObject::connectSlotsByName(CheckDialog);
    } // setupUi

    void retranslateUi(QDialog *CheckDialog)
    {
        CheckDialog->setWindowTitle(QApplication::translate("CheckDialog", "\330\247\331\205\330\261\331\210\330\262...", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CheckDialog", "\330\252\330\247\330\261\333\214\330\256 \333\214\330\247\330\257\330\242\331\210\330\261\333\214:", 0, QApplication::UnicodeUTF8));
        labelRDate->setText(QApplication::translate("CheckDialog", "\332\251\331\204\333\214\332\251 \330\261\331\210\333\214 \330\242\333\214\330\252\331\205", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("CheckDialog", "\330\247\331\205\330\261\331\210\330\262:", 0, QApplication::UnicodeUTF8));
        labelToday->setText(QApplication::translate("CheckDialog", "Today", 0, QApplication::UnicodeUTF8));
        btnExit->setText(QApplication::translate("CheckDialog", "\330\256\330\261\331\210\330\254", 0, QApplication::UnicodeUTF8));
        clbtnReturn->setText(QApplication::translate("CheckDialog", "\330\250\330\247\330\262\332\257\330\264\330\252 \330\250\331\207 \330\261\330\247\330\250\330\267 \330\247\330\265\331\204\333\214", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CheckDialog: public Ui_CheckDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHECKDIALOG_H
