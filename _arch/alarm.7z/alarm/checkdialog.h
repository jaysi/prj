﻿#ifndef CHECKDIALOG_H
#define CHECKDIALOG_H

#include <QDialog>

#include "mainwindow.h"
#include "task.h"

namespace Ui {
class CheckDialog;
}

class CheckDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CheckDialog(QWidget *parent = 0);
    CheckDialog(QWidget *parent, MainWindow* main);
    ~CheckDialog();
    void SetMain(void* main);

private slots:
    void on_clbtnReturn_clicked();

    void on_btnExit_clicked();

    void on_listToday_clicked(const QModelIndex &index);

private:
    void UpdateView();
    Ui::CheckDialog *ui;
    void* mainw;
};

#endif // CHECKDIALOG_H
