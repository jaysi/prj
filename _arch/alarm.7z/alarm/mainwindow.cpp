#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int d[6];
    char notes[bufsize];

    taskfirst = NULL;
    todayfirst = NULL;

    d13_today(d);

    if(!load_tasks(def_db, &db, &taskfirst, notes)){
        perror("1");
    }

    ui->editTodayDate->setText(tr("%1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]));

    ui->editNotes->document()->setPlainText(trUtf8(notes));

    //ui->editComments->setLayoutDirection(Qt::RightToLeft);

    UpdateView();

    shownotes = true; showinsert = true;

//    ui->groupInsert->hide();
//    ui->groupNotes->hide();

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btnRemove_clicked()
{    
    if(!ui->listAll->currentItem()) return;
    if(inactivate_task(taskfirst, ui->listAll->currentItem()->text().toUtf8().data())){
        UpdateView();
    }

}

void MainWindow::on_btnShowOld_clicked()
{
    struct task* entry;

    ui->listAll->clear();

    for(entry = taskfirst; entry; entry = entry->next){
        if(entry->stat[0] == 'D') ui->listAll->addItem(trUtf8(entry->name));
    }
}

void MainWindow::on_btnSetDate_clicked()
{
//    int d[3];
//    resolve_date(ui->editTodayDate->text().toUtf8().data(), d);
//    check_today(taskfirst, &todayfirst, d);
    UpdateView();
}

void MainWindow::on_btnInsert_clicked()
{
    //ui->editComments->document()->toPlainText().toUtf8().data();
    if(new_task(&taskfirst, &tasklast,
             ui->editName->text().toUtf8().data(),
             //ui->editComments->text().toUtf8().data(),
             ui->editComments->document()->toPlainText().toUtf8().data(),
             ui->editDate->text().toUtf8().data(),
             ui->editRemindDate->text().toUtf8().data())){
        UpdateView();
        on_btnCls_clicked();
    } else {
        qDebug()<<tr("failed to add %1").arg(ui->editName->text());
    }    
}

void MainWindow::on_btnCalcDate_clicked()
{
    int d[3];
    inum_t n;
    QString str;
    //qDebug() << tr("%1 ->").arg(ui->editDate->text().toUtf8().data());
    if(!d13_resolve_date(ui->editDate->text().toUtf8().data(), d)){
        //qDebug("false!");
    }
   // qDebug() << tr("<- %1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]);
    n = d13_jdayno(d[0], d[1], d[2]);
    //qDebug() << tr("%1/%2/%3: %4 + %5 = %6").arg(d[0]).arg(d[1]).arg(d[2]).arg(n).arg(ui->editRemindDays->text().toInt()).arg(n+ui->editRemindDays->text().toInt());
    n += ui->editRemindDays->text().toInt();
    d13_jdayno2jdate(n, d);
    str = trUtf8("%1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]);
    ui->editRemindDate->setText(str);

}

void MainWindow::on_listAll_doubleClicked(const QModelIndex &index)
{
    struct task* entry;
    if(find_task(taskfirst, ui->listAll->currentItem()->text().toUtf8().data(), &entry, NULL)){
        ui->editName->setText(trUtf8(entry->name));
        ui->editComments->document()->setPlainText(trUtf8(entry->comments));
        ui->editDate->setText(trUtf8(entry->date));
        ui->editRemindDate->setText(trUtf8(entry->remind_date));
    }

}

void MainWindow::on_btnCls_clicked()
{
    ui->editName->clear();
    ui->editComments->clear();
    ui->editDate->clear();
    ui->editRemindDate->clear();
    ui->editRemindDays->clear();
}

void MainWindow::on_btnToday_clicked()
{
    int d[6];
    QString str;
    d13_today(d);
    str = tr("%1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]);
    ui->editDate->setText(str);
}

void MainWindow::UpdateView(){
    struct task* entry;
    int today[3];

    ui->listAll->clear();
    ui->listToday->clear();

    d13_resolve_date(ui->editTodayDate->text().toUtf8().data(), today);
    check_today(taskfirst, &todayfirst, today);

    for(entry = taskfirst; entry; entry = entry->next){
        if(entry->stat[0] == 'A') ui->listAll->addItem(trUtf8(entry->name));
    }

    for(entry = todayfirst; entry; entry = entry->todaynext){
        if(entry->stat[0] == 'A') ui->listToday->addItem(trUtf8(entry->name));
    }
}

void MainWindow::closeEvent(QCloseEvent *closeevent){
    write_tasks(db, taskfirst, ui->editNotes->document()->toPlainText().toUtf8().data());
    closeevent->accept();
}

void MainWindow::on_listToday_doubleClicked(const QModelIndex &index)
{
    struct task* entry;
    if(find_task(taskfirst, ui->listToday->currentItem()->text().toUtf8().data(), &entry, NULL)){
        ui->editName->setText(trUtf8(entry->name));
        ui->editComments->document()->setPlainText(trUtf8(entry->comments));
        ui->editDate->setText(trUtf8(entry->date));
        ui->editRemindDate->setText(trUtf8(entry->remind_date));
    }
}

void MainWindow::on_btnActivate_clicked()
{
    if(!ui->listAll->currentItem()) return;
    if(activate_task(taskfirst, ui->listAll->currentItem()->text().toUtf8().data())){
        UpdateView();
    }
}

void MainWindow::on_btnUpdate_clicked()
{
    //ui->editComments->document()->toPlainText().toUtf8().data();
    if(update_task(&taskfirst, &tasklast,
             ui->editName->text().toUtf8().data(),
             //ui->editComments->text().toUtf8().data(),
             ui->editComments->document()->toPlainText().toUtf8().data(),
             ui->editDate->text().toUtf8().data(),
             ui->editRemindDate->text().toUtf8().data())){
        UpdateView();
        on_btnCls_clicked();
    } else {
        qDebug()<<tr("failed to add %1").arg(ui->editName->text());
    }
}

void MainWindow::on_btnDelete_clicked()
{
    if(!ui->listAll->currentItem()) return;
    if(delete_task_old(&taskfirst, &tasklast,
                       ui->listAll->currentItem()->text().toUtf8().data())){
        UpdateView();
    }
}

void MainWindow::on_btnRecord_clicked()
{
    write_tasks(db, taskfirst, ui->editNotes->document()->toPlainText().toUtf8().data());
    //UpdateView();
}

void MainWindow::on_btnShowNotes_clicked()
{
    if(!shownotes){
        shownotes = true;
        ui->groupNotes->show();
    } else {
        shownotes = false;
        ui->groupNotes->hide();
    }
}

void MainWindow::on_btnShowInsert_clicked()
{
    if(!showinsert){
        showinsert = true;
        ui->groupInsert->show();
    } else {
        showinsert = false;
        ui->groupInsert->hide();
    }

}
