#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QModelIndex>
#include <stdio.h>
#include <QCloseEvent>

#include "task.h"

#define def_db "alarm.lst"

namespace Ui {

class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    struct task* taskfirst, *tasklast;
    struct task* todayfirst, *todaylast;
       
private slots:
    void on_btnRemove_clicked();

    void on_btnShowOld_clicked();

    void on_btnSetDate_clicked();

    void on_btnInsert_clicked();

    void on_btnCalcDate_clicked();

    void on_listAll_doubleClicked(const QModelIndex &index);

    void on_btnCls_clicked();

    void on_btnToday_clicked();

    void on_listToday_doubleClicked(const QModelIndex &index);

    void on_btnActivate_clicked();

    void on_btnUpdate_clicked();

    void on_btnDelete_clicked();

    void on_btnRecord_clicked();

    void on_btnShowNotes_clicked();

    void on_btnShowInsert_clicked();

private:
    Ui::MainWindow *ui;
    void UpdateView();

    FILE* db;

    bool shownotes, showinsert;    

protected:
    void closeEvent(QCloseEvent *closeevent);

};

#endif // MAINWINDOW_H
