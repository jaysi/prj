/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Wed Jul 24 18:03:59 2013
**      by: Qt User Interface Compiler version 4.8.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_4;
    QGroupBox *groupInsert;
    QGridLayout *gridLayout_3;
    QFormLayout *formLayout;
    QLabel *label_2;
    QLabel *label_6;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *editDate;
    QPushButton *btnToday;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLineEdit *editRemindDate;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QLineEdit *editRemindDays;
    QPushButton *btnCalcDate;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *editName;
    QPushButton *btnCls;
    QHBoxLayout *horizontalLayout_6;
    QTextEdit *editComments;
    QVBoxLayout *verticalLayout;
    QPushButton *btnUpdate;
    QPushButton *btnInsert;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QListWidget *listAll;
    QPushButton *btnActivate;
    QPushButton *btnRemove;
    QPushButton *btnShowOld;
    QPushButton *btnDelete;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout;
    QListWidget *listToday;
    QLineEdit *editTodayDate;
    QLabel *label;
    QPushButton *btnSetDate;
    QPushButton *btnRecord;
    QPushButton *btnShowNotes;
    QPushButton *btnShowInsert;
    QGroupBox *groupNotes;
    QGridLayout *gridLayout_5;
    QTextEdit *editNotes;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(673, 510);
        MainWindow->setLayoutDirection(Qt::RightToLeft);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        gridLayout_4 = new QGridLayout(centralWidget);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        groupInsert = new QGroupBox(centralWidget);
        groupInsert->setObjectName(QString::fromUtf8("groupInsert"));
        gridLayout_3 = new QGridLayout(groupInsert);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_2 = new QLabel(groupInsert);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        label_6 = new QLabel(groupInsert);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_6);

        label_3 = new QLabel(groupInsert);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        editDate = new QLineEdit(groupInsert);
        editDate->setObjectName(QString::fromUtf8("editDate"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(editDate->sizePolicy().hasHeightForWidth());
        editDate->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(editDate);

        btnToday = new QPushButton(groupInsert);
        btnToday->setObjectName(QString::fromUtf8("btnToday"));
        sizePolicy.setHeightForWidth(btnToday->sizePolicy().hasHeightForWidth());
        btnToday->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(btnToday);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(groupInsert);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        editRemindDate = new QLineEdit(groupInsert);
        editRemindDate->setObjectName(QString::fromUtf8("editRemindDate"));
        sizePolicy.setHeightForWidth(editRemindDate->sizePolicy().hasHeightForWidth());
        editRemindDate->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(editRemindDate);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_5 = new QLabel(groupInsert);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        editRemindDays = new QLineEdit(groupInsert);
        editRemindDays->setObjectName(QString::fromUtf8("editRemindDays"));
        sizePolicy.setHeightForWidth(editRemindDays->sizePolicy().hasHeightForWidth());
        editRemindDays->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(editRemindDays);

        btnCalcDate = new QPushButton(groupInsert);
        btnCalcDate->setObjectName(QString::fromUtf8("btnCalcDate"));

        horizontalLayout_3->addWidget(btnCalcDate);


        horizontalLayout_4->addLayout(horizontalLayout_3);


        horizontalLayout_5->addLayout(horizontalLayout_4);


        formLayout->setLayout(2, QFormLayout::FieldRole, horizontalLayout_5);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        editName = new QLineEdit(groupInsert);
        editName->setObjectName(QString::fromUtf8("editName"));

        horizontalLayout_2->addWidget(editName);

        btnCls = new QPushButton(groupInsert);
        btnCls->setObjectName(QString::fromUtf8("btnCls"));

        horizontalLayout_2->addWidget(btnCls);


        formLayout->setLayout(0, QFormLayout::FieldRole, horizontalLayout_2);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        editComments = new QTextEdit(groupInsert);
        editComments->setObjectName(QString::fromUtf8("editComments"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(editComments->sizePolicy().hasHeightForWidth());
        editComments->setSizePolicy(sizePolicy1);
        editComments->setLayoutDirection(Qt::RightToLeft);
        editComments->setAutoFillBackground(false);
        editComments->setFrameShape(QFrame::StyledPanel);
        editComments->setFrameShadow(QFrame::Sunken);

        horizontalLayout_6->addWidget(editComments);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        btnUpdate = new QPushButton(groupInsert);
        btnUpdate->setObjectName(QString::fromUtf8("btnUpdate"));

        verticalLayout->addWidget(btnUpdate);

        btnInsert = new QPushButton(groupInsert);
        btnInsert->setObjectName(QString::fromUtf8("btnInsert"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(btnInsert->sizePolicy().hasHeightForWidth());
        btnInsert->setSizePolicy(sizePolicy2);

        verticalLayout->addWidget(btnInsert);


        horizontalLayout_6->addLayout(verticalLayout);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout_6);


        gridLayout_3->addLayout(formLayout, 0, 0, 1, 1);


        gridLayout_4->addWidget(groupInsert, 1, 0, 1, 5);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setLayoutDirection(Qt::RightToLeft);
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        listAll = new QListWidget(groupBox);
        listAll->setObjectName(QString::fromUtf8("listAll"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::MinimumExpanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(listAll->sizePolicy().hasHeightForWidth());
        listAll->setSizePolicy(sizePolicy3);
        listAll->setFrameShape(QFrame::StyledPanel);
        listAll->setMidLineWidth(3);
        listAll->setAutoScroll(false);
        listAll->setAlternatingRowColors(true);
        listAll->setViewMode(QListView::ListMode);
        listAll->setUniformItemSizes(false);
        listAll->setWordWrap(true);
        listAll->setSortingEnabled(true);

        gridLayout_2->addWidget(listAll, 0, 0, 1, 2);

        btnActivate = new QPushButton(groupBox);
        btnActivate->setObjectName(QString::fromUtf8("btnActivate"));

        gridLayout_2->addWidget(btnActivate, 2, 0, 1, 1);

        btnRemove = new QPushButton(groupBox);
        btnRemove->setObjectName(QString::fromUtf8("btnRemove"));

        gridLayout_2->addWidget(btnRemove, 1, 0, 1, 1);

        btnShowOld = new QPushButton(groupBox);
        btnShowOld->setObjectName(QString::fromUtf8("btnShowOld"));

        gridLayout_2->addWidget(btnShowOld, 1, 1, 1, 1);

        btnDelete = new QPushButton(groupBox);
        btnDelete->setObjectName(QString::fromUtf8("btnDelete"));

        gridLayout_2->addWidget(btnDelete, 2, 1, 1, 1);


        gridLayout_4->addWidget(groupBox, 0, 2, 1, 1);

        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setLayoutDirection(Qt::RightToLeft);
        gridLayout = new QGridLayout(groupBox_2);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        listToday = new QListWidget(groupBox_2);
        listToday->setObjectName(QString::fromUtf8("listToday"));
        sizePolicy3.setHeightForWidth(listToday->sizePolicy().hasHeightForWidth());
        listToday->setSizePolicy(sizePolicy3);
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        listToday->setFont(font);
        listToday->setMidLineWidth(1);
        listToday->setAutoScroll(false);
        listToday->setAlternatingRowColors(true);
        listToday->setUniformItemSizes(false);
        listToday->setWordWrap(true);
        listToday->setSortingEnabled(true);

        gridLayout->addWidget(listToday, 0, 0, 1, 6);

        editTodayDate = new QLineEdit(groupBox_2);
        editTodayDate->setObjectName(QString::fromUtf8("editTodayDate"));
        sizePolicy.setHeightForWidth(editTodayDate->sizePolicy().hasHeightForWidth());
        editTodayDate->setSizePolicy(sizePolicy);

        gridLayout->addWidget(editTodayDate, 3, 3, 1, 1);

        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 3, 2, 1, 1);

        btnSetDate = new QPushButton(groupBox_2);
        btnSetDate->setObjectName(QString::fromUtf8("btnSetDate"));

        gridLayout->addWidget(btnSetDate, 3, 5, 1, 1);

        btnRecord = new QPushButton(groupBox_2);
        btnRecord->setObjectName(QString::fromUtf8("btnRecord"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(btnRecord->sizePolicy().hasHeightForWidth());
        btnRecord->setSizePolicy(sizePolicy4);
        btnRecord->setFont(font);
        btnRecord->setStyleSheet(QString::fromUtf8("color:rgb(255, 0, 0)"));

        gridLayout->addWidget(btnRecord, 2, 5, 1, 1);

        btnShowNotes = new QPushButton(groupBox_2);
        btnShowNotes->setObjectName(QString::fromUtf8("btnShowNotes"));

        gridLayout->addWidget(btnShowNotes, 2, 2, 1, 1);

        btnShowInsert = new QPushButton(groupBox_2);
        btnShowInsert->setObjectName(QString::fromUtf8("btnShowInsert"));

        gridLayout->addWidget(btnShowInsert, 2, 3, 1, 1);


        gridLayout_4->addWidget(groupBox_2, 0, 3, 1, 1);

        groupNotes = new QGroupBox(centralWidget);
        groupNotes->setObjectName(QString::fromUtf8("groupNotes"));
        gridLayout_5 = new QGridLayout(groupNotes);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        editNotes = new QTextEdit(groupNotes);
        editNotes->setObjectName(QString::fromUtf8("editNotes"));

        gridLayout_5->addWidget(editNotes, 0, 0, 1, 1);


        gridLayout_4->addWidget(groupNotes, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 673, 20));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(editDate, editRemindDays);
        QWidget::setTabOrder(editRemindDays, btnCalcDate);
        QWidget::setTabOrder(btnCalcDate, btnToday);
        QWidget::setTabOrder(btnToday, listToday);
        QWidget::setTabOrder(listToday, listAll);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\333\214\330\247\330\257\330\242\331\210\330\261\333\214", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        MainWindow->setToolTip(QApplication::translate("MainWindow", "[ Programmed by Babak Akhondi < jaysi13@gmail.com > ]", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        groupInsert->setTitle(QApplication::translate("MainWindow", "\330\257\330\261\330\254", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindow", "\330\271\331\206\331\210\330\247\331\206:", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("MainWindow", "\331\205\331\204\330\247\330\255\330\270\330\247\330\252:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("MainWindow", "\330\252\330\247\330\261\333\214\330\256 \330\257\330\261\330\254:", 0, QApplication::UnicodeUTF8));
        btnToday->setText(QApplication::translate("MainWindow", "\330\247\331\205\330\261\331\210\330\262", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("MainWindow", "\330\252\330\247\330\261\333\214\330\256 \333\214\330\247\330\257\330\242\331\210\330\261\333\214:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindow", "\330\261\331\210\330\262 \330\247\330\262 \330\252\330\247\330\261\333\214\330\256 \330\257\330\261\330\254:", 0, QApplication::UnicodeUTF8));
        btnCalcDate->setText(QApplication::translate("MainWindow", "\331\205\330\255\330\247\330\263\330\250\331\207", 0, QApplication::UnicodeUTF8));
        btnCls->setText(QApplication::translate("MainWindow", "\331\276\330\247\332\251 \332\251\330\261\330\257\331\206", 0, QApplication::UnicodeUTF8));
        btnUpdate->setText(QApplication::translate("MainWindow", "\330\250\330\261\331\210\330\262\330\261\330\263\330\247\331\206\333\214", 0, QApplication::UnicodeUTF8));
        btnInsert->setText(QApplication::translate("MainWindow", "\330\257\330\261\330\254 \330\254\330\257\333\214\330\257", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "\331\207\331\205\331\207 \331\205\331\210\330\247\330\261\330\257", 0, QApplication::UnicodeUTF8));
        btnActivate->setText(QApplication::translate("MainWindow", "\331\201\330\271\330\247\331\204 \330\263\330\247\330\262\333\214", 0, QApplication::UnicodeUTF8));
        btnRemove->setText(QApplication::translate("MainWindow", "\330\272\333\214\330\261\331\201\330\271\330\247\331\204 \330\263\330\247\330\262\333\214", 0, QApplication::UnicodeUTF8));
        btnShowOld->setText(QApplication::translate("MainWindow", "\330\242\333\214\330\252\331\205 \331\207\330\247\333\214 \330\272\333\214\330\261 \331\201\330\271\330\247\331\204", 0, QApplication::UnicodeUTF8));
        btnDelete->setText(QApplication::translate("MainWindow", "\330\255\330\260\331\201", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "\331\205\331\210\330\271\330\257", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("MainWindow", "\330\252\330\247\330\261\333\214\330\256 \331\205\331\210\330\271\330\257:", 0, QApplication::UnicodeUTF8));
        btnSetDate->setText(QApplication::translate("MainWindow", "\330\252\331\206\330\270\333\214\331\205 \331\205\330\254\330\257\330\257", 0, QApplication::UnicodeUTF8));
        btnRecord->setText(QApplication::translate("MainWindow", "\330\260\330\256\331\200\331\200\331\200\331\200\331\200\331\200\331\200\331\200\333\214\330\261\331\207", 0, QApplication::UnicodeUTF8));
        btnShowNotes->setText(QApplication::translate("MainWindow", "\333\214\330\247\330\257\330\257\330\247\330\264\330\252", 0, QApplication::UnicodeUTF8));
        btnShowInsert->setText(QApplication::translate("MainWindow", "\330\257\330\261\330\254", 0, QApplication::UnicodeUTF8));
        groupNotes->setTitle(QApplication::translate("MainWindow", "\333\214\330\247\330\257\330\257\330\247\330\264\330\252", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
