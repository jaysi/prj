﻿#include <QApplication>
#include "mainwindow.h"
#include "checkdialog.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    CheckDialog d(0, &w);

    //d.SetMain(&w);
    //w.show();

    if(argv[1] && !strcmp(argv[1], "check")){
        d.show();
        //w.hide();
    } else {
        w.show();
    }

    return a.exec();
}
