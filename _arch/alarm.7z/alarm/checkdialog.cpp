﻿#include "checkdialog.h"
#include "ui_checkdialog.h"

//#include "mainwindow.h"
//#include <QMainWindow>
#include <QDebug>

CheckDialog::CheckDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CheckDialog)
{
    ui->setupUi(this);    
    UpdateView();
}

CheckDialog::CheckDialog(QWidget *parent, MainWindow* main) :
    QDialog(parent),
    ui(new Ui::CheckDialog)
{
    ui->setupUi(this);
    mainw = main;

    int d[6];

    d13_today(d);

    ui->labelToday->setText(tr("%1/%2/%3").arg(d[0]).arg(d[1]).arg(d[2]));

    UpdateView();
}

CheckDialog::~CheckDialog()
{
    delete ui;
}

void CheckDialog::SetMain(void *main){
    mainw = main;
}

void CheckDialog::on_clbtnReturn_clicked()
{
    ((MainWindow*)mainw)->show();
    close();
}

void CheckDialog::UpdateView(){
    struct task* entry;
    int today[6];
    struct task* todayfirst;

    ui->listToday->clear();

    d13_today(today);

    check_today(((MainWindow*)mainw)->taskfirst, &todayfirst, today);

    for(entry = todayfirst; entry; entry = entry->todaynext){
        if(entry->stat[0] == 'A') ui->listToday->addItem(trUtf8(entry->name));
    }
}

void CheckDialog::on_btnExit_clicked()
{
    close();
}

void CheckDialog::on_listToday_clicked(const QModelIndex &index)
{
    struct task* entry;
    if(find_task(((MainWindow*)mainw)->taskfirst, ui->listToday->currentItem()->text().toUtf8().data(), &entry, NULL)){
        ui->labelRDate->setText(tr("%3").arg(entry->remind_date));
    }

}
