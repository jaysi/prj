﻿#include "task.h"

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#ifdef linux
#include <time.h>
#endif

#define D13_ITEMS 6
#define MAXTIME 20
#define d13_datesep "/.-"

#define E13_OK  1
#define e13_error(e) 0
typedef int error13_t;

#define __true  1
#define __false 0

enum d{Y, M, D};

#include <stdio.h>
#include <stdlib.h>

#undef TEST
//#define TEST

unsigned long d13_gdayno(int g_y, int g_m, int g_d){
    int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    //int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    unsigned long gy, gm, gd, g_day_no;
    //int jy, jm, jd, j_day_no;
    //int j_np;

    gy = g_y-1600;
    gm = g_m-1;
    gd = g_d-1;

    g_day_no = 365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400);

    for (i=0; i < gm; ++i) g_day_no += g_days_in_month[i];

    if (gm>1 && ((gy%4==0 && gy%100!=0) || (gy%400==0))) g_day_no++; /* leap and after Feb */

    g_day_no += gd;

    return g_day_no;
}

unsigned long d13_jdayno(int j_y, int j_m, int j_d){
    //int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    //int gy, gm, gd, g_day_no;
    unsigned long jy, jm, jd, j_day_no;
    //int leap;

    jy = j_y-979;
    jm = j_m-1;
    jd = j_d-1;

    j_day_no = 365*jy + (jy/ 33)*8 + ((jy%33+3)/ 4);
    for (i=0; i < jm; ++i) j_day_no += j_days_in_month[i];

    j_day_no += jd;

    return j_day_no;
}

error13_t d13_jdayno2gdate(unsigned long j_day_no, int gdate[3]){

    int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    //int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    unsigned long gy, gm, gd, g_day_no;
    //int jy, jm, jd, j_day_no;
    int leap;

    g_day_no = j_day_no+79;

    gy = 1600 + 400*(g_day_no/ 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */

    g_day_no = g_day_no % 146097;
    leap = __true;

    if (g_day_no >= 36525) { /* 36525 = 365*100 + 100/4 */
        g_day_no--;
        gy += 100*(g_day_no/ 36524); /* 36524 = 365*100 + 100/4 - 100/100 */
        g_day_no = g_day_no % 36524;
        if (g_day_no >= 365) g_day_no++;
        else leap = __false;
    }

    gy += 4*(g_day_no/ 1461); /* 1461 = 365*4 + 4/4 */ g_day_no %= 1461;
    if (g_day_no >= 366) {
        leap = __false;
        g_day_no--;
        gy += (g_day_no/ 365);
        g_day_no = g_day_no % 365;
    }
    for (i = 0; g_day_no >= g_days_in_month[i] + (i == 1 && leap); i++) g_day_no -= g_days_in_month[i] + (i == 1 && leap);

    gm = i+1;
    gd = g_day_no+1;

    gdate[0] = gy;
    gdate[1] = gm;
    gdate[2] = gd;

    return E13_OK;
}

error13_t d13_gdayno2jdate(unsigned long g_day_no, int jdate[3]){

    //int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    //int gy, gm, gd, g_day_no;
    unsigned long jy, jm, jd, j_day_no;
    int j_np;

    j_day_no = g_day_no-79;
    j_np = (j_day_no/ 12053); /* 12053 = 365*33 + 32/4 */

    j_day_no = j_day_no % 12053;
    jy = 979+33*j_np+4*(j_day_no/1461); /* 1461 = 365*4 + 4/4 */

    j_day_no %= 1461;

    if(j_day_no >= 366) {
        jy += ((j_day_no-1)/ 365);
        j_day_no = (j_day_no-1)%365;
    }

    for(i = 0; i < 11 && j_day_no >= j_days_in_month[i]; ++i)
        j_day_no -= j_days_in_month[i];

    jm = i+1;
    jd = j_day_no+1;

    jdate[0] = jy;
    jdate[1] = jm;
    jdate[2] = jd;

    return E13_OK;
}

error13_t d13_jdayno2jdate(unsigned long j_day_no, int jdate[3]){
    /*
     * jd1->j1, j1->gd1, gd1->jd1;
    */

    int gdate[3];
    d13_jdayno2gdate(j_day_no, gdate);
    d13_g2j(gdate[0], gdate[1], gdate[2], jdate);
    return E13_OK;
}


error13_t d13_g2j(int g_y, int g_m, int g_d, int jdate[3]){

    int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    int gy, gm, gd, g_day_no;
    int jy, jm, jd, j_day_no;
    int j_np;

    gy = g_y-1600;
    gm = g_m-1;
    gd = g_d-1;

    g_day_no = 365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400);

    for (i=0; i < gm; ++i) g_day_no += g_days_in_month[i];

    if (gm>1 && ((gy%4==0 && gy%100!=0) || (gy%400==0))) g_day_no++; /* leap and after Feb */

    g_day_no += gd;
    j_day_no = g_day_no-79;
    j_np = (j_day_no/ 12053); /* 12053 = 365*33 + 32/4 */

    j_day_no = j_day_no % 12053;
    jy = 979+33*j_np+4*(j_day_no/1461); /* 1461 = 365*4 + 4/4 */

    j_day_no %= 1461;

    if(j_day_no >= 366) {
        jy += ((j_day_no-1)/ 365);
        j_day_no = (j_day_no-1)%365;
    }

    for(i = 0; i < 11 && j_day_no >= j_days_in_month[i]; ++i)
        j_day_no -= j_days_in_month[i];

    jm = i+1;
    jd = j_day_no+1;

    jdate[0] = jy;
    jdate[1] = jm;
    jdate[2] = jd;

    return E13_OK;
}

error13_t d13_j2g(int j_y, int j_m, int j_d, int gdate[3]) {

    int g_days_in_month[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int j_days_in_month[] = {31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29};
    int i;
    int gy, gm, gd, g_day_no;
    int jy, jm, jd, j_day_no;
    int leap;

    jy = j_y-979;
    jm = j_m-1;
    jd = j_d-1;

    j_day_no = 365*jy + (jy/ 33)*8 + ((jy%33+3)/ 4);
    for (i=0; i < jm; ++i) j_day_no += j_days_in_month[i];

    j_day_no += jd;
    g_day_no = j_day_no+79;

    gy = 1600 + 400*(g_day_no/ 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */

    g_day_no = g_day_no % 146097;
    leap = __true;

    if (g_day_no >= 36525) { /* 36525 = 365*100 + 100/4 */
        g_day_no--;
        gy += 100*(g_day_no/ 36524); /* 36524 = 365*100 + 100/4 - 100/100 */
        g_day_no = g_day_no % 36524;
        if (g_day_no >= 365) g_day_no++;
        else leap = __false;
    }

    gy += 4*(g_day_no/ 1461); /* 1461 = 365*4 + 4/4 */ g_day_no %= 1461;
    if (g_day_no >= 366) {
        leap = __false;
        g_day_no--;
        gy += (g_day_no/ 365);
        g_day_no = g_day_no % 365;
    }
    for (i = 0; g_day_no >= g_days_in_month[i] + (i == 1 && leap); i++) g_day_no -= g_days_in_month[i] + (i == 1 && leap);

    gm = i+1;
    gd = g_day_no+1;

    gdate[0] = gy;
    gdate[1] = gm;
    gdate[2] = gd;

    return E13_OK;

}

static inline error13_t _d13_get_proper_sys_time(time_t* t, int it13[D13_ITEMS]){
    struct tm* tp;
    char tmp[10];
    tp = localtime(t);
    if(!tp) return e13_error(E13_SYSE);

    strftime(tmp, 10, "%Y", tp);
    it13[0] = atoi(tmp);
    strftime(tmp, 10, "%m", tp);
    it13[1] = atoi(tmp);
    strftime(tmp, 10, "%d", tp);
    it13[2] = atoi(tmp);

    it13[3] = tp->tm_hour;
    it13[4] = tp->tm_min;
    it13[5] = tp->tm_sec;

    return E13_OK;
}

error13_t d13_time13(time_t* t, char t13[MAXTIME]){
    int it13[D13_ITEMS];

    _d13_get_proper_sys_time(t, it13);

    d13_g2j(it13[0], it13[1], it13[2], it13);

    snprintf(	t13, MAXTIME, "%i-%i-%i-%i-%i-%i",
        it13[0], it13[1], it13[2], it13[3], it13[4], it13[5]
        );

    return E13_OK;
}

//see comparision rules in header file.
int d13_cmp_time13(int t13_1[D13_ITEMS], int t13_2[D13_ITEMS]){

    register int i;

    for(i = 0; i < D13_ITEMS; i++){
        if(t13_1[i] && t13_2[i]){
            if(t13_1[i] > t13_2[i]){
                return 1;
            } else if(t13_1[i] < t13_2[i]){
                return -1;
            }
        }
    }

    return 0;
}

error13_t d13_today(int it13[D13_ITEMS]){

    time_t t;

    if(time(&t) == -1){
        return e13_error(E13_SYSE);
    }

    _d13_get_proper_sys_time(&t, it13);

    d13_g2j(it13[0], it13[1], it13[2], it13);

    return E13_OK;
}

error13_t d13_now(char t13[MAXTIME]){
    time_t t;

    if(time(&t) == -1){
        return e13_error(E13_SYSE);
    }

    d13_time13(&t, t13);

    return E13_OK;
}

error13_t d13_resolve_date(char* date, int d[3]){
    char* start, *end;
    start = date;
    int i;
    for(i = 0; i < 3; i++){

        end = strpbrk(start, d13_datesep);

        if(end) {
            *end = 0;
        }

        d[i] = atoi(start);
        if(end) *end = datesep[0];
        if(d[i] == -1){
            return e13_error(E13_RANGE);
        }
        if(end) start = end + 1;
    }
    return E13_OK;
}

size_t realstrlen(char* str){
    size_t i = 0UL;
    while(str[i++]);
    return i-1;
}

char* fgets_line(char* buf, FILE* db){

    size_t pos = 0;

read_more:
    if(!fgets(buf + pos, bufsize - pos, db)){
        return NULL;
    } else {
        pos = realstrlen(buf);
        if(buf[pos-2]!='|'){
            goto read_more;
        }
    }

    return buf;

}

int load_tasks(char *dbname, FILE** db, struct task **taskfirst, char* notes){

    struct task* newtask, *tasklast = NULL;
    char* buf;
    int ret = __true;
    //int d[3];
    size_t pos;

    *db = fopen(dbname,
#ifdef WIN32
                "r+t"
#else
                "r+"
#endif
                );
    if(!(*db)){
        perror("fopen()");
        return __false;
    }

    if(!fgets_line(notes, *db)) return __true;
    notes[realstrlen(notes)-2]=0;

    while(!feof(*db)){

        buf = (char*)malloc(bufsize);
        newtask = (struct task*)malloc(sizeof(struct task));
        newtask->name = buf;

        newtask->next = NULL;
        newtask->todaynext = NULL;

        pos = 0;

        if(!fgets_line(buf, *db)){
            free(newtask->name);
            free(newtask);
            continue;
        }

        newtask->comments = strchr(newtask->name, chsep);
        if(!newtask->comments){
            free(newtask->name);
            free(newtask);
            ret = __true;
            continue;
        }

        *(newtask->comments) = 0;
        newtask->comments++;
        //perror("ok1");

        newtask->date = strchr(newtask->comments, chsep);
        if(!newtask->date){
            ret = __false;
            goto end;
        }
        *(newtask->date) = 0;
        newtask->date++;
        //perror("ok2");

        newtask->remind_date = strchr(newtask->date, chsep);
        if(!newtask->remind_date){
            ret = __false;
            goto end;
        }
        *(newtask->remind_date) = 0;
        newtask->remind_date++;
        //perror("ok3");

        newtask->stat = strchr(newtask->remind_date, chsep);
        if(!newtask->stat){
            ret = __false;
            goto end;
        }
        *(newtask->stat) = 0;
        newtask->stat++;


//        //resolve task dates
//        if(!d13_resolve_date(newtask->date, d)){
//            perror("no date");
//            ret = __false;
//            goto end;
//        }

//        newtask->idate = d13_jdayno(d[0], d[1], d[2]);
//        if(!d13_resolve_date(newtask->remind_date, d)){
//            perror("no idate");
//            ret = __false;
//            goto end;
//        }
//        newtask->irdate = d13_jdayno(d[0], d[1], d[2]);

        //perror("ok4");
        if(!(*taskfirst)){
            *taskfirst = newtask;
            tasklast = newtask;
        } else {
            tasklast->next = newtask;
            tasklast = tasklast->next;
        }

    }

end:
    if(!ret){
        perror("false");
        while(*taskfirst){
            newtask = *taskfirst;
            *taskfirst = (*taskfirst)->next;
            free(newtask->name);
            free(newtask);
        }
    }

    return ret;
}

int check_today(struct task* taskfirst, struct task** todayfirst, int d[3]){

    struct task* entry, *todaylast;
//    int d[3];
//    inum_t today;
    int d1[3];

    //*todayfirst = NULL;

//    if(!d13_today(d)){
//        return __false;
//    }

    *todayfirst = NULL;
//    today = jdayno(d[0], d[1], d[2]);
    todaylast = NULL;

    for(entry = taskfirst; entry; entry = entry->next){
        //if(entry->irdate <= today){
        d13_resolve_date(entry->remind_date, d1);
        if(d13_cmp_time13(d1, d) <= 0){
            entry->todaynext = NULL;
            if(!(*todayfirst)){
                *todayfirst = entry;
                todaylast = entry;
            } else {
                todaylast->todaynext = entry;
                todaylast= todaylast->todaynext;
            }
        }
    }

    return __true;
}

int write_tasks(FILE* db, struct task* taskfirst, char* notes){
    struct task* entry;
    //int d[3], rd[3];

    if(!db) return __false;

    db = freopen("alarm.lst", "w", db);

    fprintf(db, "%s|\n", notes);

    for(entry = taskfirst; entry; entry = entry->next){
        //perror(entry->name);
//        d13_jdayno2jdate(entry->idate, d);
//        d13_jdayno2jdate(entry->irdate, rd);
        fprintf(db, "%s\t%s\t%s\t%s\t%s|\n", entry->name, entry->comments,
                entry->date, entry->remind_date, entry->stat);
    }

    fflush(db);

    return __true;
}

int find_task(struct task* taskfirst, char* name, struct task** entry, struct task** prev){

    //if(!name || !strlen(name)) return __false;

    if(prev) *prev = NULL;

    for(*entry = taskfirst; *entry; *entry = (*entry)->next){
        if(!strcmp(name, (*entry)->name)){
            return __true;
        }
        if(prev) *prev = *entry;
    }

    return __false;

}

int new_task(struct task** taskfirst, struct task** tasklast, char* name, char* comment, char* date, char* rdate){

    struct task* entry;
    //int d[3];

    if(!strlen(name) || !strlen(date) || !strlen(rdate)) return __false;

    if(find_task(*taskfirst, name, &entry, tasklast)) return __false;

    entry = (struct task*)malloc(sizeof(struct task));
    entry->next = NULL;
    entry->name = (char*)malloc(strlen(name)+strlen(comment)+strlen(date)+strlen(rdate)+4+2);

    entry->comments = entry->name + strlen(name)+1;
    entry->date = entry->comments + strlen(comment)+1;
    entry->remind_date = entry->date + strlen(date)+1;
    entry->stat = entry->remind_date + strlen(rdate)+1;

    strcpy(entry->name, name);
    strcpy(entry->comments, comment);
    strcpy(entry->date, date);
    strcpy(entry->remind_date, rdate);
    strcpy(entry->stat, "A");

//    if(!d13_resolve_date(entry->date, d)){
//        perror("no date");
//        free(entry->name);free(entry);
//        return __false;
//    }

//    entry->idate = d13_jdayno(d[0], d[1], d[2]);
//    if(!d13_resolve_date(entry->remind_date, d)){
//        perror("no idate");
//        free(entry->name);free(entry);
//        return __false;
//    }
//    entry->irdate = d13_jdayno(d[0], d[1], d[2]);

    if(!(*taskfirst)){
        *taskfirst = entry;
        *tasklast = entry;
    } else {
        //perror((*tasklast)->name);
        (*tasklast)->next = entry;
        (*tasklast) = (*tasklast)->next;
    }

    return __true;

}

int delete_task_old(struct task** taskfirst, struct task** tasklast, char* name){
    struct task* del, *prev;
    if(!find_task(*taskfirst, name, &del, &prev)){
        return __false;
    }

    if(del == *taskfirst){
        *taskfirst = (*taskfirst)->next;
    } else {
        if(del == *tasklast){
                *tasklast = prev;
        }
        prev->next = del->next;
    }

    free(del->name);
    free(del);

    return __true;
}

int update_task(struct task** taskfirst, struct task** tasklast, char* name, char* comment, char* date, char* rdate){
    if(delete_task_old(taskfirst, tasklast, name)){
        return new_task(taskfirst, tasklast, name, comment, date, rdate);
    }
    return __false;
}

int inactivate_task(struct task* taskfirst, char* name){
    struct task* del, *prev;
    if(!find_task(taskfirst, name, &del, &prev)){
        return __false;
    }

    strcpy(del->stat, "D");

    return __true;
}

int activate_task(struct task* taskfirst, char* name){
    struct task* del, *prev;
    if(!find_task(taskfirst, name, &del, &prev)){
        return __false;
    }

    strcpy(del->stat, "A");

    return __true;
}



