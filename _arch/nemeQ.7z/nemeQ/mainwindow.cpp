﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->labelNMHost->setHidden(true);
    ui->labelNMPort->setHidden(true);
    ui->lineNMHost->setHidden(true);
    ui->lineNMPort->setHidden(true);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_toolShowConfig_clicked()
{
    if(ui->labelNMHost->isHidden()){
        ui->toolShowConfig->setArrowType(Qt::LeftArrow);
        ui->labelNMHost->setHidden(false);
        ui->labelNMPort->setHidden(false);
        ui->lineNMHost->setHidden(false);
        ui->lineNMPort->setHidden(false);
    } else {
        ui->toolShowConfig->setArrowType(Qt::DownArrow);
        ui->labelNMHost->setHidden(true);
        ui->labelNMPort->setHidden(true);
        ui->lineNMHost->setHidden(true);
        ui->lineNMPort->setHidden(true);
    }
}
