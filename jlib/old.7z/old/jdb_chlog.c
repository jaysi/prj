#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>

#define JDB_JRNL_ALLOC_CHUNK	100

#include "jdb.h"

static inline void _jdb_changelog_hdr_to_buf(struct jdb_changelog_hdr* hdr, uchar* buf){
	memcpy(buf, (void*)&hdr->recsize, sizeof(uint32_t));	
	memcpy(buf + sizeof(uint32_t), (void*)&hdr->chid, sizeof(uint64_t));
	memcpy(buf + sizeof(uint32_t) + sizeof(uint64_t),
		(void*)&hdr->cmd, sizeof(uchar));
	memcpy(buf + sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uchar),
		(void*)&hdr->ret, sizeof(int));
	memcpy(buf + sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uchar) + sizeof(int),
		(void*)&hdr->nargs, sizeof(uchar));
}

static inline void _jdb_changelog_buf_to_hdr(uchar* buf, struct jdb_changelog_hdr* hdr){
	memcpy((void*)&hdr->recsize, buf, sizeof(uint32_t));
	memcpy((void*)&hdr->chid, buf + sizeof(uint32_t), sizeof(uint64_t));
	memcpy((void*)&hdr->cmd, buf + sizeof(uint32_t) + sizeof(uint64_t),
		sizeof(uchar));
	memcpy((void*)&hdr->ret,
		buf + sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uchar),
		sizeof(int));
	memcpy((void*)&hdr->nargs,
		buf + sizeof(uint32_t) + sizeof(uint64_t) + sizeof(uchar) + sizeof(int),
		sizeof(uchar));
}


/*
static inline int _jdb_jrnl_get_rec_hdr(struct jdb_handle* h, struct jdb_changelog_hdr* hdr){	
	size_t red;
	
	if((red = hard_read(h->jfd, hdr, sizeof(struct jdb_changelog_hdr)) != 
		sizeof(struct jdb_changelog_hdr)) return -JE_READ;
	
	return 0;
}
*/

int _jdb_changelog_get_rec(int fd, struct jdb_changelog_rec* rec){
	size_t red;
	uint32_t recsize;	
	
	_wdeb_io(L"reading kernel...");
	
	//if((ret = _jdb_jrnl_get_rec_hdr(h, &rec->hdr)) < 0) return ret;
	
	if((red = hard_read(fd, (char*)&recsize, sizeof(uint32_t))) != 
		sizeof(uint32_t)) return -JE_READ;
		
	if(recsize < sizeof(struct jdb_changelog_hdr)) return -JE_SIZE;	
	
	if(recsize == sizeof(struct jdb_changelog_hdr)){
		rec->buf = NULL;
		rec->arg = NULL;
		rec->argsize = NULL;
		return 0;
	}
		
	rec->buf = (uchar*)malloc(recsize);	
	if(!rec->buf) return -JE_MALOC;
	
	memcpy(rec->buf, &recsize, sizeof(uint32_t));
	
	if((red = hard_read(fd, (char*)(rec->buf + sizeof(uint32_t)),
			recsize - sizeof(uint32_t))) != 
			(recsize - sizeof(uint32_t)))
			return -JE_READ;
	
	rc4(rec->buf + sizeof(uint32_t), recsize, &h->rc4);
	
	_jdb_changelog_buf_to_hdr(rec->buf, &rec->hdr);
	
	//rec->nargs = rec->buf[sizeof(struct jdb_changelog_hdr)];
	rec->argsize = (uint32_t*)(rec->buf + sizeof(struct jdb_changelog_hdr) + sizeof(uchar));
	//rec->arg = (uchar*)(rec->argsize + rec->nargs*sizeof(uint32_t));
	rec->arg = (uchar*)(rec->argsize + rec->hdr.nargs);
	
	return 0;
	
}

static inline uchar* _jdb_get_changelog_arg_raw(uint32_t* argsize, uchar* arg, uint32_t n){
	uint32_t pos, i;	
	pos = 0;
	for(i = 0; i < n; i++){
		pos += argsize[i];
	}
	_wdeb_pos(L"pos is %u", pos);
	return arg + pos;
}

static inline uchar* _jdb_get_changelog_arg(struct jdb_changelog_rec* rec, uint32_t n){

	return _jdb_get_changelog_arg_raw(rec->argsize, rec->arg, n);

}

static inline void _jdb_free_changelog_rec(struct jdb_changelog_rec* rec){
	if(rec->buf) free(rec->buf);
}

static inline int _jdb_changelog_parse_create_table(struct jdb_changelog_rec* rec, struct jdb_changelog_create_table* s){

	/*
		args {
			wchar_t* name;
			uint32_t nrows;
			uint32_t ncols;
			uchar flags;
			uint16_t indexes;
		}

		nargs = 5
	*/
	
	if(rec->hdr.nargs != 5) return -JE_INV;
	
	if(
	   rec->argsize[1] != sizeof(uint32_t) ||
	   rec->argsize[2] != sizeof(uint32_t) ||
	   rec->argsize[3] != sizeof(uchar) ||
	   rec->argsize[4] != sizeof(uint16_t)
	   )
	   	return -JE_INV;
	
	
	s->name = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->nrows = (uint32_t*)_jdb_get_changelog_arg(rec, 1);
	s->ncols = (uint32_t*)_jdb_get_changelog_arg(rec, 2);
	s->flags = (uint32_t*)_jdb_get_changelog_arg(rec, 3);
	s->indexes = (uint32_t*)_jdb_get_changelog_arg(rec, 4);
	
	return 0;
}

static inline int _jdb_changelog_parse_rm_table(struct jdb_changelog_rec* rec, struct jdb_changelog_rm_table* s){
	
	/*
		args {
			wchar_t* name;
		}
		
		nargs = 1
	*/
	
	if(rec->hdr.nargs != 1) return -JE_INV;
		
	s->name = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	
	return 0;
}

static inline int _jdb_changelog_parse_add_typedef(struct jdb_changelog_rec* rec, struct jdb_changelog_add_typedef* s){
	
	/*
		args {
			wchar_t* tname;	
			jdb_data_t type_id;
			jdb_data_t base;
			uint32_t len;
			uchar flags;
		}
		
		nargs = 5				
	*/
	
	if(rec->hdr.nargs != 5) return -JE_INV;
	
	if(
	   rec->argsize[1] != sizeof(jdb_data_t) ||
	   rec->argsize[2] != sizeof(jdb_data_t) ||
	   rec->argsize[3] != sizeof(uint32_t) ||
	   rec->argsize[4] != sizeof(uchar)
	   )
	   	return -JE_INV;	
	
	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->type_id = (jdb_data_t*)_jdb_get_changelog_arg(rec, 1);
	s->base = (jdb_data_t*)_jdb_get_changelog_arg(rec, 2);
	s->len = (uint32_t*)_jdb_get_changelog_arg(rec, 3);
	s->flags = (uchar*)_jdb_get_changelog_arg(rec, 4);
	
	return 0;
}

static inline int _jdb_changelog_parse_rm_typedef(struct jdb_changelog_rec* rec, struct jdb_changelog_rm_typedef* s){
	
	/*
		args {
			wchar_t* tname;	
			jdb_data_t type_id;
		}
		
		nargs = 2
	*/
	
	if(rec->hdr.nargs != 2) return -JE_INV;

	if(
	   rec->argsize[1] != sizeof(jdb_data_t)
	   )
		return -JE_INV;
	
	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->type_id = (jdb_data_t*)_jdb_get_changelog_arg(rec, 1);
	
	return 0;
}

static inline int _jdb_changelog_parse_assign_coltype(struct jdb_changelog_rec* rec, struct jdb_changelog_assign_coltype* s){
	
	/*
		args {
			wchar_t* tname;	
			jdb_data_t type_id;
			uint32_t col;
		}
		
		nargs = 3
	*/
	
	if(rec->hdr.nargs != 3) return -JE_INV;
	
	if(
	   rec->argsize[1] != sizeof(jdb_data_t) ||
	   rec->argsize[2] != sizeof(uint32_t)
	   )
	   	return -JE_INV;		
	
	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->type_id = (jdb_data_t*)_jdb_get_changelog_arg(rec, 1);
	s->col = (uint32_t*)_jdb_get_changelog_arg(rec, 2);
	
	return 0;
}

static inline int _jdb_changelog_parse_rm_coltype(struct jdb_changelog_rec* rec, struct jdb_changelog_rm_coltype* s){
	
	/*
		args {
			wchar_t* tname;				
			uint32_t col;
		}
		
		nargs = 2
	*/
	
	if(rec->hdr.nargs != 2) return -JE_INV;
	
	if(
	   rec->argsize[1] != sizeof(uint32_t)
	   )
	   	return -JE_INV;		
	
	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);	
	s->col = (uint32_t*)_jdb_get_changelog_arg(rec, 1);
	
	return 0;
}


static inline int _jdb_changelog_parse_create_cell(struct jdb_changelog_rec* rec, struct jdb_changelog_create_cell* s){
	
	/*
		args {
			wchar_t* tname;
			uint32_t* col;
			uint32_t* row;
			uchar* data;
			uint32_t* datalen;
			jdb_data_t* data_type;
		}

		nargs = 6
	*/
	
	if(rec->hdr.nargs != 6) return -JE_INV;

	if(
	   rec->argsize[1] != sizeof(uint32_t) ||
	   rec->argsize[2] != sizeof(uint32_t) ||
	   rec->argsize[4] != sizeof(uint32_t) ||
	   rec->argsize[5] != sizeof(uchar)
	   )
	   	return -JE_INV;	

	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->col = (uint32_t*)_jdb_get_changelog_arg(rec, 1);
	s->row = (uint32_t*)_jdb_get_changelog_arg(rec, 2);
	s->data = (uchar*)_jdb_get_changelog_arg(rec, 3);
	s->datalen = (uint32_t*)_jdb_get_changelog_arg(rec, 4);
	s->data_type = (uchar*)_jdb_get_changelog_arg(rec, 5);

	return 0;
}

static inline int _jdb_changelog_parse_rm_cell(struct jdb_changelog_rec* rec, struct jdb_changelog_rm_cell* s){
	
	/*
		args {
			wchar_t* tname;
			uint32_t* col;
			uint32_t* row;
		}

		nargs = 3
	*/
	
	if(rec->hdr.nargs != 3) return -JE_INV;

	if(
	   rec->argsize[1] != sizeof(uint32_t) ||
	   rec->argsize[2] != sizeof(uint32_t)
	   )
	   	return -JE_INV;	

	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);
	s->col = (uint32_t*)_jdb_get_changelog_arg(rec, 1);
	s->row = (uint32_t*)_jdb_get_changelog_arg(rec, 2);

	return 0;
}

static inline int _jdb_changelog_parse_update_cell(struct jdb_changelog_rec* rec, struct jdb_changelog_update_cell* s){
	
	/*
		args {
			wchar_t* tname;
			uint32_t* col;
			uint32_t* row;
			uchar* data;
			uint32_t* datalen;
		}

		nargs = 5
	*/
	
	if(rec->hdr.nargs != 5) return -JE_INV;

	if(
	   rec->argsize[1] != sizeof(uint32_t) ||
	   rec->argsize[2] != sizeof(uint32_t) ||
	   rec->argsize[4] != sizeof(uint32_t)
	   )
	   	return -JE_INV;	

	
	s->tname = (wchar_t*)_jdb_get_changelog_arg(rec, 0);	
	s->col = (uint32_t*)_jdb_get_changelog_arg(rec, 1);
	s->row = (uint32_t*)_jdb_get_changelog_arg(rec, 2);
	s->data = (uchar*)_jdb_get_changelog_arg(rec, 3);
	s->datalen = (uint32_t*)_jdb_get_changelog_arg(rec, 4);	
	
	return 0;
}

static inline void _jdb_free_changelog_list(struct jdb_changelog_entry** first){
	struct jdb_changelog_entry *del;
	del = *first;
	while(*first){
		*first = (*first)->next;
		_jdb_free_changelog_rec(&del->rec);
		free(del);
		del = *first;
	}
	
}

static inline int _jdb_changelog_run_create_table(struct jdb_handle* h,
			struct jdb_changelog_create_table* create_table){
	return jdb_create_table(h,
				create_table->name,
				*(create_table->nrows),
				*(create_table->ncols),
				*(create_table->flags),
				*(create_table->indexes)
				);
}

static inline int _jdb_changelog_run_rm_table(struct jdb_handle* h,
			struct jdb_changelog_rm_table* rm_table){
	return jdb_rm_table(h,
				rm_table->name
				);
}

static inline int _jdb_changelog_run_add_typedef(struct jdb_handle* h,
			struct jdb_changelog_add_typedef* add_typedef){
	return jdb_add_typedef(h,
				add_typedef->tname,
				*(add_typedef->type_id),
				*(add_typedef->base),
				*(add_typedef->len),
				*(add_typedef->flags)
				);
}

static inline int _jdb_changelog_run_rm_typedef(struct jdb_handle* h,
			struct jdb_changelog_rm_typedef* rm_typedef){
	return jdb_rm_typedef(h,
				rm_typedef->tname,
				*(rm_typedef->type_id)
				);
}

static inline int _jdb_changelog_run_assign_coltype(struct jdb_handle* h,
			struct jdb_changelog_assign_coltype* assign_coltype){
	return jdb_assign_col_type(h,
				assign_coltype->tname,
				*(assign_coltype->type_id),
				*(assign_coltype->col)
				);
}

static inline int _jdb_changelog_run_rm_coltype(struct jdb_handle* h,
			struct jdb_changelog_rm_coltype* rm_coltype){
	return jdb_rm_col_type(h,
				rm_coltype->tname,
				*(rm_coltype->col)
				);
}

static inline int _jdb_changelog_run_create_cell(struct jdb_handle* h,
			struct jdb_changelog_create_cell* create_cell){
	return jdb_create_cell(h,
				create_cell->tname,
				*(create_cell->col),
				*(create_cell->row),
				create_cell->data,
				*(create_cell->datalen),
				*(create_cell->data_type)
				);
}

static inline int _jdb_changelog_run_rm_cell(struct jdb_handle* h,
			struct jdb_changelog_rm_cell* rm_cell){
	return jdb_rm_cell(h,
				rm_cell->tname,
				*(rm_cell->col),
				*(rm_cell->row)
				);
}

static inline int _jdb_changelog_run_update_cell(struct jdb_handle* h,
			struct jdb_changelog_update_cell* update_cell){
	return jdb_update_cell(h,
				update_cell->tname,
				*(update_cell->col),
				*(update_cell->row),
				update_cell->data,
				*(update_cell->datalen)				
				);
}

static inline int _jdb_changelog_run_rec_cmd(struct jdb_handle* h, struct jdb_changelog_entry* entry){
		
	struct jdb_changelog_create_table	create_table;
	struct jdb_changelog_rm_table		rm_table;
	struct jdb_changelog_add_typedef	add_typedef;
	struct jdb_changelog_rm_typedef		rm_typedef;
	struct jdb_changelog_assign_coltype	assign_coltype;
	struct jdb_changelog_rm_coltype		rm_coltype;
	struct jdb_changelog_create_cell	create_cell;
	struct jdb_changelog_rm_cell		rm_cell;
	struct jdb_changelog_update_cell	update_cell;
	
	switch(entry->rec.hdr.cmd){
		
		case JDB_CMD_CREATE_TABLE:
			if((ret = _jdb_changelog_parse_create_table(
				entry, &create_table)) < 0) return ret;
			return _jdb_changelog_run_create_table(h,
				&create_table);
			break;
		case JDB_CMD_RM_TABLE:
			if((ret = _jdb_changelog_parse_rm_table(
				entry, &rm_table)) < 0) return ret;
			return _jdb_changelog_run_rm_table(h,
				&rm_table);
			break;			
		case JDB_CMD_ADD_TYPEDEF:
			if((ret = _jdb_changelog_parse_add_typedef(
				entry, &add_typedef)) < 0) return ret;
			return _jdb_changelog_run_add_typedef(h,
				&add_typedef);
			break;
		case JDB_CMD_RM_TYPEDEF:
			if((ret = _jdb_changelog_parse_rm_typedef(
				entry, &rm_typedef)) < 0) return ret;
			return _jdb_changelog_run_rm_typedef(h,
				&rm_typedef);
			break;
		case JDB_CMD_ASSIGN_COLTYPE:
			if((ret = _jdb_changelog_parse_assign_coltype(
				entry, &assign_coltype)) < 0) return ret;
			return _jdb_changelog_run_assign_coltype(h,
				&assign_coltype);
			break;
		case JDB_CMD_RM_COLTYPE:
			if((ret = _jdb_changelog_parse_rm_coltype(
				entry, &rm_coltype)) < 0) return ret;
			return _jdb_changelog_run_rm_coltype(h,
				&rm_coltype);
			break;				
		case JDB_CMD_CREATE_CELL:
			if((ret = _jdb_changelog_parse_create_cell(
				entry, &create_cell)) < 0) return ret;
			return _jdb_changelog_run_create_cell(h,
				&create_cell);
			break;
		case JDB_CMD_RM_CELL:
			if((ret = _jdb_changelog_parse_rm_cell(
				entry, &rm_cell)) < 0) return ret;
			return _jdb_changelog_run_rm_cell(h,
				&rm_cell);
			break;
		case JDB_CMD_UPDATE_CELL:
			if((ret = _jdb_changelog_parse_update_cell(
				entry, &update_cell)) < 0) return ret;
			return _jdb_changelog_run_update_cell(h,
				&update_cell);
			break;
		
		default:
			return -JE_TYPE;
			break;
	}
		
	return 0;
}

static inline int _jdb_changelog_run_rec_cmd_list(struct jdb_handle* h, struct jdb_changelog_entry* first){
	struct jdb_changelog_entry* entry;
	int ret;
	
	for(entry = first; entry; entry = entry->next)
		if((ret = _jdb_changelog_run_rec_cmd(h, entry)) < 0) return ret;	
	
	return 0;
}

int _jdb_changelog_assm_rec(uchar** buf, size_t* busize, struct jdb_handle* h, uint64_t chid , uchar cmd, int ret, uchar nargs, size_t* argsize, ...){

	va_list ap;
	uchar n;
	size_t pos;	
	struct jdb_changelog_hdr hdr;
	
	*bufsize = sizeof(struct jdb_changelog_hdr);
	pos = *bufsize;
	for(n = 0; n < nargs; n++){
		*bufsize += argsize[n];
	}
	
	*buf = (uchar*)malloc(*bufsize);
	if(!(*buf)){
		return -JE_MALOC;
	}	
	
	va_start(ap, argsize);
	
	for(n = 0; n < nargs; n++){
			
		//copy data
		memcpy((*buf) + pos, va_arg(ap, uchar*), argsize[n]);
		pos += argsize[n];
		_wdeb_proc(L"pos = %u (after adding argsize[%u])", pos, n);
		
	}
	
	va_end(ap);
	
	hdr.recsize = *bufsize;	
	hdr.chid = chid;
	hdr.cmd = cmd;
	hdr.ret = ret;
	hdr.nargs = nargs;

	_wdeb_reg(L"recsize = %u, ret = %i, cmd = %u, chid = %llu, nargs = %u",
		hdr.recsize, hdr.ret, hdr.cmd, hdr.chid, hdr.nargs);
	
	_jdb_changelog_hdr_to_buf(&hdr, *buf);
	
	return 0;
	
}

int _jdb_changelog_reg(	struct jdb_handle* h, uint64_t chid , uchar cmd,
			int ret, uchar nargs, size_t* argsize, ...){
	va_list ap;
	uchar n;
	size_t bufsize;
	size_t pos;	
	uchar* buf;
	struct jdb_changelog_hdr hdr;	
	char fl;
	
	_wdeb_reg(L"registerning command 0x%x", cmd);
	
	if((h->hdr.flags & JDB_O_SNAP) || (h->hdr.flags & JDB_O_UNDO)){
		//store the previous record;
		switch(cmd){
			case JDB_CMD_RM_TABLE:
				break;
			case JDB_CMD_RM_TYPEDEF:
				break;
			case JDB_CMD_RM_COLTYPE:
				break;
			case JDB_CMD_RM_CELL:
				break;
			case JDB_CMD_UPDATE_CELL:
				break;														
			default:
				break;
		}
	}

	if(h->hdr.flags & JDB_O_JRNL){//JOURNALLING

	bufsize = sizeof(struct jdb_changelog_hdr);
	//if(nargs) bufsize += sizeof(uchar); //for nargs
	pos = bufsize;
	for(n = 0; n < nargs; n++){
		bufsize += argsize[n];
	}
	
	buf = (uchar*)malloc(bufsize);
	if(!buf){
		return -JE_MALOC;
	}	
	
	va_start(ap, argsize);
	
	for(n = 0; n < nargs; n++){
			
		//copy data
		memcpy(buf + pos, va_arg(ap, uchar*), argsize[n]);
		pos += argsize[n];
		_wdeb_proc(L"pos = %u (after adding argsize[%u])", pos, n);
		
	}
	
	va_end(ap);
	
	hdr.recsize = bufsize;	
	hdr.chid = chid;
	hdr.cmd = cmd;
	hdr.ret = ret;
	hdr.nargs = nargs;

	_wdeb_reg(L"recsize = %u, ret = %i, cmd = %u, chid = %llu, nargs = %u",
		hdr.recsize, hdr.ret, hdr.cmd, hdr.chid, hdr.nargs);
	
	//memcpy((void*)buf, (void*)&hdr, sizeof(struct jdb_changelog_hdr));
	
	_jdb_changelog_hdr_to_buf(&hdr, buf);
		
	//if(nargs) buf[sizeof(struct jdb_changelog_hdr)] = nargs;
	
	_jdb_jrnl_request_write(h, hdr.recsize, buf);
	
	}//end of if JOURNALLING
	
	
	return 0;
}

int _jdb_changelog_reg_end(struct jdb_handle* h, uint64_t chid, int ret){
	return _jdb_changelog_reg(h, chid, JDB_CMD_END, ret, 0, 0, 0, NULL);
}
